import process from 'node:process';globalThis._importMeta_={url:import.meta.url,env:process.env};import 'node:http';
import 'node:https';
export { ag as default } from './chunks/nitro/nitro.mjs';
import 'ioredis';
import 'fs';
import 'path';
import 'crypto';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'mysql2/promise';
import '@iconify/utils';
import 'consola';
//# sourceMappingURL=index.mjs.map
