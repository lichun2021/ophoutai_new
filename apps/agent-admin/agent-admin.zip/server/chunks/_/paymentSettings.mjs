import { s as sql } from '../nitro/nitro.mjs';
import 'ioredis';
import 'fs';
import 'path';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'mysql2/promise';
import '@iconify/utils';
import 'consola';

const GetOpenPaySetting = async () => {
  const result = await sql({
    query: "SELECT * FROM paymentsettings where isClose = 1"
  });
  return result;
};

export { GetOpenPaySetting };
//# sourceMappingURL=paymentSettings.mjs.map
