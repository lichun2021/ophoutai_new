import { D as getRedisCluster, s as sql } from '../nitro/nitro.mjs';

async function getByWorldId(worldId) {
  const cacheKey = `gameserver:world_${worldId}`;
  try {
    const redis = getRedisCluster();
    const cachedData = await redis.get(cacheKey);
    if (cachedData) {
      console.log(`[getByWorldId] Redis \u7F13\u5B58\u547D\u4E2D: world_id=${worldId}`);
      return JSON.parse(cachedData);
    }
    console.log(`[getByWorldId] Redis \u7F13\u5B58\u672A\u547D\u4E2D\uFF0C\u67E5\u8BE2\u6570\u636E\u5E93: world_id=${worldId}`);
  } catch (redisError) {
    console.warn(`[getByWorldId] Redis \u67E5\u8BE2\u5931\u8D25\uFF0C\u964D\u7EA7\u5230\u6570\u636E\u5E93\u67E5\u8BE2:`, redisError);
  }
  const rows = await sql({
    query: "SELECT id, server_id, name, webhost, dbip, bname, dbuser, dbpass, is_active, allow_cdk_redeem, count_online, created_at, updated_at FROM gameservers WHERE server_id = ? OR bname = ? OR name = ? LIMIT 1",
    values: [worldId, `game_${worldId}`, `game_${worldId}`]
  });
  if (rows.length > 0) {
    const serverConfig = rows[0];
    try {
      const redis = getRedisCluster();
      await redis.set(cacheKey, JSON.stringify(serverConfig), "EX", 3600);
      console.log(`[getByWorldId] \u5DF2\u7F13\u5B58\u5230 Redis: world_id=${worldId}, key=${cacheKey}`);
    } catch (redisError) {
      console.warn(`[getByWorldId] Redis \u7F13\u5B58\u5199\u5165\u5931\u8D25:`, redisError);
    }
    return serverConfig;
  }
  console.log(`[getByWorldId] \u6570\u636E\u5E93\u4E2D\u672A\u627E\u5230\u670D\u52A1\u5668\u914D\u7F6E: world_id=${worldId}`);
  return null;
}

const getGiftPackageById = async (id) => {
  const result = await sql({
    query: "SELECT * FROM externalgiftpackages WHERE id = ?",
    values: [id]
  });
  return result.length > 0 ? result[0] : null;
};
const getGiftPackageByCode = async (package_code) => {
  const result = await sql({
    query: "SELECT * FROM externalgiftpackages WHERE package_code = ?",
    values: [package_code]
  });
  return result.length > 0 ? result[0] : null;
};
const checkUserCanPurchase = async (thirdparty_uid, package_id, quantity = 1) => {
  console.log(`[\u9650\u8D2D\u68C0\u67E5] \u5F00\u59CB\u68C0\u67E5 - \u89D2\u8272UUID: ${thirdparty_uid}, \u793C\u5305ID: ${package_id}, \u6570\u91CF: ${quantity}`);
  const giftPackage = await getGiftPackageById(package_id);
  if (!giftPackage) {
    console.log(`[\u9650\u8D2D\u68C0\u67E5] \u5931\u8D25 - \u793C\u5305\u4E0D\u5B58\u5728`);
    return { canPurchase: false, reason: "\u793C\u5305\u4E0D\u5B58\u5728" };
  }
  console.log(`[\u9650\u8D2D\u68C0\u67E5] \u793C\u5305\u4FE1\u606F - \u540D\u79F0: ${giftPackage.package_name}, \u5206\u7C7B: ${giftPackage.category}, \u9650\u8D2D: ${giftPackage.max_per_user}`);
  if (!giftPackage.is_active) {
    console.log(`[\u9650\u8D2D\u68C0\u67E5] \u5931\u8D25 - \u793C\u5305\u5DF2\u4E0B\u67B6`);
    return { canPurchase: false, reason: "\u793C\u5305\u5DF2\u4E0B\u67B6" };
  }
  const now = /* @__PURE__ */ new Date();
  if (giftPackage.start_time && new Date(giftPackage.start_time) > now) {
    console.log(`[\u9650\u8D2D\u68C0\u67E5] \u5931\u8D25 - \u793C\u5305\u5C1A\u672A\u5F00\u59CB\u9500\u552E`);
    return { canPurchase: false, reason: "\u793C\u5305\u5C1A\u672A\u5F00\u59CB\u9500\u552E" };
  }
  if (giftPackage.end_time && new Date(giftPackage.end_time) < now) {
    console.log(`[\u9650\u8D2D\u68C0\u67E5] \u5931\u8D25 - \u793C\u5305\u9500\u552E\u5DF2\u7ED3\u675F`);
    return { canPurchase: false, reason: "\u793C\u5305\u9500\u552E\u5DF2\u7ED3\u675F" };
  }
  if (giftPackage.category === "scheduled" && giftPackage.available_weekdays) {
    const currentWeekday = now.getDay();
    const weekdayMap = currentWeekday === 0 ? 7 : currentWeekday;
    const availableDays = String(giftPackage.available_weekdays).split(",").map((d) => parseInt(d.trim()));
    console.log(`[\u9650\u8D2D\u68C0\u67E5] \u9650\u671F\u793C\u5305 - \u5F53\u524D\u661F\u671F: ${weekdayMap}, \u53EF\u8D2D\u4E70\u661F\u671F: [${availableDays.join(", ")}]`);
    if (!availableDays.includes(weekdayMap)) {
      const weekdayNames = ["", "\u5468\u4E00", "\u5468\u4E8C", "\u5468\u4E09", "\u5468\u56DB", "\u5468\u4E94", "\u5468\u516D", "\u5468\u65E5"];
      const availableNames = availableDays.map((d) => weekdayNames[d]).join("\u3001");
      console.log(`[\u9650\u8D2D\u68C0\u67E5] \u5931\u8D25 - \u4ECA\u65E5\u4E0D\u53EF\u8D2D\u4E70\u6B64\u793C\u5305`);
      return { canPurchase: false, reason: `\u8BE5\u793C\u5305\u4EC5\u5728${availableNames}\u53EF\u8D2D\u4E70` };
    }
    console.log(`[\u9650\u8D2D\u68C0\u67E5] \u901A\u8FC7 - \u4ECA\u65E5\u53EF\u8D2D\u4E70`);
  }
  if (giftPackage.is_limited && giftPackage.total_quantity && giftPackage.total_quantity > 0) {
    const remainingQuantity = giftPackage.total_quantity - (giftPackage.sold_quantity || 0);
    console.log(`[\u9650\u8D2D\u68C0\u67E5] \u5E93\u5B58\u68C0\u67E5 - \u603B\u91CF: ${giftPackage.total_quantity}, \u5DF2\u552E: ${giftPackage.sold_quantity}, \u5269\u4F59: ${remainingQuantity}`);
    if (remainingQuantity < quantity) {
      console.log(`[\u9650\u8D2D\u68C0\u67E5] \u5931\u8D25 - \u793C\u5305\u5E93\u5B58\u4E0D\u8DB3`);
      return { canPurchase: false, reason: "\u793C\u5305\u5E93\u5B58\u4E0D\u8DB3" };
    }
  }
  if (giftPackage.max_per_user && giftPackage.max_per_user > 0) {
    if (giftPackage.category === "daily_recharge") {
      console.log(`[\u9650\u8D2D\u68C0\u67E5] \u6BCF\u65E5\u5145\u503C\u793C\u5305 - \u5F00\u59CB\u67E5\u8BE2\u4ECA\u65E5\u8D2D\u4E70\u6B21\u6570`);
      const todayCount = await getUserPackagePurchaseCount(thirdparty_uid, package_id, { todayOnly: true });
      console.log(`[\u9650\u8D2D\u68C0\u67E5] \u4ECA\u65E5\u5DF2\u8D2D\u4E70: ${todayCount}\u6B21, \u9650\u8D2D: ${giftPackage.max_per_user}\u6B21, \u672C\u6B21\u8D2D\u4E70: ${quantity}\u6B21`);
      if (todayCount + quantity > giftPackage.max_per_user) {
        console.log(`[\u9650\u8D2D\u68C0\u67E5] \u5931\u8D25 - \u8D85\u8FC7\u6BCF\u65E5\u9650\u8D2D (${todayCount} + ${quantity} > ${giftPackage.max_per_user})`);
        return { canPurchase: false, reason: `\u6BCF\u65E5\u6700\u591A\u8D2D\u4E70${giftPackage.max_per_user}\u6B21` };
      }
      console.log(`[\u9650\u8D2D\u68C0\u67E5] \u901A\u8FC7 - \u672A\u8D85\u8FC7\u6BCF\u65E5\u9650\u8D2D`);
    } else {
      console.log(`[\u9650\u8D2D\u68C0\u67E5] \u666E\u901A\u793C\u5305 - \u5F00\u59CB\u67E5\u8BE2\u603B\u8D2D\u4E70\u6B21\u6570`);
      const userPurchaseCount = await getUserPackagePurchaseCount(thirdparty_uid, package_id);
      console.log(`[\u9650\u8D2D\u68C0\u67E5] \u603B\u5171\u5DF2\u8D2D\u4E70: ${userPurchaseCount}\u6B21, \u9650\u8D2D: ${giftPackage.max_per_user}\u6B21, \u672C\u6B21\u8D2D\u4E70: ${quantity}\u6B21`);
      if (userPurchaseCount + quantity > giftPackage.max_per_user) {
        console.log(`[\u9650\u8D2D\u68C0\u67E5] \u5931\u8D25 - \u8D85\u8FC7\u603B\u9650\u8D2D (${userPurchaseCount} + ${quantity} > ${giftPackage.max_per_user})`);
        return { canPurchase: false, reason: `\u6BCF\u7528\u6237\u6700\u591A\u8D2D\u4E70${giftPackage.max_per_user}\u4E2A` };
      }
      console.log(`[\u9650\u8D2D\u68C0\u67E5] \u901A\u8FC7 - \u672A\u8D85\u8FC7\u603B\u9650\u8D2D`);
    }
  } else {
    console.log(`[\u9650\u8D2D\u68C0\u67E5] \u65E0\u9650\u8D2D\u9650\u5236`);
  }
  console.log(`[\u9650\u8D2D\u68C0\u67E5] \u2705 \u901A\u8FC7 - \u5141\u8BB8\u8D2D\u4E70`);
  return { canPurchase: true, reason: "" };
};
const getUserPackagePurchaseCount = async (thirdparty_uid, package_id, options) => {
  var _a;
  const where = [
    "thirdparty_uid = ?",
    "package_id = ?",
    "status IN ('paid', 'delivered')"
  ];
  const values = [thirdparty_uid, package_id];
  if (options == null ? void 0 : options.todayOnly) {
    where.push("DATE(created_at) = CURDATE()");
  }
  const query = `SELECT SUM(quantity) as total FROM giftpackagepurchaserecords 
                WHERE ${where.join(" AND ")}`;
  console.log(`[\u8D2D\u4E70\u6B21\u6570\u67E5\u8BE2] SQL: ${query}, \u53C2\u6570: [${values.join(", ")}]`);
  const result = await sql({
    query,
    values
  });
  const count = parseInt(((_a = result[0]) == null ? void 0 : _a.total) || 0);
  console.log(`[\u8D2D\u4E70\u6B21\u6570\u67E5\u8BE2] \u7ED3\u679C: ${count}\u6B21, \u539F\u59CB\u6570\u636E: ${JSON.stringify(result[0])}`);
  return count;
};
const createPurchaseRecord = async (record) => {
  console.log(`[\u521B\u5EFA\u8D2D\u4E70\u8BB0\u5F55] \u5F00\u59CB\u521B\u5EFA - \u7528\u6237ID: ${record.user_id}, \u89D2\u8272UUID: ${record.thirdparty_uid}, \u5546\u6237\u8BA2\u5355\u53F7: ${record.mch_order_id || "\u65E0"}, \u793C\u5305ID: ${record.package_id}, \u793C\u5305\u540D: ${record.package_name}, \u6570\u91CF: ${record.quantity || 1}, \u72B6\u6001: ${record.status || "pending"}`);
  const safeQuantity = Math.max(1, Math.abs(record.quantity || 1));
  if (record.quantity !== safeQuantity) {
    console.error(`[\u521B\u5EFA\u8D2D\u4E70\u8BB0\u5F55] \u26A0\uFE0F \u68C0\u6D4B\u5230\u5F02\u5E38\u6570\u91CF: ${record.quantity}\uFF0C\u5DF2\u5F3A\u5236\u4FEE\u6B63\u4E3A: ${safeQuantity}`);
  }
  const safeTotalAmount = Math.abs(record.total_amount);
  const safeUnitPrice = Math.abs(record.unit_price);
  if (record.total_amount < 0 || record.unit_price < 0) {
    console.error(`[\u521B\u5EFA\u8D2D\u4E70\u8BB0\u5F55] \u26A0\uFE0F \u68C0\u6D4B\u5230\u8D1F\u6570\u91D1\u989D - \u539F\u59CB: ${record.total_amount}/${record.unit_price}\uFF0C\u5DF2\u4FEE\u6B63\u4E3A: ${safeTotalAmount}/${safeUnitPrice}`);
  }
  const result = await sql({
    query: `INSERT INTO giftpackagepurchaserecords 
                (user_id, thirdparty_uid, mch_order_id, package_id, package_code, package_name, quantity, 
                 unit_price, total_amount, balance_before, balance_after, gift_items, 
                 status, game_delivery_status, remark) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    values: [
      record.user_id,
      record.thirdparty_uid,
      record.mch_order_id || null,
      record.package_id,
      record.package_code,
      record.package_name,
      safeQuantity,
      // 使用安全验证后的数量
      safeUnitPrice,
      // 使用安全验证后的单价
      safeTotalAmount,
      // 使用安全验证后的总金额
      record.balance_before,
      record.balance_after,
      JSON.stringify(record.gift_items),
      record.status || "pending",
      record.game_delivery_status || "waiting",
      record.remark || ""
    ]
  });
  console.log(`[\u521B\u5EFA\u8D2D\u4E70\u8BB0\u5F55] \u2705 \u521B\u5EFA\u6210\u529F - \u8BB0\u5F55ID: ${result.insertId}`);
  return result;
};
const updatePackageSoldQuantity = async (package_id, quantity) => {
  const result = await sql({
    query: "UPDATE externalgiftpackages SET sold_quantity = sold_quantity + ? WHERE id = ?",
    values: [quantity, package_id]
  });
  return result;
};
const deliverPackageToGameViaIDIP = async (purchaseRecordId, serverId, roleId) => {
  var _a, _b;
  console.log(`[deliverPackageToGameViaIDIP] \u5F00\u59CB\u53D1\u653E\u793C\u5305, \u8D2D\u4E70\u8BB0\u5F55ID: ${purchaseRecordId}, \u670D\u52A1\u5668ID: ${serverId}, \u89D2\u8272ID: ${roleId}`);
  try {
    const purchaseRecord = await sql({
      query: "SELECT * FROM giftpackagepurchaserecords WHERE id = ?",
      values: [purchaseRecordId]
    });
    if (purchaseRecord.length === 0) {
      console.error(`[deliverPackageToGameViaIDIP] \u8D2D\u4E70\u8BB0\u5F55\u4E0D\u5B58\u5728, ID: ${purchaseRecordId}`);
      return { success: false, message: "\u8D2D\u4E70\u8BB0\u5F55\u4E0D\u5B58\u5728" };
    }
    const record = purchaseRecord[0];
    console.log(`[deliverPackageToGameViaIDIP] \u83B7\u53D6\u5230\u8D2D\u4E70\u8BB0\u5F55:`, JSON.stringify(record, null, 2));
    const giftPackage = await getGiftPackageById(record.package_id);
    if (!giftPackage || !giftPackage.gift_items) {
      console.error(`[deliverPackageToGameViaIDIP] \u793C\u5305\u914D\u7F6E\u4E0D\u5B58\u5728, \u793C\u5305ID: ${record.package_id}`);
      return { success: false, message: "\u793C\u5305\u914D\u7F6E\u4E0D\u5B58\u5728" };
    }
    console.log(`[deliverPackageToGameViaIDIP] \u83B7\u53D6\u5230\u793C\u5305\u914D\u7F6E:`, JSON.stringify(giftPackage, null, 2));
    let giftItems;
    try {
      if (typeof giftPackage.gift_items === "string") {
        giftItems = JSON.parse(giftPackage.gift_items);
      } else {
        giftItems = giftPackage.gift_items;
      }
    } catch (error) {
      console.error(`[deliverPackageToGameViaIDIP] \u89E3\u6790\u793C\u5305\u7269\u54C1\u5931\u8D25:`, error);
      giftItems = [];
    }
    const toNumber = (v) => {
      const n = Number(v);
      return Number.isFinite(n) ? n : NaN;
    };
    const sendItemList = Array.isArray(giftItems) ? giftItems.map((it) => {
      var _a2, _b2, _c, _d, _e, _f, _g, _h, _i, _j;
      const id = toNumber((_e = (_d = (_c = (_b2 = (_a2 = it == null ? void 0 : it.ItemId) != null ? _a2 : it == null ? void 0 : it.itemId) != null ? _b2 : it == null ? void 0 : it.id) != null ? _c : it == null ? void 0 : it.ItemID) != null ? _d : it == null ? void 0 : it.item_id) != null ? _e : it == null ? void 0 : it.i);
      const num = toNumber((_j = (_i = (_h = (_g = (_f = it == null ? void 0 : it.ItemNum) != null ? _f : it == null ? void 0 : it.itemNum) != null ? _g : it == null ? void 0 : it.num) != null ? _h : it == null ? void 0 : it.quantity) != null ? _i : it == null ? void 0 : it.count) != null ? _j : it == null ? void 0 : it.a);
      return { ItemId: id, ItemNum: num };
    }).filter((x) => Number.isFinite(x.ItemId) && x.ItemId > 0 && Number.isFinite(x.ItemNum) && x.ItemNum > 0) : [];
    if (sendItemList.length === 0) {
      await sql({
        query: 'UPDATE giftpackagepurchaserecords SET game_delivery_status = ?, remark = CONCAT(remark, " | \u53D1\u653E\u5931\u8D25: \u7269\u8D44\u5217\u8868\u4E3A\u7A7A\u6216\u65E0\u6548") WHERE id = ?',
        values: ["failed", purchaseRecordId]
      });
      return { success: false, message: "\u7269\u8D44\u5217\u8868\u4E3A\u7A7A\u6216\u65E0\u6548" };
    }
    await sql({
      query: "UPDATE giftpackagepurchaserecords SET game_delivery_status = ?, delivery_attempts = delivery_attempts + 1 WHERE id = ?",
      values: ["sent", purchaseRecordId]
    });
    const actualRoleId = record.thirdparty_uid || roleId || "";
    const gcRows = await sql({
      query: "SELECT subuser_id, server_id FROM gamecharacters WHERE uuid = ? LIMIT 1",
      values: [actualRoleId]
    });
    console.log(`[deliverPackageToGameViaIDIP] \u67E5\u8BE2\u89D2\u8272\u4FE1\u606F\u7ED3\u679C:`, gcRows);
    if (!gcRows || gcRows.length === 0) {
      const errorMsg = `\u672A\u627E\u5230\u89D2\u8272\u4FE1\u606F: uuid=${actualRoleId}`;
      console.error(`[deliverPackageToGameViaIDIP] ${errorMsg}`);
      await sql({
        query: 'UPDATE giftpackagepurchaserecords SET game_delivery_status = ?, remark = CONCAT(remark, " | ", ?) WHERE id = ?',
        values: ["failed", errorMsg, purchaseRecordId]
      });
      return { success: false, message: errorMsg };
    }
    const characterInfo = gcRows[0];
    const subUserId = characterInfo.subuser_id || record.user_id;
    const actualServerId = characterInfo.server_id || serverId;
    console.log(`[deliverPackageToGameViaIDIP] \u89D2\u8272UUID=${actualRoleId}, \u5B50\u8D26\u53F7ID=${subUserId}, \u670D\u52A1\u5668ID=${actualServerId}`);
    const worldId = Number(actualServerId);
    const serverCfg = await getByWorldId(worldId);
    if (!serverCfg || !serverCfg.webhost) {
      const errorMsg = `\u672A\u627E\u5230\u670D\u52A1\u5668\u914D\u7F6E: world_id=${actualServerId}`;
      console.error(`[deliverPackageToGameViaIDIP] ${errorMsg}`);
      await sql({
        query: 'UPDATE giftpackagepurchaserecords SET game_delivery_status = ?, remark = CONCAT(remark, " | ", ?) WHERE id = ?',
        values: ["failed", errorMsg, purchaseRecordId]
      });
      return { success: false, message: errorMsg };
    }
    console.log(`[deliverPackageToGameViaIDIP] \u627E\u5230\u670D\u52A1\u5668\u914D\u7F6E: name=${serverCfg.name}, webhost=${serverCfg.webhost}`);
    const rawBase = String(serverCfg.webhost || "").replace(/\/+$/, "");
    const baseURL = rawBase.includes("/script") ? rawBase : `${rawBase}/script`;
    const idipUrl = `${baseURL}/idip/4283`;
    const playerInfo = { openid: String(subUserId), platform: 1 };
    let platId = 1;
    const pf = playerInfo.platform;
    if (typeof pf === "string") ; else {
      platId = Number(pf) === 2 ? 2 : 1;
    }
    const serial = `${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const idipPayload = {
      head: {
        Cmdid: 4283,
        Seqid: "1",
        TimeStamp: Math.floor(Date.now() / 1e3)
      },
      body: {
        PlatId: platId,
        OpenId: String(playerInfo.openid),
        Partition: String(actualServerId),
        // 使用从角色表获取的 server_id
        RoleId: actualRoleId,
        // 使用购买记录中的 thirdparty_uid（角色UUID）
        Serial: serial,
        MailTitle: encodeURIComponent(giftPackage.package_name || "\u7CFB\u7EDF\u53D1\u653E"),
        MailContent: encodeURIComponent(`\u60A8\u8D2D\u4E70\u7684${giftPackage.package_name}\u5DF2\u5230\u8D26\uFF0C\u8BF7\u67E5\u6536\uFF01`),
        SendItemList: sendItemList
      }
    };
    console.log(`[deliverPackageToGameViaIDIP] IDIP URL: ${idipUrl}`);
    console.log(`[deliverPackageToGameViaIDIP] IDIP\u8BF7\u6C42Body:`, JSON.stringify(idipPayload.body, null, 2));
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 1e4);
    let respText = "";
    try {
      const response = await fetch(idipUrl, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(idipPayload),
        signal: controller.signal
      });
      console.log(`[deliverPackageToGameViaIDIP] HTTP\u72B6\u6001: ${response.status} ${response.statusText}`);
      respText = await response.text();
      clearTimeout(timeout);
      console.log(`[deliverPackageToGameViaIDIP] \u54CD\u5E94\u5185\u5BB9: ${respText}`);
    } catch (err) {
      clearTimeout(timeout);
      const errorMsg = (err == null ? void 0 : err.message) || String(err);
      const isTimeout = (err == null ? void 0 : err.name) === "AbortError" || errorMsg.includes("timeout") || errorMsg.includes("\u8D85\u65F6");
      const logMessage = isTimeout ? `\u8BF7\u6C42\u8D85\u65F6: ${errorMsg}` : `\u8BF7\u6C42\u5931\u8D25: ${errorMsg}`;
      console.error(`[deliverPackageToGameViaIDIP] ${logMessage}`);
      if (isTimeout) {
        await sql({
          query: 'UPDATE giftpackagepurchaserecords SET game_delivery_status = ?, remark = CONCAT(remark, " | ", ?) WHERE id = ?',
          values: ["sent", logMessage, purchaseRecordId]
        });
        return { success: false, message: logMessage, timeout: true };
      }
      await sql({
        query: 'UPDATE giftpackagepurchaserecords SET game_delivery_status = ?, remark = CONCAT(remark, " | ", ?) WHERE id = ?',
        values: ["failed", logMessage, purchaseRecordId]
      });
      return { success: false, message: logMessage, timeout: false };
    }
    let respData;
    try {
      respData = JSON.parse(respText);
    } catch {
      respData = { raw: respText };
    }
    await sql({
      query: "UPDATE giftpackagepurchaserecords SET game_delivery_data = ? WHERE id = ?",
      values: [JSON.stringify(respData), purchaseRecordId]
    });
    const resultCode = (_a = respData == null ? void 0 : respData.body) == null ? void 0 : _a.Result;
    if (resultCode === 0) {
      await sql({
        query: "UPDATE giftpackagepurchaserecords SET status = ?, game_delivery_status = ?, delivered_at = NOW() WHERE id = ?",
        values: ["delivered", "success", purchaseRecordId]
      });
      console.log(`[deliverPackageToGameViaIDIP] \u793C\u5305\u53D1\u653E\u6210\u529F: \u8BB0\u5F55ID=${purchaseRecordId}`);
      return { success: true, message: "\u53D1\u653E\u6210\u529F" };
    } else {
      const errMsg = ((_b = respData == null ? void 0 : respData.body) == null ? void 0 : _b.RetMsg) || "IDIP\u53D1\u653E\u5931\u8D25";
      await sql({
        query: 'UPDATE giftpackagepurchaserecords SET game_delivery_status = ?, remark = CONCAT(remark, " | \u53D1\u653E\u5931\u8D25: ", ?) WHERE id = ?',
        values: ["failed", errMsg, purchaseRecordId]
      });
      console.error(`[deliverPackageToGameViaIDIP] \u793C\u5305\u53D1\u653E\u5931\u8D25: \u8BB0\u5F55ID=${purchaseRecordId}, \u9519\u8BEF: ${errMsg}`);
      return { success: false, message: errMsg };
    }
  } catch (error) {
    console.error(`[deliverPackageToGameViaIDIP] \u53D1\u653E\u793C\u5305\u5F02\u5E38:`, error);
    await sql({
      query: 'UPDATE giftpackagepurchaserecords SET game_delivery_status = ?, remark = CONCAT(remark, " | \u53D1\u653E\u5F02\u5E38: ", ?) WHERE id = ?',
      values: ["failed", error.message, purchaseRecordId]
    });
    return { success: false, message: error.message };
  }
};

export { getGiftPackageByCode as a, createPurchaseRecord as b, checkUserCanPurchase as c, deliverPackageToGameViaIDIP as d, getByWorldId as e, getGiftPackageById as g, updatePackageSoldQuantity as u };
//# sourceMappingURL=externalGiftPackage.mjs.map
