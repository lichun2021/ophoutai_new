import { s as sql, g as getQuery, r as readBody, m as setResponseStatus, C as getSystemParam, K as getSystemConfig, d as defineEventHandler, D as getRedisCluster, L as pool, M as selectProviderBySystemParam, N as executePaymentBySystemParam, c as createError } from '../nitro/nitro.mjs';
import { g as getGiftPackageById, c as checkUserCanPurchase, b as createPurchaseRecord, u as updatePackageSoldQuantity, d as deliverPackageToGameViaIDIP, e as getByWorldId } from './externalGiftPackage.mjs';
import * as crypto from 'crypto';

const detailByTransId = async (transaction_id) => {
  const result = await sql({
    query: "SELECT * FROM paymentrecords WHERE transaction_id = ?",
    values: [transaction_id]
  });
  return result.length === 1 ? result[0] : null;
};
const detailByMchOrderId = async (mch_order_id) => {
  const result = await sql({
    query: "SELECT * FROM paymentrecords WHERE mch_order_id = ?",
    values: [mch_order_id]
  });
  return result.length === 1 ? result[0] : null;
};
const detailByUserId = async (user_id) => {
  const paymentdata = await sql({
    query: "SELECT * FROM paymentrecords WHERE user_id = ?",
    values: [user_id]
  });
  return paymentdata;
};
const getUserOrders = async (thirdparty_uid, status) => {
  let query = "SELECT * FROM paymentrecords WHERE user_id = ?";
  const values = [thirdparty_uid];
  query += " ORDER BY created_at DESC";
  const result = await sql({
    query,
    values
  });
  return result;
};
const updateOrderStatus = async (transaction_id, status, notify_at, callback_at, orderid) => {
  var _a, _b, _c;
  let query = "UPDATE paymentrecords SET payment_status = ?";
  const values = [status];
  if (orderid) {
    const existing = await sql({
      query: "SELECT mch_order_id, payment_status FROM paymentrecords WHERE transaction_id = ?",
      values: [transaction_id]
    });
    const current = ((_a = existing[0]) == null ? void 0 : _a.mch_order_id) || "";
    const statusNow = Number((_c = (_b = existing[0]) == null ? void 0 : _b.payment_status) != null ? _c : 0);
    const looksLocal = (v) => !v || v.startsWith("zfb_") || v.startsWith("wx_") || v.startsWith("ptb_") || v.startsWith("kf_");
    const allowOverwrite = statusNow <= 1 || looksLocal(current) || current === orderid;
    if (allowOverwrite) {
      query += ", mch_order_id = ?";
      values.push(orderid);
    }
  }
  if (notify_at !== null && notify_at !== void 0) {
    query += ", notify_at = ?";
    values.push(notify_at);
  }
  if (callback_at !== null && callback_at !== void 0) {
    query += ", callback_at = ?";
    values.push(callback_at);
  }
  query += " WHERE transaction_id = ?";
  values.push(transaction_id);
  await sql({
    query,
    values
  });
};
const getOrderStatus = async (transaction_id) => {
  try {
    const result = await sql({
      query: "SELECT payment_status FROM paymentrecords WHERE transaction_id = ?",
      values: [transaction_id]
    });
    if (result && result.length > 0) {
      return result[0].payment_status;
    } else {
      return 0;
    }
  } catch (error) {
    console.error("Failed to Get OrderStatus", error);
    return 0;
  }
};
const insert$3 = async (paymentData) => {
  const result = await sql({
    query: "INSERT INTO paymentrecords (user_id, sub_user_id, role_id, transaction_id, wuid, payment_way, payment_id, world_id, product_name, product_des, ip, amount, mch_order_id, msg, server_url, device, channel_code, game_code, payment_status, ptb_before, ptb_change, ptb_after) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
    values: [
      paymentData.user_id,
      paymentData.sub_user_id,
      // 保持null值，不转换为0
      paymentData.role_id || "",
      paymentData.transaction_id,
      paymentData.wuid,
      paymentData.payment_way,
      paymentData.payment_id || 0,
      paymentData.world_id || 1,
      paymentData.product_name,
      paymentData.product_des || "",
      paymentData.ip || "",
      paymentData.amount,
      paymentData.mch_order_id || "",
      paymentData.msg || "",
      paymentData.server_url || "",
      paymentData.device || "",
      paymentData.channel_code || "",
      paymentData.game_code || "",
      paymentData.payment_status || 0,
      paymentData.ptb_before || 0,
      paymentData.ptb_change || 0,
      paymentData.ptb_after || 0
    ]
  });
  return result;
};
const updateByTransactionId = async (transaction_id, updateData) => {
  var _a, _b, _c;
  let actualTransactionId = transaction_id;
  if (typeof transaction_id === "object" && transaction_id !== null && "attachInfo" in transaction_id) {
    actualTransactionId = transaction_id.attachInfo;
  }
  const fields = [];
  const values = [];
  if (updateData.user_id !== void 0) {
    fields.push("user_id = ?");
    values.push(updateData.user_id);
  }
  if (updateData.sub_user_id !== void 0) {
    fields.push("sub_user_id = ?");
    values.push(updateData.sub_user_id);
  }
  if (updateData.role_id !== void 0) {
    fields.push("role_id = ?");
    values.push(updateData.role_id);
  }
  if (updateData.wuid !== void 0) {
    fields.push("wuid = ?");
    values.push(updateData.wuid);
  }
  if (updateData.payment_way !== void 0) {
    fields.push("payment_way = ?");
    values.push(updateData.payment_way);
  }
  if (updateData.payment_id !== void 0) {
    fields.push("payment_id = ?");
    values.push(updateData.payment_id);
  }
  if (updateData.world_id !== void 0) {
    fields.push("world_id = ?");
    values.push(updateData.world_id);
  }
  if (updateData.product_name !== void 0) {
    fields.push("product_name = ?");
    values.push(updateData.product_name);
  }
  if (updateData.product_des !== void 0) {
    fields.push("product_des = ?");
    values.push(updateData.product_des);
  }
  if (updateData.ip !== void 0) {
    fields.push("ip = ?");
    values.push(updateData.ip);
  }
  if (updateData.amount !== void 0) {
    fields.push("amount = ?");
    values.push(updateData.amount);
  }
  if (updateData.ptb_before !== void 0) {
    fields.push("ptb_before = ?");
    values.push(updateData.ptb_before);
  }
  if (updateData.ptb_change !== void 0) {
    fields.push("ptb_change = ?");
    values.push(updateData.ptb_change);
  }
  if (updateData.ptb_after !== void 0) {
    fields.push("ptb_after = ?");
    values.push(updateData.ptb_after);
  }
  if (updateData.mch_order_id !== void 0) {
    const existing = await sql({
      query: "SELECT mch_order_id, payment_status FROM paymentrecords WHERE transaction_id = ?",
      values: [actualTransactionId]
    });
    const current = ((_a = existing[0]) == null ? void 0 : _a.mch_order_id) || "";
    const status = Number((_c = (_b = existing[0]) == null ? void 0 : _b.payment_status) != null ? _c : 0);
    const looksLocal = (v) => !v || v.startsWith("zfb_") || v.startsWith("wx_") || v.startsWith("ptb_") || v.startsWith("kf_");
    if (status <= 1 || looksLocal(current) || current === updateData.mch_order_id) {
      fields.push("mch_order_id = ?");
      values.push(updateData.mch_order_id);
    }
  }
  if (updateData.msg !== void 0) {
    fields.push("msg = ?");
    values.push(updateData.msg);
  }
  if (updateData.server_url !== void 0) {
    fields.push("server_url = ?");
    values.push(updateData.server_url);
  }
  if (updateData.device !== void 0) {
    fields.push("device = ?");
    values.push(updateData.device);
  }
  if (updateData.channel_code !== void 0) {
    fields.push("channel_code = ?");
    values.push(updateData.channel_code);
  }
  if (updateData.game_code !== void 0) {
    fields.push("game_code = ?");
    values.push(updateData.game_code);
  }
  if (updateData.payment_status !== void 0) {
    fields.push("payment_status = ?");
    values.push(updateData.payment_status);
  }
  if (updateData.notify_at !== void 0) {
    fields.push("notify_at = ?");
    values.push(updateData.notify_at);
  }
  if (updateData.callback_at !== void 0) {
    fields.push("callback_at = ?");
    values.push(updateData.callback_at);
  }
  if (fields.length === 0) {
    return;
  }
  values.push(actualTransactionId);
  await sql({
    query: `UPDATE paymentrecords SET ${fields.join(", ")} WHERE transaction_id = ?`,
    values
  });
};

const findByParentUserId = async (parent_user_id) => {
  const result = await sql({
    query: "SELECT * FROM subusers WHERE parent_user_id = ?",
    values: [parent_user_id]
  });
  return result;
};
const findByUsername = async (username) => {
  const result = await sql({
    query: "SELECT * FROM subusers WHERE username = ?",
    values: [username]
  });
  return result.length === 1 ? result[0] : null;
};
const findById$1 = async (id) => {
  const result = await sql({
    query: "SELECT * FROM subusers WHERE id = ?",
    values: [id]
  });
  return result.length === 1 ? result[0] : null;
};
const countByParentUserId = async (parent_user_id) => {
  const result = await sql({
    query: "SELECT COUNT(*) AS total FROM subusers WHERE parent_user_id = ?",
    values: [parent_user_id]
  });
  return result[0].total;
};
const read$2 = async () => {
  const subUsers = await sql({
    query: "SELECT * FROM subusers ORDER BY created_at DESC"
  });
  return subUsers;
};
const readPage$2 = async (pageIndex, pageSize = 10, parent_user_id) => {
  const offset = (pageIndex - 1) * pageSize;
  let _sql = {
    query: "SELECT * FROM subusers",
    values: []
  };
  if (parent_user_id) {
    _sql.query += " WHERE parent_user_id = ?";
    _sql.values.push(parent_user_id);
  }
  _sql.query += " ORDER BY created_at DESC LIMIT ?, ?";
  _sql.values.push(offset, pageSize);
  const subUsers = await sql(_sql);
  return subUsers;
};
const count$2 = async (parent_user_id) => {
  try {
    let _sql = {
      query: "SELECT COUNT(*) AS total FROM subusers",
      values: []
    };
    if (parent_user_id) {
      _sql.query += " WHERE parent_user_id = ?";
      _sql.values.push(parent_user_id);
    }
    const result = await sql(_sql);
    const rows = result;
    return rows[0].total;
  } catch (error) {
    console.error("Failed to count SubUsers:", error);
    return 0;
  }
};
const insert$2 = async (subUserData) => {
  const result = await sql({
    query: "INSERT INTO subusers (parent_user_id, username, wuid) VALUES (?, ?, ?)",
    values: [subUserData.parent_user_id, subUserData.username, subUserData.wuid || ""]
  });
  return result;
};
const update$1 = async (id, subUserData) => {
  const fields = [];
  const values = [];
  if (subUserData.parent_user_id !== void 0) {
    fields.push("parent_user_id = ?");
    values.push(subUserData.parent_user_id);
  }
  if (subUserData.username !== void 0) {
    fields.push("username = ?");
    values.push(subUserData.username);
  }
  if (subUserData.wuid !== void 0) {
    fields.push("wuid = ?");
    values.push(subUserData.wuid);
  }
  if (fields.length > 0) {
    values.push(id);
    await sql({
      query: `UPDATE subusers SET ${fields.join(", ")} WHERE id = ?`,
      values
    });
  }
};
const remove$2 = async (id) => {
  await sql({
    query: "DELETE FROM subusers WHERE id = ?",
    values: [id]
  });
};
const removeByParentUserId = async (parent_user_id) => {
  await sql({
    query: "DELETE FROM subusers WHERE parent_user_id = ?",
    values: [parent_user_id]
  });
};
const updateWuidByThirdpartyUid = async (thirdparty_uid, uid) => {
  try {
    const subUserResult = await sql({
      query: "SELECT id FROM subusers WHERE id = ?",
      values: [thirdparty_uid]
    });
    if (subUserResult.length === 0) {
      return {
        success: false,
        message: "\u6CE8\u518C\u5931\u8D25\uFF1A\u672A\u627E\u5230\u5BF9\u5E94\u7684\u5B50\u8D26\u53F7"
      };
    }
    await sql({
      query: "UPDATE subusers SET wuid = ? WHERE id = ?",
      values: [uid, thirdparty_uid]
    });
    return {
      success: true,
      message: "\u6CE8\u518C\u6210\u529F"
    };
  } catch (error) {
    console.error("\u66F4\u65B0\u5B50\u7528\u6237wuid\u5931\u8D25:", error);
    return {
      success: false,
      message: "\u6CE8\u518C\u5931\u8D25\uFF1A\u7CFB\u7EDF\u9519\u8BEF"
    };
  }
};

const subUsers = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  count: count$2,
  countByParentUserId: countByParentUserId,
  findById: findById$1,
  findByParentUserId: findByParentUserId,
  findByUsername: findByUsername,
  insert: insert$2,
  read: read$2,
  readPage: readPage$2,
  remove: remove$2,
  removeByParentUserId: removeByParentUserId,
  update: update$1,
  updateWuidByThirdpartyUid: updateWuidByThirdpartyUid
}, Symbol.toStringTag, { value: 'Module' }));

const findById = async (id) => {
  const result = await sql({
    query: "SELECT * FROM users WHERE id = ?",
    values: [id]
  });
  return result.length === 1 ? result[0] : null;
};
const findByThirdpartyUid = async (thirdparty_uid) => {
  const result = await sql({
    query: "SELECT * FROM users WHERE thirdparty_uid = ?",
    values: [thirdparty_uid]
  });
  return result.length === 1 ? result[0] : null;
};
const login = async (username, password) => {
  try {
    const result = await sql({
      query: "SELECT * FROM users WHERE username = ? AND password = ?",
      values: [username, password]
    });
    return result.length === 1 ? result[0] : null;
  } catch (error) {
    console.error("\u7528\u6237\u767B\u5F55\u67E5\u8BE2\u5931\u8D25:", error);
    return null;
  }
};
const upsertUserByThirdparty = async (thirdparty_uid, access_token, sign, channel) => {
  const existingUser = await findByThirdpartyUid(thirdparty_uid);
  if (existingUser) {
    await sql({
      query: "UPDATE users SET access_token = ? WHERE thirdparty_uid = ?",
      values: [access_token, thirdparty_uid]
    });
    return { ...existingUser, access_token };
  } else {
    const result = await sql({
      query: `INSERT INTO users 
                (username, iphone, password, channel_code, thirdparty_uid, platform_coins, status, created_at) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      values: [
        `user_${thirdparty_uid.substring(0, 8)}`,
        // 生成默认用户名
        "",
        // 默认空手机号
        "",
        // 默认空密码
        channel,
        // 渠道代码
        thirdparty_uid,
        0,
        // 默认平台币余额
        0
        // 默认状态：0=正常
      ]
    });
    console.log("upsertUserByThirdparty result:", result);
    return {
      code: 200,
      msg: "\u7528\u6237\u521B\u5EFA\u6210\u529F"
    };
  }
};
const detailByUserID = async (thirdparty_uid) => {
  let _sql = {
    query: "SELECT * FROM users WHERE thirdparty_uid = ? ",
    values: [thirdparty_uid]
  };
  console.log("detailByUserID _sql:", _sql);
  const result = await sql(_sql);
  return result.length > 0 ? result[0] : null;
};
const detail = async (mob, pwd) => {
  const result = await sql({
    query: "SELECT * FROM users WHERE iphone = ? and password = ?",
    values: [mob, pwd]
  });
  return result.length === 1 ? result[0] : null;
};
const read$1 = async () => {
  const users = await sql({
    query: "SELECT * FROM users"
  });
  return users;
};
const readPage$1 = async (pageIndex, permissions, mobile, start_time, end_time, userid) => {
  const pageSize = 10;
  const offset = (pageIndex - 1) * pageSize;
  let _sql = {
    query: "SELECT * FROM users ",
    values: []
  };
  let where = false;
  if (permissions && permissions.channel_codes && permissions.channel_codes.length > 0) {
    if (!where) {
      _sql.query += " WHERE ";
      where = true;
    }
    _sql.query += " channel_code IN (" + permissions.channel_codes.map(() => "?").join(",") + ")";
    permissions.channel_codes.forEach((code) => _sql.values.push(code));
  }
  if (mobile) {
    if (!where) {
      _sql.query += " WHERE ";
      where = true;
    } else {
      _sql.query += " AND ";
    }
    _sql.query += " iphone = ?";
    _sql.values.push(mobile);
  }
  if (userid) {
    if (!where) {
      _sql.query += " WHERE ";
      where = true;
    } else {
      _sql.query += " AND ";
    }
    _sql.query += " thirdparty_uid = ?";
    _sql.values.push(userid);
  }
  if (start_time && end_time) {
    if (!where) {
      _sql.query += " WHERE ";
      where = true;
    } else {
      _sql.query += " AND ";
    }
    _sql.query += " timestamp(created_at) between ? and ?";
    _sql.values.push(start_time);
    _sql.values.push(end_time);
  }
  _sql.query += " ORDER BY created_at DESC";
  _sql.query += " LIMIT ?, ?";
  _sql.values.push(offset);
  _sql.values.push(pageSize);
  console.log("readPage User sql:", _sql);
  const users = await sql(_sql);
  return users;
};
const getchannel = async (userId) => {
  let _sql = {
    query: "SELECT channel_code FROM users where id = ?",
    values: [userId]
  };
  const result = await sql(_sql);
  console.log("getchannel:", _sql);
  return result.length === 1 ? result[0].channel_code : "";
};
const count$1 = async (permissions, mobile, start_time, end_time, userid) => {
  try {
    let _sql = {
      query: "SELECT COUNT(*) AS total FROM users",
      values: []
    };
    let where = false;
    if (permissions && permissions.channel_codes && permissions.channel_codes.length > 0) {
      if (!where) {
        _sql.query += " WHERE ";
        where = true;
      }
      _sql.query += " channel_code IN (" + permissions.channel_codes.map(() => "?").join(",") + ")";
      permissions.channel_codes.forEach((code) => _sql.values.push(code));
    }
    if (mobile) {
      if (!where) {
        _sql.query += " WHERE ";
        where = true;
      } else {
        _sql.query += " AND ";
      }
      _sql.query += " iphone = ?";
      _sql.values.push(mobile);
    }
    if (userid) {
      if (!where) {
        _sql.query += " WHERE ";
        where = true;
      } else {
        _sql.query += " AND ";
      }
      _sql.query += " thirdparty_uid = ?";
      _sql.values.push(userid);
    }
    if (start_time && end_time) {
      if (!where) {
        _sql.query += " WHERE ";
        where = true;
      } else {
        _sql.query += " AND ";
      }
      _sql.query += " timestamp(created_at) between ? and ?";
      _sql.values.push(start_time);
      _sql.values.push(end_time);
    }
    const result = await sql(_sql);
    const rows = result;
    return rows[0].total;
  } catch (error) {
    console.error("Failed to count users:", error);
    return 0;
  }
};
const updatePhone = async (id, data) => {
  await sql({
    query: "UPDATE users SET iphone = ? WHERE id = ?",
    values: [data.iphone, id]
  });
};
const updateByUserId = async (userData) => {
  await sql({
    query: "UPDATE users SET username = ? , iphone = ? , password = ?, channel_code = ?, game_code = ?, platform_coins = ?  WHERE thirdparty_uid = ?",
    values: [userData.username, userData.iphone, userData.password, userData.channel_code, userData.game_code, userData.platform_coins, userData.thirdparty_uid]
  });
};
const remove$1 = async (id) => {
  await sql({
    query: "DELETE FROM users WHERE id = ?",
    values: [id]
  });
};
const insert$1 = async (userData) => {
  try {
    await sql({
      query: "START TRANSACTION",
      values: []
    });
    const userResult = await sql({
      query: "INSERT INTO users (username, iphone, password, channel_code, game_code, thirdparty_uid, platform_coins, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
      values: [userData.username, userData.iphone, userData.password, userData.channel_code, userData.game_code, userData.thirdparty_uid, userData.platform_coins || 0, userData.status || 0]
    });
    const userId = userResult.insertId;
    const subUserData = {
      parent_user_id: userId,
      username: "\u5C0F\u53F71_\u5C0F\u53F71"
    };
    await insert$2(subUserData);
    await sql({
      query: "COMMIT",
      values: []
    });
    return userResult;
  } catch (error) {
    try {
      await sql({
        query: "ROLLBACK",
        values: []
      });
    } catch (rollbackError) {
      console.error("\u56DE\u6EDA\u4E8B\u52A1\u5931\u8D25:", rollbackError);
    }
    console.error("\u521B\u5EFA\u7528\u6237\u548C\u5B50\u7528\u6237\u5931\u8D25:", error);
    throw error;
  }
};
const getPlatformCoins = async (user_id) => {
  const result = await sql({
    query: "SELECT platform_coins FROM users WHERE id = ?",
    values: [user_id]
  });
  return result.length > 0 ? parseFloat(result[0].platform_coins) : 0;
};
const getPlatformCoinsByThirdpartyUid = async (thirdparty_uid) => {
  const result = await sql({
    query: "SELECT platform_coins FROM users WHERE thirdparty_uid = ?",
    values: [thirdparty_uid]
  });
  return result.length > 0 ? parseFloat(result[0].platform_coins) : 0;
};
const updatePlatformCoinsUnified = async (userId, amount, operationType) => {
  const operationNames = {
    1: "\u6E38\u620F\u5185\u8D2D\u6263\u6B3E",
    2: "\u7B2C\u4E09\u65B9\u5145\u503C\u5230\u8D26",
    3: "\u6536\u94F6\u53F0\u5145\u503C\u5230\u8D26",
    4: "\u652F\u4ED8\u67E5\u8BE2\u8865\u5355",
    5: "\u7BA1\u7406\u5458\u53D1\u653E",
    6: "\u793C\u5305\u5931\u8D25\u9000\u6B3E",
    7: "\u793C\u5305\u5F02\u5E38\u9000\u6B3E"
  };
  console.log(`[\u5E73\u53F0\u5E01\u64CD\u4F5C] userId=${userId}, amount=${amount}, operationType=${operationType}(${operationNames[operationType]})`);
  try {
    const oldBalance = await getPlatformCoins(userId);
    if (amount < 0 && oldBalance < Math.abs(amount)) {
      console.log(`[\u5E73\u53F0\u5E01\u64CD\u4F5C\u5931\u8D25] userId=${userId}, \u4F59\u989D\u4E0D\u8DB3: \u5F53\u524D=${oldBalance}, \u9700\u8981=${Math.abs(amount)}`);
      return { success: false, message: "\u5E73\u53F0\u5E01\u4F59\u989D\u4E0D\u8DB3", oldBalance };
    }
    const newBalance = oldBalance + amount;
    await sql({
      query: "UPDATE users SET platform_coins = ? WHERE id = ?",
      values: [newBalance, userId]
    });
    console.log(`[\u5E73\u53F0\u5E01\u64CD\u4F5C\u6210\u529F] userId=${userId}, \u65E7\u4F59\u989D=${oldBalance}, \u53D8\u52A8=${amount}, \u65B0\u4F59\u989D=${newBalance}`);
    return { success: true, newBalance, oldBalance };
  } catch (error) {
    console.error(`[\u5E73\u53F0\u5E01\u64CD\u4F5C\u5F02\u5E38] userId=${userId}, amount=${amount}, operationType=${operationType}`, error);
    return { success: false, message: "\u5E73\u53F0\u5E01\u64CD\u4F5C\u5931\u8D25" };
  }
};
const updateUserStatus = async (user_id, status) => {
  try {
    if (status !== 0 && status !== 1) {
      return { success: false, message: "\u72B6\u6001\u503C\u65E0\u6548\uFF0C\u53EA\u80FD\u662F0\uFF08\u6B63\u5E38\uFF09\u62161\uFF08\u5C01\u53F7\uFF09" };
    }
    const user = await findById(user_id);
    if (!user) {
      return { success: false, message: "\u7528\u6237\u4E0D\u5B58\u5728" };
    }
    await sql({
      query: "UPDATE users SET status = ? WHERE id = ?",
      values: [status, user_id]
    });
    return {
      success: true,
      message: status === 1 ? "\u7528\u6237\u5DF2\u5C01\u53F7" : "\u7528\u6237\u5DF2\u89E3\u5C01"
    };
  } catch (error) {
    console.error("\u66F4\u65B0\u7528\u6237\u72B6\u6001\u5931\u8D25:", error);
    return { success: false, message: "\u66F4\u65B0\u7528\u6237\u72B6\u6001\u5931\u8D25" };
  }
};
const updateUserStatusByThirdpartyUid = async (thirdparty_uid, status) => {
  try {
    if (status !== 0 && status !== 1) {
      return { success: false, message: "\u72B6\u6001\u503C\u65E0\u6548\uFF0C\u53EA\u80FD\u662F0\uFF08\u6B63\u5E38\uFF09\u62161\uFF08\u5C01\u53F7\uFF09" };
    }
    const user = await findByThirdpartyUid(thirdparty_uid);
    if (!user) {
      return { success: false, message: "\u7528\u6237\u4E0D\u5B58\u5728" };
    }
    return await updateUserStatus(user.id, status);
  } catch (error) {
    console.error("\u66F4\u65B0\u7528\u6237\u72B6\u6001\u5931\u8D25:", error);
    return { success: false, message: "\u66F4\u65B0\u7528\u6237\u72B6\u6001\u5931\u8D25" };
  }
};
const checkUserStatus = async (user_id) => {
  try {
    const result = await sql({
      query: "SELECT status FROM users WHERE id = ?",
      values: [user_id]
    });
    if (result.length === 0) {
      return { isBanned: false, status: 0 };
    }
    const status = parseInt(result[0].status) || 0;
    return { isBanned: status === 1, status };
  } catch (error) {
    console.error("\u68C0\u67E5\u7528\u6237\u72B6\u6001\u5931\u8D25:", error);
    return { isBanned: false, status: 0 };
  }
};
const checkUserStatusByThirdpartyUid = async (thirdparty_uid) => {
  try {
    const result = await sql({
      query: "SELECT status FROM users WHERE thirdparty_uid = ?",
      values: [thirdparty_uid]
    });
    if (result.length === 0) {
      return { isBanned: false, status: 0 };
    }
    const status = parseInt(result[0].status) || 0;
    return { isBanned: status === 1, status };
  } catch (error) {
    console.error("\u68C0\u67E5\u7528\u6237\u72B6\u6001\u5931\u8D25:", error);
    return { isBanned: false, status: 0 };
  }
};

const user = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  checkUserStatus: checkUserStatus,
  checkUserStatusByThirdpartyUid: checkUserStatusByThirdpartyUid,
  count: count$1,
  detail: detail,
  detailByUserID: detailByUserID,
  findById: findById,
  findByThirdpartyUid: findByThirdpartyUid,
  getPlatformCoins: getPlatformCoins,
  getPlatformCoinsByThirdpartyUid: getPlatformCoinsByThirdpartyUid,
  getchannel: getchannel,
  insert: insert$1,
  login: login,
  read: read$1,
  readPage: readPage$1,
  remove: remove$1,
  updateByUserId: updateByUserId,
  updatePhone: updatePhone,
  updatePlatformCoinsUnified: updatePlatformCoinsUnified,
  updateUserStatus: updateUserStatus,
  updateUserStatusByThirdpartyUid: updateUserStatusByThirdpartyUid,
  upsertUserByThirdparty: upsertUserByThirdparty
}, Symbol.toStringTag, { value: 'Module' }));

const findByUuid = async (uuid) => {
  const result = await sql({
    query: "SELECT * FROM gamecharacters WHERE uuid = ? LIMIT 1",
    values: [uuid]
  });
  return result.length > 0 ? result[0] : null;
};
const findByUserId = async (user_id) => {
  const result = await sql({
    query: "SELECT * FROM gamecharacters WHERE user_id = ? ORDER BY created_at DESC",
    values: [user_id]
  });
  return result;
};
const findBySubUserId = async (subuser_id) => {
  const result = await sql({
    query: "SELECT * FROM gamecharacters WHERE subuser_id = ? ORDER BY created_at DESC",
    values: [subuser_id]
  });
  return result;
};
const findByGameId = async (game_id) => {
  const result = await sql({
    query: "SELECT * FROM gamecharacters WHERE game_id = ? ORDER BY created_at DESC",
    values: [game_id]
  });
  return result;
};
const findByUserAndGame = async (user_id, game_id) => {
  const result = await sql({
    query: "SELECT * FROM gamecharacters WHERE user_id = ? AND game_id = ? ORDER BY created_at DESC",
    values: [user_id, game_id]
  });
  return result;
};
const findBySubUserAndGame = async (subuser_id, game_id) => {
  const result = await sql({
    query: "SELECT * FROM gamecharacters WHERE subuser_id = ? AND game_id = ? ORDER BY created_at DESC",
    values: [subuser_id, game_id]
  });
  return result;
};
const read = async () => {
  const characters = await sql({
    query: "SELECT * FROM gamecharacters ORDER BY created_at DESC"
  });
  return characters;
};
const readPage = async (pageIndex, pageSize = 10, user_id, subuser_id, game_id) => {
  const offset = (pageIndex - 1) * pageSize;
  let _sql = {
    query: "SELECT * FROM gamecharacters",
    values: []
  };
  const conditions = [];
  if (user_id !== void 0) {
    conditions.push("user_id = ?");
    _sql.values.push(user_id);
  }
  if (subuser_id !== void 0) {
    conditions.push("subuser_id = ?");
    _sql.values.push(subuser_id);
  }
  if (game_id !== void 0) {
    conditions.push("game_id = ?");
    _sql.values.push(game_id);
  }
  if (conditions.length > 0) {
    _sql.query += " WHERE " + conditions.join(" AND ");
  }
  _sql.query += " ORDER BY created_at DESC LIMIT ?, ?";
  _sql.values.push(offset, pageSize);
  const characters = await sql(_sql);
  return characters;
};
const count = async (user_id, subuser_id, game_id) => {
  try {
    let _sql = {
      query: "SELECT COUNT(*) AS total FROM gamecharacters",
      values: []
    };
    const conditions = [];
    if (user_id !== void 0) {
      conditions.push("user_id = ?");
      _sql.values.push(user_id);
    }
    if (subuser_id !== void 0) {
      conditions.push("subuser_id = ?");
      _sql.values.push(subuser_id);
    }
    if (game_id !== void 0) {
      conditions.push("game_id = ?");
      _sql.values.push(game_id);
    }
    if (conditions.length > 0) {
      _sql.query += " WHERE " + conditions.join(" AND ");
    }
    const result = await sql(_sql);
    const rows = result;
    return rows[0].total;
  } catch (error) {
    console.error("Failed to count GameCharacters:", error);
    return 0;
  }
};
const normalizeExtData = (ext) => {
  if (!ext) return null;
  if (typeof ext === "object") {
    return JSON.stringify(ext);
  } else if (typeof ext === "string") {
    try {
      JSON.parse(ext);
      return ext;
    } catch {
      return JSON.stringify({ value: ext });
    }
  }
  return null;
};
const insert = async (characterData) => {
  const extData = normalizeExtData(characterData.ext);
  const result = await sql({
    query: "INSERT INTO gamecharacters (user_id, subuser_id, game_id, uuid, character_name, character_level, server_name, server_id, ext, last_login_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
    values: [
      characterData.user_id,
      characterData.subuser_id,
      characterData.game_id,
      characterData.uuid,
      characterData.character_name,
      characterData.character_level || 1,
      characterData.server_name,
      characterData.server_id || 1,
      extData,
      characterData.last_login_at || null
    ]
  });
  return result;
};
const upsertByUuid = async (characterData) => {
  try {
    const extData = normalizeExtData(characterData.ext);
    const characterLevel = characterData.character_level || 1;
    const existingResult = await sql({
      query: "SELECT id, server_id, server_name FROM gamecharacters WHERE subuser_id = ? AND uuid = ? LIMIT 1",
      values: [characterData.subuser_id, characterData.uuid]
    });
    if (existingResult.length > 0) {
      const existingId = existingResult[0].id;
      await sql({
        query: `
                    UPDATE gamecharacters 
                    SET 
                        character_name = ?, 
                        character_level = ?, 
                        ext = ?, 
                        last_login_at = NOW() 
                    WHERE id = ?
                `,
        values: [
          characterData.character_name,
          characterLevel,
          extData,
          existingId
        ]
      });
      console.log(`\u89D2\u8272\u4E0A\u62A5\u6210\u529F: \u66F4\u65B0\u4FE1\u606F uuid=${characterData.uuid}, \u670D\u52A1\u5668ID=${existingResult[0].server_id}`);
      return { isNew: false, id: existingId };
    } else {
      const result = await sql({
        query: `
                    INSERT INTO gamecharacters 
                    (user_id, subuser_id, game_id, uuid, character_name, character_level, server_name, server_id, ext, last_login_at) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
                `,
        values: [
          characterData.user_id,
          characterData.subuser_id,
          characterData.game_id,
          characterData.uuid,
          characterData.character_name,
          characterLevel,
          characterData.server_name,
          characterData.server_id || 1,
          extData
        ]
      });
      const id = result.insertId || result.lastInsertId;
      console.log(`\u89D2\u8272\u4E0A\u62A5\u6210\u529F: \u65B0\u5EFA\u89D2\u8272 uuid=${characterData.uuid}, \u670D\u52A1\u5668ID=${characterData.server_id || 1}`);
      return { isNew: true, id };
    }
  } catch (error) {
    console.error("\u89D2\u8272\u4E0A\u62A5\u5931\u8D25:", error);
    throw error;
  }
};
const update = async (id, characterData) => {
  const fields = [];
  const values = [];
  if (characterData.user_id !== void 0) {
    fields.push("user_id = ?");
    values.push(characterData.user_id);
  }
  if (characterData.subuser_id !== void 0) {
    fields.push("subuser_id = ?");
    values.push(characterData.subuser_id);
  }
  if (characterData.game_id !== void 0) {
    fields.push("game_id = ?");
    values.push(characterData.game_id);
  }
  if (characterData.uuid !== void 0) {
    fields.push("uuid = ?");
    values.push(characterData.uuid);
  }
  if (characterData.character_name !== void 0) {
    fields.push("character_name = ?");
    values.push(characterData.character_name);
  }
  if (characterData.character_level !== void 0) {
    fields.push("character_level = ?");
    values.push(characterData.character_level);
  }
  if (characterData.server_name !== void 0) {
    fields.push("server_name = ?");
    values.push(characterData.server_name);
  }
  if (characterData.server_id !== void 0) {
    fields.push("server_id = ?");
    values.push(characterData.server_id);
  }
  if (characterData.ext !== void 0) {
    const extData = typeof characterData.ext === "object" ? JSON.stringify(characterData.ext) : characterData.ext;
    fields.push("ext = ?");
    values.push(extData);
  }
  if (characterData.last_login_at !== void 0) {
    fields.push("last_login_at = ?");
    values.push(characterData.last_login_at);
  }
  if (fields.length > 0) {
    values.push(id);
    await sql({
      query: `UPDATE gamecharacters SET ${fields.join(", ")} WHERE id = ?`,
      values
    });
  }
};
const updateLastLogin = async (id, last_login_at) => {
  await sql({
    query: "UPDATE gamecharacters SET last_login_at = ? WHERE id = ?",
    values: [last_login_at, id]
  });
};
const updateLevel = async (id, character_level) => {
  await sql({
    query: "UPDATE gamecharacters SET character_level = ? WHERE id = ?",
    values: [character_level, id]
  });
};
const remove = async (id) => {
  await sql({
    query: "DELETE FROM gamecharacters WHERE id = ?",
    values: [id]
  });
};
const removeByUserId = async (user_id) => {
  await sql({
    query: "DELETE FROM gamecharacters WHERE user_id = ?",
    values: [user_id]
  });
};
const removeBySubUserId = async (subuser_id) => {
  await sql({
    query: "DELETE FROM gamecharacters WHERE subuser_id = ?",
    values: [subuser_id]
  });
};

const gameCharacters = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  count: count,
  findByGameId: findByGameId,
  findBySubUserAndGame: findBySubUserAndGame,
  findBySubUserId: findBySubUserId,
  findByUserAndGame: findByUserAndGame,
  findByUserId: findByUserId,
  findByUuid: findByUuid,
  insert: insert,
  read: read,
  readPage: readPage,
  remove: remove,
  removeBySubUserId: removeBySubUserId,
  removeByUserId: removeByUserId,
  update: update,
  updateLastLogin: updateLastLogin,
  updateLevel: updateLevel,
  upsertByUuid: upsertByUuid
}, Symbol.toStringTag, { value: 'Module' }));

function normalizeIPAddress(ip) {
  if (!ip) return "127.0.0.1";
  if (ip.startsWith("::ffff:")) {
    return ip.substring(7);
  }
  if (ip === "::1") {
    return "127.0.0.1";
  }
  const ipv4Regex = /^(\d{1,3}\.){3}\d{1,3}$/;
  if (ipv4Regex.test(ip)) {
    return ip;
  }
  return "127.0.0.1";
}
function getCurrentFormattedTime() {
  const date = /* @__PURE__ */ new Date();
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  const hours = String(date.getHours()).padStart(2, "0");
  const minutes = String(date.getMinutes()).padStart(2, "0");
  const seconds = String(date.getSeconds()).padStart(2, "0");
  return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
}
defineEventHandler(async (event) => {
  var _a, _b;
  try {
    const tranId = (_b = (_a = event.context.params) == null ? void 0 : _a.tranId) != null ? _b : "";
    var _status = await getOrderStatus(tranId);
    if (_status == 3) {
      const currentTime = getCurrentFormattedTime();
      await updateOrderStatus(tranId, 3, null, currentTime);
    }
    return _status;
  } catch (e) {
    return -1;
  }
});
async function notifyGameServer(transactionId, wuid, serverUrl, gameServerUrl, worldId) {
  try {
    let port = "";
    let preferredBaseUrl = "";
    if (typeof serverUrl === "string" && (serverUrl.startsWith("http://") || serverUrl.startsWith("https://"))) {
      try {
        const urlObj = new URL(serverUrl);
        port = urlObj.port || "";
      } catch (error) {
        console.error("URL \u89E3\u6790\u5931\u8D25:", serverUrl, error);
      }
    } else if (serverUrl) {
      port = String(serverUrl || "");
    }
    const requestData = {
      transactionId,
      uid: wuid,
      port
    };
    const systemConfig = await getSystemConfig();
    if (worldId && Number(worldId) > 0) {
      try {
        const serverCfg = await getByWorldId(Number(worldId));
        if (serverCfg && serverCfg.webhost) {
          const base = serverCfg.webhost.replace(/\/$/, "");
          preferredBaseUrl = `${base}/update_pay_status`;
          try {
            const u = new URL(serverCfg.webhost);
            if (!port) port = u.port || "";
          } catch {
          }
        }
      } catch (e) {
        console.warn("\u6309 worldId \u67E5\u8BE2 GameServers \u5931\u8D25\uFF0C\u9000\u56DE\u9ED8\u8BA4:", e);
      }
    }
    const targetGameServerUrl = preferredBaseUrl || gameServerUrl || systemConfig.notify_game_url || "http://160.202.240.19:8888/update_pay_status";
    console.log("\u51C6\u5907\u8C03\u7528\u6E38\u620F\u670D\u63A5\u53E3:", requestData, "\u5730\u5740:", targetGameServerUrl);
    const response = await fetch(targetGameServerUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(requestData),
      signal: AbortSignal.timeout(3e4)
    });
    if (response.ok) {
      console.log("\u6E38\u620F\u670D\u901A\u77E5\u6210\u529F:", transactionId);
      return {
        success: true,
        message: "\u6E38\u620F\u670D\u901A\u77E5\u6210\u529F"
      };
    } else {
      console.error("\u6E38\u620F\u670D\u901A\u77E5\u5931\u8D25:", response.status, response.statusText);
      return {
        success: false,
        message: `\u6E38\u620F\u670D\u8FD4\u56DE\u9519\u8BEF: ${response.status}`
      };
    }
  } catch (fetchError) {
    console.error("\u6E38\u620F\u670D\u901A\u77E5\u5F02\u5E38:", fetchError);
    if (fetchError.name === "AbortError") {
      return {
        success: false,
        message: "\u6E38\u620F\u670D\u54CD\u5E94\u8D85\u65F6"
      };
    } else {
      return {
        success: false,
        message: `\u6E38\u620F\u670D\u8FDE\u63A5\u5931\u8D25: ${fetchError.message}`
      };
    }
  }
}
async function generateUserLoginUrl(userId, redirectPath = "/user/home") {
  try {
    const userResult = await sql({
      query: "SELECT username, password FROM users WHERE id = ?",
      values: [userId]
    });
    if (userResult.length === 0) {
      console.error("\u7528\u6237\u4E0D\u5B58\u5728:", userId);
      return null;
    }
    const { username, password } = userResult[0];
    const systemConfig = await getSystemConfig();
    const baseLoginUrl = systemConfig.user_login_url;
    const ts = Math.floor(Date.now() / 1e3).toString();
    const secret = await getSystemParam("user_auto_login_secret", "12w12rdf43r43t564y7");
    const sig = crypto.createHash("md5").update(`${username}${ts}${secret}`).digest("hex");
    const loginParams = new URLSearchParams({ username, ts, sig, auto_login: "true", redirect: redirectPath });
    const fullLoginUrl = `${baseLoginUrl}?${loginParams.toString()}`;
    return fullLoginUrl;
  } catch (error) {
    console.error("\u751F\u6210\u7528\u6237\u767B\u5F55\u94FE\u63A5\u5931\u8D25:", error);
    return null;
  }
}
async function deductPlatformCoinsForPayment(userId, amount, transactionId, orderData, wuid) {
  var _a;
  getCurrentFormattedTime();
  try {
    const userResult = await sql({
      query: "SELECT platform_coins FROM users WHERE id = ?",
      values: [userId]
    });
    if (userResult.length === 0) {
      return {
        success: false,
        code: -2,
        msg: "\u7528\u6237\u4E0D\u5B58\u5728"
      };
    }
    const currentBalance = parseFloat(userResult[0].platform_coins) || 0;
    if (currentBalance < amount) {
      try {
        await updateByTransactionId(transactionId, { msg: "INSUFFICIENT_PTB" });
      } catch {
      }
      let redirectPath = "/user/cashier";
      try {
        let worldIdForRedirect = "";
        try {
          const w = Number(orderData == null ? void 0 : orderData.world_id);
          if (Number.isFinite(w) && w > 0) worldIdForRedirect = String(w);
        } catch {
        }
        if (!worldIdForRedirect && transactionId) {
          try {
            const ord = await detailByTransId(transactionId);
            if (ord && ord.world_id) worldIdForRedirect = String(ord.world_id);
          } catch {
          }
        }
        const qs = new URLSearchParams({
          sub_user_id: String((_a = orderData == null ? void 0 : orderData.sub_user_id) != null ? _a : ""),
          wuid: String(wuid || ""),
          world_id: worldIdForRedirect || ""
        }).toString();
        redirectPath = `/user/cashier?${qs}`;
      } catch {
      }
      const autoLoginUrl = await generateUserLoginUrl(userId, redirectPath);
      return {
        success: false,
        code: -6,
        msg: "\u4F59\u989D\u4E0D\u8DB3",
        data: autoLoginUrl || ""
      };
    }
    let securityCheckPassed = false;
    try {
      const lastOrder = await sql({
        query: `SELECT ptb_after, transaction_id, created_at, ptb_change 
                        FROM paymentrecords 
                        WHERE user_id = ? 
                        AND payment_status = 3 
                        AND ptb_after IS NOT NULL
                        ORDER BY created_at DESC 
                        LIMIT 1`,
        values: [userId]
      });
      if (lastOrder.length > 0) {
        const lastPtbAfter = parseFloat(lastOrder[0].ptb_after) || 0;
        const isBalanceValid = Math.abs(currentBalance - lastPtbAfter) < 0.01 || // 当前余额 = 上一笔的 after
        lastPtbAfter === 0;
        if (!isBalanceValid) {
          const hasAnyPtbConsumption = await sql({
            query: `SELECT id FROM paymentrecords 
                                WHERE user_id = ? 
                                AND payment_status = 3 
                                AND payment_way LIKE '%\u5E73\u53F0\u5E01%'
                                LIMIT 1`,
            values: [userId]
          });
          if (hasAnyPtbConsumption.length === 0) {
            console.warn("\u{1F50D} [\u5E73\u53F0\u5E01\u6821\u9A8C\u8DF3\u8FC7] \u4F59\u989D\u4E0D\u4E00\u81F4\u4F46\u672A\u627E\u5230\u4EFB\u4F55\u6D88\u8D39\u8BB0\u5F55\uFF0C\u5141\u8BB8\u4EA4\u6613", {
              userId,
              currentBalance,
              lastPtbAfter
            });
          } else {
            securityCheckPassed = true;
            console.error("\u{1F6A8} [\u5E73\u53F0\u5E01\u5F02\u5E38\u62D2\u7EDD] \u4F59\u989D\u6570\u636E\u5F02\u5E38\uFF0C\u4EA4\u6613\u88AB\u62D2\u7EDD\uFF01", {
              userId,
              transactionId,
              currentBalance,
              lastPtbAfter,
              diff: currentBalance - lastPtbAfter,
              lastTransaction: lastOrder[0].transaction_id,
              lastTransactionTime: lastOrder[0].created_at
            });
            try {
              await updateByTransactionId(transactionId, {
                msg: `BALANCE_ANOMALY:\u5F53\u524D\u4F59\u989D${currentBalance},\u4E0A\u6B21\u7ED3\u4F59${lastPtbAfter}`
              });
            } catch {
            }
            return {
              success: false,
              code: -11,
              msg: "\u8D26\u6237\u5F02\u5E38\uFF0C\u8BF7\u8054\u7CFB\u7BA1\u7406\u5458\u5904\u7406(1)",
              data: null
            };
          }
        }
      }
    } catch (checkError) {
      return {
        success: false,
        code: -12,
        msg: "\u8D26\u6237\u5F02\u5E38\uFF0C\u8BF7\u8054\u7CFB\u7BA1\u7406\u5458\u5904\u7406(2)",
        data: null
      };
    }
    if (securityCheckPassed) {
      return {
        success: false,
        code: -11,
        msg: "\u8D26\u6237\u5F02\u5E38\uFF0C\u8BF7\u8054\u7CFB\u7BA1\u7406\u5458\u5904\u7406(3)",
        data: null
      };
    }
    try {
      const updateResult = await updatePlatformCoinsUnified(userId, -amount, 1);
      if (!updateResult.success) {
        console.error("[\u5E73\u53F0\u5E01\u652F\u4ED8] \u6263\u6B3E\u5931\u8D25:", updateResult.message);
        await updateByTransactionId(transactionId, {
          payment_status: 2,
          msg: updateResult.message || "\u6263\u6B3E\u5931\u8D25"
        });
        return { success: false, message: updateResult.message || "\u6263\u6B3E\u5931\u8D25" };
      }
      const newBalance = updateResult.newBalance;
      const oldBalance = updateResult.oldBalance;
      await updateByTransactionId(transactionId, {
        payment_status: 1,
        // 处理中
        amount,
        ptb_change: -amount,
        ptb_after: newBalance
      });
      console.log("[\u5E73\u53F0\u5E01\u652F\u4ED8] \u6263\u6B3E\u5B8C\u6210\uFF0C\u5F00\u59CB\u5230\u8D26\u5904\u7406:", { transactionId, amount, newBalance });
      let giftHandled = false;
      let apiDeliveryHandled = false;
      const orderDetail = await detailByTransId(transactionId);
      const isGiftOrder = orderDetail && String(orderDetail.server_url || "").startsWith("gift://");
      if (orderDetail && isGiftOrder) {
        giftHandled = await processGiftOrder(orderDetail, `ptb_deduct_${transactionId}`);
        if (giftHandled) {
          console.log("[\u5E73\u53F0\u5E01\u652F\u4ED8] \u793C\u5305\u5230\u8D26\u6210\u529F:", transactionId);
          await updateByTransactionId(transactionId, {
            payment_status: 3
          });
        } else {
          console.error("[\u5E73\u53F0\u5E01\u652F\u4ED8] \u793C\u5305\u5230\u8D26\u5931\u8D25\uFF0C\u9000\u8FD8\u5E73\u53F0\u5E01:", transactionId);
          const { getPaymentRefundEnabled } = await import('./systemParams.mjs');
          const refundEnabled = await getPaymentRefundEnabled();
          if (refundEnabled) {
            const refundResult = await updatePlatformCoinsUnified(userId, amount, 6);
            await updateByTransactionId(transactionId, {
              payment_status: 2,
              ptb_change: 0,
              ptb_after: refundResult.newBalance || oldBalance,
              msg: "GIFT_DELIVERY_FAILED:\u793C\u5305\u53D1\u653E\u5931\u8D25\uFF0C\u5DF2\u9000\u6B3E"
            });
            return {
              success: false,
              code: -12,
              msg: "\u793C\u5305\u53D1\u653E\u5931\u8D25\uFF0C\u5DF2\u9000\u8FD8\u5E73\u53F0\u5E01",
              data: null
            };
          }
          await updateByTransactionId(transactionId, {
            payment_status: 1,
            msg: "GIFT_DELIVERY_FAILED_NO_REFUND:\u793C\u5305\u53D1\u653E\u5931\u8D25\uFF08\u9000\u6B3E\u5173\u95ED\uFF09"
          });
          return {
            success: false,
            code: -12,
            msg: "\u793C\u5305\u53D1\u653E\u5931\u8D25\uFF08\u9000\u6B3E\u5173\u95ED\uFF09",
            data: null
          };
        }
      } else if (orderDetail && !isGiftOrder) {
        try {
          const { getApiDeliveryEnabled, getApiDeliveryTestRoleId } = await import('./systemParams.mjs');
          const { getRechargeConfig } = await import('../nitro/nitro.mjs').then(function (n) { return n.ai; });
          const apiDeliveryEnabled = await getApiDeliveryEnabled();
          const testRoleId = await getApiDeliveryTestRoleId();
          const playerRoleId = orderDetail.role_id || wuid;
          const isTestRole = testRoleId && playerRoleId && String(playerRoleId).trim() === String(testRoleId).trim();
          const shouldProcessApiDelivery = (apiDeliveryEnabled || isTestRole) && orderDetail.product_name && orderDetail.world_id;
          console.log("API\u5230\u8D26--\u68C0\u67E5\u914D\u7F6E:", {
            apiDeliveryEnabled,
            testRoleId,
            playerRoleId,
            isTestRole,
            shouldProcessApiDelivery,
            productName: orderDetail.product_des,
            worldId: orderDetail.world_id
          });
          if (shouldProcessApiDelivery) {
            const config = orderDetail.product_des ? getRechargeConfig(orderDetail.product_des) : null;
            console.log("API\u5230\u8D26--\u5546\u54C1\u914D\u7F6E:", config ? `\u627E\u5230\u914D\u7F6E:${config.id}` : "\u672A\u627E\u5230\u914D\u7F6E");
            if (config) {
              let finalGoodsId = config.andid;
              try {
                const character = await findByUuid(playerRoleId);
                if (character && character.ext) {
                  let extObj = {};
                  try {
                    extObj = typeof character.ext === "string" ? JSON.parse(character.ext) : character.ext;
                  } catch (e) {
                    extObj = { value: character.ext };
                  }
                  if (extObj && extObj.value === "ios") {
                    finalGoodsId = config.id;
                    console.log(`API\u5230\u8D26--\u5E73\u53F0\u5224\u5B9A: iOS, \u4F7F\u7528 id=${finalGoodsId}, \u89D2\u8272UUID=${playerRoleId}`);
                  } else {
                    finalGoodsId = config.andid || config.id;
                    console.log(`API\u5230\u8D26--\u5E73\u53F0\u5224\u5B9A: \u975EiOS, \u4F7F\u7528 andid=${finalGoodsId}, \u89D2\u8272UUID=${playerRoleId}`);
                  }
                } else {
                  finalGoodsId = config.andid || config.id;
                  console.log(`API\u5230\u8D26--\u5E73\u53F0\u5224\u5B9A: \u672A\u627E\u5230\u89D2\u8272\u6216ext\u4E3A\u7A7A, \u9ED8\u8BA4\u4F7F\u7528 andid=${finalGoodsId}, \u89D2\u8272UUID=${playerRoleId}`);
                }
              } catch (charError) {
                console.error("API\u5230\u8D26--\u5E73\u53F0\u5224\u5B9A\u5F02\u5E38:", charError);
                finalGoodsId = config.andid || config.id;
              }
              const serverCfg = await getByWorldId(Number(orderDetail.world_id));
              console.log("API\u5230\u8D26--\u670D\u52A1\u5668\u914D\u7F6E:", serverCfg ? `\u627E\u5230\u670D\u52A1\u5668:${serverCfg.webhost}` : `\u672A\u627E\u5230world_id=${orderDetail.world_id}`);
              if (serverCfg && serverCfg.webhost) {
                const webhost = serverCfg.webhost.replace(/\/$/, "");
                const playerId = String(wuid);
                const rechargeUrl = `${webhost}/script/gmRecharge?playerId=${playerId}&rechargeType=${config.rechargeType}&goodsId=${finalGoodsId}&billno=${orderDetail.mch_order_id}`;
                const response = await fetch(rechargeUrl, {
                  method: "GET",
                  signal: AbortSignal.timeout(1e4)
                });
                console.log("API\u5230\u8D26--rechargeUrl:", rechargeUrl);
                const responseText = await response.text();
                const currentTime2 = getCurrentFormattedTime();
                if (response.ok) {
                  try {
                    const result = JSON.parse(responseText);
                    const isSuccess = result.code === 0 || result.msg === "success" || result.result && String(result.result).toLowerCase().includes("success");
                    if (isSuccess) {
                      console.log("API\u5230\u8D26--Success:", { transactionId, playerId, product: finalGoodsId, response: result });
                      apiDeliveryHandled = true;
                      await updateByTransactionId(transactionId, {
                        payment_status: 3,
                        notify_at: currentTime2,
                        msg: `API\u5230\u8D26\u6210\u529F:${JSON.stringify(result).substring(0, 500)}`
                      });
                    } else {
                      console.error("API\u5230\u8D26--Failed:", result);
                      await updateByTransactionId(transactionId, {
                        msg: `API\u5230\u8D26\u5931\u8D25:${JSON.stringify(result).substring(0, 500)}`
                      });
                    }
                  } catch (parseError) {
                    if (responseText.trim().toLowerCase() === "success") {
                      console.log("API\u5230\u8D26--Success:", { transactionId, playerId });
                      apiDeliveryHandled = true;
                      await updateByTransactionId(transactionId, {
                        payment_status: 3,
                        notify_at: currentTime2,
                        msg: "API\u5230\u8D26\u6210\u529F:\u7EAF\u6587\u672Csuccess\u54CD\u5E94"
                      });
                    } else {
                      const errorMsg = `API\u5230\u8D26\u54CD\u5E94\u89E3\u6790\u5931\u8D25:${responseText.substring(0, 200)}`;
                      console.error("API\u5230\u8D26--\u54CD\u5E94\u89E3\u6790\u5931\u8D25:", {
                        transactionId,
                        playerId,
                        responseText: responseText.substring(0, 200),
                        parseError: parseError instanceof Error ? parseError.message : "Unknown error"
                      });
                      await updateByTransactionId(transactionId, {
                        msg: errorMsg
                      });
                    }
                  }
                } else {
                  const errorMsg = `API\u5230\u8D26HTTP\u9519\u8BEF:${response.status} ${response.statusText}`;
                  console.error("API\u5230\u8D26--HTTP\u9519\u8BEF:", { status: response.status, statusText: response.statusText });
                  await updateByTransactionId(transactionId, {
                    msg: errorMsg
                  });
                }
              } else {
                const errorMsg = `API\u5230\u8D26\u672A\u627E\u5230\u670D\u52A1\u5668\u914D\u7F6E:world_id=${orderDetail.world_id}`;
                console.warn("API\u5230\u8D26--\u672A\u627E\u5230\u670D\u52A1\u5668\u914D\u7F6E:", orderDetail.world_id);
                await updateByTransactionId(transactionId, {
                  msg: errorMsg
                });
              }
            } else {
              const errorMsg = `API\u5230\u8D26\u627E\u4E0D\u5230\u5546\u54C1\u914D\u7F6E:${orderDetail.product_name}`;
              console.warn("API\u5230\u8D26--\u627E\u4E0D\u5230\u5546\u54C1\u914D\u7F6E:", orderDetail.product_name);
              await updateByTransactionId(transactionId, {
                msg: errorMsg
              });
            }
          } else {
            console.log("API\u5230\u8D26--\u65E0\u9700\u5904\u7406:", {
              reason: !apiDeliveryEnabled && !isTestRole ? "API\u5230\u8D26\u5F00\u5173\u672A\u5F00\u542F" : !orderDetail.product_name ? "\u7F3A\u5C11\u5546\u54C1\u540D\u79F0" : !orderDetail.world_id ? "\u7F3A\u5C11\u670D\u52A1\u5668ID" : "\u672A\u77E5"
            });
            await updateByTransactionId(transactionId, {
              payment_status: 3
            });
            apiDeliveryHandled = true;
          }
        } catch (apiError) {
          const errorMsg = `API\u5230\u8D26\u5F02\u5E38:${apiError.message}`;
          console.error("API\u5230\u8D26--\u5F02\u5E38:", apiError.message);
          await updateByTransactionId(transactionId, {
            msg: errorMsg
          });
        }
        if (apiDeliveryHandled) {
          console.log("[\u5E73\u53F0\u5E01\u652F\u4ED8] API\u5230\u8D26\u6210\u529F:", transactionId);
        } else {
          console.error("[\u5E73\u53F0\u5E01\u652F\u4ED8] API\u5230\u8D26\u5931\u8D25\uFF0C\u9000\u8FD8\u5E73\u53F0\u5E01:", transactionId);
          const { getPaymentRefundEnabled } = await import('./systemParams.mjs');
          const refundEnabled = await getPaymentRefundEnabled();
          if (refundEnabled) {
            const refundResult = await updatePlatformCoinsUnified(userId, amount, 6);
            await updateByTransactionId(transactionId, {
              payment_status: 2,
              // 失败
              ptb_change: 0,
              ptb_after: refundResult.newBalance || oldBalance,
              msg: "API_DELIVERY_FAILED:API\u5230\u8D26\u5931\u8D25\uFF0C\u5DF2\u9000\u6B3E"
            });
            return {
              success: false,
              code: -13,
              msg: "\u5230\u8D26\u5931\u8D25\uFF0C\u5DF2\u9000\u8FD8\u5E73\u53F0\u5E01",
              data: null
            };
          }
          await updateByTransactionId(transactionId, {
            payment_status: 1,
            msg: "API_DELIVERY_FAILED_NO_REFUND:API\u5230\u8D26\u5931\u8D25\uFF08\u9000\u6B3E\u5173\u95ED\uFF09"
          });
          return {
            success: false,
            code: -13,
            msg: "\u5230\u8D26\u5931\u8D25\uFF08\u9000\u6B3E\u5173\u95ED\uFF09",
            data: null
          };
        }
      }
      return {
        success: true,
        code: 1,
        msg: "\u652F\u4ED8\u6210\u529F",
        data: {
          transactionId,
          newBalance,
          amount
        }
      };
    } catch (transactionError) {
      console.error("[\u5E73\u53F0\u5E01\u652F\u4ED8] \u5904\u7406\u5F02\u5E38\uFF0C\u9000\u8FD8\u5E73\u53F0\u5E01:", transactionError);
      try {
        const { getPaymentRefundEnabled } = await import('./systemParams.mjs');
        const refundEnabled = await getPaymentRefundEnabled();
        if (refundEnabled) {
          const refundResult = await updatePlatformCoinsUnified(userId, amount, 7);
          await updateByTransactionId(transactionId, {
            payment_status: 2,
            ptb_change: 0,
            ptb_after: refundResult.newBalance || await getPlatformCoins(userId),
            msg: `EXCEPTION:\u5904\u7406\u5F02\u5E38\uFF0C\u5DF2\u9000\u6B3E - ${transactionError.message}`
          });
        } else {
          await updateByTransactionId(transactionId, {
            payment_status: 1,
            msg: `EXCEPTION_NO_REFUND:\u5904\u7406\u5F02\u5E38\uFF08\u9000\u6B3E\u5173\u95ED\uFF09 - ${transactionError.message}`
          });
        }
      } catch (refundError) {
        console.error("[\u5E73\u53F0\u5E01\u652F\u4ED8] \u9000\u6B3E\u5931\u8D25:", refundError);
      }
      return {
        success: false,
        code: -14,
        msg: "\u652F\u4ED8\u5904\u7406\u5F02\u5E38\uFF0C\u5DF2\u9000\u8FD8\u5E73\u53F0\u5E01",
        data: null
      };
    }
  } catch (dbError) {
    console.error("[\u5E73\u53F0\u5E01\u652F\u4ED8] \u6570\u636E\u5E93\u64CD\u4F5C\u5931\u8D25:", dbError);
    return {
      success: false,
      code: -9,
      msg: "\u652F\u4ED8\u5904\u7406\u5931\u8D25"
    };
  }
}
defineEventHandler(async (event) => {
  var _a, _b;
  const transaction_id = (_b = (_a = event.context.params) == null ? void 0 : _a.transaction_id) != null ? _b : "";
  try {
    const result = await detailByTransId(transaction_id);
    return {
      code: result === null ? 404 : 200,
      data: result
    };
  } catch (e) {
    throw createError({
      status: 500,
      message: e.message
    });
  }
});
const getGameOrder = defineEventHandler(async (event) => {
  const query = getQuery(event);
  let oid = query.oid || "";
  if (!oid && event.node.req.method === "POST") {
    try {
      const body = await readBody(event);
      oid = body.oid || "";
    } catch (error) {
      console.error("\u8BFB\u53D6POST\u8BF7\u6C42\u4F53\u5931\u8D25:", error);
    }
  }
  try {
    if (!oid) {
      return {
        code: -1,
        msg: "\u7F3A\u5C11\u8BA2\u5355\u53F7\u53C2\u6570",
        amount: "0"
      };
    }
    const result = await detailByMchOrderId(oid);
    if (!result) {
      return {
        code: 0,
        msg: "\u8BA2\u5355\u4E0D\u5B58\u5728:" + oid,
        amount: "0"
      };
    }
    let code = 0;
    let msg = "\u8BA2\u5355\u672A\u77E5\u72B6\u6001";
    switch (result.payment_status) {
      case 0:
        code = 0;
        msg = "\u8BA2\u5355\u672A\u5B8C\u6210";
        break;
      case 1:
        code = 0;
        msg = "\u8BA2\u5355\u5904\u7406\u4E2D";
        break;
      case 2:
        code = 0;
        msg = "\u8BA2\u5355\u5931\u8D25";
        break;
      case 3:
      case 4:
        code = 1;
        msg = "\u8BA2\u5355\u6210\u529F";
        break;
      default:
        code = 0;
        msg = "\u8BA2\u5355\u72B6\u6001\u5F02\u5E38";
        break;
    }
    return {
      code,
      msg,
      amount: (result.amount || 0).toString()
    };
  } catch (e) {
    console.error("SDK\u6E38\u620F\u8BA2\u5355\u67E5\u8BE2\u5931\u8D25:", e);
    return {
      code: -1,
      msg: "\u7CFB\u7EDF\u9519\u8BEF",
      amount: "0"
    };
  }
});
defineEventHandler(async (event) => {
  var _a, _b;
  var user_id = (_b = (_a = event.context.params) == null ? void 0 : _a.user_id) != null ? _b : 0;
  try {
    const result = await detailByUserId(user_id);
    return {
      code: result === null ? 404 : 200,
      data: result
    };
  } catch (e) {
    throw createError({
      status: 500,
      message: e.message
    });
  }
});
const doPayment = async (evt) => {
  var _a, _b, _c, _d, _e, _f;
  try {
    let body = {};
    const method = ((_a = evt.node.req.method) == null ? void 0 : _a.toUpperCase()) || "GET";
    if (method !== "GET") {
      try {
        body = await readBody(evt);
      } catch {
        body = {};
      }
    }
    console.log("\u652F\u4ED8\u8BF7\u6C42:", body);
    const query = getQuery(evt) || {};
    const safeBody = body && typeof body === "object" ? body : {};
    const params = { ...query, ...safeBody };
    let paymentMethod = typeof params.z === "string" ? params.z.toLowerCase() : "";
    const subject = params.b;
    const username = params.f;
    const wuid = params.x;
    const serverId = params.h;
    const gameId = params.j;
    const osType = params.os;
    const subUserId = params.tr;
    const orderId = params.xx;
    const deviceImei = params.c;
    const appId = params.d;
    const agentId = params.e;
    let productName = params.k;
    const productDesc = params.l;
    const attachInfo = params.y;
    const price = params.p;
    let resolvedPrice = price;
    const serverUrl = params.server_url ? String(params.server_url) : "";
    const isGiftOrder = serverUrl.startsWith("gift://");
    const dailyLimitedProducts = /* @__PURE__ */ new Set([
      "com.tencent.tmgp.hjol.gift_100",
      "com.tencent.tmgp.hjol.gift_300",
      "com.tencent.tmgp.hjol.gift_600",
      "com.tencent.tmgp.hjol.gift_1200",
      "com.tencent.tmgp.hjol.happyshopping_3000",
      "com.tencent.tmgp.hjol.preferential_box_4500",
      "com.tencent.tmgp.hjol.box_600",
      "com.tencent.tmgp.hjol.box_1200",
      "com.tencent.tmgp.hjol.box_1800",
      "com.tencent.tmgp.hjol.box_3000",
      "com.tencent.tmgp.hjol.box_6800",
      "com.tencent.tmgp.hjol.chest_100"
    ]);
    if (!isGiftOrder && productName) {
      try {
        const { getRechargeProductName } = await import('../nitro/nitro.mjs').then(function (n) { return n.ai; });
        const configName = getRechargeProductName(productName);
        if (configName && configName !== productName) {
          productName = configName;
        }
      } catch (e) {
      }
    }
    const isCashierPayment = params.cashier_payment === "true";
    if (!paymentMethod && isGiftOrder) {
      paymentMethod = "ptb";
    }
    let giftOrderContext = null;
    const uaRaw = evt.node.req.headers["user-agent"];
    const isMobileUA = /android|iphone|ipad|ipod|mobile/i.test(String(uaRaw || "").toLowerCase());
    const deviceForGateway = isMobileUA ? "mobile" : "pc";
    if (!username || !gameId || !paymentMethod || !productName) {
      setResponseStatus(evt, 200);
      return {
        code: -1,
        msg: "\u7F3A\u5C11\u5FC5\u8981\u53C2\u6570\uFF1A\u7528\u6237\u540D\u3001\u6E38\u620FID\u3001\u652F\u4ED8\u65B9\u5F0F\u3001\u5546\u54C1\u540D\u79F0",
        data: null
      };
    }
    if (!isGiftOrder && paymentMethod !== "kf" && (!price || isNaN(parseFloat(price)))) {
      setResponseStatus(evt, 200);
      return {
        code: -1,
        msg: "\u7F3A\u5C11\u6709\u6548\u7684\u91D1\u989D\u53C2\u6570",
        data: null
      };
    }
    if (!isGiftOrder && paymentMethod !== "kf" && paymentMethod !== "ptb") {
      try {
        const { GetOpenPaySetting } = await import('./paymentSettings.mjs');
        const paymentSettings = await GetOpenPaySetting();
        const currentSetting = paymentSettings.find(
          (setting) => setting.payment_method === paymentMethod
        );
        if (currentSetting) {
          const amount = parseFloat(price);
          const minPrice = currentSetting.MinPrice || 0;
          const maxPrice = currentSetting.MaxPrice || 999999;
          if (amount < minPrice || amount > maxPrice) {
            console.warn("[\u652F\u4ED8\u62E6\u622A] \u91D1\u989D\u8D85\u51FA\u8303\u56F4:", {
              paymentMethod,
              amount,
              minPrice,
              maxPrice,
              username
            });
            setResponseStatus(evt, 200);
            return {
              code: -12,
              msg: `\u652F\u4ED8\u91D1\u989D\u5FC5\u987B\u5728 \xA5${minPrice} - \xA5${maxPrice} \u4E4B\u95F4`,
              data: null
            };
          }
        }
      } catch (e) {
        console.error("[\u652F\u4ED8\u91D1\u989D\u9A8C\u8BC1] \u68C0\u67E5\u5931\u8D25:", e);
        return {
          code: -12,
          msg: `\u91D1\u989D\u67E5\u8BE2\u5931\u8D25,\u8BF7\u518D\u6B21\u5C1D\u8BD5`,
          data: null
        };
      }
    }
    try {
      const redis = getRedisCluster();
      let lockKey = "";
      if (wuid) {
        lockKey = `sdkpay:lock:wuid:${wuid}`;
      } else {
        const rawSubUserId = (subUserId || "").toString().trim();
        const rawUsername = (username || "").toString().trim();
        lockKey = rawSubUserId ? `sdkpay:lock:sub:${rawSubUserId}` : `sdkpay:lock:user:${rawUsername}`;
      }
      if (lockKey) {
        const lockOk = await redis.set(lockKey, "1", "EX", 15, "NX");
        if (lockOk !== "OK") {
          setResponseStatus(evt, 200);
          return {
            code: -10,
            msg: "\u4E0B\u5355\u8FC7\u4E8E\u9891\u7E41,\u8BF715\u79D2\u540E\u518D\u8BD5",
            data: null
          };
        }
      }
    } catch (e) {
      console.error("Redis \u9650\u6D41\u5F02\u5E38:", e);
      setResponseStatus(evt, 200);
      return {
        code: -13,
        msg: "\u670D\u52A1\u5F02\u5E38,\u8BF7\u7A0D\u540E\u518D\u8BD5",
        data: null
      };
    }
    const bjTimeStr = new Date(Date.now() + 8 * 36e5).toISOString().replace("T", " ").substring(0, 23);
    let dbHost = "unknown";
    let dbName = "unknown";
    try {
      const connCfg = (_d = (_c = (_b = pool) == null ? void 0 : _b.pool) == null ? void 0 : _c.config) == null ? void 0 : _d.connectionConfig;
      if (connCfg) {
        dbHost = connCfg.host || "unknown";
        dbName = connCfg.database || "unknown";
      }
    } catch {
    }
    console.log(`[${bjTimeStr}] [doPayment] \u5F00\u59CB\u6821\u9A8C\u7528\u6237\u662F\u5426\u5B58\u5728...`);
    console.log(`[${bjTimeStr}] [doPayment] \u6570\u636E\u5E93\u73AF\u5883 -> Host: ${dbHost}, Database: ${dbName}`);
    console.log(`[${bjTimeStr}] [doPayment] \u6821\u9A8C\u53C2\u6570 -> username (f): "${username}" (\u7C7B\u578B: ${typeof username}, \u957F\u5EA6: ${String(username || "").length})`);
    console.log(`[${bjTimeStr}] [doPayment] \u6267\u884CSQL -> SELECT id, platform_coins, game_code, channel_code FROM users WHERE username = ? OR thirdparty_uid = ?`);
    console.log(`[${bjTimeStr}] [doPayment] SQL\u7ED1\u5B9A\u503C -> ["${username}", "${username}"]`);
    const user = await sql({
      query: "SELECT id, platform_coins, game_code, channel_code FROM users WHERE username = ? OR thirdparty_uid = ?",
      values: [username, username]
    });
    console.log(`[${bjTimeStr}] [doPayment] SQL\u6267\u884C\u5B8C\u6BD5\uFF0C\u5339\u914D\u7528\u6237\u8BB0\u5F55\u6570 -> ${user.length}`);
    if (user.length === 0) {
      console.error(`[${bjTimeStr}] [doPayment] \u274C [\u652F\u4ED8\u4E0B\u5355\u5931\u8D25] \u7528\u6237\u4E0D\u5B58\u5728: \u4F20\u5165\u7684 username \u4E3A "${username}"`);
      setResponseStatus(evt, 200);
      return {
        code: -2,
        msg: "\u7528\u6237\u4E0D\u5B58\u5728",
        data: null
      };
    }
    const userData = user[0];
    console.log(`[${bjTimeStr}] [doPayment] \u2705 \u7528\u6237\u6821\u9A8C\u6210\u529F:`, JSON.stringify(userData));
    const userId = userData.id;
    const userPlatformCoins = parseFloat(userData.platform_coins) || 0;
    const userGameCode = userData.game_code || "";
    const userChannelCode = userData.channel_code || "";
    if (dailyLimitedProducts.has(productDesc)) {
      const limitRows = await sql({
        query: `SELECT COUNT(*) AS cnt
                        FROM paymentrecords
                        WHERE wuid = ?
                          AND product_des = ?
                          AND payment_status = 3
                          AND DATE(created_at) = CURDATE()`,
        values: [wuid || username, productDesc]
      });
      const purchaseCount = ((_e = limitRows == null ? void 0 : limitRows[0]) == null ? void 0 : _e.cnt) || 0;
      if (purchaseCount > 0) {
        setResponseStatus(evt, 200);
        return {
          code: -15,
          msg: "\u8BE5\u793C\u5305\u6BCF\u65E5\u9650\u8D2D\u4E00\u6B21\uFF0C\u8BF7\u660E\u65E5\u518D\u8BD5",
          data: null
        };
      }
    }
    let validatedSubUserId = null;
    if (subUserId) {
      const subUserIdNum = parseInt(subUserId);
      if (!isNaN(subUserIdNum)) {
        const subUser = await sql({
          query: "SELECT id FROM subusers WHERE id = ? AND parent_user_id = ?",
          values: [subUserIdNum, userId]
        });
        if (subUser.length > 0) {
          validatedSubUserId = subUserIdNum;
        } else {
          setResponseStatus(evt, 200);
          return {
            code: -3,
            msg: "\u5B50\u7528\u6237\u4E0D\u5B58\u5728\u6216\u4E0D\u5C5E\u4E8E\u5F53\u524D\u4E3B\u7528\u6237",
            data: null
          };
        }
      }
    }
    if (isGiftOrder) {
      try {
        const encoded = serverUrl.slice("gift://".length);
        const decoded = decodeURIComponent(encoded);
        const meta = JSON.parse(decoded || "{}");
        const packageId = Number(meta.pid || meta.package_id || meta.packageId);
        const characterUuid = String(meta.cid || meta.character_uuid || meta.characterUuid || "");
        const quantity = 1;
        const serverIdFromMeta = String(meta.sid || meta.server_id || meta.serverId || serverId || 1);
        console.log(`[doPayment] \u793C\u5305\u8BA2\u5355\u9650\u8D2D\u68C0\u67E5 - \u793C\u5305ID: ${packageId}, \u89D2\u8272UUID: ${characterUuid}, \u6570\u91CF: ${quantity}`);
        if (!packageId || !characterUuid) {
          console.error("[doPayment] \u793C\u5305\u8BA2\u5355\u53C2\u6570\u7F3A\u5931:", meta);
          setResponseStatus(evt, 200);
          return {
            code: -11,
            msg: "\u793C\u5305\u8BA2\u5355\u53C2\u6570\u7F3A\u5931",
            data: null
          };
        }
        const giftPackage = await getGiftPackageById(packageId);
        if (!giftPackage) {
          console.error(`[doPayment] \u793C\u5305\u4E0D\u5B58\u5728: package_id=${packageId}`);
          setResponseStatus(evt, 200);
          return {
            code: -11,
            msg: "\u793C\u5305\u4E0D\u5B58\u5728",
            data: null
          };
        }
        const checkResult = await checkUserCanPurchase(characterUuid, packageId, quantity);
        if (!checkResult.canPurchase) {
          console.error(`[doPayment] \u793C\u5305\u9650\u8D2D\u68C0\u67E5\u5931\u8D25: ${checkResult.reason}`);
          setResponseStatus(evt, 200);
          return {
            code: -11,
            msg: checkResult.reason,
            data: null
          };
        }
        console.log(`[doPayment] \u2705 \u793C\u5305\u9650\u8D2D\u68C0\u67E5\u901A\u8FC7`);
        const unitPlatformCoins = Number(giftPackage.price_platform_coins || 0);
        const unitRealMoney = Number(giftPackage.price_real_money || 0);
        const totalPlatformCoins = unitPlatformCoins * quantity;
        const totalRealMoney = unitRealMoney * quantity;
        giftOrderContext = {
          packageId,
          characterUuid,
          quantity,
          serverId: serverIdFromMeta,
          unitPlatformCoins,
          unitRealMoney,
          totalPlatformCoins,
          totalRealMoney
        };
        if (!paymentMethod) {
          paymentMethod = "ptb";
        }
        if (paymentMethod === "ptb") {
          resolvedPrice = totalPlatformCoins.toString();
        } else if (totalRealMoney > 0) {
          resolvedPrice = totalRealMoney.toString();
        }
      } catch (error) {
        console.error("[doPayment] \u793C\u5305\u8BA2\u5355\u89E3\u6790\u5931\u8D25:", error);
      }
    }
    const paymentWayMap = {
      "kf": "\u5BA2\u670D",
      "ptb": "\u5E73\u53F0\u5E01",
      "zfb": "\u652F\u4ED8\u5B9D",
      "wx": "\u5FAE\u4FE1",
      "yl": "\u94F6\u8054"
    };
    const paymentWayName = paymentWayMap[paymentMethod] || paymentMethod;
    const amountNumGlobal = parseFloat(String(resolvedPrice));
    if (paymentMethod !== "kf" && (!resolvedPrice || isNaN(amountNumGlobal) || amountNumGlobal <= 0)) {
      setResponseStatus(evt, 200);
      return {
        code: -1,
        msg: "\u652F\u4ED8\u91D1\u989D\u5FC5\u987B\u5927\u4E8E0",
        data: null
      };
    }
    const normalizedProductNameForType = String(productName || "").toLowerCase();
    const isPlatformCoinRecharge = normalizedProductNameForType.includes("\u5E73\u53F0\u5E01") || normalizedProductNameForType.includes("\u5145\u503C") || normalizedProductNameForType.includes("ptb") || serverUrl.includes("cashier");
    if (!isGiftOrder && !isPlatformCoinRecharge) {
      try {
        const productKey = productDesc || productName || "";
        const { getRechargeConfig } = await import('../nitro/nitro.mjs').then(function (n) { return n.ai; });
        const cfg = productKey ? getRechargeConfig(productKey) : null;
        const cfgPrice = cfg && typeof cfg.price === "number" ? Number(cfg.price) : NaN;
        if (!cfg || isNaN(cfgPrice) || cfgPrice <= 0) {
          setResponseStatus(evt, 200);
          return {
            code: -10,
            msg: "\u5546\u54C1\u4EF7\u683C\u914D\u7F6E\u7F3A\u5931\u6216\u65E0\u6548",
            data: null
          };
        }
        if (Math.abs(amountNumGlobal - cfgPrice) > 1e-3) {
          setResponseStatus(evt, 200);
          return {
            code: -10,
            msg: "\u652F\u4ED8\u91D1\u989D\u4E0E\u5546\u54C1\u914D\u7F6E\u4E0D\u4E00\u81F4",
            data: null
          };
        }
      } catch (e) {
        console.warn("[doPayment] \u91D1\u989D\u4E0E\u914D\u7F6E\u6821\u9A8C\u5F02\u5E38:", e);
      }
    }
    if (paymentMethod === "kf") {
    } else if (paymentMethod === "ptb") {
      const amountNum = parseFloat(String(resolvedPrice));
      const transactionId = `ptb_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      const resolvedWorldIdSource = (_f = giftOrderContext == null ? void 0 : giftOrderContext.serverId) != null ? _f : serverId;
      const parsedWorldId = resolvedWorldIdSource ? parseInt(String(resolvedWorldIdSource), 10) : 1;
      const safeWorldId = Number.isNaN(parsedWorldId) ? 1 : parsedWorldId;
      const resolvedRoleId = (giftOrderContext == null ? void 0 : giftOrderContext.characterUuid) || (wuid ? String(wuid) : "");
      {
        const userBalanceResult = await sql({
          query: "SELECT platform_coins FROM users WHERE id = ?",
          values: [userId]
        });
        const currentPtbBalance = userBalanceResult.length > 0 ? parseFloat(userBalanceResult[0].platform_coins) || 0 : 0;
        const paymentData = {
          user_id: userId,
          sub_user_id: validatedSubUserId,
          role_id: resolvedRoleId || "",
          transaction_id: transactionId,
          wuid: wuid || username,
          payment_way: paymentWayName,
          payment_id: 0,
          world_id: safeWorldId,
          product_name: productName,
          product_des: productDesc || "",
          ip: "",
          amount: amountNum,
          mch_order_id: orderId || "",
          msg: "",
          server_url: serverUrl || "",
          device: deviceImei || "",
          channel_code: userChannelCode,
          game_code: userGameCode,
          payment_status: 0,
          // 待支付
          ptb_before: currentPtbBalance
          // 只设置扣款前余额
          // ptb_change 和 ptb_after 在扣款时才设置
        };
        await insert$3(paymentData);
        const deductResult = await deductPlatformCoinsForPayment(
          userId,
          amountNum,
          transactionId,
          paymentData,
          wuid || username
        );
        setResponseStatus(evt, 200);
        if (deductResult.success) {
          const systemConfig = await getSystemConfig();
          const baseUrl = process.env.BASE_URL || "http://localhost:3000";
          const paySucUrl = systemConfig.pay_suc_url || `${baseUrl}/user/payment-success`;
          const successParams = new URLSearchParams({
            amount: amountNum.toString(),
            product_name: productName,
            payment_method: "ptb",
            transaction_id: transactionId,
            payment_time: (/* @__PURE__ */ new Date()).toISOString()
          });
          const successUrl = `${paySucUrl}?${successParams.toString()}`;
          return { code: deductResult.code, msg: deductResult.msg, data: successUrl };
        } else {
          return { code: deductResult.code, msg: deductResult.msg, data: deductResult.data };
        }
      }
    } else if (paymentMethod === "zfb") {
      const amountNum = parseFloat(String(resolvedPrice));
      const transactionId = `zfb_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      const mchOrderId = orderId || `zfb_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      const { channelId: zfbChannelId } = await selectProviderBySystemParam(amountNum, "zfb", transactionId);
      let currentPtbBalance = 0;
      try {
        const userBalance = await sql({
          query: "SELECT platform_coins FROM users WHERE id = ?",
          values: [userId]
        });
        if (userBalance.length > 0) {
          currentPtbBalance = parseFloat(userBalance[0].platform_coins) || 0;
        }
      } catch (err) {
        console.warn("\u83B7\u53D6\u7528\u6237\u5E73\u53F0\u5E01\u4F59\u989D\u5931\u8D25:", err);
      }
      const paymentData = {
        user_id: userId,
        sub_user_id: validatedSubUserId,
        role_id: "",
        transaction_id: transactionId,
        wuid: wuid || username,
        payment_way: paymentWayName,
        payment_id: parseInt(zfbChannelId) || 0,
        // 保存渠道ID到payment_id
        world_id: serverId ? parseInt(serverId) : 1,
        product_name: productName,
        product_des: productDesc || "",
        ip: "",
        amount: amountNum,
        mch_order_id: mchOrderId,
        msg: "",
        server_url: serverUrl || "",
        device: deviceImei || "",
        channel_code: userChannelCode,
        game_code: userGameCode,
        payment_status: 0,
        // 非平台币支付也记录平台币快照（无变化）
        ptb_before: currentPtbBalance,
        ptb_change: 0,
        ptb_after: currentPtbBalance
      };
      await insert$3(paymentData);
      console.log(`\u652F\u4ED8\u5B9D\u652F\u4ED8\u8BB0\u5F55\u5DF2\u63D2\u5165: ${transactionId}, \u6E20\u9053ID: ${zfbChannelId}`);
      try {
        const systemConfig = await getSystemConfig();
        const baseUrl = systemConfig.notify_url || process.env.BASE_URL || "http://localhost:3000";
        const thirdPartyResult = await callThirdPartyPayment({
          type: "alipay",
          out_trade_no: mchOrderId,
          name: productName,
          money: amountNum.toString(),
          notify_url: `${baseUrl.replace(/\/+$/, "")}/api/payment/${isCashierPayment ? "cashier-notify" : "third-party-notify"}`,
          return_url: `${systemConfig.pay_suc_url}?transaction_id=${transactionId}`,
          clientip: normalizeIPAddress(
            evt.node.req.headers["x-forwarded-for"] || evt.node.req.headers["x-real-ip"] || evt.node.req.socket.remoteAddress || "127.0.0.1"
          ),
          device: deviceForGateway,
          param: transactionId
        }, { paymentMethod, agentId, appId, gameId });
        if (thirdPartyResult.code === 1) {
          await updateOrderStatus(transactionId, 1);
          if (thirdPartyResult.trade_no) {
            await updateByTransactionId(transactionId, { mch_order_id: thirdPartyResult.trade_no });
          }
          let returnData = null;
          if (thirdPartyResult.qrcode) {
            const systemConfig2 = await getSystemConfig();
            const qrBase = systemConfig2.qrcode_url || `${process.env.BASE_URL || "http://localhost:3000"}/user/qrcode`;
            returnData = `${qrBase}?transaction_id=${transactionId}&qrcode=${encodeURIComponent(thirdPartyResult.qrcode)}`;
          } else {
            returnData = thirdPartyResult.payurl || thirdPartyResult.urlscheme || null;
          }
          setResponseStatus(evt, 200);
          return {
            code: 1,
            msg: "\u652F\u4ED8\u5B9D\u652F\u4ED8\u8BA2\u5355\u521B\u5EFA\u6210\u529F",
            data: returnData
          };
        } else {
          await updateOrderStatus(transactionId, 2);
          setResponseStatus(evt, 200);
          return {
            code: -6,
            msg: thirdPartyResult.msg || "\u652F\u4ED8\u5B9D\u652F\u4ED8\u63A5\u53E3\u8C03\u7528\u5931\u8D25",
            data: null
          };
        }
      } catch (error) {
        await updateOrderStatus(transactionId, 2);
        console.error("\u652F\u4ED8\u5B9D\u652F\u4ED8\u63A5\u53E3\u8C03\u7528\u5F02\u5E38:", error);
        setResponseStatus(evt, 200);
        return {
          code: -7,
          msg: error.message || "\u652F\u4ED8\u5B9D\u652F\u4ED8\u63A5\u53E3\u8C03\u7528\u5931\u8D25",
          data: null
        };
      }
    } else if (paymentMethod === "wx") {
      const amountNum = parseFloat(price);
      const transactionId = `wx_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      const mchOrderId = orderId || `wx_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      const { channelId: wxChannelId } = await selectProviderBySystemParam(amountNum, "wx", transactionId);
      let currentPtbBalance = 0;
      try {
        const userBalance = await sql({
          query: "SELECT platform_coins FROM users WHERE id = ?",
          values: [userId]
        });
        if (userBalance.length > 0) {
          currentPtbBalance = parseFloat(userBalance[0].platform_coins) || 0;
        }
      } catch (err) {
        console.warn("\u83B7\u53D6\u7528\u6237\u5E73\u53F0\u5E01\u4F59\u989D\u5931\u8D25:", err);
      }
      const paymentData = {
        user_id: userId,
        sub_user_id: validatedSubUserId,
        role_id: "",
        transaction_id: transactionId,
        wuid: wuid || username,
        payment_way: paymentWayName,
        payment_id: parseInt(wxChannelId) || 0,
        // 保存渠道ID到payment_id
        world_id: serverId ? parseInt(serverId) : 1,
        product_name: productName,
        product_des: productDesc || "",
        ip: "",
        amount: amountNum,
        mch_order_id: mchOrderId,
        msg: "",
        server_url: serverUrl || "",
        device: deviceImei || "",
        channel_code: userChannelCode,
        game_code: userGameCode,
        payment_status: 0,
        // 微信支付也记录平台币快照（无变化）
        ptb_before: currentPtbBalance,
        ptb_change: 0,
        ptb_after: currentPtbBalance
      };
      await insert$3(paymentData);
      console.log(`\u5FAE\u4FE1\u652F\u4ED8\u8BB0\u5F55\u5DF2\u63D2\u5165: ${transactionId}, \u6E20\u9053ID: ${wxChannelId}`);
      try {
        const systemConfig = await getSystemConfig();
        const baseUrl = systemConfig.notify_url || process.env.BASE_URL || "http://localhost:3000";
        const notifyBase = baseUrl.replace(/\/+$/, "");
        const thirdPartyResult = await callThirdPartyPayment({
          type: "wxpay",
          out_trade_no: mchOrderId,
          name: productName,
          money: amountNum.toString(),
          notify_url: `${notifyBase}/api/payment/${isCashierPayment ? "cashier-notify" : "third-party-notify"}`,
          return_url: `${systemConfig.pay_suc_url}?transaction_id=${transactionId}`,
          clientip: normalizeIPAddress(
            evt.node.req.headers["x-forwarded-for"] || evt.node.req.headers["x-real-ip"] || evt.node.req.socket.remoteAddress || "127.0.0.1"
          ),
          device: deviceForGateway,
          param: transactionId
        }, { paymentMethod, agentId, appId, gameId });
        if (thirdPartyResult.code === 1) {
          await updateOrderStatus(transactionId, 1);
          if (thirdPartyResult.trade_no) {
            await updateByTransactionId(transactionId, { mch_order_id: thirdPartyResult.trade_no });
          }
          let returnData = null;
          if (thirdPartyResult.qrcode) {
            const systemConfig2 = await getSystemConfig();
            const qrBase = systemConfig2.qrcode_url || `${process.env.BASE_URL || "http://localhost:3000"}/user/qrcode`;
            returnData = `${qrBase}?transaction_id=${transactionId}&qrcode=${encodeURIComponent(thirdPartyResult.qrcode)}`;
          } else {
            returnData = thirdPartyResult.payurl || thirdPartyResult.urlscheme || null;
          }
          setResponseStatus(evt, 200);
          return {
            code: 1,
            msg: "\u5FAE\u4FE1\u652F\u4ED8\u8BA2\u5355\u521B\u5EFA\u6210\u529F",
            data: returnData
          };
        } else {
          await updateOrderStatus(transactionId, 2);
          setResponseStatus(evt, 200);
          return {
            code: -6,
            msg: thirdPartyResult.msg || "\u5FAE\u4FE1\u652F\u4ED8\u63A5\u53E3\u8C03\u7528\u5931\u8D25",
            data: null
          };
        }
      } catch (error) {
        await updateOrderStatus(transactionId, 2);
        console.error("\u5FAE\u4FE1\u652F\u4ED8\u63A5\u53E3\u8C03\u7528\u5F02\u5E38:", error);
        setResponseStatus(evt, 200);
        return {
          code: -7,
          msg: error.message || "\u5FAE\u4FE1\u652F\u4ED8\u63A5\u53E3\u8C03\u7528\u5931\u8D25",
          data: null
        };
      }
    } else {
      console.error("\u4E0D\u652F\u6301\u7684\u652F\u4ED8\u65B9\u5F0F:", paymentMethod);
      setResponseStatus(evt, 200);
      return {
        code: -8,
        msg: `\u4E0D\u652F\u6301\u7684\u652F\u4ED8\u65B9\u5F0F: ${paymentMethod}`,
        data: null
      };
    }
  } catch (e) {
    console.error("\u652F\u4ED8\u8BF7\u6C42\u5F02\u5E38:", e);
    setResponseStatus(evt, 200);
    return {
      code: -999,
      msg: e.message || "\u652F\u4ED8\u8BF7\u6C42\u5931\u8D25",
      data: null
    };
  }
};
async function fixPaymentWay(localOrder, callbackBody, requestId) {
  if (!localOrder.payment_way || localOrder.payment_way === "\u672A\u77E5") {
    let inferredPaymentWay = null;
    if (callbackBody.type === "alipay") {
      inferredPaymentWay = "\u652F\u4ED8\u5B9D";
    } else if (callbackBody.type === "wxpay") {
      inferredPaymentWay = "\u5FAE\u4FE1";
    } else if (callbackBody.type === "bank") {
      inferredPaymentWay = "\u94F6\u8054";
    }
    if (!inferredPaymentWay && localOrder.transaction_id) {
      if (localOrder.transaction_id.startsWith("zfb_")) {
        inferredPaymentWay = "\u652F\u4ED8\u5B9D";
      } else if (localOrder.transaction_id.startsWith("wx_")) {
        inferredPaymentWay = "\u5FAE\u4FE1";
      } else if (localOrder.transaction_id.startsWith("ptb_")) {
        inferredPaymentWay = "\u5E73\u53F0\u5E01";
      } else if (localOrder.transaction_id.startsWith("kf_")) {
        inferredPaymentWay = "\u5BA2\u670D";
      }
    }
    if (!inferredPaymentWay && localOrder.mch_order_id) {
      if (localOrder.mch_order_id.startsWith("zfb_")) {
        inferredPaymentWay = "\u652F\u4ED8\u5B9D";
      } else if (localOrder.mch_order_id.startsWith("wx_")) {
        inferredPaymentWay = "\u5FAE\u4FE1";
      } else if (localOrder.mch_order_id.startsWith("ptb_")) {
        inferredPaymentWay = "\u5E73\u53F0\u5E01";
      } else if (localOrder.mch_order_id.startsWith("kf_")) {
        inferredPaymentWay = "\u5BA2\u670D";
      }
    }
    if (inferredPaymentWay) {
      console.log(`\u{1F527} [${requestId}] [\u4FEE\u590D\u652F\u4ED8\u65B9\u5F0F] \u4ECE"${localOrder.payment_way}"\u4FEE\u590D\u4E3A"${inferredPaymentWay}"`);
      await updateByTransactionId(localOrder.transaction_id || "", {
        payment_way: inferredPaymentWay
      });
    } else {
      console.log(`\u26A0\uFE0F [${requestId}] [\u4FEE\u590D\u652F\u4ED8\u65B9\u5F0F] \u65E0\u6CD5\u63A8\u65AD\u652F\u4ED8\u65B9\u5F0F\uFF0C\u4FDD\u6301\u539F\u503C: ${localOrder.payment_way}`);
    }
  }
}
async function callThirdPartyPayment(paymentData, _ctx) {
  return await executePaymentBySystemParam();
}
async function processGiftOrder(localOrder, requestId, tradeNo) {
  const serverUrlRaw = String(localOrder.server_url || "");
  if (!serverUrlRaw.startsWith("gift://")) {
    return false;
  }
  if ((localOrder.msg || "").startsWith("GIFT_")) {
    console.log(`[${requestId}] \u793C\u5305\u8BA2\u5355\u5DF2\u5904\u7406\uFF0C\u8DF3\u8FC7\u91CD\u590D\u5904\u7406: ${localOrder.transaction_id}`);
    return true;
  }
  console.log(`[${requestId}] \u793C\u5305\u8BA2\u5355\u5904\u7406 - \u5546\u6237\u8BA2\u5355\u53F7(trade_no): ${tradeNo || "\u65E0"}, \u7CFB\u7EDF\u8BA2\u5355\u53F7: ${localOrder.transaction_id}`);
  try {
    const encoded = serverUrlRaw.slice("gift://".length);
    const decoded = decodeURIComponent(encoded);
    const meta = JSON.parse(decoded || "{}");
    const packageId = Number(meta.pid || meta.package_id || meta.packageId);
    const characterUuid = String(meta.cid || meta.character_uuid || meta.characterUuid || "");
    const quantity = 1;
    const serverId = String(meta.sid || meta.server_id || meta.serverId || localOrder.world_id || 1);
    if (!packageId || !characterUuid) {
      console.error(`[${requestId}] \u793C\u5305\u8BA2\u5355\u53C2\u6570\u7F3A\u5931:`, meta);
      await updateByTransactionId(localOrder.transaction_id || "", {
        msg: "GIFT_ERROR:\u53C2\u6570\u7F3A\u5931"
      });
      return true;
    }
    const giftPackage = await getGiftPackageById(packageId);
    if (!giftPackage) {
      console.error(`[${requestId}] \u793C\u5305\u4E0D\u5B58\u5728, package_id=${packageId}`);
      await updateByTransactionId(localOrder.transaction_id || "", {
        msg: "GIFT_ERROR:\u793C\u5305\u4E0D\u5B58\u5728"
      });
      return true;
    }
    if (!characterUuid) {
      console.error(`[${requestId}] \u89D2\u8272UUID\u7F3A\u5931\uFF0C\u4EA4\u6613ID: ${localOrder.transaction_id}`);
      await updateByTransactionId(localOrder.transaction_id || "", {
        msg: "GIFT_ERROR:\u89D2\u8272UUID\u7F3A\u5931"
      });
      return true;
    }
    const checkResult = await checkUserCanPurchase(characterUuid, packageId, quantity);
    if (!checkResult.canPurchase) {
      console.error(`[${requestId}] \u793C\u5305\u9650\u8D2D\u68C0\u67E5\u5931\u8D25:`, checkResult.reason);
      await updateByTransactionId(localOrder.transaction_id || "", {
        msg: `GIFT_ERROR:${checkResult.reason}`
      });
      return true;
    }
    const isPlatformCoinPayment = (localOrder.payment_way || "") === "\u5E73\u53F0\u5E01" || (localOrder.payment_way || "").includes("\u5E73\u53F0\u5E01") || (localOrder.transaction_id || "").startsWith("ptb_") || (localOrder.mch_order_id || "").startsWith("ptb_");
    const unitPlatformCoins = Number(giftPackage.price_platform_coins || 0);
    const unitRealMoney = Number(giftPackage.price_real_money || 0);
    const unitPrice = isPlatformCoinPayment ? unitPlatformCoins : unitRealMoney;
    const totalAmount = unitPrice * quantity;
    const balanceBefore = isPlatformCoinPayment ? Number(localOrder.ptb_before || 0) : 0;
    const balanceAfter = isPlatformCoinPayment ? Number(localOrder.ptb_after || 0) : 0;
    const purchaseRemark = isPlatformCoinPayment ? `\u5E73\u53F0\u5E01\u652F\u4ED8\u6210\u529F - \u670D\u52A1\u5668${serverId}` : `\u652F\u4ED8\u6210\u529F - \u670D\u52A1\u5668${serverId}`;
    const purchaseRecord = {
      user_id: localOrder.user_id || 0,
      thirdparty_uid: characterUuid,
      // 使用角色UUID作为thirdparty_uid
      mch_order_id: tradeNo || void 0,
      // 使用第三方支付平台返回的 trade_no
      package_id: packageId,
      package_code: giftPackage.package_code,
      package_name: giftPackage.package_name,
      quantity,
      unit_price: unitPrice,
      total_amount: totalAmount,
      balance_before: balanceBefore,
      balance_after: balanceAfter,
      gift_items: giftPackage.gift_items,
      status: "paid",
      remark: purchaseRemark,
      game_delivery_status: "waiting"
    };
    console.log(`[${requestId}] \u521B\u5EFA\u793C\u5305\u8D2D\u4E70\u8BB0\u5F55 - \u5546\u6237\u8BA2\u5355\u53F7(trade_no): ${tradeNo || "\u65E0"}`);
    const insertResult = await createPurchaseRecord(purchaseRecord);
    const purchaseRecordId = insertResult == null ? void 0 : insertResult.insertId;
    await updateByTransactionId(localOrder.transaction_id || "", {
      role_id: characterUuid
    });
    if (giftPackage.is_limited) {
      await updatePackageSoldQuantity(packageId, quantity);
    }
    if (purchaseRecordId) {
      const deliveryResult = await deliverPackageToGameViaIDIP(
        purchaseRecordId,
        serverId,
        characterUuid
      );
      if (deliveryResult.success) {
        console.log(`[${requestId}] \u793C\u5305\u5DF2\u6210\u529F\u53D1\u653E, \u4EA4\u6613ID=${localOrder.transaction_id}`);
        const currentTime = getCurrentFormattedTime();
        ;
        await updateByTransactionId(localOrder.transaction_id || "", {
          notify_at: currentTime,
          msg: "\u793C\u5305\u53D1\u653E\u6210\u529F"
        });
      } else {
        console.error(`[${requestId}] \u793C\u5305\u53D1\u653E\u5931\u8D25:`, deliveryResult.message);
        await updateByTransactionId(localOrder.transaction_id || "", {
          msg: `GIFT_DELIVERY_FAILED:${deliveryResult.message || ""}`
        });
      }
    }
  } catch (error) {
    console.error(`[${requestId}] \u793C\u5305\u8BA2\u5355\u5904\u7406\u5F02\u5E38:`, error);
    await updateByTransactionId(localOrder.transaction_id || "", {
      msg: `GIFT_ERROR:${(error == null ? void 0 : error.message) || error}`
    });
  }
  return true;
}
const handleThirdPartyNotify = async (evt) => {
  var _a;
  const startTime = Date.now();
  const requestId = `notify_${startTime}_${Math.random().toString(36).substr(2, 9)}`;
  try {
    console.log(`[${requestId}] === \u5F00\u59CB\u5904\u7406\u7B2C\u4E09\u65B9\u652F\u4ED8\u56DE\u8C03 ===`);
    console.log(`[${requestId}] \u65F6\u95F4: ${(/* @__PURE__ */ new Date()).toISOString()}`);
    console.log(`[${requestId}] \u8BF7\u6C42\u65B9\u6CD5: ${evt.node.req.method}`);
    console.log(`[${requestId}] \u8BF7\u6C42URL: ${evt.node.req.url}`);
    console.log(`[${requestId}] \u8BF7\u6C42\u5934:`, evt.node.req.headers);
    const query = getQuery(evt);
    const requestMethod = (_a = evt.node.req.method) == null ? void 0 : _a.toUpperCase();
    console.log(`[${requestId}] GET\u67E5\u8BE2\u53C2\u6570:`, query);
    let body = {};
    if (requestMethod === "POST") {
      try {
        body = await readBody(evt);
        console.log(`[${requestId}] POST\u8BF7\u6C42\u4F53\u8BFB\u53D6\u6210\u529F:`, body);
      } catch (e) {
        console.log(`[${requestId}] POST body\u8BFB\u53D6\u5931\u8D25\uFF0C\u56DE\u9000\u5230GET\u53C2\u6570`);
        body = query;
      }
    } else {
      console.log(`[${requestId}] \u68C0\u6D4B\u5230GET\u8BF7\u6C42\uFF0C\u4F7F\u7528query\u53C2\u6570`);
      body = query;
    }
    console.log(`[${requestId}] \u6700\u7EC8\u4F7F\u7528\u7684\u901A\u77E5\u53C2\u6570:`, body);
    console.log(`[${requestId}] \u53C2\u6570\u7C7B\u578B:`, typeof body);
    console.log(`[${requestId}] \u53C2\u6570\u952E\u503C\u5BF9:`, Object.keys(body));
    console.log(`[${requestId}] \u8BA2\u5355\u72B6\u6001:`, body.trade_status);
    if (body.trade_status !== "TRADE_SUCCESS") {
      console.log(`[${requestId}] \u8BA2\u5355\u72B6\u6001\u4E0D\u662F\u6210\u529F:`, body.trade_status);
      setResponseStatus(evt, 200);
      return "success";
    }
    console.log(`[${requestId}] \u8BA2\u5355\u72B6\u6001\u9A8C\u8BC1\u6210\u529F!`);
    console.log(`[${requestId}] \u4F7F\u7528 trade_no \u67E5\u627E\u8BA2\u5355:`, body.trade_no);
    const result = await sql({
      query: "SELECT * FROM paymentrecords WHERE mch_order_id = ? LIMIT 1",
      values: [body.trade_no]
    });
    const localOrder = result.length > 0 ? result[0] : null;
    if (!localOrder) {
      console.error(`[${requestId}] \u8BA2\u5355\u4E0D\u5B58\u5728, trade_no:`, body.trade_no);
      setResponseStatus(evt, 200);
      return "fail";
    }
    console.log(`[${requestId}] \u8BA2\u5355\u67E5\u627E\u6210\u529F!`, { transaction_id: localOrder.transaction_id, mch_order_id: localOrder.mch_order_id });
    const dbChannelId = localOrder.payment_id;
    const channelId = String(dbChannelId || "1");
    console.log(`[${requestId}] [\u56DE\u8C03\u8FFD\u8E2A] \u8BA2\u5355\u53F7:${localOrder.transaction_id}, \u6570\u636E\u5E93\u5B58\u7684\u6E20\u9053ID:${dbChannelId}, \u6700\u7EC8\u91C7\u7528ID:${channelId}`);
    const { getProviderByChannelId } = await import('../nitro/nitro.mjs').then(function (n) { return n.ah; });
    let provider, credentials;
    try {
      const result2 = getProviderByChannelId(channelId);
      provider = result2.provider;
      credentials = result2.credentials;
      console.log(`[${requestId}] \u4F7F\u7528\u6E20\u9053 ${channelId} \u7684\u914D\u7F6E\u8FDB\u884C\u9A8C\u7B7E`);
    } catch (error) {
      console.error(`[${requestId}] \u83B7\u53D6\u652F\u4ED8\u6E20\u9053\u914D\u7F6E\u5931\u8D25:`, error);
      const { selectProviderBySystemParam: selectProviderBySystemParam2 } = await import('../nitro/nitro.mjs').then(function (n) { return n.ah; });
      const result2 = await selectProviderBySystemParam2();
      provider = result2.provider;
      credentials = result2.credentials;
      console.log(`[${requestId}] \u964D\u7EA7\u4F7F\u7528\u7CFB\u7EDF\u9ED8\u8BA4\u914D\u7F6E\u8FDB\u884C\u9A8C\u7B7E`);
    }
    const verified = provider.verify ? provider.verify(body, credentials) : true;
    if (!verified) {
      console.error(`[${requestId}] \u7B7E\u540D\u9A8C\u8BC1\u5931\u8D25! \u6E20\u9053ID: ${channelId}`);
      setResponseStatus(evt, 200);
      return "fail";
    }
    console.log(`[${requestId}] \u7B7E\u540D\u9A8C\u8BC1\u6210\u529F!`);
    console.log(`[${requestId}] \u68C0\u67E5\u8BA2\u5355\u5904\u7406\u72B6\u6001:`, localOrder.payment_status);
    if (localOrder.payment_status === 3) {
      console.log(`[${requestId}] \u8BA2\u5355\u5DF2\u5904\u7406\u8FC7:`, body.out_trade_no);
      setResponseStatus(evt, 200);
      return "success";
    }
    console.log(`[${requestId}] \u5F00\u59CB\u9A8C\u8BC1\u91D1\u989D...`);
    const notifyAmount = parseFloat(body.money);
    const orderAmount = parseFloat(String(localOrder.amount || 0));
    console.log(`[${requestId}] \u901A\u77E5\u91D1\u989D:`, notifyAmount, "\u8BA2\u5355\u91D1\u989D:", orderAmount);
    if (Math.abs(notifyAmount - orderAmount) > 0.01) {
      console.error(`[${requestId}] \u91D1\u989D\u4E0D\u5339\u914D:`, { notify: notifyAmount, order: orderAmount });
      setResponseStatus(evt, 200);
      return "fail";
    }
    console.log(`[${requestId}] \u91D1\u989D\u9A8C\u8BC1\u6210\u529F!`);
    console.log(`[${requestId}] \u5F00\u59CB\u66F4\u65B0\u8BA2\u5355\u72B6\u6001\u4E3A\u6210\u529F...`);
    console.log(`\u{1F50D} [\u7B2C\u4E09\u65B9\u56DE\u8C03] \u5F53\u524D\u8BA2\u5355\u652F\u4ED8\u65B9\u5F0F\u72B6\u6001:`, {
      transactionId: localOrder.transaction_id,
      currentPaymentWay: localOrder.payment_way,
      isPaymentWayEmpty: !localOrder.payment_way,
      isPaymentWayUnknown: localOrder.payment_way === "\u672A\u77E5",
      callbackType: body.type || "unknown",
      callbackParams: body
    });
    await fixPaymentWay(localOrder, body, requestId);
    const currentTime = getCurrentFormattedTime();
    console.log(`[${requestId}] \u66F4\u65B0\u53C2\u6570:`, {
      transaction_id: localOrder.transaction_id,
      status: 3,
      currentTime,
      trade_no: body.trade_no
    });
    await updateOrderStatus(localOrder.transaction_id || "", 3, currentTime, currentTime, body.trade_no);
    console.log(`[${requestId}] \u8BA2\u5355\u72B6\u6001\u66F4\u65B0\u5B8C\u6210!`);
    try {
      const isRoutingEnabled = await getSystemParam("payment_routing_enabled", "false");
      if (isRoutingEnabled === "true") {
        const { getOrderRuleMapping, incrementRedisUsedQuota } = await import('./paymentRouting.mjs');
        const ruleId = await getOrderRuleMapping(localOrder.transaction_id || "");
        if (ruleId) {
          await incrementRedisUsedQuota(ruleId, notifyAmount);
          console.log(`[${requestId}] \u652F\u4ED8\u8DEF\u7531 Redis \u989D\u5EA6\u5DF2\u7D2F\u52A0: \u89C4\u5219ID=${ruleId}, \u91D1\u989D=${notifyAmount}`);
        }
      }
    } catch (redisErr) {
      console.error(`[${requestId}] \u652F\u4ED8\u8DEF\u7531 Redis \u989D\u5EA6\u7D2F\u52A0\u5931\u8D25:`, redisErr);
    }
    const giftHandled = await processGiftOrder(localOrder, requestId, body.trade_no);
    if (!giftHandled) {
      console.log(`[${requestId}] \u8BBE\u7F6E\u5EF6\u8FDF\u6E38\u620F\u670D\u901A\u77E5...`);
      setTimeout(async () => {
        try {
          console.log(`[${requestId}] \u5F00\u59CB\u6267\u884C\u5EF6\u8FDF\u6E38\u620F\u670D\u901A\u77E5`);
          await notifyGameServer(
            String(localOrder.transaction_id || ""),
            String(localOrder.wuid || ""),
            String(localOrder.server_url || ""),
            void 0,
            Number(localOrder.world_id || 0)
          );
          console.log(`[${requestId}] \u5EF6\u8FDF\u6E38\u620F\u670D\u901A\u77E5\u5B8C\u6210`);
        } catch (error) {
          console.error(`[${requestId}] \u5EF6\u8FDF\u901A\u77E5\u6E38\u620F\u670D\u5931\u8D25:`, error);
        }
      }, 12e4);
    } else {
      console.log(`[${requestId}] \u793C\u5305\u8BA2\u5355\u5DF2\u5904\u7406\uFF0C\u8DF3\u8FC7\u6E38\u620F\u670D\u901A\u77E5`);
    }
    const endTime = Date.now();
    const processingTime = endTime - startTime;
    console.log(`[${requestId}] === \u7B2C\u4E09\u65B9\u652F\u4ED8\u56DE\u8C03\u5904\u7406\u5B8C\u6210\uFF0C\u8FD4\u56DEsuccess ===`);
    console.log(`[${requestId}] \u603B\u5904\u7406\u65F6\u95F4: ${processingTime}ms`);
    setResponseStatus(evt, 200);
    return "success";
  } catch (error) {
    const endTime = Date.now();
    const processingTime = endTime - startTime;
    console.error(`[${requestId}] \u5904\u7406\u7B2C\u4E09\u65B9\u652F\u4ED8\u901A\u77E5\u5931\u8D25:`, error);
    console.error(`[${requestId}] \u9519\u8BEF\u5806\u6808:`, error.stack);
    console.error(`[${requestId}] \u5904\u7406\u65F6\u95F4: ${processingTime}ms`);
    setResponseStatus(evt, 200);
    return "fail";
  }
};
const handleCashierPaymentNotify = async (evt) => {
  var _a;
  const startTime = Date.now();
  const requestId = `cashier_notify_${startTime}_${Math.random().toString(36).substr(2, 9)}`;
  try {
    console.log(`[${requestId}] === \u5F00\u59CB\u5904\u7406\u6536\u94F6\u53F0\u652F\u4ED8\u56DE\u8C03 ===`);
    console.log(`[${requestId}] \u65F6\u95F4: ${(/* @__PURE__ */ new Date()).toISOString()}`);
    console.log(`[${requestId}] \u8BF7\u6C42\u65B9\u6CD5: ${evt.node.req.method}`);
    console.log(`[${requestId}] \u8BF7\u6C42URL: ${evt.node.req.url}`);
    console.log(`[${requestId}] \u8BF7\u6C42\u5934:`, evt.node.req.headers);
    const query = getQuery(evt);
    const requestMethod = (_a = evt.node.req.method) == null ? void 0 : _a.toUpperCase();
    console.log(`[${requestId}] GET\u67E5\u8BE2\u53C2\u6570:`, query);
    let body = {};
    if (requestMethod === "POST") {
      try {
        body = await readBody(evt);
        console.log(`[${requestId}] POST\u8BF7\u6C42\u4F53\u8BFB\u53D6\u6210\u529F:`, body);
      } catch (e) {
        console.log(`[${requestId}] POST body\u8BFB\u53D6\u5931\u8D25\uFF0C\u56DE\u9000\u5230GET\u53C2\u6570`);
        body = query;
      }
    } else {
      console.log(`[${requestId}] \u68C0\u6D4B\u5230GET\u8BF7\u6C42\uFF0C\u4F7F\u7528query\u53C2\u6570`);
      body = query;
    }
    console.log(`[${requestId}] \u6700\u7EC8\u4F7F\u7528\u7684\u901A\u77E5\u53C2\u6570:`, body);
    console.log(`[${requestId}] \u53C2\u6570\u7C7B\u578B:`, typeof body);
    console.log(`[${requestId}] \u53C2\u6570\u952E\u503C\u5BF9:`, Object.keys(body));
    console.log(`[${requestId}] \u8BA2\u5355\u72B6\u6001:`, body.trade_status);
    if (body.trade_status !== "TRADE_SUCCESS") {
      console.log(`[${requestId}] \u8BA2\u5355\u72B6\u6001\u4E0D\u662F\u6210\u529F:`, body.trade_status);
      setResponseStatus(evt, 200);
      return "success";
    }
    console.log(`[${requestId}] \u8BA2\u5355\u72B6\u6001\u9A8C\u8BC1\u6210\u529F!`);
    console.log(`[${requestId}] \u4F7F\u7528 trade_no \u67E5\u627E\u8BA2\u5355:`, body.trade_no);
    const result = await sql({
      query: "SELECT * FROM paymentrecords WHERE mch_order_id = ? LIMIT 1",
      values: [body.trade_no]
    });
    const localOrder = result.length > 0 ? result[0] : null;
    if (!localOrder) {
      console.error(`[${requestId}] \u8BA2\u5355\u4E0D\u5B58\u5728, trade_no:`, body.trade_no);
      setResponseStatus(evt, 200);
      return "fail";
    }
    console.log(`[${requestId}] \u8BA2\u5355\u67E5\u627E\u6210\u529F!`, { transaction_id: localOrder.transaction_id, mch_order_id: localOrder.mch_order_id });
    const dbChannelId = localOrder.payment_id;
    const channelId = String(dbChannelId || "1");
    console.log(`[${requestId}] [\u56DE\u8C03\u8FFD\u8E2A] \u8BA2\u5355\u53F7:${localOrder.transaction_id}, \u6570\u636E\u5E93\u5B58\u7684\u6E20\u9053ID:${dbChannelId}, \u6700\u7EC8\u91C7\u7528ID:${channelId}`);
    const { getProviderByChannelId } = await import('../nitro/nitro.mjs').then(function (n) { return n.ah; });
    let provider, credentials;
    try {
      const result2 = getProviderByChannelId(channelId);
      provider = result2.provider;
      credentials = result2.credentials;
      console.log(`[${requestId}] \u4F7F\u7528\u6E20\u9053 ${channelId} \u7684\u914D\u7F6E\u8FDB\u884C\u9A8C\u7B7E`);
    } catch (error) {
      console.error(`[${requestId}] \u83B7\u53D6\u652F\u4ED8\u6E20\u9053\u914D\u7F6E\u5931\u8D25:`, error);
      const { selectProviderBySystemParam: selectProviderBySystemParam2 } = await import('../nitro/nitro.mjs').then(function (n) { return n.ah; });
      const result2 = await selectProviderBySystemParam2();
      provider = result2.provider;
      credentials = result2.credentials;
      console.log(`[${requestId}] \u964D\u7EA7\u4F7F\u7528\u7CFB\u7EDF\u9ED8\u8BA4\u914D\u7F6E\u8FDB\u884C\u9A8C\u7B7E`);
    }
    const verified = provider.verify ? provider.verify(body, credentials) : true;
    if (!verified) {
      console.error(`[${requestId}] \u7B7E\u540D\u9A8C\u8BC1\u5931\u8D25! \u6E20\u9053ID: ${channelId}`);
      setResponseStatus(evt, 200);
      return "fail";
    }
    console.log(`[${requestId}] \u7B7E\u540D\u9A8C\u8BC1\u6210\u529F!`);
    console.log(`[${requestId}] \u68C0\u67E5\u8BA2\u5355\u5904\u7406\u72B6\u6001:`, localOrder.payment_status);
    if (localOrder.payment_status === 3) {
      console.log(`[${requestId}] \u8BA2\u5355\u5DF2\u5904\u7406\u8FC7:`, body.out_trade_no);
      setResponseStatus(evt, 200);
      return "success";
    }
    console.log(`[${requestId}] \u5F00\u59CB\u9A8C\u8BC1\u91D1\u989D...`);
    const notifyAmount = parseFloat(body.money);
    const orderAmount = parseFloat(String(localOrder.amount || 0));
    console.log(`[${requestId}] \u901A\u77E5\u91D1\u989D:`, notifyAmount, "\u8BA2\u5355\u91D1\u989D:", orderAmount);
    if (Math.abs(notifyAmount - orderAmount) > 0.01) {
      console.error(`[${requestId}] \u91D1\u989D\u4E0D\u5339\u914D:`, { notify: notifyAmount, order: orderAmount });
      setResponseStatus(evt, 200);
      return "fail";
    }
    console.log(`[${requestId}] \u91D1\u989D\u9A8C\u8BC1\u6210\u529F!`);
    console.log(`[${requestId}] \u5F00\u59CB\u66F4\u65B0\u8BA2\u5355\u72B6\u6001\u4E3A\u6210\u529F...`);
    console.log(`\u{1F50D} [\u7B2C\u4E09\u65B9\u56DE\u8C03] \u5F53\u524D\u8BA2\u5355\u652F\u4ED8\u65B9\u5F0F\u72B6\u6001:`, {
      transactionId: localOrder.transaction_id,
      currentPaymentWay: localOrder.payment_way,
      isPaymentWayEmpty: !localOrder.payment_way,
      isPaymentWayUnknown: localOrder.payment_way === "\u672A\u77E5",
      callbackType: body.type || "unknown",
      callbackParams: body
    });
    await fixPaymentWay(localOrder, body, requestId);
    const currentTime = getCurrentFormattedTime();
    console.log(`[${requestId}] \u66F4\u65B0\u53C2\u6570:`, {
      transaction_id: localOrder.transaction_id,
      status: 3,
      currentTime,
      trade_no: body.trade_no
    });
    await updateOrderStatus(localOrder.transaction_id || "", 3, currentTime, currentTime, body.trade_no);
    console.log(`[${requestId}] \u8BA2\u5355\u72B6\u6001\u66F4\u65B0\u5B8C\u6210!`);
    try {
      const { getSystemParam: getSystemParam2 } = await import('../nitro/nitro.mjs').then(function (n) { return n.aj; });
      const isRoutingEnabled = await getSystemParam2("payment_routing_enabled", "false");
      if (isRoutingEnabled === "true") {
        const { getOrderRuleMapping, incrementRedisUsedQuota } = await import('./paymentRouting.mjs');
        const ruleId = await getOrderRuleMapping(localOrder.transaction_id || "");
        if (ruleId) {
          await incrementRedisUsedQuota(ruleId, orderAmount);
          console.log(`[${requestId}] \u652F\u4ED8\u8DEF\u7531 Redis \u989D\u5EA6\u5DF2\u7D2F\u52A0: \u89C4\u5219ID=${ruleId}, \u91D1\u989D=${orderAmount}`);
        }
      }
    } catch (redisErr) {
      console.error(`[${requestId}] \u652F\u4ED8\u8DEF\u7531 Redis \u989D\u5EA6\u7D2F\u52A0\u5931\u8D25:`, redisErr);
    }
    console.log(`[${requestId}] \u5F00\u59CB\u5904\u7406\u5E73\u53F0\u5E01\u5230\u8D26...`);
    try {
      const rateStr = await getSystemParam("ptb_exchange_rate", "10");
      const rate = Math.max(1, parseFloat(rateStr) || 10);
      const platformCoinsToAdd = orderAmount * rate;
      console.log(`[${requestId}] \u8BA1\u7B97\u5E73\u53F0\u5E01\u5230\u8D26\u6570\u91CF: ${orderAmount}\u5143 = ${platformCoinsToAdd}\u5E73\u53F0\u5E01`);
      const user = await sql({
        query: "SELECT id, platform_coins FROM users WHERE id = ?",
        values: [localOrder.user_id]
      });
      if (user.length === 0) {
        console.error(`[${requestId}] \u7528\u6237\u4E0D\u5B58\u5728:`, localOrder.user_id);
        setResponseStatus(evt, 200);
        return "fail";
      }
      const currentPlatformCoins = parseFloat(user[0].platform_coins) || 0;
      console.log(`[${requestId}] \u5E73\u53F0\u5E01\u4F59\u989D\u66F4\u65B0: ${currentPlatformCoins} + ${platformCoinsToAdd}`);
      const updateResult = await updatePlatformCoinsUnified(localOrder.user_id, platformCoinsToAdd, 3);
      if (!updateResult.success) {
        console.error(`[${requestId}] \u5E73\u53F0\u5E01\u4F59\u989D\u66F4\u65B0\u5931\u8D25:`, updateResult.message);
        setResponseStatus(evt, 200);
        return "fail";
      }
      const newPlatformCoins = updateResult.newBalance;
      console.log(`[${requestId}] \u5E73\u53F0\u5E01\u4F59\u989D\u66F4\u65B0\u6210\u529F!`);
      try {
        await updateByTransactionId(localOrder.transaction_id || "", {
          ptb_before: currentPlatformCoins,
          ptb_change: platformCoinsToAdd,
          ptb_after: newPlatformCoins
        });
        console.log(`[${requestId}] PaymentRecords \u5E73\u53F0\u5E01\u53D8\u5316\u5DF2\u8BB0\u5F55`, {
          before: currentPlatformCoins,
          change: platformCoinsToAdd,
          after: newPlatformCoins
        });
      } catch (e) {
        console.warn(`[${requestId}] PaymentRecords \u5E73\u53F0\u5E01\u53D8\u5316\u8BB0\u5F55\u5931\u8D25(\u4E0D\u5F71\u54CD\u5230\u8D26):`, (e == null ? void 0 : e.message) || e);
      }
      await sql({
        query: "INSERT INTO logs (log_type, log_content) VALUES (?, ?)",
        values: [
          "platform_coin_recharge",
          `\u7528\u6237ID: ${localOrder.user_id}, \u7528\u6237\u540D: ${localOrder.wuid}, \u5145\u503C\u91D1\u989D: ${orderAmount}\u5143, \u5230\u8D26\u5E73\u53F0\u5E01: ${platformCoinsToAdd}, \u4EA4\u6613ID: ${localOrder.transaction_id}`
        ]
      });
      console.log(`[${requestId}] \u5E73\u53F0\u5E01\u5145\u503C\u65E5\u5FD7\u8BB0\u5F55\u6210\u529F!`);
    } catch (platformCoinError) {
      console.error(`[${requestId}] \u5E73\u53F0\u5E01\u5230\u8D26\u5904\u7406\u5931\u8D25:`, platformCoinError);
      await sql({
        query: "INSERT INTO logs (log_type, log_content) VALUES (?, ?)",
        values: [
          "platform_coin_recharge_error",
          `\u7528\u6237ID: ${localOrder.user_id}, \u4EA4\u6613ID: ${localOrder.transaction_id}, \u9519\u8BEF: ${platformCoinError.message}`
        ]
      });
    }
    const endTime = Date.now();
    const processingTime = endTime - startTime;
    console.log(`[${requestId}] === \u6536\u94F6\u53F0\u652F\u4ED8\u56DE\u8C03\u5904\u7406\u5B8C\u6210\uFF0C\u8FD4\u56DEsuccess ===`);
    console.log(`[${requestId}] \u603B\u5904\u7406\u65F6\u95F4: ${processingTime}ms`);
    setResponseStatus(evt, 200);
    return "success";
  } catch (error) {
    const endTime = Date.now();
    const processingTime = endTime - startTime;
    console.error(`[${requestId}] \u5904\u7406\u6536\u94F6\u53F0\u652F\u4ED8\u901A\u77E5\u5931\u8D25:`, error);
    console.error(`[${requestId}] \u9519\u8BEF\u5806\u6808:`, error.stack);
    console.error(`[${requestId}] \u5904\u7406\u65F6\u95F4: ${processingTime}ms`);
    setResponseStatus(evt, 200);
    return "fail";
  }
};

export { handleThirdPartyNotify as a, generateUserLoginUrl as b, updateUserStatus as c, doPayment as d, getGameOrder as e, findByThirdpartyUid as f, getUserOrders as g, handleCashierPaymentNotify as h, insert$1 as i, user as j, gameCharacters as k, subUsers as s, upsertUserByThirdparty as u };
//# sourceMappingURL=payment.mjs.map
