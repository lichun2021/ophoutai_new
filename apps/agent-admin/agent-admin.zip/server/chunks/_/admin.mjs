import { s as sql } from '../nitro/nitro.mjs';
import 'ioredis';
import 'fs';
import 'path';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'mysql2/promise';
import '@iconify/utils';
import 'consola';

const getAdminLevel = async (id) => {
  const result = await sql({
    query: "SELECT level FROM admins WHERE id = ?",
    values: [id]
  });
  return result.length === 1 ? result[0].level : null;
};
const login = async (name, password) => {
  const result = await sql({
    query: "SELECT * FROM admins WHERE name = ? and password = ?",
    values: [name, password]
  });
  return result.length === 1 ? result[0] : null;
};
const getByName = async (name) => {
  const result = await sql({
    query: "SELECT * FROM admins WHERE name = ? LIMIT 1",
    values: [name]
  });
  return result.length === 1 ? result[0] : null;
};
const read = async () => {
  const users = await sql({
    query: "SELECT * FROM admins"
  });
  return users;
};
const updatePassword = async (id, data) => {
  await sql({
    query: "UPDATE admins SET password = ? WHERE id = ?",
    values: [data.password, id]
  });
};
const remove = async (id) => {
  await sql({
    query: "DELETE FROM admins WHERE id = ?",
    values: [id]
  });
};
const insert = async (adminData) => {
  const result = await sql({
    query: "INSERT INTO admins (level, name, password, channel_code, settlement_type, settlement_amount, settlement_amount_available, divide_rate, platform_coins, available_platform_coins, tg_account, qq_account, email, phone, is_active, allowed_channel_codes, allowed_game_ids) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
    values: [
      adminData.level,
      adminData.name,
      adminData.password,
      adminData.channel_code || "",
      adminData.settlement_type || 0,
      adminData.settlement_amount || 0,
      adminData.settlement_amount_available || 0,
      adminData.divide_rate || 0,
      adminData.platform_coins || 0,
      adminData.available_platform_coins || 0,
      adminData.tg_account || "",
      adminData.qq_account || "",
      adminData.email || "",
      adminData.phone || "",
      adminData.is_active !== void 0 ? adminData.is_active ? 1 : 0 : 1,
      JSON.stringify(adminData.allowed_channel_codes || []),
      JSON.stringify(adminData.allowed_game_ids || [])
    ]
  });
  return result;
};
const updateAdmin = async (id, adminData) => {
  const fields = [];
  const values = [];
  if (adminData.level !== void 0) {
    fields.push("level = ?");
    values.push(adminData.level);
  }
  if (adminData.name !== void 0) {
    fields.push("name = ?");
    values.push(adminData.name);
  }
  if (adminData.password !== void 0) {
    fields.push("password = ?");
    values.push(adminData.password);
  }
  if (adminData.channel_code !== void 0) {
    fields.push("channel_code = ?");
    values.push(adminData.channel_code);
  }
  if (adminData.settlement_type !== void 0) {
    fields.push("settlement_type = ?");
    values.push(adminData.settlement_type);
  }
  if (adminData.settlement_amount !== void 0) {
    fields.push("settlement_amount = ?");
    values.push(adminData.settlement_amount);
  }
  if (adminData.settlement_amount_available !== void 0) {
    fields.push("settlement_amount_available = ?");
    values.push(adminData.settlement_amount_available);
  }
  if (adminData.divide_rate !== void 0) {
    fields.push("divide_rate = ?");
    values.push(adminData.divide_rate);
  }
  if (adminData.platform_coins !== void 0) {
    fields.push("platform_coins = ?");
    values.push(adminData.platform_coins);
  }
  if (adminData.available_platform_coins !== void 0) {
    fields.push("available_platform_coins = ?");
    values.push(adminData.available_platform_coins);
  }
  if (adminData.tg_account !== void 0) {
    fields.push("tg_account = ?");
    values.push(adminData.tg_account);
  }
  if (adminData.qq_account !== void 0) {
    fields.push("qq_account = ?");
    values.push(adminData.qq_account);
  }
  if (adminData.email !== void 0) {
    fields.push("email = ?");
    values.push(adminData.email);
  }
  if (adminData.phone !== void 0) {
    fields.push("phone = ?");
    values.push(adminData.phone);
  }
  if (adminData.is_active !== void 0) {
    fields.push("is_active = ?");
    values.push(adminData.is_active ? 1 : 0);
  }
  if (adminData.allowed_channel_codes !== void 0) {
    fields.push("allowed_channel_codes = ?");
    values.push(JSON.stringify(adminData.allowed_channel_codes));
  }
  if (adminData.allowed_game_ids !== void 0) {
    fields.push("allowed_game_ids = ?");
    values.push(JSON.stringify(adminData.allowed_game_ids));
  }
  if (fields.length > 0) {
    fields.push("updated_at = NOW()");
    values.push(id);
    await sql({
      query: `UPDATE admins SET ${fields.join(", ")} WHERE id = ?`,
      values
    });
  }
};
const getAdminWithPermissions = async (id) => {
  const result = await sql({
    query: "SELECT * FROM admins WHERE id = ?",
    values: [id]
  });
  if (result.length === 1) {
    const admin = result[0];
    try {
      if (admin.allowed_channel_codes) {
        if (typeof admin.allowed_channel_codes === "string") {
          admin.allowed_channel_codes = JSON.parse(admin.allowed_channel_codes);
        } else if (!Array.isArray(admin.allowed_channel_codes)) {
          admin.allowed_channel_codes = [];
        }
      } else {
        admin.allowed_channel_codes = [];
      }
      if (admin.allowed_game_ids) {
        if (typeof admin.allowed_game_ids === "string") {
          admin.allowed_game_ids = JSON.parse(admin.allowed_game_ids);
        } else if (!Array.isArray(admin.allowed_game_ids)) {
          admin.allowed_game_ids = [];
        }
      } else {
        admin.allowed_game_ids = [];
      }
    } catch (error) {
      console.error(`JSON\u89E3\u6790\u5931\u8D25 - \u7BA1\u7406\u5458 ${admin.name}: ${error}`);
      admin.allowed_channel_codes = [];
      admin.allowed_game_ids = [];
    }
    return admin;
  }
  return null;
};
const updateChannelCodes = async (id, channelCodes) => {
  await sql({
    query: "UPDATE admins SET allowed_channel_codes = ?, updated_at = NOW() WHERE id = ?",
    values: [JSON.stringify(channelCodes), id]
  });
};
const refreshAdminPermissions = async (adminId) => {
  try {
    const admin = await getAdminWithPermissions(adminId);
    if (!admin) {
      throw new Error("\u7BA1\u7406\u5458\u4E0D\u5B58\u5728");
    }
    let channelCodes = [];
    if (admin.level === 0) {
      channelCodes = [];
    } else {
      if (admin.channel_code) {
        channelCodes.push(admin.channel_code);
      }
      if (admin.channel_code) {
        const AgentRelationships = await import('./agentRelationships.mjs');
        const childChannelCodes = await AgentRelationships.getAllChildChannelCodes(admin.channel_code);
        for (const childChannelCode of childChannelCodes) {
          if (!channelCodes.includes(childChannelCode)) {
            channelCodes.push(childChannelCode);
          }
        }
      }
    }
    await updateChannelCodes(adminId, channelCodes);
    return channelCodes;
  } catch (error) {
    console.error("\u5237\u65B0\u7BA1\u7406\u5458\u6743\u9650\u5931\u8D25:", error);
    throw error;
  }
};
const refreshAllAdminPermissions = async () => {
  try {
    const admins = await read();
    for (const admin of admins) {
      await refreshAdminPermissions(admin.id);
    }
    console.log("\u6240\u6709\u7BA1\u7406\u5458\u6743\u9650\u5237\u65B0\u5B8C\u6210");
  } catch (error) {
    console.error("\u6279\u91CF\u5237\u65B0\u6743\u9650\u5931\u8D25:", error);
    throw error;
  }
};
const cascadeRefreshUpwardPermissions = async (channelCode) => {
  try {
    const AgentRelationships = await import('./agentRelationships.mjs');
    const allAdmins = await read();
    const channelToAdmin = /* @__PURE__ */ new Map();
    allAdmins.forEach((admin) => {
      if (admin.channel_code) {
        channelToAdmin.set(admin.channel_code, admin);
      }
    });
    let currentChannelCode = channelCode;
    const visitedChannels = /* @__PURE__ */ new Set();
    const maxDepth = 10;
    let depth = 0;
    while (currentChannelCode && depth < maxDepth) {
      if (visitedChannels.has(currentChannelCode)) {
        console.log(`\u68C0\u6D4B\u5230\u5FAA\u73AF\u5F15\u7528\uFF0C\u505C\u6B62\u7EA7\u8054\u5237\u65B0: ${currentChannelCode}`);
        break;
      }
      visitedChannels.add(currentChannelCode);
      const parentChannelCode = await AgentRelationships.getParentChannelCode(currentChannelCode);
      if (parentChannelCode) {
        const parentAdmin = channelToAdmin.get(parentChannelCode);
        if (parentAdmin) {
          console.log(`\u5411\u4E0A\u7EA7\u8054\u5237\u65B0\u6743\u9650: ${parentAdmin.name} (${parentChannelCode}), \u6DF1\u5EA6: ${depth + 1}`);
          await refreshAdminPermissions(parentAdmin.id);
        } else {
          console.log(`\u672A\u627E\u5230\u6E20\u9053\u4EE3\u7801\u5BF9\u5E94\u7684\u7BA1\u7406\u5458: ${parentChannelCode}`);
        }
      }
      currentChannelCode = parentChannelCode;
      depth++;
    }
    if (depth >= maxDepth) {
      console.log(`\u5411\u4E0A\u7EA7\u8054\u5237\u65B0\u6743\u9650\u8FBE\u5230\u6700\u5927\u6DF1\u5EA6\u9650\u5236: ${maxDepth}`);
    }
    console.log(`\u5411\u4E0A\u7EA7\u8054\u5237\u65B0\u6743\u9650\u5B8C\u6210\uFF0C\u8D77\u59CB\u6E20\u9053: ${channelCode}, \u5904\u7406\u6DF1\u5EA6: ${depth}`);
  } catch (error) {
    console.error("\u5411\u4E0A\u7EA7\u8054\u5237\u65B0\u6743\u9650\u5931\u8D25:", error);
    console.log("\u7EA7\u8054\u6743\u9650\u5237\u65B0\u5931\u8D25\uFF0C\u4F46\u7EE7\u7EED\u6267\u884C\u540E\u7EED\u903B\u8F91");
  }
};
const updateGameIds = async (id, gameIds) => {
  await sql({
    query: "UPDATE admins SET allowed_game_ids = ?, updated_at = NOW() WHERE id = ?",
    values: [JSON.stringify(gameIds), id]
  });
};
const toggleAdminStatus = async (id, isActive) => {
  await sql({
    query: "UPDATE admins SET is_active = ?, updated_at = NOW() WHERE id = ?",
    values: [isActive ? 1 : 0, id]
  });
};
const getAllGames = async () => {
  const games = await sql({
    query: "SELECT id, game_name, game_code, icon_url, supported_devices, register_url, ios_download_url, android_download_url, description, is_active FROM games ORDER BY id"
  });
  return games;
};
const hasGamePermission = async (adminId, gameId) => {
  const admin = await getAdminWithPermissions(adminId);
  if (!admin) {
    return false;
  }
  if (admin.level === 0) {
    return true;
  }
  if (!admin.allowed_game_ids || admin.allowed_game_ids.length === 0) {
    return false;
  }
  return admin.allowed_game_ids.includes(gameId);
};
const canEditGamePermissions = async (adminId) => {
  const admin = await getAdminWithPermissions(adminId);
  return admin ? admin.level === 0 || admin.level === 1 : false;
};
const getManageableAdmins = async (adminId) => {
  const admin = await getAdminWithPermissions(adminId);
  if (!admin) {
    return [];
  }
  if (admin.level === 0) {
    const allAdmins = await read();
    return allAdmins.filter((a) => a.level > 0 && a.id !== adminId);
  }
  if (!admin.channel_code) {
    return [];
  }
  try {
    const AgentRelationships = await import('./agentRelationships.mjs');
    const childChannelCodes = await AgentRelationships.getDirectChildChannelCodes(admin.channel_code);
    if (childChannelCodes.length === 0) {
      return [];
    }
    const allAdmins = await read();
    return allAdmins.filter(
      (a) => a.channel_code && childChannelCodes.includes(a.channel_code) && a.id !== adminId
    );
  } catch (error) {
    console.error("\u83B7\u53D6\u53EF\u7BA1\u7406\u4EE3\u7406\u5931\u8D25:", error);
    return [];
  }
};
const getFilteredGames = async (adminId) => {
  const admin = await getAdminWithPermissions(adminId);
  const allGames = await getAllGames();
  if (!admin) {
    return [];
  }
  if (admin.level === 0) {
    return allGames;
  }
  if (!admin.allowed_game_ids || admin.allowed_game_ids.length === 0) {
    return [];
  }
  return allGames.filter((game) => admin.allowed_game_ids.includes(game.id));
};
const cascadeUpdateGamePermissionsWithNewPermissions = async (adminId, newGameIds, removedGameIds = []) => {
  const admin = await getAdminWithPermissions(adminId);
  if (!admin) {
    return;
  }
  admin.allowed_game_ids = newGameIds;
  try {
    const AgentRelationships = await import('./agentRelationships.mjs');
    let allChildChannelCodes = [];
    if (admin.level === 0) {
      const allAdmins2 = await read();
      allChildChannelCodes = allAdmins2.filter((a) => a.level > 0 && a.channel_code && a.id !== adminId).map((a) => a.channel_code);
    } else if (admin.channel_code) {
      allChildChannelCodes = await AgentRelationships.getAllChildChannelCodes(admin.channel_code);
    }
    if (allChildChannelCodes.length === 0) {
      return;
    }
    const allAdmins = await read();
    const childAdmins = allAdmins.filter(
      (a) => a.channel_code && allChildChannelCodes.includes(a.channel_code)
    );
    for (const childAdmin of childAdmins) {
      const childWithPermissions = await getAdminWithPermissions(childAdmin.id);
      if (!childWithPermissions) {
        continue;
      }
      let currentGameIds = childWithPermissions.allowed_game_ids || [];
      const originalGameIds = [...currentGameIds];
      if (removedGameIds.length > 0) {
        currentGameIds = currentGameIds.filter((gameId) => !removedGameIds.includes(gameId));
      }
      const parentGameIds = admin.allowed_game_ids || [];
      if (admin.level >= 0) {
        currentGameIds = currentGameIds.filter((gameId) => parentGameIds.includes(gameId));
      }
      const hasChanged = JSON.stringify(originalGameIds.sort()) !== JSON.stringify(currentGameIds.sort());
      if (hasChanged) {
        await updateGameIds(childAdmin.id, currentGameIds);
        console.log(`\u7EA7\u8054\u66F4\u65B0: ${childAdmin.name} (${childAdmin.channel_code}) \u6743\u9650\u4ECE [${originalGameIds.join(",")}] \u66F4\u65B0\u4E3A [${currentGameIds.join(",")}]`);
      } else {
        console.log(`\u7EA7\u8054\u66F4\u65B0: ${childAdmin.name} (${childAdmin.channel_code}) \u6743\u9650\u65E0\u53D8\u5316 [${originalGameIds.join(",")}]`);
      }
    }
  } catch (error) {
    console.error("\u7EA7\u8054\u66F4\u65B0\u6E38\u620F\u6743\u9650\u5931\u8D25:", error);
  }
};
const cascadeUpdateGamePermissions = async (adminId, removedGameIds = []) => {
  var _a;
  const admin = await getAdminWithPermissions(adminId);
  if (!admin) {
    console.log("\u7EA7\u8054\u66F4\u65B0\u5931\u8D25\uFF1A\u627E\u4E0D\u5230\u7BA1\u7406\u5458");
    return;
  }
  console.log(`\u5F00\u59CB\u7EA7\u8054\u66F4\u65B0 - \u4E0A\u7EA7: ${admin.name} (${admin.channel_code}, Level: ${admin.level})`);
  console.log(`\u4E0A\u7EA7\u5F53\u524D\u6E38\u620F\u6743\u9650: [${((_a = admin.allowed_game_ids) == null ? void 0 : _a.join(", ")) || ""}]`);
  console.log(`\u9700\u8981\u79FB\u9664\u7684\u6E38\u620F: [${removedGameIds.join(", ")}]`);
  try {
    const AgentRelationships = await import('./agentRelationships.mjs');
    let allChildChannelCodes = [];
    if (admin.level === 0) {
      const allAdmins2 = await read();
      allChildChannelCodes = allAdmins2.filter((a) => a.level > 0 && a.channel_code && a.id !== adminId).map((a) => a.channel_code);
      console.log(`\u8D85\u7EA7\u7BA1\u7406\u5458\u6A21\u5F0F - \u5F71\u54CD\u6240\u6709\u4EE3\u7406: [${allChildChannelCodes.join(", ")}]`);
    } else if (admin.channel_code) {
      allChildChannelCodes = await AgentRelationships.getAllChildChannelCodes(admin.channel_code);
      console.log(`\u666E\u901A\u4EE3\u7406\u6A21\u5F0F - \u67E5\u627E ${admin.channel_code} \u7684\u6240\u6709\u4E0B\u7EA7: [${allChildChannelCodes.join(", ")}]`);
    }
    if (allChildChannelCodes.length === 0) {
      console.log("\u6CA1\u6709\u627E\u5230\u4E0B\u7EA7\u4EE3\u7406\uFF0C\u7EA7\u8054\u66F4\u65B0\u7ED3\u675F");
      return;
    }
    const allAdmins = await read();
    const childAdmins = allAdmins.filter(
      (a) => a.channel_code && allChildChannelCodes.includes(a.channel_code)
    );
    console.log(`\u627E\u5230 ${childAdmins.length} \u4E2A\u4E0B\u7EA7\u4EE3\u7406\u9700\u8981\u66F4\u65B0`);
    for (const childAdmin of childAdmins) {
      console.log(`
\u5904\u7406\u4E0B\u7EA7\u4EE3\u7406: ${childAdmin.name} (${childAdmin.channel_code}, Level: ${childAdmin.level})`);
      const childWithPermissions = await getAdminWithPermissions(childAdmin.id);
      if (!childWithPermissions) {
        console.log(`\u8DF3\u8FC7 - \u65E0\u6CD5\u83B7\u53D6\u6743\u9650\u4FE1\u606F`);
        continue;
      }
      let currentGameIds = childWithPermissions.allowed_game_ids || [];
      const originalGameIds = [...currentGameIds];
      console.log(`\u4E0B\u7EA7\u539F\u59CB\u6743\u9650: [${originalGameIds.join(", ")}]`);
      if (removedGameIds.length > 0) {
        currentGameIds = currentGameIds.filter((gameId) => !removedGameIds.includes(gameId));
        console.log(`\u79FB\u9664\u88AB\u5220\u9664\u6E38\u620F\u540E: [${currentGameIds.join(", ")}]`);
      }
      const parentGameIds = admin.allowed_game_ids || [];
      if (admin.level >= 0) {
        const beforeFilter = [...currentGameIds];
        currentGameIds = currentGameIds.filter((gameId) => parentGameIds.includes(gameId));
        console.log(`\u4E0A\u7EA7\u6743\u9650\u9650\u5236\u524D: [${beforeFilter.join(", ")}]`);
        console.log(`\u4E0A\u7EA7\u6743\u9650\u9650\u5236\u540E: [${currentGameIds.join(", ")}]`);
      }
      const hasChanged = JSON.stringify(originalGameIds.sort()) !== JSON.stringify(currentGameIds.sort());
      console.log(`\u6743\u9650\u662F\u5426\u6709\u53D8\u5316: ${hasChanged}`);
      if (hasChanged) {
        await updateGameIds(childAdmin.id, currentGameIds);
        console.log(`\u2713 \u5DF2\u66F4\u65B0: ${childAdmin.name} (${childAdmin.channel_code}) \u7684\u6E38\u620F\u6743\u9650`);
      } else {
        console.log(`- \u65E0\u9700\u66F4\u65B0: ${childAdmin.name} (${childAdmin.channel_code}) \u7684\u6E38\u620F\u6743\u9650`);
      }
    }
    console.log(`\u7EA7\u8054\u66F4\u65B0\u5B8C\u6210 - \u5171\u5904\u7406 ${childAdmins.length} \u4E2A\u4E0B\u7EA7\u4EE3\u7406`);
  } catch (error) {
    console.error("\u7EA7\u8054\u66F4\u65B0\u6E38\u620F\u6743\u9650\u5931\u8D25:", error);
  }
};
const removeGameFromAllAdmins = async (gameId) => {
  const allAdmins = await read();
  for (const admin of allAdmins) {
    const adminWithPermissions = await getAdminWithPermissions(admin.id);
    if (!adminWithPermissions || !adminWithPermissions.allowed_game_ids) continue;
    if (adminWithPermissions.allowed_game_ids.includes(gameId)) {
      const updatedGameIds = adminWithPermissions.allowed_game_ids.filter((id) => id !== gameId);
      await updateGameIds(admin.id, updatedGameIds);
      console.log(`\u4ECE ${admin.name} (Level ${admin.level}) \u79FB\u9664\u6E38\u620F\u6743\u9650: ${gameId}`);
    }
  }
};
const syncAllGamePermissions = async () => {
  console.log("\u5F00\u59CB\u540C\u6B65\u6240\u6709\u4EE3\u7406\u7684\u6E38\u620F\u6743\u9650...");
  try {
    const AgentRelationships = await import('./agentRelationships.mjs');
    const allAdmins = await read();
    const allRelationships = await AgentRelationships.read();
    const channelToAdmin = /* @__PURE__ */ new Map();
    allAdmins.forEach((admin) => {
      if (admin.channel_code) {
        channelToAdmin.set(admin.channel_code, admin);
      }
    });
    for (const admin of allAdmins) {
      if (!admin.channel_code || admin.level === 0) {
        continue;
      }
      const adminWithPermissions = await getAdminWithPermissions(admin.id);
      if (!adminWithPermissions) continue;
      let currentGameIds = adminWithPermissions.allowed_game_ids || [];
      const parentChannelCode = await AgentRelationships.getParentChannelCode(admin.channel_code);
      if (parentChannelCode) {
        const parentAdmin = channelToAdmin.get(parentChannelCode);
        if (parentAdmin) {
          const parentWithPermissions = await getAdminWithPermissions(parentAdmin.id);
          if (parentWithPermissions) {
            const parentGameIds = parentWithPermissions.allowed_game_ids || [];
            if (parentAdmin.level > 0 && parentGameIds.length > 0) {
              const originalLength = currentGameIds.length;
              currentGameIds = currentGameIds.filter((gameId) => parentGameIds.includes(gameId));
              if (originalLength !== currentGameIds.length) {
                await updateGameIds(admin.id, currentGameIds);
                console.log(`\u540C\u6B65\u4EE3\u7406 ${admin.name} (${admin.channel_code}) \u7684\u6E38\u620F\u6743\u9650\uFF0C\u53D7\u4E0A\u7EA7 ${parentAdmin.name} (${parentChannelCode}) \u9650\u5236`);
              }
            }
          }
        }
      } else {
        const superAdmins = allAdmins.filter((a) => a.level === 0);
        if (superAdmins.length > 0) {
          console.log(`\u4EE3\u7406 ${admin.name} (${admin.channel_code}) \u6743\u9650\u4FDD\u6301\u4E0D\u53D8\uFF0C\u65E0\u76F4\u63A5\u4E0A\u7EA7`);
        }
      }
    }
    console.log("\u6240\u6709\u4EE3\u7406\u7684\u6E38\u620F\u6743\u9650\u540C\u6B65\u5B8C\u6210");
  } catch (error) {
    console.error("\u540C\u6B65\u6240\u6709\u6E38\u620F\u6743\u9650\u5931\u8D25:", error);
    throw error;
  }
};
const updateAdminPassword = async (adminId, newPassword) => {
  try {
    await sql({
      query: "UPDATE admins SET password = ?, updated_at = NOW() WHERE id = ?",
      values: [newPassword, adminId]
    });
    return true;
  } catch (error) {
    console.error("\u66F4\u65B0\u7BA1\u7406\u5458\u5BC6\u7801\u5931\u8D25:", error);
    return false;
  }
};
const updateProfile = async (adminId, profileData) => {
  try {
    const fields = [];
    const values = [];
    if (profileData.qq_account !== void 0) {
      fields.push("qq_account = ?");
      values.push(profileData.qq_account);
    }
    if (profileData.tg_account !== void 0) {
      fields.push("tg_account = ?");
      values.push(profileData.tg_account);
    }
    if (fields.length > 0) {
      fields.push("updated_at = NOW()");
      values.push(adminId);
      await sql({
        query: `UPDATE admins SET ${fields.join(", ")} WHERE id = ?`,
        values
      });
    }
    return true;
  } catch (error) {
    console.error("\u66F4\u65B0\u7BA1\u7406\u5458\u4E2A\u4EBA\u4FE1\u606F\u5931\u8D25:", error);
    return false;
  }
};
const getAdminProfile = async (adminId) => {
  try {
    const result = await sql({
      query: "SELECT id, level, name, channel_code, created_at, updated_at, settlement_type, settlement_amount, settlement_amount_available, divide_rate, tg_account, qq_account, email, phone, allowed_channel_codes, allowed_game_ids FROM admins WHERE id = ?",
      values: [adminId]
    });
    if (result.length === 1) {
      const admin = result[0];
      try {
        if (admin.allowed_channel_codes && typeof admin.allowed_channel_codes === "string") {
          admin.allowed_channel_codes = JSON.parse(admin.allowed_channel_codes);
        } else {
          admin.allowed_channel_codes = [];
        }
        if (admin.allowed_game_ids && typeof admin.allowed_game_ids === "string") {
          admin.allowed_game_ids = JSON.parse(admin.allowed_game_ids);
        } else {
          admin.allowed_game_ids = [];
        }
      } catch {
        admin.allowed_channel_codes = [];
        admin.allowed_game_ids = [];
      }
      return admin;
    }
    return null;
  } catch (error) {
    console.error("\u83B7\u53D6\u7BA1\u7406\u5458\u4E2A\u4EBA\u4FE1\u606F\u5931\u8D25:", error);
    return null;
  }
};

export { canEditGamePermissions, cascadeRefreshUpwardPermissions, cascadeUpdateGamePermissions, cascadeUpdateGamePermissionsWithNewPermissions, getAdminLevel, getAdminProfile, getAdminWithPermissions, getAllGames, getByName, getFilteredGames, getManageableAdmins, hasGamePermission, insert, login, read, refreshAdminPermissions, refreshAllAdminPermissions, remove, removeGameFromAllAdmins, syncAllGamePermissions, toggleAdminStatus, updateAdmin, updateAdminPassword, updateChannelCodes, updateGameIds, updatePassword, updateProfile };
//# sourceMappingURL=admin.mjs.map
