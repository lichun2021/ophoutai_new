import { s as sql, a as getChinaDateString } from '../nitro/nitro.mjs';
import 'ioredis';
import 'fs';
import 'path';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'mysql2/promise';
import '@iconify/utils';
import 'consola';

const formatDateForMySQL = (dateString) => {
  try {
    if (dateString.includes("T") && dateString.includes("Z")) {
      return dateString.replace("T", " ").replace("Z", "").substring(0, 19);
    }
    return dateString.substring(0, 19);
  } catch (error) {
    const now = /* @__PURE__ */ new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, "0");
    const day = String(now.getDate()).padStart(2, "0");
    const hour = String(now.getHours()).padStart(2, "0");
    const minute = String(now.getMinutes()).padStart(2, "0");
    const second = String(now.getSeconds()).padStart(2, "0");
    return `${year}-${month}-${day} ${hour}:${minute}:${second}`;
  }
};
const formatDeviceInfo = (userAgent) => {
  if (!userAgent) {
    return "Unknown";
  }
  const ua = userAgent.toLowerCase();
  if (ua.includes("mobile") || ua.includes("android") || ua.includes("iphone") || ua.includes("ipad")) {
    if (ua.includes("android")) {
      return "Mobile-Android";
    } else if (ua.includes("iphone")) {
      return "Mobile-iPhone";
    } else if (ua.includes("ipad")) {
      return "Mobile-iPad";
    } else {
      return "Mobile";
    }
  }
  if (ua.includes("windows")) {
    return "PC-Windows";
  } else if (ua.includes("mac") && !ua.includes("iphone") && !ua.includes("ipad")) {
    return "PC-Mac";
  } else if (ua.includes("linux")) {
    return "PC-Linux";
  }
  if (ua.includes("chrome")) {
    return "PC-Chrome";
  } else if (ua.includes("firefox")) {
    return "PC-Firefox";
  } else if (ua.includes("safari")) {
    return "PC-Safari";
  } else if (ua.includes("edge")) {
    return "PC-Edge";
  }
  return userAgent.substring(0, 90);
};
const recordLogin = async (loginData) => {
  const mysqlDateTime = formatDateForMySQL(loginData.login_time);
  const formattedDevice = formatDeviceInfo(loginData.device || "");
  const normalizedIp = "";
  const result = await sql({
    query: `INSERT INTO userloginlogs 
                (username, sub_user_id, sub_user_name, game_code, login_time, imei, ip_address, device, channel_code) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    values: [
      loginData.username,
      loginData.sub_user_id || null,
      loginData.sub_user_name || "",
      loginData.game_code || "",
      mysqlDateTime,
      loginData.imei || "",
      normalizedIp,
      formattedDevice,
      loginData.channel_code || ""
    ]
  });
  return result;
};
const getLoginLogs = async (page = 1, pageSize = 20, filters, allowedChannelCodes = []) => {
  const offset = (page - 1) * pageSize;
  let whereConditions = [];
  let values = [];
  if (allowedChannelCodes.length > 0) {
    whereConditions.push(`channel_code IN (${allowedChannelCodes.map(() => "?").join(",")})`);
    values.push(...allowedChannelCodes);
  }
  if (filters == null ? void 0 : filters.username) {
    whereConditions.push("username LIKE ?");
    values.push(`%${filters.username}%`);
  }
  if (filters == null ? void 0 : filters.sub_user_name) {
    whereConditions.push("sub_user_name LIKE ?");
    values.push(`%${filters.sub_user_name}%`);
  }
  if (filters == null ? void 0 : filters.game_code) {
    whereConditions.push("game_code LIKE ?");
    values.push(`%${filters.game_code}%`);
  }
  if (filters == null ? void 0 : filters.imei) {
    whereConditions.push("imei LIKE ?");
    values.push(`%${filters.imei}%`);
  }
  if (filters == null ? void 0 : filters.channel_code) {
    whereConditions.push("channel_code LIKE ?");
    values.push(`%${filters.channel_code}%`);
  }
  if (filters == null ? void 0 : filters.startDate) {
    whereConditions.push("login_time >= ?");
    values.push(filters.startDate);
  }
  if (filters == null ? void 0 : filters.endDate) {
    whereConditions.push("login_time <= ?");
    values.push(filters.endDate + " 23:59:59");
  }
  let query = "SELECT * FROM userloginlogs";
  if (whereConditions.length > 0) {
    query += " WHERE " + whereConditions.join(" AND ");
  }
  query += " ORDER BY login_time DESC LIMIT ? OFFSET ?";
  values.push(pageSize, offset);
  const result = await sql({
    query,
    values
  });
  return result;
};
const getLoginLogsCount = async (filters, allowedChannelCodes = []) => {
  let whereConditions = [];
  let values = [];
  if (allowedChannelCodes.length > 0) {
    whereConditions.push(`channel_code IN (${allowedChannelCodes.map(() => "?").join(",")})`);
    values.push(...allowedChannelCodes);
  }
  if (filters == null ? void 0 : filters.username) {
    whereConditions.push("username LIKE ?");
    values.push(`%${filters.username}%`);
  }
  if (filters == null ? void 0 : filters.sub_user_name) {
    whereConditions.push("sub_user_name LIKE ?");
    values.push(`%${filters.sub_user_name}%`);
  }
  if (filters == null ? void 0 : filters.game_code) {
    whereConditions.push("game_code LIKE ?");
    values.push(`%${filters.game_code}%`);
  }
  if (filters == null ? void 0 : filters.imei) {
    whereConditions.push("imei LIKE ?");
    values.push(`%${filters.imei}%`);
  }
  if (filters == null ? void 0 : filters.channel_code) {
    whereConditions.push("channel_code LIKE ?");
    values.push(`%${filters.channel_code}%`);
  }
  if (filters == null ? void 0 : filters.startDate) {
    whereConditions.push("login_time >= ?");
    values.push(filters.startDate);
  }
  if (filters == null ? void 0 : filters.endDate) {
    whereConditions.push("login_time <= ?");
    values.push(filters.endDate + " 23:59:59");
  }
  let query = "SELECT COUNT(*) as total FROM userloginlogs";
  if (whereConditions.length > 0) {
    query += " WHERE " + whereConditions.join(" AND ");
  }
  const result = await sql({
    query,
    values
  });
  return result[0].total;
};
const getTodayLoginStats = async () => {
  const today = getChinaDateString();
  const result = await sql({
    query: `SELECT 
                    COUNT(*) as total_logins,
                    COUNT(DISTINCT username) as unique_users
                FROM userloginlogs 
                WHERE DATE(login_time) = ?`,
    values: [today]
  });
  return result[0];
};
const getLoginStatsForDateRange = async (startDate, endDate, allowedChannelCodes = []) => {
  let whereConditions = [];
  let values = [];
  if (allowedChannelCodes.length > 0) {
    whereConditions.push(`channel_code IN (${allowedChannelCodes.map(() => "?").join(",")})`);
    values.push(...allowedChannelCodes);
  }
  if (startDate) {
    whereConditions.push("login_time >= ?");
    values.push(startDate);
  }
  if (endDate) {
    whereConditions.push("login_time <= ?");
    values.push(endDate + " 23:59:59");
  }
  let query = `SELECT 
                    COUNT(*) as total_logins,
                    COUNT(DISTINCT username) as unique_users
                FROM userloginlogs`;
  if (whereConditions.length > 0) {
    query += " WHERE " + whereConditions.join(" AND ");
  }
  const result = await sql({
    query,
    values
  });
  return result[0];
};

export { getLoginLogs, getLoginLogsCount, getLoginStatsForDateRange, getTodayLoginStats, recordLogin };
//# sourceMappingURL=userLoginLogs.mjs.map
