import { s as sql } from '../nitro/nitro.mjs';
import 'ioredis';
import 'fs';
import 'path';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'mysql2/promise';
import '@iconify/utils';
import 'consola';

const detail = async (key) => {
  const result = await sql({
    query: "SELECT * FROM systemparams WHERE `key` = ?",
    values: [key]
  });
  return result.length === 1 ? result[0] : null;
};
const read = async () => {
  const result = await sql({
    query: "SELECT * FROM systemparams ORDER BY id ASC"
  });
  return result;
};
const update = async (key, content) => {
  await sql({
    query: "UPDATE systemparams SET content = ? WHERE `key` = ?",
    values: [content, key]
  });
};
const insert = async (data) => {
  const result = await sql({
    query: "INSERT INTO systemparams (`key`, content) VALUES (?, ?)",
    values: [data.key, data.content]
  });
  return result;
};
const remove = async (key) => {
  await sql({
    query: "DELETE FROM systemparams WHERE `key` = ?",
    values: [key]
  });
};
const getOrCreate = async (key, defaultContent = "") => {
  let param = await detail(key);
  if (!param) {
    await insert({ key, content: defaultContent });
    param = await detail(key);
  }
  return param;
};
const getPaymentMessage = async () => {
  const param = await getOrCreate("payment_message", "*\u5E73\u53F0\u5E01\u8BF4\u660E\uFF1A1\u4EBA\u6C11\u5E01=1\u5E73\u53F0\u5E01\uFF0C\u4E0D\u4F1A\u8FC7\u671F\uFF0C\u53EF\u524D\u5F80\u76D2\u5B50\u6216\u5B98\u7F51\u8FDB\u884C\u5145\u503C\u3002\n\u4EB2\u7231\u7684\u73A9\u5BB6\uFF1A\u6E38\u620F\u5145\u503C\u540E\u53EF\u524D\u5F80\u76D2\u5B50\u7533\u8BF7\u798F\u5229\u54E6");
  return (param == null ? void 0 : param.content) || "";
};
const setPaymentMessage = async (content) => {
  await getOrCreate("payment_message", "");
  await update("payment_message", content);
};
const getApiDeliveryEnabled = async () => {
  const param = await getOrCreate("payment_api_delivery", "false");
  return (param == null ? void 0 : param.content) === "true";
};
const setApiDeliveryEnabled = async (enabled) => {
  await getOrCreate("payment_api_delivery", "false");
  await update("payment_api_delivery", enabled ? "true" : "false");
};
const getApiDeliveryTestRoleId = async () => {
  const param = await getOrCreate("payment_api_delivery_test_role_id", "");
  return (param == null ? void 0 : param.content) || "";
};
const setApiDeliveryTestRoleId = async (roleId) => {
  await getOrCreate("payment_api_delivery_test_role_id", "");
  await update("payment_api_delivery_test_role_id", roleId);
};
const getPaymentRefundEnabled = async () => {
  const param = await getOrCreate("payment_refund_enabled", "false");
  return (param == null ? void 0 : param.content) === "true";
};
const setPaymentRefundEnabled = async (enabled) => {
  await getOrCreate("payment_refund_enabled", "false");
  await update("payment_refund_enabled", enabled ? "true" : "false");
};

export { detail, getApiDeliveryEnabled, getApiDeliveryTestRoleId, getOrCreate, getPaymentMessage, getPaymentRefundEnabled, insert, read, remove, setApiDeliveryEnabled, setApiDeliveryTestRoleId, setPaymentMessage, setPaymentRefundEnabled, update };
//# sourceMappingURL=systemParams.mjs.map
