import { s as sql } from '../nitro/nitro.mjs';
import 'ioredis';
import 'fs';
import 'path';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'mysql2/promise';
import '@iconify/utils';
import 'consola';

const findByParentChannelCode = async (parent_channel_code) => {
  const result = await sql({
    query: "SELECT * FROM agentrelationships WHERE parent_channel_code = ? ORDER BY created_at DESC",
    values: [parent_channel_code]
  });
  return result;
};
const findByChildChannelCode = async (child_channel_code) => {
  const result = await sql({
    query: "SELECT * FROM agentrelationships WHERE child_channel_code = ? ORDER BY created_at DESC",
    values: [child_channel_code]
  });
  return result;
};
const read = async () => {
  const relationships = await sql({
    query: "SELECT * FROM agentrelationships ORDER BY created_at DESC"
  });
  return relationships;
};
const insert = async (relationshipData) => {
  const result = await sql({
    query: "INSERT INTO agentrelationships (parent_channel_code, child_channel_code) VALUES (?, ?)",
    values: [
      relationshipData.parent_channel_code,
      relationshipData.child_channel_code
    ]
  });
  return result;
};
const remove = async (id) => {
  await sql({
    query: "DELETE FROM agentrelationships WHERE id = ?",
    values: [id]
  });
};
const getAllChildChannelCodes = async (parentChannelCode) => {
  const directChildren = await findByParentChannelCode(parentChannelCode);
  let allChildren = [];
  for (const child of directChildren) {
    allChildren.push(child.child_channel_code);
    const grandChildren = await getAllChildChannelCodes(child.child_channel_code);
    allChildren = allChildren.concat(grandChildren);
  }
  return [...new Set(allChildren)];
};
const getDirectChildChannelCodes = async (parentChannelCode) => {
  const directChildren = await findByParentChannelCode(parentChannelCode);
  return directChildren.map((child) => child.child_channel_code);
};
const getParentChannelCode = async (childChannelCode) => {
  const parents = await findByChildChannelCode(childChannelCode);
  return parents.length > 0 ? parents[0].parent_channel_code : null;
};

export { findByChildChannelCode, findByParentChannelCode, getAllChildChannelCodes, getDirectChildChannelCodes, getParentChannelCode, insert, read, remove };
//# sourceMappingURL=agentRelationships.mjs.map
