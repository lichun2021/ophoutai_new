import { d as defineEventHandler, D as getRedisCluster, c as createError, r as readBody, g as getQuery, E as updateApiUrl, s as sql, i as getHeaders, F as sdkMessages, G as config, m as setResponseStatus, H as verifyThirdPartyToken, C as getSystemParam, I as selectGameIpByAmount, u as useBase, h as createRouter, k as getMethod, l as getRequestURL, J as verifySdkSign } from '../../nitro/nitro.mjs';
import { v4 } from 'uuid';
import { g as getUserOrders, u as upsertUserByThirdparty, b as generateUserLoginUrl, f as findByThirdpartyUid, i as insert, c as updateUserStatus, d as doPayment, e as getGameOrder } from '../../_/payment.mjs';
import { getAdminWithPermissions } from '../../_/admin.mjs';
import * as crypto from 'crypto';
import { GetOpenPaySetting } from '../../_/paymentSettings.mjs';
import 'ioredis';
import 'fs';
import 'path';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'mysql2/promise';
import '@iconify/utils';
import 'consola';
import '../../_/externalGiftPackage.mjs';

function getGameIp(amount) {
  const value = typeof amount === "number" && Number.isFinite(amount) ? amount : 0;
  return selectGameIpByAmount(value);
}
async function getUserZfbWxSuccessTotal(userId) {
  var _a, _b;
  const rows = await sql({
    query: `SELECT COALESCE(SUM(amount), 0) AS total
                FROM paymentrecords
                WHERE user_id = ?
                  AND payment_status = 3
                  AND payment_way IN ('\u652F\u4ED8\u5B9D', '\u5FAE\u4FE1')`,
    values: [userId]
  });
  const total = parseFloat(String((_b = (_a = rows[0]) == null ? void 0 : _a.total) != null ? _b : 0));
  return Number.isFinite(total) ? total : 0;
}
const quickreg = defineEventHandler(async (event) => {
  var _a, _b, _c, _d, _e;
  const query = getQuery(event);
  try {
    const userid = (_a = query == null ? void 0 : query.userid) != null ? _a : "";
    const token = (_b = query == null ? void 0 : query.token) != null ? _b : "";
    const sign = (_c = query == null ? void 0 : query.sign) != null ? _c : "";
    const channel = (_d = query == null ? void 0 : query.channel) != null ? _d : "";
    const apiUrl = (_e = query == null ? void 0 : query.host) != null ? _e : "";
    if (String(apiUrl).length > 10) {
      await updateApiUrl(String(apiUrl));
    }
    const result = await upsertUserByThirdparty(
      String(userid),
      String(token),
      String(sign),
      String(channel)
    );
    return {
      status: "ok",
      data: result
    };
  } catch (e) {
    return {
      status: "fail",
      msg: e.message
    };
  }
});
const checkUser = async (evt) => {
  const body = await readBody(evt);
  const user = await findByThirdpartyUid(body.userid);
  if (!user) {
    return { code: -1, msg: "\u7528\u6237\u4E0D\u5B58\u5728" };
  }
  const result = await verifyThirdPartyToken(body.token);
  return result;
};
const getNewOne = defineEventHandler(async (event) => {
  var _a, _b;
  const thirdparty_uid = (_b = (_a = event.context.params) == null ? void 0 : _a.thirdparty_uid) != null ? _b : "";
  try {
    const result = await sql({
      query: "SELECT * FROM subusers WHERE id = ?",
      values: [thirdparty_uid]
    });
    console.log("getNewOne result:", result);
    if (result.length === 0) {
      return {
        code: 404,
        data: null
      };
    }
    const subUserData = result[0];
    const responseData = {
      ...subUserData,
      uid: subUserData.wuid
      // 把 wuid 重命名为 uid
    };
    delete responseData.wuid;
    return {
      code: 200,
      data: responseData
    };
  } catch (e) {
    throw createError({
      status: 500,
      message: e.message
    });
  }
});
const getpostorders = defineEventHandler(async (event) => {
  var _a;
  try {
    const body = await readBody(event);
    const thirdparty_uid = (_a = body.thirdparty_uid) != null ? _a : "";
    if (!thirdparty_uid) {
      return {
        code: 400,
        message: "\u7F3A\u5C11\u7528\u6237ID\u53C2\u6570"
      };
    }
    const orders = await getUserOrders(thirdparty_uid);
    if (!orders || orders.length === 0) {
      return {
        code: 200,
        data: [],
        message: "\u6CA1\u6709\u627E\u5230\u7B26\u5408\u6761\u4EF6\u7684\u8BA2\u5355"
      };
    }
    const redis = getRedisCluster();
    const validOrders = [];
    for (const order of orders) {
      try {
        const transactionData = await redis.get(order.transaction_id || "");
        if (transactionData) {
          const transaction = JSON.parse(transactionData);
          if (transaction.done === 0 && transaction.haspay === 1) {
            validOrders.push({
              ...order,
              redisStatus: transaction
            });
          }
        }
      } catch (redisError) {
        console.error(`\u83B7\u53D6Redis\u6570\u636E\u51FA\u9519\uFF0C\u8BA2\u5355ID: ${order.transaction_id}`, redisError);
      }
    }
    return {
      code: 200,
      data: validOrders,
      total: validOrders.length
    };
  } catch (error) {
    console.error("\u83B7\u53D6\u8BA2\u5355\u5217\u8868\u51FA\u9519:", error);
    throw createError({
      status: 500,
      message: "\u83B7\u53D6\u8BA2\u5355\u5217\u8868\u65F6\u53D1\u751F\u9519\u8BEF"
    });
  }
});
const getorders = defineEventHandler(async (event) => {
  var _a, _b;
  try {
    const thirdparty_uid = (_b = (_a = event.context.params) == null ? void 0 : _a.thirdparty_uid) != null ? _b : "";
    if (!thirdparty_uid) {
      return {
        code: 400,
        message: "\u7F3A\u5C11\u7528\u6237ID\u53C2\u6570"
      };
    }
    const orders = await getUserOrders(thirdparty_uid);
    if (!orders || orders.length === 0) {
      return {
        code: 200,
        data: [],
        message: "\u6CA1\u6709\u627E\u5230\u7B26\u5408\u6761\u4EF6\u7684\u8BA2\u5355"
      };
    }
    const redis = getRedisCluster();
    const validOrders = [];
    for (const order of orders) {
      try {
        const transactionData = await redis.get(order.transaction_id || "");
        if (transactionData) {
          const transaction = JSON.parse(transactionData);
          if (transaction.done === 0 && transaction.haspay === 1) {
            validOrders.push({
              ...order,
              redisStatus: transaction
            });
          }
        }
      } catch (redisError) {
        console.error(`\u83B7\u53D6Redis\u6570\u636E\u51FA\u9519\uFF0C\u8BA2\u5355ID: ${order.transaction_id}`, redisError);
      }
    }
    return {
      code: 200,
      data: validOrders,
      total: validOrders.length
    };
  } catch (error) {
    console.error("\u83B7\u53D6\u8BA2\u5355\u5217\u8868\u51FA\u9519:", error);
    throw createError({
      status: 500,
      message: "\u83B7\u53D6\u8BA2\u5355\u5217\u8868\u65F6\u53D1\u751F\u9519\u8BEF"
    });
  }
});
const userLogin = async (evt) => {
  var _a;
  let loginSuccess = false;
  let userId = 0;
  let usernameToLog = "";
  try {
    const body = await readBody(evt);
    console.log("\u7528\u6237\u767B\u5F55\u8BF7\u6C42:", body);
    const { username, password, ts, sig } = body;
    usernameToLog = username || "";
    const headers = getHeaders(evt);
    const ipAddress = headers["x-forwarded-for"] || headers["x-real-ip"] || "unknown";
    const userAgent = headers["user-agent"] || "";
    if (!username) {
      console.log("\u7528\u6237\u767B\u5F55\u5931\u8D25: \u7528\u6237\u540D\u4E3A\u7A7A");
      throw createError({ status: 400, message: "\u7528\u6237\u540D\u4E0D\u80FD\u4E3A\u7A7A" });
    }
    console.log("\u6B63\u5728\u67E5\u8BE2\u7528\u6237:", username);
    let user = [];
    if (password) {
      user = await sql({
        query: "SELECT * FROM users WHERE username = ? AND password = ?",
        values: [username, password]
      });
    } else if (sig && ts) {
      const now = Math.floor(Date.now() / 1e3);
      const tsNum = parseInt(String(ts));
      if (isNaN(tsNum) || Math.abs(now - tsNum) > 300) {
        throw createError({ status: 401, message: "\u7B7E\u540D\u5DF2\u8FC7\u671F" });
      }
      const secret = await getSystemParam("user_auto_login_secret", "12w12rdf43r43t564y7");
      const expect = crypto.createHash("md5").update(`${username}${tsNum}${secret}`).digest("hex");
      console.log("\u7B7E\u540D\u9A8C\u8BC1\u8BE6\u60C5:", {
        username,
        tsNum,
        secret,
        expectSig: expect,
        receivedSig: sig,
        matched: expect === String(sig)
      });
      if (expect !== String(sig)) {
        throw createError({ status: 401, message: "\u7B7E\u540D\u65E0\u6548" });
      }
      user = await sql({
        query: "SELECT * FROM users WHERE username = ? LIMIT 1",
        values: [username]
      });
    } else {
      throw createError({ status: 400, message: "\u7F3A\u5C11\u5BC6\u7801\u6216\u7B7E\u540D" });
    }
    console.log("\u6570\u636E\u5E93\u67E5\u8BE2\u7ED3\u679C:", user.length > 0 ? "\u627E\u5230\u7528\u6237" : "\u672A\u627E\u5230\u7528\u6237");
    if (user.length === 0) {
      console.log("\u7528\u6237\u767B\u5F55\u5931\u8D25: \u7528\u6237\u540D\u6216\u5BC6\u7801\u9519\u8BEF");
      const UserLoginLogsModel2 = await import('../../_/userLoginLogs.mjs');
      await UserLoginLogsModel2.recordLogin({
        username: usernameToLog,
        game_code: "",
        login_time: (/* @__PURE__ */ new Date()).toISOString(),
        imei: "",
        ip_address: ipAddress,
        device: userAgent,
        channel_code: ""
      });
      throw createError({
        status: 401,
        message: "\u7528\u6237\u540D\u6216\u5BC6\u7801\u9519\u8BEF"
      });
    }
    const userData = user[0];
    userId = userData.id;
    let rechargeUrl = "";
    let mallUrl = "";
    if (userId) {
      const generatedUrl = await generateUserLoginUrl(userId, "/user/cashier");
      const generatedmallUrl = await generateUserLoginUrl(userId, "/user/mall");
      if (generatedUrl) {
        rechargeUrl = generatedUrl;
      }
      if (generatedmallUrl) {
        mallUrl = generatedmallUrl;
      }
    }
    const userStatus = parseInt(String((_a = userData.status) != null ? _a : "0")) || 0;
    if (userStatus === 1) {
      console.log("\u7528\u6237\u767B\u5F55\u5931\u8D25: \u7528\u6237\u5DF2\u88AB\u5C01\u53F7");
      const UserLoginLogsModel2 = await import('../../_/userLoginLogs.mjs');
      await UserLoginLogsModel2.recordLogin({
        username: userData.username || "",
        game_code: "",
        login_time: (/* @__PURE__ */ new Date()).toISOString(),
        imei: "",
        ip_address: ipAddress,
        device: userAgent,
        channel_code: userData.channel_code || ""
      });
      throw createError({
        status: 403,
        message: "\u60A8\u7684\u8D26\u53F7\u5DF2\u88AB\u5C01\u53F7\uFF0C\u65E0\u6CD5\u767B\u5F55"
      });
    }
    loginSuccess = true;
    console.log("\u7528\u6237\u767B\u5F55\u6210\u529F:", userData.username);
    const UserLoginLogsModel = await import('../../_/userLoginLogs.mjs');
    await UserLoginLogsModel.recordLogin({
      username: userData.username || "",
      game_code: "",
      // 暂时为空，后续可根据需要填充
      login_time: (/* @__PURE__ */ new Date()).toISOString(),
      imei: "",
      // 暂时为空，需要从客户端传递
      ip_address: ipAddress,
      device: userAgent,
      channel_code: userData.channel_code || ""
    });
    const { password: pwd, ...userInfo } = userData;
    const rechargeTotal = await getUserZfbWxSuccessTotal(userId);
    const response = {
      code: 200,
      message: "\u767B\u5F55\u6210\u529F",
      data: {
        user: userInfo,
        rechargeUrl,
        mallUrl,
        // 根据该用户支付宝/微信成功充值总额选择游戏服IP
        gameip: getGameIp(rechargeTotal),
        isUser: true
      }
    };
    console.log("\u7528\u6237\u767B\u5F55\u8FD4\u56DE\u6570\u636E:", response);
    return response;
  } catch (e) {
    console.error("\u7528\u6237\u767B\u5F55\u5F02\u5E38:", e);
    if (!loginSuccess && usernameToLog) {
      try {
        const headers = getHeaders(evt);
        const ipAddress = headers["x-forwarded-for"] || headers["x-real-ip"] || "unknown";
        const userAgent = headers["user-agent"] || "";
        const UserLoginLogsModel = await import('../../_/userLoginLogs.mjs');
        await UserLoginLogsModel.recordLogin({
          username: usernameToLog,
          game_code: "",
          login_time: (/* @__PURE__ */ new Date()).toISOString(),
          imei: "",
          ip_address: ipAddress,
          device: userAgent,
          channel_code: ""
        });
      } catch (logError) {
        console.error("\u8BB0\u5F55\u767B\u5F55\u65E5\u5FD7\u5931\u8D25:", logError);
      }
    }
    throw createError({
      status: e.status || 500,
      message: e.message || "\u767B\u5F55\u5931\u8D25"
    });
  }
};
const sdkLogin = async (evt) => {
  var _a, _b;
  let loginSuccess = false;
  let usernameToLog = "";
  try {
    const body = await readBody(evt);
    console.log("SDK\u767B\u5F55", { username: (body == null ? void 0 : body.z) || "", gameId: (body == null ? void 0 : body.d) || "" });
    const {
      z: username,
      // 用户名
      b: password,
      // 密码
      c: loginType,
      // 登录类型
      d: gameId,
      // 游戏ID
      e: imei,
      // 设备IMEI
      f: agentId,
      // 代理ID
      x: appId,
      // APP ID
      h: deviceInfo,
      // 设备信息
      i: quickLogin,
      // 快速登录标识
      vs: versionCode,
      // 版本号
      sid: serverId,
      // 服务器ID
      o: dpi,
      // 屏幕信息
      p: deviceName,
      // 设备名
      q: netType,
      // 网络类型
      r: providersName,
      // 运营商
      s: deviceInfo2,
      // 设备信息2
      si: isEmulator
      // 模拟器检测
    } = body;
    usernameToLog = username || "";
    const headers = getHeaders(evt);
    const ipAddress = headers["x-forwarded-for"] || headers["x-real-ip"] || "unknown";
    const userAgent = headers["user-agent"] || "";
    if (!username || !password) {
      console.log("SDK\u767B\u5F55\u5931\u8D25: \u7528\u6237\u540D\u6216\u5BC6\u7801\u4E3A\u7A7A");
      return {
        z: -1,
        x: sdkMessages.login.missingCredentials(),
        b: "",
        c: "",
        d: "",
        sid: serverId || "",
        e: Date.now().toString()
      };
    }
    console.log("\u6B63\u5728\u67E5\u8BE2SDK\u7528\u6237:", username);
    const user = await sql({
      query: "SELECT * FROM users WHERE username = ? AND password = ?",
      values: [username, password]
    });
    console.log("SDK\u6570\u636E\u5E93\u67E5\u8BE2\u7ED3\u679C:", user.length > 0 ? "\u627E\u5230\u7528\u6237" : "\u672A\u627E\u5230\u7528\u6237");
    if (user.length === 0) {
      console.log("SDK\u767B\u5F55\u5931\u8D25: \u7528\u6237\u540D\u6216\u5BC6\u7801\u9519\u8BEF");
      try {
        const UserLoginLogsModel = await import('../../_/userLoginLogs.mjs');
        await UserLoginLogsModel.recordLogin({
          username: usernameToLog,
          game_code: gameId || "",
          login_time: (/* @__PURE__ */ new Date()).toISOString(),
          imei: imei || "",
          ip_address: ipAddress,
          device: deviceInfo || userAgent,
          channel_code: agentId || ""
        });
      } catch (logError) {
        console.error("\u8BB0\u5F55SDK\u767B\u5F55\u65E5\u5FD7\u5931\u8D25:", logError);
      }
      return {
        z: -1,
        x: sdkMessages.login.invalidCredentials(),
        b: "",
        c: "",
        d: "",
        sid: serverId || "",
        e: Date.now().toString()
      };
    }
    const userData = user[0];
    const userStatus = parseInt(String((_a = userData.status) != null ? _a : "0")) || 0;
    if (userStatus === 1) {
      console.log("SDK\u767B\u5F55\u5931\u8D25: \u7528\u6237\u5DF2\u88AB\u5C01\u53F7");
      try {
        const UserLoginLogsModel = await import('../../_/userLoginLogs.mjs');
        await UserLoginLogsModel.recordLogin({
          username: userData.username || "",
          game_code: gameId || "",
          login_time: (/* @__PURE__ */ new Date()).toISOString(),
          imei: imei || "",
          ip_address: ipAddress,
          device: deviceInfo || userAgent,
          channel_code: userData.channel_code || agentId || ""
        });
      } catch (logError) {
        console.error("\u8BB0\u5F55SDK\u767B\u5F55\u65E5\u5FD7\u5931\u8D25:", logError);
      }
      return {
        z: -1,
        x: "\u60A8\u7684\u8D26\u53F7\u5DF2\u88AB\u5C01\u53F7\uFF0C\u65E0\u6CD5\u767B\u5F55",
        b: "",
        c: "",
        d: "",
        sid: serverId || "",
        e: Date.now().toString()
      };
    }
    loginSuccess = true;
    console.log("SDK\u7528\u6237\u767B\u5F55\u6210\u529F:", userData.username);
    const sign = crypto.createHash("md5").update(`${userData.username}${Date.now()}${((_b = config.thirdPartyConfig) == null ? void 0 : _b.accessKey) || "default_key"}`).digest("hex");
    const rechargeTotal = await getUserZfbWxSuccessTotal(userData.id);
    let rechargeUrl = "";
    let mallUrl = "";
    const userId = userData.id;
    if (userId) {
      const generatedUrl = await generateUserLoginUrl(userId, "/user/cashier");
      const generatedmallUrl = await generateUserLoginUrl(userId, "/user/mall");
      if (generatedUrl) {
        rechargeUrl = generatedUrl;
      }
      if (generatedmallUrl) {
        mallUrl = generatedmallUrl;
      }
    }
    const response = {
      z: 1,
      // 成功状态码
      x: sdkMessages.login.success(),
      // 消息
      b: userData.username || "",
      // 用户名
      c: userData.password || "",
      // 密码（如果需要返回）
      d: sign,
      // 签名
      sid: serverId || "",
      // 服务器ID
      e: Date.now().toString(),
      // 登录时间戳  
      gameip: getGameIp(rechargeTotal),
      // 按支付宝/微信成功充值总额选择游戏服IP
      rechargeUrl,
      mallUrl
    };
    console.log("SDK\u767B\u5F55\u8FD4\u56DE\u6570\u636E:", response);
    return response;
  } catch (e) {
    console.error("SDK\u767B\u5F55\u5F02\u5E38:", e);
    if (!loginSuccess && usernameToLog) {
      try {
        const headers = getHeaders(evt);
        const ipAddress = headers["x-forwarded-for"] || headers["x-real-ip"] || "unknown";
        const userAgent = headers["user-agent"] || "";
        const UserLoginLogsModel = await import('../../_/userLoginLogs.mjs');
        await UserLoginLogsModel.recordLogin({
          username: usernameToLog,
          game_code: "",
          login_time: (/* @__PURE__ */ new Date()).toISOString(),
          imei: "",
          ip_address: ipAddress,
          device: userAgent,
          channel_code: ""
        });
      } catch (logError) {
        console.error("\u8BB0\u5F55SDK\u767B\u5F55\u65E5\u5FD7\u5931\u8D25:", logError);
      }
    }
    return {
      z: -1,
      x: e.message || sdkMessages.login.failed(),
      b: "",
      c: "",
      d: "",
      sid: "",
      e: Date.now().toString()
    };
  }
};
const getSubAccountList = async (evt) => {
  try {
    const body = await readBody(evt);
    console.log("\u83B7\u53D6\u5B50\u8D26\u53F7\u5217\u8868\u8BF7\u6C42:", body);
    const {
      z: username,
      // 用户名
      c: gameId,
      // 游戏ID
      e: agentId,
      // 代理ID
      f: appId
      // APP ID
    } = body;
    if (!username) {
      setResponseStatus(evt, 200);
      return {
        code: "0",
        data: [],
        msg: "\u7528\u6237\u540D\u4E0D\u80FD\u4E3A\u7A7A",
        djq: null,
        ttb: null,
        discount: null,
        flb: 0
      };
    }
    const user = await sql({
      query: "SELECT id FROM users WHERE username = ?",
      values: [username]
    });
    if (user.length === 0) {
      setResponseStatus(evt, 200);
      return {
        code: "0",
        data: [],
        msg: "\u7528\u6237\u4E0D\u5B58\u5728",
        djq: null,
        ttb: null,
        discount: null,
        flb: 0
      };
    }
    const userId = user[0].id;
    const SubUsersModel = await import('../../_/payment.mjs').then(function (n) { return n.s; });
    const subUsers = await SubUsersModel.findByParentUserId(userId);
    const currentTime = Math.floor(Date.now() / 1e3);
    const subAccountList = subUsers.map((subUser) => {
      var _a, _b;
      const signString = `${subUser.id}${currentTime}${((_a = config.thirdPartyConfig) == null ? void 0 : _a.accessKey) || "default_key"}`;
      const sign = crypto.createHash("md5").update(signString).digest("hex");
      return {
        username: ((_b = subUser.id) == null ? void 0 : _b.toString()) || "",
        // 返回 subusers 的 id
        nickname: subUser.username,
        // nickname 是子账号的完整名称
        login_time: currentTime,
        sign
      };
    });
    setResponseStatus(evt, 200);
    return {
      code: "1",
      // 成功返回字符串"1"
      data: subAccountList,
      msg: "\u67E5\u8BE2\u6210\u529F",
      djq: null,
      ttb: null,
      discount: null,
      flb: 0
    };
  } catch (e) {
    console.error("\u83B7\u53D6\u5B50\u8D26\u53F7\u5217\u8868\u5F02\u5E38:", e);
    setResponseStatus(evt, 200);
    return {
      code: "0",
      data: [],
      msg: e.message || "\u83B7\u53D6\u5B50\u8D26\u53F7\u5217\u8868\u5931\u8D25",
      djq: null,
      ttb: null,
      discount: null,
      flb: 0
    };
  }
};
const addSubAccount = async (evt) => {
  try {
    const body = await readBody(evt);
    console.log("\u6DFB\u52A0\u5B50\u8D26\u53F7\u8BF7\u6C42:", body);
    const {
      z: username,
      // 主用户名
      c: gameId,
      // 游戏ID
      e: agentId,
      // 代理ID
      f: appId,
      // APP ID
      x: subAccountName
      // 子账号名称
    } = body;
    if (!username) {
      setResponseStatus(evt, 200);
      return {
        code: "0",
        data: [],
        msg: "\u7528\u6237\u540D\u4E0D\u80FD\u4E3A\u7A7A",
        djq: null,
        ttb: null,
        discount: null,
        flb: 0
      };
    }
    const user = await sql({
      query: "SELECT id FROM users WHERE username = ?",
      values: [username]
    });
    if (user.length === 0) {
      setResponseStatus(evt, 200);
      return {
        code: "0",
        data: [],
        msg: "\u4E3B\u7528\u6237\u4E0D\u5B58\u5728",
        djq: null,
        ttb: null,
        discount: null,
        flb: 0
      };
    }
    const userId = user[0].id;
    const SubUsersModel = await import('../../_/payment.mjs').then(function (n) { return n.s; });
    const subUserCount = await SubUsersModel.countByParentUserId(userId);
    if (subUserCount >= 10) {
      setResponseStatus(evt, 200);
      return {
        code: "0",
        data: [],
        msg: "\u6BCF\u4E2A\u4E3B\u8D26\u53F7\u6700\u591A\u53EA\u80FD\u521B\u5EFA10\u4E2A\u5B50\u8D26\u53F7",
        djq: null,
        ttb: null,
        discount: null,
        flb: 0
      };
    }
    const subAccountIndex = subUserCount + 1;
    const nickname = subAccountName || `\u5C0F\u53F7${subAccountIndex}`;
    const finalSubAccountName = `\u5C0F\u53F7${subAccountIndex}_${nickname}`;
    const existingSubUser = await SubUsersModel.findByUsername(finalSubAccountName);
    if (existingSubUser) {
      setResponseStatus(evt, 200);
      return {
        code: "0",
        data: [],
        msg: "\u5B50\u8D26\u53F7\u540D\u5DF2\u5B58\u5728",
        djq: null,
        ttb: null,
        discount: null,
        flb: 0
      };
    }
    const result = await SubUsersModel.insert({
      parent_user_id: userId,
      username: finalSubAccountName
    });
    const subUsers = await SubUsersModel.findByParentUserId(userId);
    const currentTime = Math.floor(Date.now() / 1e3);
    const subAccountList = subUsers.map((subUser) => {
      var _a, _b;
      const signString = `${subUser.id}${currentTime}${((_a = config.thirdPartyConfig) == null ? void 0 : _a.accessKey) || "default_key"}`;
      const sign = crypto.createHash("md5").update(signString).digest("hex");
      return {
        username: ((_b = subUser.id) == null ? void 0 : _b.toString()) || "",
        // 返回 subusers 的 id
        nickname: subUser.username,
        // nickname 是子账号的完整名称
        login_time: currentTime,
        sign
      };
    });
    setResponseStatus(evt, 200);
    return {
      code: "1",
      // 成功返回字符串"1"
      data: subAccountList,
      // 返回完整的子账号列表
      msg: "\u6DFB\u52A0\u5B50\u8D26\u53F7\u6210\u529F",
      djq: null,
      ttb: null,
      discount: null,
      flb: 0
    };
  } catch (e) {
    console.error("\u6DFB\u52A0\u5B50\u8D26\u53F7\u5F02\u5E38:", e);
    if (e.message && e.message.includes("\u4E0D\u80FD\u4E3A\u5355\u4E2A\u4E3B\u8D26\u53F7\u521B\u5EFA\u8D85\u8FC710\u4E2A\u5B50\u8D26\u53F7")) {
      setResponseStatus(evt, 200);
      return {
        code: "0",
        data: [],
        msg: "\u6BCF\u4E2A\u4E3B\u8D26\u53F7\u6700\u591A\u53EA\u80FD\u521B\u5EFA10\u4E2A\u5B50\u8D26\u53F7",
        djq: null,
        ttb: null,
        discount: null,
        flb: 0
      };
    }
    setResponseStatus(evt, 200);
    return {
      code: "0",
      data: [],
      msg: e.message || "\u6DFB\u52A0\u5B50\u8D26\u53F7\u5931\u8D25",
      djq: null,
      ttb: null,
      discount: null,
      flb: 0
    };
  }
};
const editSubAccountNickname = async (evt) => {
  var _a;
  try {
    const body = await readBody(evt);
    console.log("\u7F16\u8F91\u5B50\u8D26\u53F7\u6635\u79F0\u8BF7\u6C42:", body);
    const {
      username,
      // 主用户名
      gid: gameId,
      // 游戏ID
      cpsId: agentId,
      // 代理ID
      appid: appId,
      // APP ID
      nickname,
      // 昵称
      subAccount
      // 子账号名称
    } = body;
    if (!username || !subAccount || !nickname) {
      setResponseStatus(evt, 200);
      return {
        code: "0",
        data: null,
        msg: "\u7528\u6237\u540D\u3001\u5B50\u8D26\u53F7\u540D\u548C\u6635\u79F0\u4E0D\u80FD\u4E3A\u7A7A",
        djq: null,
        ttb: null,
        discount: null,
        flb: 0
      };
    }
    const user = await sql({
      query: "SELECT id FROM users WHERE username = ?",
      values: [username]
    });
    if (user.length === 0) {
      setResponseStatus(evt, 200);
      return {
        code: "0",
        data: null,
        msg: "\u4E3B\u7528\u6237\u4E0D\u5B58\u5728",
        djq: null,
        ttb: null,
        discount: null,
        flb: 0
      };
    }
    const userId = user[0].id;
    const subUser = await sql({
      query: "SELECT id FROM subusers WHERE username = ? AND parent_user_id = ?",
      values: [subAccount, userId]
    });
    if (subUser.length === 0) {
      setResponseStatus(evt, 200);
      return {
        code: "0",
        data: null,
        msg: "\u5B50\u8D26\u53F7\u4E0D\u5B58\u5728\u6216\u4E0D\u5C5E\u4E8E\u8BE5\u4E3B\u7528\u6237",
        djq: null,
        ttb: null,
        discount: null,
        flb: 0
      };
    }
    const subUserId = subUser[0].id;
    await sql({
      query: "UPDATE subusers SET username = ? WHERE id = ?",
      values: [nickname, subUserId]
    });
    const currentTime = Math.floor(Date.now() / 1e3);
    const signString = `${nickname}${currentTime}${((_a = config.thirdPartyConfig) == null ? void 0 : _a.accessKey) || "default_key"}`;
    const sign = crypto.createHash("md5").update(signString).digest("hex");
    setResponseStatus(evt, 200);
    return {
      code: "1",
      // 成功返回字符串"1"
      data: {
        username: nickname,
        nickname,
        login_time: currentTime,
        sign
      },
      msg: "\u7F16\u8F91\u5B50\u8D26\u53F7\u6635\u79F0\u6210\u529F",
      djq: null,
      ttb: null,
      discount: null,
      flb: 0
    };
  } catch (e) {
    console.error("\u7F16\u8F91\u5B50\u8D26\u53F7\u6635\u79F0\u5F02\u5E38:", e);
    setResponseStatus(evt, 200);
    return {
      code: "0",
      data: null,
      msg: e.message || "\u7F16\u8F91\u5B50\u8D26\u53F7\u6635\u79F0\u5931\u8D25",
      djq: null,
      ttb: null,
      discount: null,
      flb: 0
    };
  }
};
const reportRole = async (evt) => {
  var _a, _b;
  try {
    const body = await readBody(evt);
    console.log("\u89D2\u8272\u4E0A\u62A5\u8BF7\u6C42:", body);
    const {
      z: username,
      // 主用户名
      b: gameId,
      // 游戏ID
      i: appId,
      // APP ID
      xh: subUserId,
      // 子账号ID（subusers表的id）
      c: characterUuid,
      // 角色UUID（角色的唯一标识）
      d: roleName,
      // 角色名称
      e: roleLevel,
      // 角色等级
      f: serverId,
      // 服务器ID
      x: serverName,
      // 服务器名称
      h: extData
      // 扩展信息
    } = body;
    if (!username || !gameId || !subUserId || !characterUuid || !roleName || !serverName) {
      setResponseStatus(evt, 200);
      return {
        z: -1,
        x: "\u7F3A\u5C11\u5FC5\u8981\u53C2\u6570",
        b: "",
        c: "",
        d: "",
        sid: "",
        e: Date.now().toString()
      };
    }
    const user = await sql({
      query: "SELECT id FROM users WHERE username = ?",
      values: [username]
    });
    if (user.length === 0) {
      setResponseStatus(evt, 200);
      return {
        z: -1,
        x: "\u4E3B\u7528\u6237\u4E0D\u5B58\u5728",
        b: "",
        c: "",
        d: "",
        sid: "",
        e: Date.now().toString()
      };
    }
    const userId = user[0].id;
    const SubUsersModel = await import('../../_/payment.mjs').then(function (n) { return n.s; });
    const subUser = await SubUsersModel.findById(parseInt(subUserId));
    if (!subUser || subUser.parent_user_id !== userId) {
      setResponseStatus(evt, 200);
      return {
        z: -1,
        x: "\u5B50\u8D26\u53F7\u4E0D\u5B58\u5728\u6216\u4E0D\u5C5E\u4E8E\u8BE5\u4E3B\u7528\u6237",
        b: "",
        c: "",
        d: "",
        sid: "",
        e: Date.now().toString()
      };
    }
    let gameIdNum = parseInt(gameId, 10);
    if (!Number.isFinite(gameIdNum)) {
      gameIdNum = 1;
    }
    const characterData = {
      user_id: userId,
      subuser_id: subUser.id,
      game_id: gameIdNum,
      uuid: characterUuid.toString(),
      character_name: roleName.toString(),
      character_level: parseInt(roleLevel) || 1,
      server_name: serverName.toString(),
      server_id: parseInt(serverId) || 1,
      ext: extData || null
    };
    const GameCharactersModel = await import('../../_/payment.mjs').then(function (n) { return n.k; });
    const result = await GameCharactersModel.upsertByUuid(characterData);
    console.log(`\u89D2\u8272\u4E0A\u62A5\u6210\u529F: ${result.isNew ? "\u65B0\u5EFA" : "\u66F4\u65B0"} \u89D2\u8272ID=${result.id}`);
    try {
      console.log("\u89D2\u8272\u4E0A\u62A5\u6210\u529F\uFF0C\u5F00\u59CB\u81EA\u52A8\u4E0A\u62A5\u767B\u5F55\u65E5\u5FD7");
      const headers = getHeaders(evt);
      const ipAddress = headers["x-forwarded-for"] || headers["x-real-ip"] || "unknown";
      const userInfoResult = await sql({
        query: "SELECT game_code, channel_code FROM users WHERE id = ?",
        values: [userId]
      });
      if (userInfoResult.length > 0) {
        const { game_code: gameCode, channel_code: channelCode } = userInfoResult[0];
        const loginLogData = {
          username: subUser.username,
          // 使用子账号用户名
          sub_user_id: subUser.id,
          // 子账号ID
          sub_user_name: subUser.username,
          // 子账号名称（用于显示）
          game_code: gameCode,
          login_time: (/* @__PURE__ */ new Date()).toISOString(),
          imei: "",
          // 角色上报中没有设备信息
          ip_address: ipAddress,
          device: "Unknown",
          // 角色上报中没有设备类型信息
          channel_code: channelCode
          // 从users表获取channel_code
        };
        const UserLoginLogsModel = await import('../../_/userLoginLogs.mjs');
        await UserLoginLogsModel.recordLogin(loginLogData);
        console.log(`\u81EA\u52A8\u767B\u5F55\u65E5\u5FD7\u4E0A\u62A5\u6210\u529F: \u7528\u6237=${loginLogData.username}, \u6E38\u620F=${gameCode}, \u6E20\u9053=${channelCode}`);
      }
    } catch (loginLogError) {
      console.error("\u81EA\u52A8\u767B\u5F55\u65E5\u5FD7\u4E0A\u62A5\u5931\u8D25:", loginLogError);
    }
    setResponseStatus(evt, 200);
    return {
      z: 0,
      // 成功
      x: "\u89D2\u8272\u4E0A\u62A5\u6210\u529F",
      b: result.isNew ? "\u65B0\u5EFA\u89D2\u8272" : "\u66F4\u65B0\u89D2\u8272",
      c: ((_a = result.id) == null ? void 0 : _a.toString()) || "",
      d: characterData.character_name,
      sid: ((_b = characterData.server_id) == null ? void 0 : _b.toString()) || "",
      e: Date.now().toString()
    };
  } catch (e) {
    console.error("\u89D2\u8272\u4E0A\u62A5\u5F02\u5E38:", e);
    setResponseStatus(evt, 200);
    return {
      z: -1,
      x: e.message || "\u89D2\u8272\u4E0A\u62A5\u5931\u8D25",
      b: "",
      c: "",
      d: "",
      sid: "",
      e: Date.now().toString()
    };
  }
};
const updateSubUserWuid = async (evt) => {
  try {
    const body = await readBody(evt);
    console.log("\u66F4\u65B0\u5B50\u7528\u6237wuid\u8BF7\u6C42:", body);
    const { thirdparty_uid, uid } = body;
    if (!thirdparty_uid || !uid) {
      return {
        success: false,
        message: "\u7F3A\u5C11\u5FC5\u8981\u53C2\u6570\uFF1Athirdparty_uid \u548C uid \u4E0D\u80FD\u4E3A\u7A7A"
      };
    }
    const SubUsersModel = await import('../../_/payment.mjs').then(function (n) { return n.s; });
    const result = await SubUsersModel.updateWuidByThirdpartyUid(thirdparty_uid, uid);
    return result;
  } catch (error) {
    console.error("\u66F4\u65B0\u5B50\u7528\u6237wuid\u5931\u8D25:", error);
    return {
      success: false,
      message: "\u6CE8\u518C\u5931\u8D25\uFF1A\u7CFB\u7EDF\u9519\u8BEF"
    };
  }
};
const register = async (evt) => {
  try {
    const body = await readBody(evt);
    console.log("\u7528\u6237\u6CE8\u518C\u8BF7\u6C42:", body);
    if (!body.username || !body.password) {
      return {
        status: "fail",
        message: "\u7528\u6237\u540D\u548C\u5BC6\u7801\u4E0D\u80FD\u4E3A\u7A7A"
      };
    }
    if (!body.channel_code) {
      return {
        status: "fail",
        message: "\u7F3A\u5C11\u6E20\u9053\u4EE3\u7801\u53C2\u6570"
      };
    }
    if (!body.game_code) {
      return {
        status: "fail",
        message: "\u7F3A\u5C11\u6E38\u620F\u4EE3\u7801\u53C2\u6570"
      };
    }
    const thirdpartyUid = body.thirdparty_uid || `user_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const existingUserByUsername = await sql({
      query: "SELECT id FROM users WHERE username = ?",
      values: [body.username]
    });
    if (existingUserByUsername.length > 0) {
      return {
        status: "fail",
        message: "\u7528\u6237\u540D\u5DF2\u5B58\u5728"
      };
    }
    const existingUserByThirdpartyUid = await findByThirdpartyUid(thirdpartyUid);
    if (existingUserByThirdpartyUid) {
      return {
        status: "fail",
        message: "\u8BE5\u8D26\u53F7\u5DF2\u5B58\u5728"
      };
    }
    const adminResult = await sql({
      query: "SELECT id FROM admins WHERE channel_code = ? AND is_active = 1",
      values: [body.channel_code]
    });
    if (adminResult.length === 0) {
      return {
        status: "fail",
        message: "\u65E0\u6548\u7684\u6E20\u9053\u4EE3\u7801"
      };
    }
    const gameResult = await sql({
      query: "SELECT id FROM games WHERE game_code = ? AND is_active = 1",
      values: [body.game_code]
    });
    if (gameResult.length === 0) {
      return {
        status: "fail",
        message: "\u65E0\u6548\u7684\u6E38\u620F\u4EE3\u7801"
      };
    }
    const userData = {
      username: body.username.trim(),
      password: body.password,
      iphone: body.iphone || "",
      channel_code: body.channel_code,
      game_code: body.game_code,
      thirdparty_uid: thirdpartyUid,
      platform_coins: 0
    };
    const result = await insert(userData);
    console.log("\u7528\u6237\u6CE8\u518C\u6210\u529F:", { userId: result.insertId, thirdpartyUid });
    return {
      status: "success",
      message: "\u6CE8\u518C\u6210\u529F",
      data: {
        user_id: result.insertId,
        thirdparty_uid: thirdpartyUid
      }
    };
  } catch (error) {
    console.error("\u7528\u6237\u6CE8\u518C\u5931\u8D25:", error);
    if (error instanceof Error) {
      if (error.message.includes("Duplicate") && error.message.includes("username")) {
        return {
          status: "fail",
          message: "\u7528\u6237\u540D\u5DF2\u5B58\u5728"
        };
      } else if (error.message.includes("Duplicate") && error.message.includes("thirdparty_uid")) {
        return {
          status: "fail",
          message: "\u8BE5\u8D26\u53F7\u5DF2\u5B58\u5728"
        };
      }
    }
    return {
      status: "fail",
      message: "\u6CE8\u518C\u5931\u8D25\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5"
    };
  }
};
const banUser = async (evt) => {
  try {
    const body = await readBody(evt);
    const { user_id, status, admin_id } = body;
    console.log("\u5C01\u53F7/\u89E3\u5C01\u7528\u6237\u8BF7\u6C42:", body);
    if (!user_id || status === void 0) {
      return {
        status: "fail",
        message: "\u7F3A\u5C11\u7528\u6237ID\u6216\u72B6\u6001\u53C2\u6570"
      };
    }
    if (status !== 0 && status !== 1) {
      return {
        status: "fail",
        message: "\u72B6\u6001\u503C\u65E0\u6548\uFF0C\u53EA\u80FD\u662F0\uFF08\u89E3\u5C01\uFF09\u62161\uFF08\u5C01\u53F7\uFF09"
      };
    }
    if (!admin_id) {
      return {
        status: "fail",
        message: "\u9700\u8981\u7BA1\u7406\u5458\u6388\u6743"
      };
    }
    const admin = await getAdminWithPermissions(admin_id);
    if (!admin || admin.level !== 0) {
      return {
        status: "fail",
        message: "\u53EA\u6709\u8D85\u7EA7\u7BA1\u7406\u5458\u53EF\u4EE5\u5C01\u53F7\u7528\u6237"
      };
    }
    const result = await updateUserStatus(user_id, status);
    if (result.success) {
      console.log(`\u7528\u6237\u72B6\u6001\u66F4\u65B0\u6210\u529F: \u7528\u6237ID=${user_id}, \u72B6\u6001=${status}, \u64CD\u4F5C\u5458=${admin.name}`);
      return {
        status: "success",
        message: result.message,
        data: {
          user_id,
          status,
          operator: admin.name
        }
      };
    } else {
      return {
        status: "fail",
        message: result.message
      };
    }
  } catch (error) {
    console.error("\u5C01\u53F7/\u89E3\u5C01\u7528\u6237\u5931\u8D25:", error);
    return {
      status: "fail",
      message: "\u5C01\u53F7/\u89E3\u5C01\u7528\u6237\u5931\u8D25\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5"
    };
  }
};

const getPayWay = async (evt) => {
  try {
    let body = {};
    try {
      body = await readBody(evt);
    } catch {
    }
    if (!body || Object.keys(body).length === 0) {
      const q = getQuery(evt);
      body = {
        username: q.username,
        gid: q.gid ? Number(q.gid) : void 0,
        money: q.money ? Number(q.money) : void 0
      };
    }
    console.log("getPayWay \u8BF7\u6C42\u53C2\u6570:", body);
    const {
      username,
      // 用户名
      gid: gameId,
      // 游戏ID  
      money
      // 充值金额
    } = body;
    if (!money || money <= 0) {
      setResponseStatus(evt, 200);
      return {
        code: "0",
        data: [],
        msg: sdkMessages.payment.invalidAmount(),
        djq: null,
        ttb: null,
        discount: null,
        flb: 0,
        rechargeUrl: ""
      };
    }
    const paymentSettings = await GetOpenPaySetting();
    const validPaymentMethods = paymentSettings.filter((setting) => {
      if (setting.clientIsClose === 0) return false;
      return money >= setting.MinPrice && money <= setting.MaxPrice;
    });
    validPaymentMethods.sort((a, b) => (a.Sort || 0) - (b.Sort || 0));
    const paymentData = validPaymentMethods.map((setting) => {
      const baseUrl = "https://api.lzb88.com/static/paytype/";
      let icon = "";
      let amountStr = "";
      let moneyStr = "";
      let displayName = "";
      switch (setting.payment_method) {
        case "zfb":
          displayName = "\u652F\u4ED8\u5B9D";
          icon = `${baseUrl}zfb.png`;
          amountStr = `${money}\u5143`;
          moneyStr = `${money}\u5143`;
          break;
        case "wx":
          displayName = "\u5FAE\u4FE1\u652F\u4ED8";
          icon = `${baseUrl}wx.png`;
          amountStr = `${money}\u5143`;
          moneyStr = `${money}\u5143`;
          break;
        case "ptb":
          displayName = "\u5E73\u53F0\u5E01";
          icon = `${baseUrl}ptb.png`;
          amountStr = `${money}\u5E73\u53F0\u5E01`;
          moneyStr = `${money}\u5E73\u53F0\u5E01`;
          break;
        case "djq":
          displayName = "\u4EE3\u91D1\u5238";
          icon = `${baseUrl}djq.png`;
          amountStr = `${money}\u5143`;
          moneyStr = `${money}\u5143`;
          break;
        case "kf":
          displayName = "\u5BA2\u670D";
          icon = `${baseUrl}kf.png`;
          amountStr = `${money}\u5143`;
          moneyStr = `${money}\u5143`;
          break;
        case "flb":
          displayName = "\u798F\u5229\u5E01";
          icon = `${baseUrl}flb.png`;
          amountStr = `${money}\u5143`;
          moneyStr = `${money}\u5143`;
          break;
        default:
          displayName = setting.payment_method;
          icon = `${baseUrl}default.png`;
          amountStr = `${money}\u5143`;
          moneyStr = `${money}\u5143`;
      }
      return {
        name: displayName,
        // 根据paytype显示对应的中文名称
        paytype: setting.payment_method,
        // 使用支付方式作为类型
        yue: setting.payment_method === "ptb" ? "0" : "",
        icon: setting.icon_url || icon,
        // 优先使用数据库配置的图标URL
        discount: "",
        amount_str: amountStr,
        amount: money.toString(),
        money_str: moneyStr
      };
    });
    let userPlatformCoins = 0;
    let rechargeUrl = "";
    let userId = null;
    if (username) {
      try {
        console.log(`\u5F00\u59CB\u67E5\u8BE2\u7528\u6237\u5E73\u53F0\u5E01\u4F59\u989D\uFF0Cusername: ${username}`);
        const userResult = await sql({
          query: "SELECT id, username, platform_coins FROM users WHERE username = ? LIMIT 1",
          values: [username]
        });
        console.log(`\u7528\u6237\u67E5\u8BE2\u7ED3\u679C:`, userResult);
        if (userResult && userResult.length > 0) {
          userId = userResult[0].id;
          userPlatformCoins = parseFloat(userResult[0].platform_coins) || 0;
          console.log(`\u627E\u5230\u7528\u6237: ID=${userResult[0].id}, username=${userResult[0].username}, platform_coins=${userResult[0].platform_coins}`);
        } else {
          console.log(`\u672A\u627E\u5230\u7528\u6237\uFF0Cusername: ${username}`);
          const allUsersResult = await sql({
            query: "SELECT id, username, platform_coins FROM users LIMIT 5",
            values: []
          });
          console.log(`\u6570\u636E\u5E93\u4E2D\u524D5\u4E2A\u7528\u6237:`, allUsersResult);
        }
        console.log(`\u6700\u7EC8\u5E73\u53F0\u5E01\u4F59\u989D: ${userPlatformCoins}`);
      } catch (error) {
        console.log("\u83B7\u53D6\u7528\u6237\u5E73\u53F0\u5E01\u4F59\u989D\u5931\u8D25:", error);
      }
    } else {
      console.log("username\u53C2\u6570\u4E3A\u7A7A\uFF0C\u65E0\u6CD5\u67E5\u8BE2\u5E73\u53F0\u5E01\u4F59\u989D");
    }
    const platformCoinPayment = paymentData.find((p) => p.paytype === "ptb");
    if (platformCoinPayment) {
      platformCoinPayment.yue = userPlatformCoins.toString();
    }
    const SystemParamsModel = await import('../../_/systemParams.mjs');
    const paymentMessage = await SystemParamsModel.getPaymentMessage();
    setResponseStatus(evt, 200);
    return {
      code: "1",
      data: paymentData,
      msg: paymentMessage,
      djq: null,
      ttb: null,
      discount: null,
      flb: 0
    };
  } catch (error) {
    console.error("getPayWay \u63A5\u53E3\u5F02\u5E38:", error);
    setResponseStatus(evt, 200);
    return {
      code: "0",
      data: [],
      msg: error.message || sdkMessages.payment.getPaymentMethodsFailed(),
      djq: null,
      ttb: null,
      discount: null,
      flb: 0
    };
  }
};

const router = createRouter();
const withLogging = (handler, apiName) => {
  return defineEventHandler(async (event) => {
    var _a, _b, _c, _d, _e;
    const startTime = Date.now();
    const requestId = `req_${startTime}_${Math.random().toString(36).substr(2, 9)}`;
    const headers = getHeaders(event);
    const ipAddress = headers["x-forwarded-for"] || headers["x-real-ip"] || "unknown";
    const userAgent = headers["user-agent"] || "unknown";
    const method = getMethod(event);
    const url = getRequestURL(event);
    let requestBody = {};
    try {
      const parsed = await readBody(event);
      requestBody = parsed && typeof parsed === "object" ? parsed : {};
    } catch (e) {
      requestBody = {};
    }
    const maskIpForPrivacy = apiName.includes("\u767B\u5F55");
    console.log(`[IN] \u65F6\u95F4: ${(/* @__PURE__ */ new Date()).toISOString()}`);
    console.log(`[IN] \u8DEF\u5F84: ${method} ${url.pathname}${url.search}`);
    console.log(`[IN] IP: ${maskIpForPrivacy ? "[masked]" : ipAddress}, ${userAgent.split(" ")[0]}`);
    console.log(`[IN] \u53C2\u6570: \u7528\u6237\u540D=${(_a = requestBody == null ? void 0 : requestBody.z) != null ? _a : "N/A"}, \u767B\u5F55\u7C7B\u578B=${(_b = requestBody == null ? void 0 : requestBody.c) != null ? _b : "N/A"}, \u6E38\u620FID=${(_c = requestBody == null ? void 0 : requestBody.d) != null ? _c : "N/A"}, \u4EE3\u7406ID=${(_d = requestBody == null ? void 0 : requestBody.f) != null ? _d : "N/A"}`);
    console.log(`[IN] \u8BF7\u6C42\u4F53: ${JSON.stringify(requestBody)}`);
    console.log("=========================================");
    let response = {};
    let error = null;
    try {
      try {
        const tsFromBody = (_e = requestBody == null ? void 0 : requestBody.ts) != null ? _e : requestBody == null ? void 0 : requestBody.TS;
        const tsFromQuery = url.searchParams ? url.searchParams.get("ts") : void 0;
        const tsRaw = tsFromBody != null ? tsFromBody : tsFromQuery;
        if (tsRaw !== void 0 && tsRaw !== null && tsRaw !== "") {
          const n = Number(tsRaw);
          if (!Number.isFinite(n)) {
            throw new Error("\u65E0\u6548\u7684\u65F6\u95F4\u6233");
          }
          const tsSec = n > 1e12 ? Math.floor(n / 1e3) : Math.floor(n);
          const nowSec = Math.floor(Date.now() / 1e3);
          if (Math.abs(nowSec - tsSec) > 50) {
            throw new Error("\u8BF7\u6C42\u5DF2\u8FC7\u671F");
          }
        }
      } catch (tsErr) {
        throw new Error((tsErr == null ? void 0 : tsErr.message) || "\u65F6\u95F4\u6233\u6821\u9A8C\u5931\u8D25");
      }
      response = await handler(event);
    } catch (e) {
      error = e;
      if (apiName.includes("\u652F\u4ED8") || apiName.includes("getPayWay")) {
        response = {
          code: "0",
          data: [],
          msg: e.message || sdkMessages.payment.systemError(),
          djq: null,
          ttb: null,
          discount: null,
          flb: 0
        };
      } else if (apiName.includes("\u6E38\u620F\u8BA2\u5355\u67E5\u8BE2")) {
        response = {
          code: -1,
          msg: e.message || sdkMessages.payment.systemError(),
          amount: "0"
        };
      } else {
        response = {
          z: -1,
          x: e.message || sdkMessages.login.systemError(),
          b: "",
          c: "",
          d: "",
          sid: requestBody.sid || "",
          e: Date.now().toString()
        };
      }
    }
    const endTime = Date.now();
    const processingTime = endTime - startTime;
    console.log(`[OUT] ${apiName} \u8017\u65F6: ${processingTime}ms, \u72B6\u6001: ${response && response.code !== void 0 ? `\u7801=${response.code}, ${String(response.code) === "1" ? "\u6210\u529F" : "\u5931\u8D25"}` : response && response.z !== void 0 ? `\u7801=${response.z}, ${response.z === 0 ? "\u6210\u529F" : "\u5931\u8D25"}` : "\u672A\u77E5"}${error ? `, \u9519\u8BEF: ${error.message}` : ""}`);
    try {
      let logEntry = {
        requestId,
        apiName,
        timestamp: (/* @__PURE__ */ new Date()).toISOString(),
        method,
        path: url.pathname,
        clientIp: ipAddress,
        userAgent,
        processingTime,
        error: (error == null ? void 0 : error.message) || null
      };
      if (apiName.includes("\u652F\u4ED8") || apiName.includes("getPayWay")) {
        logEntry.request = {
          gameId: requestBody == null ? void 0 : requestBody.z,
          username: requestBody == null ? void 0 : requestBody.zz,
          channelId: requestBody == null ? void 0 : requestBody.b,
          agentId: requestBody == null ? void 0 : requestBody.bb,
          money: requestBody == null ? void 0 : requestBody.money
        };
        logEntry.response = response ? {
          code: response.code,
          message: response.msg,
          success: response.code === "1"
        } : { code: "undefined", message: "no response", success: false };
      } else {
        logEntry.request = {
          username: requestBody == null ? void 0 : requestBody.z,
          loginType: requestBody == null ? void 0 : requestBody.c,
          gameId: requestBody == null ? void 0 : requestBody.d,
          agentId: requestBody == null ? void 0 : requestBody.f
        };
        logEntry.response = response ? {
          code: response.z,
          message: response.x,
          success: response.z === 0
        } : { code: "undefined", message: "no response", success: false };
      }
    } catch (logError) {
      console.error("[ERROR] \u65E5\u5FD7\u8BB0\u5F55\u5931\u8D25:", logError);
    }
    return response;
  });
};
const withSign = (handler) => {
  return defineEventHandler(async (event) => {
    const ok = await verifySdkSign(event);
    if (!ok) {
      throw new Error("\u7B7E\u540D\u65E0\u6548");
    }
    return handler(event);
  });
};
const withSignAndLogging = (handler, apiName) => withLogging(withSign(handler), apiName);
router.post("/login/dologin", withSignAndLogging(sdkLogin, "SDK\u767B\u5F55\u63A5\u53E3"));
router.post("/login/xiaohao", withSignAndLogging(getSubAccountList, "\u83B7\u53D6\u5B50\u8D26\u53F7\u5217\u8868\u63A5\u53E3"));
router.post("/login/addxiaohao", withSignAndLogging(addSubAccount, "\u6DFB\u52A0\u5B50\u8D26\u53F7\u63A5\u53E3"));
router.post("/login/editSubAccount", withSignAndLogging(editSubAccountNickname, "\u7F16\u8F91\u5B50\u8D26\u53F7\u6635\u79F0\u63A5\u53E3"));
router.post("/Pay/payway", withSignAndLogging(getPayWay, "\u83B7\u53D6\u652F\u4ED8\u65B9\u5F0F\u63A5\u53E3"));
router.post("/user/setRole", withSignAndLogging(reportRole, "\u89D2\u8272\u4E0A\u62A5\u63A5\u53E3"));
router.post("/Unipay/pay", withSignAndLogging(doPayment, "\u652F\u4ED8\u8BF7\u6C42\u63A5\u53E3"));
router.post("/game/order", withSignAndLogging(getGameOrder, "\u6E38\u620F\u8BA2\u5355\u67E5\u8BE2\u63A5\u53E3"));
router.get("/user/token", withSignAndLogging(quickreg, "SDK \u83B7\u53D6\u7528\u6237token"));
router.post("/user/check", withSignAndLogging(checkUser, "SDK \u68C0\u67E5\u7528\u6237"));
router.post("/user/login", withSignAndLogging(async (event) => {
  const result = await userLogin(event);
  try {
    const ok = !!(result && result.data && result.data.user);
    if (ok) {
      event.node.res.setHeader("Set-Cookie", [
        "auth_logged_in=true; Path=/; HttpOnly; SameSite=Lax",
        "auth_is_user=true; Path=/; HttpOnly; SameSite=Lax"
      ]);
    }
  } catch {
  }
  return result;
}, "SDK \u7528\u6237\u767B\u5F55"));
router.post("/user/reg", withSignAndLogging(updateSubUserWuid, "SDK \u5728\u5B50\u5E10\u6237\u5173\u8054\u6E38\u620F wuid"));
router.post("/user/register", withSignAndLogging(register, "SDK \u7528\u6237\u6CE8\u518C\u63A5\u53E3"));
router.post("/user/ban", withSignAndLogging(banUser, "SDK \u5C01\u53F7/\u89E3\u5C01\u7528\u6237\u63A5\u53E3"));
router.get("/user/get/:thirdparty_uid", withSignAndLogging(getNewOne, "SDK \u6839\u636E\u7B2C\u4E09\u65B9\u7528\u6237ID\u83B7\u53D6\u7528\u6237\u4FE1\u606F"));
router.get("/user/undo/:thirdparty_uid", withSignAndLogging(defineEventHandler(getorders), "SDK \u83B7\u53D6\u7528\u6237\u8BA2\u5355(\u672A\u5B8C\u6210)"));
router.post("/user/undop", withSignAndLogging(defineEventHandler(getpostorders), "SDK POST\u83B7\u53D6\u7528\u6237\u8BA2\u5355(\u672A\u5B8C\u6210)"));
router.get("/utils/uuid", withSignAndLogging(async (event) => {
  const id = v4();
  return { code: "1", msg: "success", data: { uuid: id } };
}, "\u751F\u6210\u552F\u4E00UUID\u63A5\u53E3"));
router.post("/utils/uuid", withSignAndLogging(async (event) => {
  const id = v4();
  return { code: "1", msg: "success", data: { uuid: id } };
}, "\u751F\u6210\u552F\u4E00UUID\u63A5\u53E3"));
const _____ = useBase("/sdkapi", router.handler);

export { _____ as default };
//# sourceMappingURL=_..._.mjs.map
