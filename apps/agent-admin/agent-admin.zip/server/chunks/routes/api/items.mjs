import { d as defineEventHandler, g as getQuery, B as searchItems, z as getAllItems } from '../../nitro/nitro.mjs';
import 'ioredis';
import 'fs';
import 'path';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'mysql2/promise';
import '@iconify/utils';
import 'consola';

const items = defineEventHandler(async (event) => {
  const query = getQuery(event);
  const search = query.search;
  console.log("[/api/items] \u8BF7\u6C42\u53C2\u6570:", query);
  if (search && search.trim()) {
    const results = searchItems(search.trim());
    console.log("[/api/items] \u641C\u7D22\u7ED3\u679C:", results.length, "\u4E2A\u7269\u54C1");
    return {
      success: true,
      data: results
    };
  }
  const allItems = getAllItems();
  console.log("[/api/items] \u8FD4\u56DE\u6240\u6709\u7269\u54C1:", allItems.length, "\u4E2A");
  console.log("[/api/items] \u524D3\u4E2A\u7269\u54C1:", allItems.slice(0, 3));
  return {
    success: true,
    data: allItems
  };
});

export { items as default };
//# sourceMappingURL=items.mjs.map
