import { s as sql, r as readBody, c as createError, g as getQuery, d as defineEventHandler, a as getChinaDateString, b as getChinaYesterdayString, e as getHeader, f as getRouterParam, u as useBase, h as createRouter, i as getHeaders, j as signAdminSession, k as getMethod, l as getRequestURL, v as verifyApiSignature, m as setResponseStatus, n as getCookie, o as verifyAdminSession } from '../../nitro/nitro.mjs';
import { getByName, getAdminWithPermissions, refreshAdminPermissions, canEditGamePermissions, read as read$1, updateProfile as updateProfile$1, getAdminProfile, getFilteredGames as getFilteredGames$1, getAllGames as getAllGames$1, getManageableAdmins as getManageableAdmins$1, updateAdmin } from '../../_/admin.mjs';
import crypto__default from 'crypto';
import { h as handleCashierPaymentNotify, a as handleThirdPartyNotify } from '../../_/payment.mjs';
import { read as read$2, detail } from '../../_/systemParams.mjs';
import 'ioredis';
import 'fs';
import 'path';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'mysql2/promise';
import '@iconify/utils';
import 'consola';
import '../../_/externalGiftPackage.mjs';

const transferBetweenAdmins = async (fromChannelCode, toChannelCode, amount, remark = "", operatorChannelCode = "") => {
  try {
    await sql({ query: "START TRANSACTION" });
    const fromAdmin = await sql({
      query: "SELECT name, available_platform_coins FROM admins WHERE channel_code = ?",
      values: [fromChannelCode]
    });
    if (!fromAdmin.length) {
      throw new Error("\u53D1\u9001\u65B9\u4EE3\u7406\u4E0D\u5B58\u5728");
    }
    const toAdmin = await sql({
      query: "SELECT name, available_platform_coins FROM admins WHERE channel_code = ?",
      values: [toChannelCode]
    });
    if (!toAdmin.length) {
      throw new Error("\u63A5\u6536\u65B9\u4EE3\u7406\u4E0D\u5B58\u5728");
    }
    const fromBalance = parseFloat(fromAdmin[0].available_platform_coins) || 0;
    const toBalance = parseFloat(toAdmin[0].available_platform_coins) || 0;
    if (fromBalance < amount) {
      throw new Error("\u4F59\u989D\u4E0D\u8DB3");
    }
    const newFromBalance = fromBalance - amount;
    const newToBalance = toBalance + amount;
    await sql({
      query: "UPDATE admins SET available_platform_coins = ? WHERE channel_code = ?",
      values: [newFromBalance, fromChannelCode]
    });
    await sql({
      query: "UPDATE admins SET available_platform_coins = ? WHERE channel_code = ?",
      values: [newToBalance, toChannelCode]
    });
    await sql({
      query: `INSERT INTO adminplatformcointransactions 
                   (from_channel_code, to_channel_code, from_admin_name, to_admin_name, 
                    amount, from_balance_before, from_balance_after, to_balance_before, to_balance_after, 
                    remark, operator_channel_code) 
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      values: [
        fromChannelCode,
        toChannelCode,
        fromAdmin[0].name,
        toAdmin[0].name,
        amount,
        fromBalance,
        newFromBalance,
        toBalance,
        newToBalance,
        remark,
        operatorChannelCode
      ]
    });
    await sql({ query: "COMMIT" });
    return { success: true, message: "\u8F6C\u8D26\u6210\u529F" };
  } catch (error) {
    await sql({ query: "ROLLBACK" });
    throw error;
  }
};
const transferToPlayer = async (adminChannelCode, userId, amount, remark = "", operatorChannelCode = "") => {
  try {
    await sql({ query: "START TRANSACTION" });
    const admin = await sql({
      query: "SELECT name, available_platform_coins FROM admins WHERE channel_code = ?",
      values: [adminChannelCode]
    });
    if (!admin.length) {
      throw new Error("\u4EE3\u7406\u4E0D\u5B58\u5728");
    }
    const user = await sql({
      query: "SELECT id, platform_coins, channel_code, game_code, thirdparty_uid FROM users WHERE id = ?",
      values: [parseInt(userId.toString())]
    });
    if (!user.length) {
      throw new Error("\u73A9\u5BB6\u4E0D\u5B58\u5728");
    }
    const adminBalance = parseFloat(admin[0].available_platform_coins) || 0;
    const playerBalance = parseFloat(user[0].platform_coins) || 0;
    if (amount > 0) {
      if (adminBalance < amount) {
        throw new Error("\u4EE3\u7406\u4F59\u989D\u4E0D\u8DB3");
      }
    } else if (amount < 0) {
      if (playerBalance < Math.abs(amount)) {
        throw new Error("\u73A9\u5BB6\u4F59\u989D\u4E0D\u8DB3");
      }
    }
    const newAdminBalance = adminBalance - amount;
    await sql({
      query: "UPDATE admins SET available_platform_coins = ? WHERE channel_code = ?",
      values: [newAdminBalance, adminChannelCode]
    });
    const { updatePlatformCoinsUnified } = await import('../../_/payment.mjs').then(function (n) { return n.j; });
    const updateResult = await updatePlatformCoinsUnified(parseInt(userId.toString()), amount, 5);
    if (!updateResult.success) {
      throw new Error(updateResult.message || "\u66F4\u65B0\u73A9\u5BB6\u4F59\u989D\u5931\u8D25");
    }
    const newPlayerBalance = updateResult.newBalance;
    await sql({
      query: `INSERT INTO admintoplayerplatformcointransactions 
                   (admin_channel_code, admin_name, user_thirdparty_uid, user_channel_code, game_code,
                    amount, admin_balance_before, admin_balance_after, player_balance_before, player_balance_after, 
                    remark, operator_channel_code) 
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      values: [
        adminChannelCode,
        admin[0].name,
        user[0].thirdparty_uid || "",
        user[0].channel_code || "",
        user[0].game_code || "",
        amount,
        adminBalance,
        newAdminBalance,
        playerBalance,
        newPlayerBalance,
        remark,
        operatorChannelCode
      ]
    });
    const transactionId = `bonus_${Date.now()}_${userId}_${Math.random().toString(36).substr(2, 9)}`;
    const operationType = amount > 0 ? "\u7BA1\u7406\u5458\u53D1\u653E" : "\u7BA1\u7406\u5458\u6263\u9664";
    await sql({
      query: `INSERT INTO paymentrecords 
                   (user_id, sub_user_id, transaction_id, wuid, payment_way, payment_id,
                    world_id, product_name, product_des, ip, amount, mch_order_id, msg,
                    server_url, device, channel_code, game_code, payment_status,
                    ptb_before, ptb_change, ptb_after)
                   VALUES (?, ?, ?,  ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      values: [
        parseInt(userId.toString()),
        // user_id
        null,
        // sub_user_id
        transactionId,
        // transaction_id
        0,
        // wuid （管理员发放设置为'0'）
        "\u5E73\u53F0\u5E01",
        // payment_way
        0,
        // payment_id
        1,
        // world_id
        operationType,
        // product_name
        remark || `${operationType}\u5E73\u53F0\u5E01`,
        // product_des
        "",
        // ip
        Math.abs(amount),
        // amount (绝对值)
        transactionId,
        // mch_order_id
        `\u64CD\u4F5C\u4EBA:${operatorChannelCode || adminChannelCode}`,
        // msg
        "",
        // server_url
        "",
        // device
        user[0].channel_code || "",
        // channel_code
        user[0].game_code || "",
        // game_code
        3,
        // payment_status (成功)
        playerBalance,
        // ptb_before
        amount,
        // ptb_change (可能是正数或负数)
        newPlayerBalance
        // ptb_after
      ]
    });
    await sql({ query: "COMMIT" });
    const message = amount > 0 ? "\u53D1\u653E\u6210\u529F" : "\u6263\u9664\u6210\u529F";
    return { success: true, message };
  } catch (error) {
    await sql({ query: "ROLLBACK" });
    throw error;
  }
};
const getAdminTransactions = async (channelCode, page = 1, pageSize = 20) => {
  const offset = (page - 1) * pageSize;
  const transactions = await sql({
    query: `SELECT * FROM adminplatformcointransactions 
               WHERE from_channel_code = ? OR to_channel_code = ?
               ORDER BY created_at DESC 
               LIMIT ? OFFSET ?`,
    values: [channelCode, channelCode, pageSize, offset]
  });
  const countResult = await sql({
    query: `SELECT COUNT(*) as total FROM adminplatformcointransactions 
               WHERE from_channel_code = ? OR to_channel_code = ?`,
    values: [channelCode, channelCode]
  });
  return {
    data: transactions,
    total: countResult[0].total,
    page,
    pageSize
  };
};
const getAdminToPlayerTransactions$1 = async (channelCode, page = 1, pageSize = 20) => {
  const offset = (page - 1) * pageSize;
  const transactions = await sql({
    query: `SELECT 
                   apt.*,
                   g.game_name,
                   u.id as user_id
                FROM admintoplayerplatformcointransactions apt
                LEFT JOIN games g ON apt.game_code = g.game_code
                LEFT JOIN users u ON apt.user_thirdparty_uid = u.thirdparty_uid
                WHERE apt.admin_channel_code = ?
                ORDER BY apt.created_at DESC 
                LIMIT ? OFFSET ?`,
    values: [channelCode, pageSize, offset]
  });
  const countResult = await sql({
    query: `SELECT COUNT(*) as total FROM admintoplayerplatformcointransactions 
               WHERE admin_channel_code = ?`,
    values: [channelCode]
  });
  return {
    data: transactions,
    total: countResult[0].total,
    page,
    pageSize
  };
};
const getAdminBalance = async (channelCode) => {
  const result = await sql({
    query: "SELECT platform_coins, available_platform_coins FROM admins WHERE channel_code = ?",
    values: [channelCode]
  });
  if (!result.length) {
    throw new Error("\u4EE3\u7406\u4E0D\u5B58\u5728");
  }
  return {
    platform_coins: parseFloat(result[0].platform_coins) || 0,
    available_platform_coins: parseFloat(result[0].available_platform_coins) || 0
  };
};

const read = async (evt) => {
  try {
    const result = await read$1();
    const admins = Array.isArray(result) ? result : [];
    const AgentRelationships = await import('../../_/agentRelationships.mjs');
    const channelToAdmin = /* @__PURE__ */ new Map();
    admins.forEach((admin) => {
      if (admin == null ? void 0 : admin.channel_code) {
        channelToAdmin.set(admin.channel_code, admin);
      }
    });
    const cashRows = await sql({
      query: `
                SELECT channel_code, SUM(amount) AS total_amount
                FROM paymentrecords
                WHERE payment_status = 3
                  AND channel_code IS NOT NULL
                  AND channel_code <> ''
                  AND (
                    payment_way LIKE '%\u652F\u4ED8\u5B9D%' OR
                    payment_way LIKE '%\u5FAE\u4FE1%' OR
                    LOWER(payment_way) LIKE '%alipay%' OR
                    LOWER(payment_way) LIKE '%wechat%' OR
                    LOWER(payment_way) LIKE 'zfb%' OR
                    LOWER(payment_way) LIKE 'wx%'
                  )
                GROUP BY channel_code
            `
    });
    const cashMap = /* @__PURE__ */ new Map();
    cashRows.forEach((row) => {
      var _a;
      const code = row.channel_code;
      if (!code) return;
      const total = parseFloat((_a = row.total_amount) != null ? _a : 0);
      if (!Number.isFinite(total)) return;
      cashMap.set(code, total);
    });
    const parseAllowedChannels = (value) => {
      if (!value) return [];
      if (Array.isArray(value)) {
        return value.map((v) => String(v)).filter(Boolean);
      }
      if (typeof value === "string") {
        try {
          const parsed = JSON.parse(value);
          if (Array.isArray(parsed)) {
            return parsed.map((v) => String(v)).filter(Boolean);
          }
        } catch {
        }
        return value.split(",").map((v) => v.trim()).filter(Boolean);
      }
      return [];
    };
    const enrichRows = async (rows) => {
      return await Promise.all(rows.map(async (row) => {
        var _a;
        if (!row) return row;
        const allowedChannels = parseAllowedChannels(row.allowed_channel_codes);
        const allChannels = /* @__PURE__ */ new Set();
        allowedChannels.forEach((code) => {
          if (code) allChannels.add(code);
        });
        if (row.channel_code) {
          allChannels.add(row.channel_code);
        }
        let totalCash = 0;
        allChannels.forEach((code) => {
          const cashVal = cashMap.get(code);
          if (cashVal) totalCash += cashVal;
        });
        const divideRate = parseFloat((_a = row.divide_rate) != null ? _a : 0) || 0;
        const totalShare = totalCash * (divideRate / 100);
        let parentChannelCode = null;
        let parentAdminName = "";
        if (row.channel_code) {
          try {
            parentChannelCode = await AgentRelationships.getParentChannelCode(row.channel_code) || null;
            if (parentChannelCode) {
              const parentAdmin = channelToAdmin.get(parentChannelCode);
              if (parentAdmin) {
                parentAdminName = parentAdmin.name || "";
              }
            }
          } catch (error) {
            console.error("\u83B7\u53D6\u4E0A\u7EA7\u6E20\u9053\u5931\u8D25:", error);
          }
        }
        return {
          ...row,
          allowed_channel_codes: allowedChannels,
          all_channel_codes: Array.from(allChannels),
          parent_channel_code: parentChannelCode,
          parent_admin_name: parentAdminName,
          total_cash_flow: Number(totalCash.toFixed(2)),
          total_rev_share: Number(totalShare.toFixed(2))
        };
      }));
    };
    if (!evt) {
      const enriched2 = await enrichRows(admins);
      return {
        data: enriched2
      };
    }
    const authHeader = getHeader(evt, "authorization") || "";
    const currentAdminId = authHeader ? parseInt(String(authHeader)) || null : null;
    if (!currentAdminId) {
      const enriched2 = await enrichRows(admins);
      return {
        data: enriched2
      };
    }
    const currentAdmin = await getAdminWithPermissions(currentAdminId);
    if (!currentAdmin) {
      const enriched2 = await enrichRows(admins);
      return {
        data: enriched2
      };
    }
    if (currentAdmin.level === 0) {
      const enriched2 = await enrichRows(admins);
      return {
        data: enriched2
      };
    }
    const allowedChannelCodes = currentAdmin.allowed_channel_codes || [];
    const filteredRows = admins.filter((row) => {
      if (!row || !row.channel_code) return false;
      return allowedChannelCodes.includes(row.channel_code);
    });
    const enriched = await enrichRows(filteredRows);
    return {
      data: enriched
    };
  } catch (e) {
    console.error("\u7BA1\u7406\u5458\u8BFB\u53D6\u5931\u8D25:", e);
    throw createError({
      status: 500,
      message: e.message
    });
  }
};
const login = async (evt) => {
  try {
    const body = await readBody(evt);
    const name = String((body == null ? void 0 : body.name) || "").trim();
    const pwd = String((body == null ? void 0 : body.password) || "");
    const admin = await getByName(name);
    console.log("login:", admin ? { id: admin.id, level: admin.level, name: admin.name } : null, name);
    if (admin) {
      const SALT = "1a!@#33er4r";
      const inner = crypto__default.createHash("md5").update(pwd).digest("hex");
      const finalHash = crypto__default.createHash("md5").update(inner + SALT).digest("hex");
      const passOk = finalHash === admin.password;
      if (!passOk) {
        return { data: null };
      }
      const adminWithPermissions = await getAdminWithPermissions(admin.id);
      if (!adminWithPermissions) {
        return { data: null };
      }
      if (!adminWithPermissions.allowed_channel_codes || adminWithPermissions.allowed_channel_codes.length === 0) {
        const refreshedChannelCodes = await refreshAdminPermissions(admin.id);
        adminWithPermissions.allowed_channel_codes = refreshedChannelCodes;
      }
      const permissions = {
        level: adminWithPermissions.level,
        channel_codes: adminWithPermissions.allowed_channel_codes,
        game_ids: adminWithPermissions.allowed_game_ids,
        divide_rate: adminWithPermissions.divide_rate || 0,
        settlement_type: adminWithPermissions.settlement_type || 0,
        settlement_amount: adminWithPermissions.settlement_amount || 0,
        settlement_amount_available: adminWithPermissions.settlement_amount_available || 0,
        tg_account: adminWithPermissions.tg_account || "",
        qq_account: adminWithPermissions.qq_account || "",
        email: adminWithPermissions.email || "",
        phone: adminWithPermissions.phone || "",
        channel_code: adminWithPermissions.channel_code || ""
      };
      return {
        data: {
          ...adminWithPermissions,
          permissions: JSON.stringify(permissions)
        }
      };
    } else {
      return {
        data: null
      };
    }
  } catch (e) {
    console.error("\u767B\u5F55\u5931\u8D25:", e);
    throw createError({
      status: 500,
      message: e.message
    });
  }
};
const refreshPermissions = async (evt) => {
  try {
    const body = await readBody(evt);
    const { admin_id } = body;
    if (!admin_id) {
      throw createError({
        status: 400,
        message: "\u7F3A\u5C11\u7BA1\u7406\u5458ID"
      });
    }
    const channelCodes = await refreshAdminPermissions(admin_id);
    return {
      success: true,
      message: "\u6743\u9650\u5237\u65B0\u6210\u529F",
      data: {
        admin_id,
        channel_codes: channelCodes
      }
    };
  } catch (e) {
    console.error("\u5237\u65B0\u6743\u9650\u5931\u8D25:", e);
    throw createError({
      status: 500,
      message: e.message
    });
  }
};
const getAllGames = async (evt) => {
  try {
    const games = await getAllGames$1();
    return {
      success: true,
      data: games
    };
  } catch (e) {
    console.error("\u83B7\u53D6\u6E38\u620F\u5217\u8868\u5931\u8D25:", e);
    throw createError({
      status: 500,
      message: e.message
    });
  }
};
const getFilteredGames = async (evt) => {
  try {
    const body = await readBody(evt);
    const { admin_id } = body;
    if (!admin_id) {
      throw createError({
        status: 400,
        message: "\u7F3A\u5C11\u7BA1\u7406\u5458ID"
      });
    }
    const games = await getFilteredGames$1(admin_id);
    return {
      success: true,
      data: games
    };
  } catch (e) {
    console.error("\u83B7\u53D6\u8FC7\u6EE4\u6E38\u620F\u5217\u8868\u5931\u8D25:", e);
    throw createError({
      status: 500,
      message: e.message
    });
  }
};
const getManageableAdmins = async (evt) => {
  try {
    const body = await readBody(evt);
    const { admin_id } = body;
    if (!admin_id) {
      throw createError({
        status: 400,
        message: "\u7F3A\u5C11\u7BA1\u7406\u5458ID"
      });
    }
    const canEdit = await canEditGamePermissions(admin_id);
    if (!canEdit) {
      throw createError({
        status: 403,
        message: "\u65E0\u6743\u9650\u7F16\u8F91\u6E38\u620F\u6743\u9650"
      });
    }
    const manageableAdmins = await getManageableAdmins$1(admin_id);
    return {
      success: true,
      data: manageableAdmins
    };
  } catch (e) {
    console.error("\u83B7\u53D6\u53EF\u7BA1\u7406\u7BA1\u7406\u5458\u5931\u8D25:", e);
    throw createError({
      status: 500,
      message: e.message
    });
  }
};
const checkEditPermission = async (evt) => {
  try {
    const body = await readBody(evt);
    const { admin_id } = body;
    if (!admin_id) {
      throw createError({
        status: 400,
        message: "\u7F3A\u5C11\u7BA1\u7406\u5458ID"
      });
    }
    const canEdit = await canEditGamePermissions(admin_id);
    return {
      success: true,
      data: {
        can_edit: canEdit
      }
    };
  } catch (e) {
    console.error("\u68C0\u67E5\u7F16\u8F91\u6743\u9650\u5931\u8D25:", e);
    throw createError({
      status: 500,
      message: e.message
    });
  }
};
const updateProfile = async (evt) => {
  try {
    const body = await readBody(evt);
    const { admin_id, qq_account, tg_account } = body;
    if (!admin_id) {
      throw createError({
        status: 400,
        message: "\u7F3A\u5C11\u7BA1\u7406\u5458ID"
      });
    }
    const success = await updateProfile$1(admin_id, {
      qq_account: qq_account || "",
      tg_account: tg_account || ""
    });
    if (success) {
      return {
        success: true,
        message: "\u4E2A\u4EBA\u4FE1\u606F\u66F4\u65B0\u6210\u529F"
      };
    } else {
      throw createError({
        status: 500,
        message: "\u4E2A\u4EBA\u4FE1\u606F\u66F4\u65B0\u5931\u8D25"
      });
    }
  } catch (e) {
    console.error("\u66F4\u65B0\u4E2A\u4EBA\u4FE1\u606F\u5931\u8D25:", e);
    throw createError({
      status: 500,
      message: e.message
    });
  }
};
const getProfile = async (evt) => {
  try {
    const body = await readBody(evt);
    const { admin_id } = body;
    if (!admin_id) {
      throw createError({
        status: 400,
        message: "\u7F3A\u5C11\u7BA1\u7406\u5458ID"
      });
    }
    const profile = await getAdminProfile(admin_id);
    if (profile) {
      return {
        success: true,
        data: profile
      };
    } else {
      throw createError({
        status: 404,
        message: "\u7BA1\u7406\u5458\u4E0D\u5B58\u5728"
      });
    }
  } catch (e) {
    console.error("\u83B7\u53D6\u4E2A\u4EBA\u4FE1\u606F\u5931\u8D25:", e);
    throw createError({
      status: 500,
      message: e.message
    });
  }
};
const getUserLoginLogs = async (evt) => {
  try {
    const query = getQuery(evt);
    const page = Number(query.page) || 1;
    const pageSize = Number(query.pageSize) || 20;
    const statsOnly = query.statsOnly === "true";
    let allowedChannelCodes = [];
    const authorizationHeader = getHeader(evt, "authorization");
    const token = authorizationHeader ? parseInt(authorizationHeader) : null;
    if (token) {
      try {
        const adminResult = await getAdminWithPermissions(token);
        if (adminResult && adminResult.level > 0) {
          allowedChannelCodes = adminResult.allowed_channel_codes || [];
          console.log(`\u7BA1\u7406\u5458 ${adminResult.name} \u7684\u6E20\u9053\u6743\u9650:`, allowedChannelCodes);
        }
      } catch (error) {
        throw createError({
          status: 403,
          message: "\u6743\u9650\u9A8C\u8BC1\u5931\u8D25"
        });
      }
    } else {
      throw createError({
        status: 401,
        message: "\u672A\u63D0\u4F9B\u8BA4\u8BC1token"
      });
    }
    const filters = {};
    if (query.username) filters.username = query.username;
    if (query.sub_user_name) filters.sub_user_name = query.sub_user_name;
    if (query.game_code) filters.game_code = query.game_code;
    if (query.imei) filters.imei = query.imei;
    if (query.channel_code) filters.channel_code = query.channel_code;
    if (query.startDate) filters.startDate = query.startDate;
    if (query.endDate) filters.endDate = query.endDate;
    const UserLoginLogsModel = await import('../../_/userLoginLogs.mjs');
    if (statsOnly) {
      const stats = await UserLoginLogsModel.getLoginStatsForDateRange(filters.startDate, filters.endDate, allowedChannelCodes);
      return {
        success: true,
        data: {
          totalLogs: stats.total_logins,
          uniqueUsers: stats.unique_users
        }
      };
    }
    const [logs, total] = await Promise.all([
      UserLoginLogsModel.getLoginLogs(page, pageSize, filters, allowedChannelCodes),
      UserLoginLogsModel.getLoginLogsCount(filters, allowedChannelCodes)
    ]);
    return {
      success: true,
      data: {
        logs,
        pagination: {
          page,
          pageSize,
          total,
          totalPages: Math.ceil(total / pageSize)
        }
      }
    };
  } catch (e) {
    console.error("\u83B7\u53D6\u7528\u6237\u767B\u5F55\u8BB0\u5F55\u5931\u8D25:", e);
    throw createError({
      status: 500,
      message: e.message
    });
  }
};
const getTodayLoginStats = async (evt) => {
  try {
    const UserLoginLogsModel = await import('../../_/userLoginLogs.mjs');
    const stats = await UserLoginLogsModel.getTodayLoginStats();
    return {
      success: true,
      data: stats
    };
  } catch (e) {
    console.error("\u83B7\u53D6\u4ECA\u65E5\u767B\u5F55\u7EDF\u8BA1\u5931\u8D25:", e);
    throw createError({
      status: 500,
      message: e.message
    });
  }
};
const getChildChannels = async (evt) => {
  var _a, _b, _c, _d;
  try {
    const body = await readBody(evt).catch(() => ({}));
    const query = getQuery(evt);
    const channel_code = (_a = body == null ? void 0 : body.channel_code) != null ? _a : query == null ? void 0 : query.channel_code;
    const adminId = (_c = (_b = body == null ? void 0 : body.adminId) != null ? _b : query == null ? void 0 : query.adminId) != null ? _c : query == null ? void 0 : query.admin_id;
    const parentChannelCode = (_d = body == null ? void 0 : body.parentChannelCode) != null ? _d : query == null ? void 0 : query.parentChannelCode;
    if (parentChannelCode) {
      try {
        const AgentRelationships2 = await import('../../_/agentRelationships.mjs');
        const childChannelCodes2 = await AgentRelationships2.getDirectChildChannelCodes(parentChannelCode);
        if (childChannelCodes2.length === 0) {
          return {
            success: true,
            data: []
          };
        }
        const channelPlaceholders = childChannelCodes2.map(() => "?").join(",");
        const childAdminsResult = await sql({
          query: `SELECT id, name, channel_code, level FROM admins 
                            WHERE channel_code IN (${channelPlaceholders}) AND is_active = 1
                            ORDER BY name`,
          values: childChannelCodes2
        });
        const childChannels = childAdminsResult.map((admin) => ({
          channel_code: admin.channel_code,
          channel_name: admin.name || admin.channel_code,
          level: admin.level
        }));
        return {
          success: true,
          data: childChannels
        };
      } catch (error) {
        console.error("\u67E5\u8BE2\u4E0B\u7EA7\u6E20\u9053\u5931\u8D25:", error);
        return {
          success: true,
          data: []
        };
      }
    }
    if (adminId) {
      const adminInfo = await getAdminWithPermissions(parseInt(adminId));
      if (!adminInfo) {
        throw createError({
          status: 404,
          message: "\u7BA1\u7406\u5458\u4E0D\u5B58\u5728"
        });
      }
      let targetLevel = null;
      if (adminInfo.level === 0) {
        targetLevel = 1;
      } else if (adminInfo.level === 1) {
        targetLevel = 2;
      } else if (adminInfo.level === 2) {
        targetLevel = 3;
      } else if (adminInfo.level === 3) {
        targetLevel = 4;
      } else if (adminInfo.level === 4) {
        targetLevel = null;
      }
      if (targetLevel === null) {
        return {
          success: true,
          data: []
        };
      }
      const childAdminsResult = await sql({
        query: `SELECT id, name, channel_code, level FROM admins 
                        WHERE level = ? AND is_active = 1 AND channel_code IS NOT NULL
                        ORDER BY name`,
        values: [targetLevel]
      });
      let filteredAdmins = [];
      if (adminInfo.level === 0) {
        filteredAdmins = childAdminsResult;
      } else {
        const allowedChannels = adminInfo.allowed_channel_codes || [];
        filteredAdmins = childAdminsResult.filter(
          (admin) => allowedChannels.includes(admin.channel_code)
        );
      }
      const childChannels = filteredAdmins.map((admin) => ({
        channel_code: admin.channel_code,
        channel_name: admin.name || admin.channel_code,
        level: admin.level
      }));
      return {
        success: true,
        data: childChannels
      };
    }
    if (!channel_code) {
      throw createError({
        status: 400,
        message: "\u7F3A\u5C11\u6E20\u9053\u4EE3\u7801\u6216\u7EA7\u522B\u53C2\u6570"
      });
    }
    const AgentRelationships = await import('../../_/agentRelationships.mjs');
    const childChannelCodes = await AgentRelationships.getAllChildChannelCodes(channel_code);
    return {
      success: true,
      data: childChannelCodes
    };
  } catch (e) {
    console.error("\u83B7\u53D6\u4E0B\u7EA7\u6E20\u9053\u5931\u8D25:", e);
    throw createError({
      status: 500,
      message: e.message
    });
  }
};
const getUsers = async (evt) => {
  try {
    const query = getQuery(evt);
    const page = Number(query.page) || 1;
    const pageSize = Number(query.pageSize) || 20;
    const statsOnly = query.statsOnly === "true";
    const authorizationHeader = getHeader(evt, "authorization");
    const token = authorizationHeader ? parseInt(authorizationHeader) : null;
    let adminPermissions = null;
    let allowedChannelCodes = [];
    if (token) {
      try {
        const adminWithPermissions = await getAdminWithPermissions(token);
        if (!adminWithPermissions) {
          throw createError({
            status: 403,
            message: "\u7BA1\u7406\u5458\u4E0D\u5B58\u5728"
          });
        }
        adminPermissions = adminWithPermissions;
        if (adminWithPermissions.level === 0) {
          allowedChannelCodes = [];
        } else {
          allowedChannelCodes = adminWithPermissions.allowed_channel_codes || [];
        }
        console.log(`\u7BA1\u7406\u5458 ${adminWithPermissions.name} \u7684\u7528\u6237\u6570\u636E\u6743\u9650:`, {
          level: adminWithPermissions.level,
          allowedChannelCodes
        });
      } catch (error) {
        console.error("\u7528\u6237\u6570\u636E\u6743\u9650\u68C0\u67E5\u5931\u8D25:", error);
        throw createError({
          status: 403,
          message: "\u6743\u9650\u9A8C\u8BC1\u5931\u8D25"
        });
      }
    } else {
      throw createError({
        status: 401,
        message: "\u672A\u63D0\u4F9B\u8BA4\u8BC1token"
      });
    }
    const filters = {};
    if (query.user_id) filters.user_id = Number(query.user_id);
    if (query.username) filters.username = query.username;
    if (query.iphone) filters.iphone = query.iphone;
    if (query.thirdparty_uid) filters.thirdparty_uid = query.thirdparty_uid;
    if (query.channel_code) filters.channel_code = query.channel_code;
    if (query.startDate) filters.startDate = query.startDate;
    if (query.endDate) filters.endDate = query.endDate;
    const UserModel = await import('../../_/payment.mjs').then(function (n) { return n.j; });
    if (statsOnly) {
      const stats = await getUserStatsForDateRange(filters.startDate, filters.endDate, allowedChannelCodes);
      return {
        success: true,
        data: {
          todayRegisterCount: stats.today_register_count,
          totalUsers: stats.total_users
        }
      };
    }
    const [users, total] = await Promise.all([
      getUsersWithFilters(page, pageSize, filters, allowedChannelCodes),
      getUsersCount(filters, allowedChannelCodes)
    ]);
    return {
      success: true,
      data: {
        users,
        pagination: {
          page,
          pageSize,
          total,
          totalPages: Math.ceil(total / pageSize)
        }
      }
    };
  } catch (e) {
    console.error("\u83B7\u53D6\u7528\u6237\u6CE8\u518C\u8BB0\u5F55\u5931\u8D25:", e);
    throw createError({
      status: 500,
      message: e.message
    });
  }
};
const getChannelCodeOptions = async (evt) => {
  try {
    const authz = getHeader(evt, "authorization");
    const adminId = authz ? parseInt(String(authz)) : NaN;
    if (isNaN(adminId)) {
      throw createError({ status: 401, message: "\u672A\u63D0\u4F9B\u8BA4\u8BC1token" });
    }
    const admin = await getAdminWithPermissions(adminId);
    if (!admin) {
      throw createError({ status: 403, message: "\u7BA1\u7406\u5458\u4E0D\u5B58\u5728\u6216\u65E0\u6743\u9650" });
    }
    const rows = await sql({
      query: `
                SELECT DISTINCT channel_code
                FROM admins
                WHERE channel_code IS NOT NULL
                  AND channel_code <> ''
                  AND is_active = 1
                ORDER BY channel_code ASC
            `
    });
    const allCodes = rows.map((r) => String(r.channel_code || "").trim()).filter(Boolean);
    if (admin.level === 0) {
      return { success: true, data: allCodes };
    }
    const allowed = new Set([
      ...admin.allowed_channel_codes || [],
      String(admin.channel_code || "").trim()
    ].filter(Boolean));
    const filtered = allCodes.filter((code) => allowed.has(code));
    return { success: true, data: filtered };
  } catch (e) {
    throw createError({ status: e.statusCode || 500, message: e.message || "\u83B7\u53D6\u6E20\u9053\u5217\u8868\u5931\u8D25" });
  }
};
const getUsersWithFilters = async (page, pageSize, filters, allowedChannelCodes = []) => {
  const offset = (page - 1) * pageSize;
  let whereConditions = [];
  let values = [];
  if (allowedChannelCodes.length > 0) {
    whereConditions.push(`channel_code IN (${allowedChannelCodes.map(() => "?").join(",")})`);
    values.push(...allowedChannelCodes);
  }
  if (filters.user_id) {
    whereConditions.push("id = ?");
    values.push(filters.user_id);
  }
  if (filters.username) {
    whereConditions.push("username LIKE ?");
    values.push(`%${filters.username}%`);
  }
  if (filters.iphone) {
    whereConditions.push("iphone LIKE ?");
    values.push(`%${filters.iphone}%`);
  }
  if (filters.thirdparty_uid) {
    whereConditions.push("thirdparty_uid LIKE ?");
    values.push(`%${filters.thirdparty_uid}%`);
  }
  if (filters.channel_code) {
    whereConditions.push("channel_code = ?");
    values.push(filters.channel_code);
  }
  if (filters.startDate) {
    whereConditions.push("DATE(created_at) >= ?");
    values.push(filters.startDate);
  }
  if (filters.endDate) {
    whereConditions.push("DATE(created_at) <= ?");
    values.push(filters.endDate);
  }
  let query = "SELECT id, username, iphone, thirdparty_uid, channel_code, game_code, platform_coins, status, created_at FROM users";
  if (whereConditions.length > 0) {
    query += " WHERE " + whereConditions.join(" AND ");
  }
  query += " ORDER BY created_at DESC LIMIT ? OFFSET ?";
  values.push(pageSize, offset);
  const result = await sql({
    query,
    values
  });
  return result;
};
const getUsersCount = async (filters, allowedChannelCodes = []) => {
  let whereConditions = [];
  let values = [];
  if (allowedChannelCodes.length > 0) {
    whereConditions.push(`channel_code IN (${allowedChannelCodes.map(() => "?").join(",")})`);
    values.push(...allowedChannelCodes);
  }
  if (filters.user_id) {
    whereConditions.push("id = ?");
    values.push(filters.user_id);
  }
  if (filters.username) {
    whereConditions.push("username LIKE ?");
    values.push(`%${filters.username}%`);
  }
  if (filters.iphone) {
    whereConditions.push("iphone LIKE ?");
    values.push(`%${filters.iphone}%`);
  }
  if (filters.thirdparty_uid) {
    whereConditions.push("thirdparty_uid LIKE ?");
    values.push(`%${filters.thirdparty_uid}%`);
  }
  if (filters.channel_code) {
    whereConditions.push("channel_code = ?");
    values.push(filters.channel_code);
  }
  if (filters.startDate) {
    whereConditions.push("DATE(created_at) >= ?");
    values.push(filters.startDate);
  }
  if (filters.endDate) {
    whereConditions.push("DATE(created_at) <= ?");
    values.push(filters.endDate);
  }
  let query = "SELECT COUNT(*) as total FROM users";
  if (whereConditions.length > 0) {
    query += " WHERE " + whereConditions.join(" AND ");
  }
  const result = await sql({
    query,
    values
  });
  return result[0].total;
};
const getUserStatsForDateRange = async (startDate, endDate, allowedChannelCodes = []) => {
  const today = getChinaDateString();
  let todayQuery = `SELECT COUNT(*) as today_register_count FROM users WHERE DATE(created_at) = ?`;
  let todayValues = [today];
  if (allowedChannelCodes.length > 0) {
    todayQuery += ` AND channel_code IN (${allowedChannelCodes.map(() => "?").join(",")})`;
    todayValues.push(...allowedChannelCodes);
  }
  const todayResult = await sql({
    query: todayQuery,
    values: todayValues
  });
  let totalQuery = "SELECT COUNT(*) as total_users FROM users";
  let totalValues = [];
  if (allowedChannelCodes.length > 0) {
    totalQuery += ` WHERE channel_code IN (${allowedChannelCodes.map(() => "?").join(",")})`;
    totalValues.push(...allowedChannelCodes);
  }
  const totalResult = await sql({
    query: totalQuery,
    values: totalValues
  });
  return {
    today_register_count: todayResult[0].today_register_count,
    total_users: totalResult[0].total_users
  };
};
const getPaymentRecords = async (evt) => {
  try {
    const query = getQuery(evt);
    const page = Number(query.page) || 1;
    const pageSize = Number(query.pageSize) || 20;
    const statsOnly = query.statsOnly === "true";
    const authorizationHeader = getHeader(evt, "authorization");
    const token = authorizationHeader ? parseInt(authorizationHeader) : null;
    let adminPermissions = null;
    let allowedChannelCodes = [];
    if (token) {
      try {
        const adminWithPermissions = await getAdminWithPermissions(token);
        if (!adminWithPermissions) {
          throw createError({
            status: 403,
            message: "\u7BA1\u7406\u5458\u4E0D\u5B58\u5728"
          });
        }
        adminPermissions = adminWithPermissions;
        if (adminWithPermissions.level === 0) {
          allowedChannelCodes = [];
        } else {
          allowedChannelCodes = adminWithPermissions.allowed_channel_codes || [];
        }
        console.log(`\u7BA1\u7406\u5458 ${adminWithPermissions.name} \u7684\u652F\u4ED8\u6570\u636E\u6743\u9650:`, {
          level: adminWithPermissions.level,
          allowedChannelCodes
        });
      } catch (error) {
        console.error("\u652F\u4ED8\u6570\u636E\u6743\u9650\u68C0\u67E5\u5931\u8D25:", error);
        throw createError({
          status: 403,
          message: "\u6743\u9650\u9A8C\u8BC1\u5931\u8D25"
        });
      }
    } else {
      throw createError({
        status: 401,
        message: "\u672A\u63D0\u4F9B\u8BA4\u8BC1token"
      });
    }
    const filters = {};
    if (query.transaction_id) filters.transaction_id = query.transaction_id;
    if (query.user_id) filters.user_id = query.user_id;
    if (query.mch_order_id) filters.mch_order_id = query.mch_order_id;
    if (query.payment_status) filters.payment_status = query.payment_status;
    if (query.payment_method) filters.payment_method = query.payment_method;
    if (query.game_id) filters.game_id = query.game_id;
    if (query.level1_agent) filters.level1_agent = query.level1_agent;
    if (query.level2_agent) filters.level2_agent = query.level2_agent;
    if (query.startDate) filters.startDate = query.startDate;
    if (query.endDate) filters.endDate = query.endDate;
    if (statsOnly) {
      const [todayStats, queryStats] = await Promise.all([
        getPaymentStatsForDateRange(filters.startDate, filters.endDate, true, null, allowedChannelCodes),
        // 今日统计
        getPaymentStatsForDateRange(filters.startDate, filters.endDate, false, filters, allowedChannelCodes)
        // 查询统计
      ]);
      return {
        success: true,
        data: {
          ...todayStats,
          ...queryStats
        }
      };
    }
    const [payments, total, currentQueryStats] = await Promise.all([
      getPaymentRecordsWithFilters(page, pageSize, filters, allowedChannelCodes),
      getPaymentRecordsCount(filters, allowedChannelCodes),
      getCurrentQueryStats(filters, allowedChannelCodes)
    ]);
    return {
      success: true,
      data: {
        payments,
        pagination: {
          page,
          pageSize,
          total,
          totalPages: Math.ceil(total / pageSize)
        },
        currentQueryStats
      }
    };
  } catch (e) {
    console.error("\u83B7\u53D6\u5145\u503C\u8BB0\u5F55\u5931\u8D25:", e);
    throw createError({
      status: 500,
      message: e.message
    });
  }
};
const applyPaymentMethodFilter = (filters, whereConditions, values) => {
  if (!filters.payment_method) return;
  const method = String(filters.payment_method).trim();
  if (!method) return;
  console.log("\u7B5B\u9009\u652F\u4ED8\u65B9\u5F0F:", method);
  if (method === "\u652F\u4ED8\u5B9D+\u5FAE\u4FE1") {
    whereConditions.push("(pr.payment_way LIKE ? OR pr.payment_way LIKE ? OR pr.payment_way = ? OR pr.payment_way = ? OR pr.payment_way = ? OR pr.payment_way = ?)");
    values.push("%\u652F\u4ED8\u5B9D%", "%\u5FAE\u4FE1%", "\u652F\u4ED8\u5B9D", "\u5FAE\u4FE1", "zfb", "wx");
    return;
  }
  if (method === "\u652F\u4ED8\u5B9D") {
    whereConditions.push("(pr.payment_way LIKE ? OR pr.payment_way = ? OR pr.payment_way = ?)");
    values.push("%\u652F\u4ED8\u5B9D%", "\u652F\u4ED8\u5B9D", "zfb");
    return;
  }
  if (method === "\u5FAE\u4FE1") {
    whereConditions.push("(pr.payment_way LIKE ? OR pr.payment_way = ? OR pr.payment_way = ?)");
    values.push("%\u5FAE\u4FE1%", "\u5FAE\u4FE1", "wx");
    return;
  }
  whereConditions.push("(pr.payment_way LIKE ? OR pr.payment_way = ?)");
  values.push(`%${method}%`, method);
};
const getPaymentRecordsWithFilters = async (page, pageSize, filters, allowedChannelCodes = []) => {
  const offset = (page - 1) * pageSize;
  console.log("getPaymentRecordsWithFilters \u53C2\u6570:", { page, pageSize, filters, allowedChannelCodes });
  let whereConditions = [];
  let values = [];
  if (allowedChannelCodes.length > 0) {
    whereConditions.push(`u.channel_code IN (${allowedChannelCodes.map(() => "?").join(",")})`);
    values.push(...allowedChannelCodes);
  }
  if (filters.transaction_id) {
    whereConditions.push("pr.transaction_id LIKE ?");
    values.push(`%${filters.transaction_id}%`);
  }
  if (filters.user_id) {
    const cleanUserId = filters.user_id.toString().trim().replace(/^\+/, "");
    console.log("getPaymentRecordsWithFilters \u6E05\u7406\u540E\u7684user_id:", cleanUserId, "\u539F\u59CB\u503C:", filters.user_id);
    whereConditions.push(`(
            pr.user_id = ? OR 
            su.id = ? OR 
            su.wuid = ? OR 
            pr.role_id = ? OR
            pr.wuid = ? OR
            pr.sub_user_id = ?
        )`);
    values.push(cleanUserId, cleanUserId, cleanUserId, cleanUserId, cleanUserId, cleanUserId);
  }
  if (filters.mch_order_id) {
    whereConditions.push("pr.mch_order_id LIKE ?");
    values.push(`%${filters.mch_order_id}%`);
  }
  if (filters.payment_status) {
    whereConditions.push("pr.payment_status = ?");
    values.push(filters.payment_status);
  }
  applyPaymentMethodFilter(filters, whereConditions, values);
  if (filters.game_id) {
    whereConditions.push("g.id = ?");
    values.push(filters.game_id);
  }
  if (filters.level1_agent || filters.level2_agent) {
    const targetAgent = filters.level2_agent || filters.level1_agent;
    whereConditions.push("u.channel_code = ?");
    values.push(targetAgent);
  }
  if (filters.startDate) {
    whereConditions.push("DATE(pr.created_at) >= ?");
    values.push(filters.startDate);
  }
  if (filters.endDate) {
    whereConditions.push("DATE(pr.created_at) <= ?");
    values.push(filters.endDate);
  }
  let query = `SELECT 
        pr.id,
        pr.user_id,
        pr.sub_user_id,
        pr.role_id,
        pr.transaction_id,
        pr.wuid,
        pr.payment_way,
        pr.payment_id,
        pr.world_id,
        pr.product_name,
        pr.product_des,
        pr.ip,
        pr.amount,
        pr.mch_order_id,
        pr.created_at,
        pr.notify_at,
        pr.callback_at,
        pr.msg,
        pr.server_url,
        pr.device,
        COALESCE(u.channel_code, pr.channel_code) as channel_code,
        pr.game_code,
        pr.payment_status,
        pr.ptb_before,
        pr.ptb_change,
        pr.ptb_after,
        g.game_name,
        COALESCE(su.wuid, pr.wuid) as role_id_from_join,
        gc.character_name as role_name,
        ps.payment_channel
    FROM paymentrecords pr 
    LEFT JOIN users u ON pr.user_id = u.id 
    LEFT JOIN games g ON u.game_code = g.game_code
    LEFT JOIN subusers su ON pr.sub_user_id = su.id
    LEFT JOIN gamecharacters gc ON pr.role_id = gc.uuid
    LEFT JOIN paymentsettings ps ON pr.payment_id = ps.id`;
  if (whereConditions.length > 0) {
    query += " WHERE " + whereConditions.join(" AND ");
  }
  query += " GROUP BY pr.id ORDER BY pr.created_at DESC LIMIT ? OFFSET ?";
  values.push(pageSize, offset);
  console.log("\u6267\u884C\u67E5\u8BE2:", query);
  console.log("\u67E5\u8BE2\u53C2\u6570:", values);
  const result = await sql({
    query,
    values
  });
  console.log("\u67E5\u8BE2\u7ED3\u679C\u6570\u91CF:", result.length);
  const uniqueResults = /* @__PURE__ */ new Map();
  for (const row of result) {
    if (!uniqueResults.has(row.id)) {
      if (row.role_id_from_join) {
        delete row.role_id_from_join;
      }
      uniqueResults.set(row.id, row);
    }
  }
  return Array.from(uniqueResults.values());
};
const getPaymentRecordsCount = async (filters, allowedChannelCodes = []) => {
  console.log("getPaymentRecordsCount \u53C2\u6570:", { filters, allowedChannelCodes });
  let whereConditions = [];
  let values = [];
  if (allowedChannelCodes.length > 0) {
    whereConditions.push(`u.channel_code IN (${allowedChannelCodes.map(() => "?").join(",")})`);
    values.push(...allowedChannelCodes);
  }
  if (filters.transaction_id) {
    whereConditions.push("pr.transaction_id LIKE ?");
    values.push(`%${filters.transaction_id}%`);
  }
  if (filters.user_id) {
    const cleanUserId = filters.user_id.toString().trim().replace(/^\+/, "");
    console.log("getPaymentRecordsCount \u6E05\u7406\u540E\u7684user_id:", cleanUserId, "\u539F\u59CB\u503C:", filters.user_id);
    whereConditions.push(`(
            pr.user_id = ? OR 
            su.id = ? OR 
            su.wuid = ? OR 
            pr.role_id = ? OR
            pr.wuid = ? OR
            pr.sub_user_id = ?
        )`);
    values.push(cleanUserId, cleanUserId, cleanUserId, cleanUserId, cleanUserId, cleanUserId);
  }
  if (filters.mch_order_id) {
    whereConditions.push("pr.mch_order_id LIKE ?");
    values.push(`%${filters.mch_order_id}%`);
  }
  if (filters.payment_status) {
    whereConditions.push("pr.payment_status = ?");
    values.push(filters.payment_status);
  }
  applyPaymentMethodFilter(filters, whereConditions, values);
  if (filters.game_id) {
    whereConditions.push("g.id = ?");
    values.push(filters.game_id);
  }
  if (filters.level1_agent || filters.level2_agent) {
    const targetAgent = filters.level2_agent || filters.level1_agent;
    whereConditions.push("u.channel_code = ?");
    values.push(targetAgent);
  }
  if (filters.startDate) {
    whereConditions.push("DATE(pr.created_at) >= ?");
    values.push(filters.startDate);
  }
  if (filters.endDate) {
    whereConditions.push("DATE(pr.created_at) <= ?");
    values.push(filters.endDate);
  }
  let query = `SELECT COUNT(*) as total 
    FROM paymentrecords pr 
    LEFT JOIN users u ON pr.user_id = u.id 
    LEFT JOIN games g ON u.game_code = g.game_code
    LEFT JOIN subusers su ON pr.sub_user_id = su.id`;
  if (whereConditions.length > 0) {
    query += " WHERE " + whereConditions.join(" AND ");
  }
  console.log("\u8BA1\u6570\u67E5\u8BE2:", query);
  console.log("\u8BA1\u6570\u53C2\u6570:", values);
  const result = await sql({
    query,
    values
  });
  console.log("\u8BA1\u6570\u7ED3\u679C:", result[0].total);
  return result[0].total;
};
const getCurrentQueryStats = async (filters, allowedChannelCodes = []) => {
  console.log("getCurrentQueryStats \u53C2\u6570:", { filters, allowedChannelCodes });
  let whereConditions = [];
  let values = [];
  if (allowedChannelCodes.length > 0) {
    whereConditions.push(`u.channel_code IN (${allowedChannelCodes.map(() => "?").join(",")})`);
    values.push(...allowedChannelCodes);
  }
  if (filters.transaction_id) {
    whereConditions.push("pr.transaction_id LIKE ?");
    values.push(`%${filters.transaction_id}%`);
  }
  if (filters.user_id) {
    const cleanUserId = filters.user_id.toString().trim().replace(/^\+/, "");
    console.log("getCurrentQueryStats \u6E05\u7406\u540E\u7684user_id:", cleanUserId, "\u539F\u59CB\u503C:", filters.user_id);
    whereConditions.push(`(
            pr.user_id = ? OR 
            su.id = ? OR 
            su.wuid = ? OR 
            pr.role_id = ? OR
            pr.wuid = ? OR
            pr.sub_user_id = ?
        )`);
    values.push(cleanUserId, cleanUserId, cleanUserId, cleanUserId, cleanUserId, cleanUserId);
  }
  if (filters.mch_order_id) {
    whereConditions.push("pr.mch_order_id LIKE ?");
    values.push(`%${filters.mch_order_id}%`);
  }
  if (filters.payment_status) {
    whereConditions.push("pr.payment_status = ?");
    values.push(filters.payment_status);
  }
  applyPaymentMethodFilter(filters, whereConditions, values);
  if (filters.game_id) {
    whereConditions.push("g.id = ?");
    values.push(filters.game_id);
  }
  if (filters.level1_agent || filters.level2_agent) {
    const targetAgent = filters.level2_agent || filters.level1_agent;
    whereConditions.push("u.channel_code = ?");
    values.push(targetAgent);
  }
  if (filters.startDate) {
    whereConditions.push("DATE(pr.created_at) >= ?");
    values.push(filters.startDate);
  }
  if (filters.endDate) {
    whereConditions.push("DATE(pr.created_at) <= ?");
    values.push(filters.endDate);
  }
  let query = `SELECT 
        COUNT(*) as count,
        COALESCE(SUM(pr.amount), 0) as amount 
    FROM paymentrecords pr 
    LEFT JOIN users u ON pr.user_id = u.id 
    LEFT JOIN games g ON u.game_code = g.game_code
    LEFT JOIN subusers su ON pr.sub_user_id = su.id`;
  if (whereConditions.length > 0) {
    query += " WHERE " + whereConditions.join(" AND ");
  }
  console.log("\u5F53\u524D\u67E5\u8BE2\u7EDF\u8BA1 SQL:", query);
  console.log("\u5F53\u524D\u67E5\u8BE2\u7EDF\u8BA1\u53C2\u6570:", values);
  const result = await sql({
    query,
    values
  });
  return {
    count: result[0].count,
    amount: parseFloat(result[0].amount).toFixed(2)
  };
};
const getPaymentStatsForDateRange = async (startDate, endDate, isTodayStats = false, filters, allowedChannelCodes = []) => {
  const today = getChinaDateString();
  if (isTodayStats) {
    let todaySuccessQuery = `
            SELECT 
                COUNT(*) as count,
                COALESCE(SUM(pr.amount), 0) as amount 
            FROM paymentrecords pr 
            LEFT JOIN users u ON pr.user_id = u.id 
            WHERE DATE(pr.created_at) = ? AND pr.payment_status = 3
            AND (pr.payment_way NOT LIKE '%\u5E73\u53F0\u5E01%' OR pr.payment_way IS NULL OR pr.payment_way = '')
        `;
    let todayTotalQuery = `
            SELECT 
                COUNT(*) as count,
                COALESCE(SUM(pr.amount), 0) as amount 
            FROM paymentrecords pr 
            LEFT JOIN users u ON pr.user_id = u.id 
            WHERE DATE(pr.created_at) = ?
        `;
    let todaySuccessValues = [today];
    let todayTotalValues = [today];
    if (allowedChannelCodes.length > 0) {
      const channelFilter = ` AND u.channel_code IN (${allowedChannelCodes.map(() => "?").join(",")})`;
      todaySuccessQuery += channelFilter;
      todayTotalQuery += channelFilter;
      todaySuccessValues.push(...allowedChannelCodes);
      todayTotalValues.push(...allowedChannelCodes);
    }
    const [todaySuccessResult, todayTotalResult] = await Promise.all([
      sql({ query: todaySuccessQuery, values: todaySuccessValues }),
      sql({ query: todayTotalQuery, values: todayTotalValues })
    ]);
    return {
      todaySuccessCount: todaySuccessResult[0].count,
      todaySuccessAmount: parseFloat(todaySuccessResult[0].amount).toFixed(2),
      todayTotalCount: todayTotalResult[0].count,
      todayTotalAmount: parseFloat(todayTotalResult[0].amount).toFixed(2)
    };
  } else {
    let whereConditions = ["pr.payment_status = 3", "(pr.payment_way NOT LIKE '%\u5E73\u53F0\u5E01%' OR pr.payment_way IS NULL OR pr.payment_way = '')"];
    let whereConditionsAll = ["1=1"];
    let values = [];
    let valuesAll = [];
    if (startDate) {
      whereConditions.push("DATE(pr.created_at) >= ?");
      whereConditionsAll.push("DATE(pr.created_at) >= ?");
      values.push(startDate);
      valuesAll.push(startDate);
    }
    if (endDate) {
      whereConditions.push("DATE(pr.created_at) <= ?");
      whereConditionsAll.push("DATE(pr.created_at) <= ?");
      values.push(endDate);
      valuesAll.push(endDate);
    }
    if (allowedChannelCodes.length > 0) {
      whereConditions.push(`u.channel_code IN (${allowedChannelCodes.map(() => "?").join(",")})`);
      whereConditionsAll.push(`u.channel_code IN (${allowedChannelCodes.map(() => "?").join(",")})`);
      values.push(...allowedChannelCodes);
      valuesAll.push(...allowedChannelCodes);
    }
    if (filters) {
      if (filters.transaction_id) {
        whereConditions.push("pr.transaction_id LIKE ?");
        whereConditionsAll.push("pr.transaction_id LIKE ?");
        values.push(`%${filters.transaction_id}%`);
        valuesAll.push(`%${filters.transaction_id}%`);
      }
      if (filters.user_id) {
        const cleanUserId = filters.user_id.toString().trim().replace(/^\+/, "");
        console.log("getPaymentStatsForDateRange \u6E05\u7406\u540E\u7684user_id:", cleanUserId, "\u539F\u59CB\u503C:", filters.user_id);
        whereConditions.push(`(
                    pr.user_id = ? OR 
                    su.id = ? OR 
                    su.wuid = ? OR 
                    pr.role_id = ? OR
                    pr.wuid = ? OR
                    pr.sub_user_id = ?
                )`);
        whereConditionsAll.push(`(
                    pr.user_id = ? OR 
                    su.id = ? OR 
                    su.wuid = ? OR 
                    pr.role_id = ? OR
                    pr.wuid = ? OR
                    pr.sub_user_id = ?
                )`);
        values.push(cleanUserId, cleanUserId, cleanUserId, cleanUserId, cleanUserId, cleanUserId);
        valuesAll.push(cleanUserId, cleanUserId, cleanUserId, cleanUserId, cleanUserId, cleanUserId);
      }
      if (filters.mch_order_id) {
        whereConditions.push("pr.mch_order_id LIKE ?");
        whereConditionsAll.push("pr.mch_order_id LIKE ?");
        values.push(`%${filters.mch_order_id}%`);
        valuesAll.push(`%${filters.mch_order_id}%`);
      }
      if (filters.payment_status) {
        whereConditions.push("pr.payment_status = ?");
        whereConditionsAll.push("pr.payment_status = ?");
        values.push(filters.payment_status);
        valuesAll.push(filters.payment_status);
      }
      if (filters.payment_method) {
        applyPaymentMethodFilter(filters, whereConditions, values);
        applyPaymentMethodFilter(filters, whereConditionsAll, valuesAll);
      }
      if (filters.game_id) {
        whereConditions.push("g.id = ?");
        whereConditionsAll.push("g.id = ?");
        values.push(filters.game_id);
        valuesAll.push(filters.game_id);
      }
      if (filters.level1_agent || filters.level2_agent) {
        const targetAgent = filters.level2_agent || filters.level1_agent;
        whereConditions.push("u.channel_code = ?");
        whereConditionsAll.push("u.channel_code = ?");
        values.push(targetAgent);
        valuesAll.push(targetAgent);
      }
    }
    const successConditions = whereConditions.join(" AND ");
    const allConditions = whereConditionsAll.join(" AND ");
    let querySuccessQuery = `
            SELECT 
                COUNT(*) as count,
                COALESCE(SUM(pr.amount), 0) as amount 
            FROM paymentrecords pr 
            LEFT JOIN users u ON pr.user_id = u.id 
            LEFT JOIN games g ON u.game_code = g.game_code
            LEFT JOIN subusers su ON pr.sub_user_id = su.id
            WHERE ${successConditions}
        `;
    let queryTotalQuery = `
            SELECT 
                COUNT(*) as count,
                COALESCE(SUM(pr.amount), 0) as amount 
            FROM paymentrecords pr 
            LEFT JOIN users u ON pr.user_id = u.id 
            LEFT JOIN games g ON u.game_code = g.game_code
            LEFT JOIN subusers su ON pr.sub_user_id = su.id
            WHERE ${allConditions}
        `;
    const [querySuccessResult, queryTotalResult] = await Promise.all([
      sql({ query: querySuccessQuery, values }),
      sql({ query: queryTotalQuery, values: valuesAll })
    ]);
    return {
      querySuccessCount: querySuccessResult[0].count,
      querySuccessAmount: parseFloat(querySuccessResult[0].amount).toFixed(2),
      queryTotalCount: queryTotalResult[0].count,
      queryTotalAmount: parseFloat(queryTotalResult[0].amount).toFixed(2)
    };
  }
};
const getGameCharacters = async (evt) => {
  try {
    const query = getQuery(evt);
    const page = Number(query.page) || 1;
    const pageSize = Number(query.pageSize) || 20;
    const statsOnly = query.statsOnly === "true";
    let allowedChannelCodes = [];
    const authorizationHeader = getHeader(evt, "authorization");
    const token = authorizationHeader ? parseInt(authorizationHeader) : null;
    if (token) {
      try {
        const adminResult = await getAdminWithPermissions(token);
        if (adminResult && adminResult.level > 0) {
          allowedChannelCodes = adminResult.allowed_channel_codes || [];
          console.log(`\u7BA1\u7406\u5458 ${adminResult.name} \u7684\u6E20\u9053\u6743\u9650:`, allowedChannelCodes);
        }
      } catch (error) {
        throw createError({
          status: 403,
          message: "\u6743\u9650\u9A8C\u8BC1\u5931\u8D25"
        });
      }
    } else {
      throw createError({
        status: 401,
        message: "\u672A\u63D0\u4F9B\u8BA4\u8BC1token"
      });
    }
    const filters = {};
    if (query.user_id) filters.user_id = query.user_id;
    if (query.subuser_id) filters.subuser_id = query.subuser_id;
    if (query.subuser_name) filters.subuser_name = query.subuser_name;
    if (query.character_name) filters.character_name = query.character_name;
    if (query.uuid) filters.uuid = query.uuid;
    if (query.game_id) filters.game_id = query.game_id;
    if (query.server_id) filters.server_id = query.server_id;
    if (query.startDate) filters.startDate = query.startDate;
    if (query.endDate) filters.endDate = query.endDate;
    if (statsOnly) {
      const stats = await getCharacterStatsForDateRange(filters.startDate, filters.endDate, allowedChannelCodes);
      return {
        success: true,
        data: {
          todayCharacterCount: stats.today_character_count,
          totalCharacters: stats.total_characters
        }
      };
    }
    const [characters, total] = await Promise.all([
      getGameCharactersWithFilters(page, pageSize, filters, allowedChannelCodes),
      getGameCharactersCount(filters, allowedChannelCodes)
    ]);
    return {
      success: true,
      data: {
        characters,
        pagination: {
          page,
          pageSize,
          total,
          totalPages: Math.ceil(total / pageSize)
        }
      }
    };
  } catch (e) {
    console.error("\u83B7\u53D6\u89D2\u8272\u67E5\u8BE2\u8BB0\u5F55\u5931\u8D25:", e);
    throw createError({
      status: 500,
      message: e.message
    });
  }
};
const getGameCharactersWithFilters = async (page, pageSize, filters, allowedChannelCodes = []) => {
  const offset = (page - 1) * pageSize;
  let whereConditions = [];
  let values = [];
  if (allowedChannelCodes.length > 0) {
    whereConditions.push(`u.channel_code IN (${allowedChannelCodes.map(() => "?").join(",")})`);
    values.push(...allowedChannelCodes);
  }
  if (filters.user_id) {
    whereConditions.push("gc.user_id = ?");
    values.push(filters.user_id);
  }
  if (filters.subuser_id) {
    whereConditions.push("gc.subuser_id = ?");
    values.push(filters.subuser_id);
  }
  if (filters.subuser_name) {
    whereConditions.push("su.username LIKE ?");
    values.push(`%${filters.subuser_name}%`);
  }
  if (filters.character_name) {
    whereConditions.push("gc.character_name LIKE ?");
    values.push(`%${filters.character_name}%`);
  }
  if (filters.uuid) {
    whereConditions.push("gc.uuid LIKE ?");
    values.push(`%${filters.uuid}%`);
  }
  if (filters.game_id) {
    whereConditions.push("gc.game_id = ?");
    values.push(filters.game_id);
  }
  if (filters.server_id) {
    whereConditions.push("gc.server_id = ?");
    values.push(filters.server_id);
  }
  if (filters.startDate) {
    whereConditions.push("DATE(gc.created_at) >= ?");
    values.push(filters.startDate);
  }
  if (filters.endDate) {
    whereConditions.push("DATE(gc.created_at) <= ?");
    values.push(filters.endDate);
  }
  let query = `
        SELECT 
            gc.*,
            u.username,
            u.channel_code,
            su.username as subuser_name,
            g.game_name
        FROM gamecharacters gc 
        LEFT JOIN users u ON gc.user_id = u.id 
        LEFT JOIN subusers su ON gc.subuser_id = su.id
        LEFT JOIN games g ON gc.game_id = g.id
    `;
  if (whereConditions.length > 0) {
    query += " WHERE " + whereConditions.join(" AND ");
  }
  query += " ORDER BY gc.created_at DESC LIMIT ? OFFSET ?";
  values.push(pageSize, offset);
  const result = await sql({
    query,
    values
  });
  return result;
};
const getGameCharactersCount = async (filters, allowedChannelCodes = []) => {
  let whereConditions = [];
  let values = [];
  if (allowedChannelCodes.length > 0) {
    whereConditions.push(`u.channel_code IN (${allowedChannelCodes.map(() => "?").join(",")})`);
    values.push(...allowedChannelCodes);
  }
  if (filters.user_id) {
    whereConditions.push("gc.user_id = ?");
    values.push(filters.user_id);
  }
  if (filters.subuser_id) {
    whereConditions.push("gc.subuser_id = ?");
    values.push(filters.subuser_id);
  }
  if (filters.subuser_name) {
    whereConditions.push("su.username LIKE ?");
    values.push(`%${filters.subuser_name}%`);
  }
  if (filters.character_name) {
    whereConditions.push("gc.character_name LIKE ?");
    values.push(`%${filters.character_name}%`);
  }
  if (filters.uuid) {
    whereConditions.push("gc.uuid LIKE ?");
    values.push(`%${filters.uuid}%`);
  }
  if (filters.game_id) {
    whereConditions.push("gc.game_id = ?");
    values.push(filters.game_id);
  }
  if (filters.server_id) {
    whereConditions.push("gc.server_id = ?");
    values.push(filters.server_id);
  }
  if (filters.startDate) {
    whereConditions.push("DATE(gc.created_at) >= ?");
    values.push(filters.startDate);
  }
  if (filters.endDate) {
    whereConditions.push("DATE(gc.created_at) <= ?");
    values.push(filters.endDate);
  }
  let query = `
        SELECT COUNT(*) as total 
        FROM gamecharacters gc 
        LEFT JOIN users u ON gc.user_id = u.id 
        LEFT JOIN subusers su ON gc.subuser_id = su.id
        LEFT JOIN games g ON gc.game_id = g.id
    `;
  if (whereConditions.length > 0) {
    query += " WHERE " + whereConditions.join(" AND ");
  }
  const result = await sql({
    query,
    values
  });
  return result[0].total;
};
const getCharacterStatsForDateRange = async (startDate, endDate, allowedChannelCodes = []) => {
  const today = getChinaDateString();
  let todayQuery = `
        SELECT COUNT(*) as today_character_count
        FROM gamecharacters gc
        LEFT JOIN users u ON gc.user_id = u.id
        WHERE DATE(gc.created_at) = ?
    `;
  let todayValues = [today];
  if (allowedChannelCodes.length > 0) {
    todayQuery += ` AND u.channel_code IN (${allowedChannelCodes.map(() => "?").join(",")})`;
    todayValues.push(...allowedChannelCodes);
  }
  const todayResult = await sql({
    query: todayQuery,
    values: todayValues
  });
  let totalQuery = `
        SELECT COUNT(*) as total_characters 
        FROM gamecharacters gc
        LEFT JOIN users u ON gc.user_id = u.id
    `;
  let totalValues = [];
  if (allowedChannelCodes.length > 0) {
    totalQuery += ` WHERE u.channel_code IN (${allowedChannelCodes.map(() => "?").join(",")})`;
    totalValues.push(...allowedChannelCodes);
  }
  const totalResult = await sql({
    query: totalQuery,
    values: totalValues
  });
  return {
    today_character_count: todayResult[0].today_character_count,
    total_characters: totalResult[0].total_characters
  };
};
const getDataOverview = async (evt) => {
  try {
    const query = getQuery(evt);
    const startDate = query.startDate || getPastDate(7);
    const endDate = query.endDate || getCurrentDate();
    const channelCode = query.channelCode || "";
    const adminId = query.adminId || "";
    const gameId = query.gameId || "";
    let currentUserInfo = {
      level: 0,
      allowed_channel_codes: [],
      allowed_game_ids: []
    };
    if (adminId) {
      try {
        const adminResult = await getAdminWithPermissions(parseInt(adminId));
        if (adminResult) {
          currentUserInfo = {
            level: adminResult.level,
            allowed_channel_codes: adminResult.allowed_channel_codes || [],
            allowed_game_ids: adminResult.allowed_game_ids || []
          };
        }
      } catch (error) {
        console.error("\u83B7\u53D6\u7BA1\u7406\u5458\u4FE1\u606F\u5931\u8D25:", error);
      }
    }
    let allowedChannels = [];
    if (channelCode) {
      const AgentRelationships = await import('../../_/agentRelationships.mjs');
      const childChannels = await AgentRelationships.getAllChildChannelCodes(channelCode);
      allowedChannels = [channelCode, ...childChannels];
      console.log("[\u6982\u8FF0\u6570\u636E\u67E5\u8BE2] \u9009\u62E9\u4E86\u5177\u4F53\u6E20\u9053:", {
        selectedChannel: channelCode,
        allChannels: allowedChannels
      });
    } else {
      if (currentUserInfo.level === 0) {
        allowedChannels = [];
        console.log("[\u6982\u8FF0\u6570\u636E\u67E5\u8BE2] \u8D85\u7EA7\u7BA1\u7406\u5458\uFF0C\u4E0D\u9650\u5236\u6E20\u9053");
      } else {
        allowedChannels = currentUserInfo.allowed_channel_codes;
        console.log("[\u6982\u8FF0\u6570\u636E\u67E5\u8BE2] \u4F7F\u7528\u7528\u6237\u6743\u9650:", {
          allowedChannels
        });
      }
    }
    let gameCodeFilter = "";
    if (gameId) {
      if (currentUserInfo.level > 0 && currentUserInfo.allowed_game_ids.length > 0 && !currentUserInfo.allowed_game_ids.includes(parseInt(gameId))) {
        return {
          success: false,
          message: "\u65E0\u6743\u9650\u67E5\u770B\u8BE5\u6E38\u620F\u6570\u636E"
        };
      }
      const gameResult = await sql({
        query: "SELECT game_code FROM games WHERE id = ?",
        values: [parseInt(gameId)]
      });
      if (gameResult.length > 0) {
        gameCodeFilter = gameResult[0].game_code;
      }
    }
    let conditions = ["ds.stat_date BETWEEN ? AND ?"];
    let values = [startDate, endDate];
    if (allowedChannels.length > 0) {
      conditions.push(`ds.channel_code IN (${allowedChannels.map(() => "?").join(",")})`);
      values.push(...allowedChannels);
    }
    if (gameCodeFilter) {
      conditions.push("ds.game_code = ?");
      values.push(gameCodeFilter);
    } else if (currentUserInfo.level > 0 && currentUserInfo.allowed_game_ids.length > 0) {
      const gameCodesResult = await sql({
        query: `SELECT game_code FROM games WHERE id IN (${currentUserInfo.allowed_game_ids.map(() => "?").join(",")})`,
        values: currentUserInfo.allowed_game_ids
      });
      if (gameCodesResult.length > 0) {
        const gameCodes = gameCodesResult.map((g) => g.game_code);
        conditions.push(`ds.game_code IN (${gameCodes.map(() => "?").join(",")})`);
        values.push(...gameCodes);
      }
    }
    const overviewQuery = `
            SELECT 
                COALESCE(SUM(ds.active_users), 0) as activeUsers,
                COALESCE(SUM(ds.new_users), 0) as newUsers,
                COALESCE(SUM(ds.pay_users), 0) as payUsers,
                COALESCE(SUM(ds.new_pay_users), 0) as newPayUsers,
                COALESCE(SUM(ds.pay_amount), 0) as payAmount,
                COALESCE(SUM(ds.new_pay_amount), 0) as newPayAmount,
                COALESCE(AVG(ds.pay_rate), 0) as payRate,
                COALESCE(AVG(ds.new_pay_rate), 0) as newPayRate,
                COALESCE(AVG(ds.pay_arpu), 0) as payArpu,
                COALESCE(AVG(ds.active_arpu), 0) as totalArpu,
                COALESCE(AVG(ds.new_arpu), 0) as newArpu,
                COALESCE(AVG(ds.new_pay_arpu), 0) as newPayArpu
            FROM dailystats ds
            WHERE ${conditions.join(" AND ")}
        `;
    const overviewResult = await sql({
      query: overviewQuery,
      values
    });
    let gameStatsConditions = ["ds.stat_date BETWEEN ? AND ?"];
    let gameStatsValues = [startDate, endDate];
    if (allowedChannels.length > 0) {
      gameStatsConditions.push(`ds.channel_code IN (${allowedChannels.map(() => "?").join(",")})`);
      gameStatsValues.push(...allowedChannels);
    }
    if (gameCodeFilter) {
      gameStatsConditions.push("ds.game_code = ?");
      gameStatsValues.push(gameCodeFilter);
    } else if (currentUserInfo.level > 0 && currentUserInfo.allowed_game_ids.length > 0) {
      const gameCodesResult = await sql({
        query: `SELECT game_code FROM games WHERE id IN (${currentUserInfo.allowed_game_ids.map(() => "?").join(",")})`,
        values: currentUserInfo.allowed_game_ids
      });
      if (gameCodesResult.length > 0) {
        const gameCodes = gameCodesResult.map((g) => g.game_code);
        gameStatsConditions.push(`ds.game_code IN (${gameCodes.map(() => "?").join(",")})`);
        gameStatsValues.push(...gameCodes);
      }
    }
    const gameStatsQuery = `
            SELECT 
                g.id as game_id,
                g.game_name,
                COALESCE(SUM(ds.active_users), 0) as active_users,
                COALESCE(SUM(ds.register_users), 0) as register_users,
                COALESCE(SUM(ds.real_recharge_amount), 0) as recharge_amount,
                COALESCE(SUM(ds.pay_users), 0) as pay_users,
                COALESCE(AVG(ds.pay_rate), 0) as pay_rate,
                COALESCE(AVG(ds.active_arpu), 0) as arpu
            FROM dailystats ds
            JOIN games g ON ds.game_code = g.game_code
            WHERE g.is_active = 1 AND ${gameStatsConditions.join(" AND ")}
            GROUP BY g.id, g.game_name, ds.game_code
            ORDER BY recharge_amount DESC, g.game_name
        `;
    const gameStats = await sql({
      query: gameStatsQuery,
      values: gameStatsValues
    });
    const result = overviewResult[0] || {};
    const activeUsers = Number(result.activeUsers) || 0;
    const newUsers = Number(result.newUsers) || 0;
    const payUsers = Number(result.payUsers) || 0;
    const payAmount = Number(result.payAmount) || 0;
    const newPayUsers = Number(result.newPayUsers) || 0;
    const newPayAmount = Number(result.newPayAmount) || 0;
    const payRate = Number(result.payRate) || 0;
    const newPayRate = Number(result.newPayRate) || 0;
    const payArpu = Number(result.payArpu) || 0;
    const totalArpu = Number(result.totalArpu) || 0;
    const newArpu = Number(result.newArpu) || 0;
    const newPayArpu = Number(result.newPayArpu) || 0;
    return {
      success: true,
      data: {
        // 用户统计数据
        activeUsers,
        newUsers,
        payUsers,
        newPayUsers,
        payAmount: payAmount.toFixed(2),
        newPayAmount: newPayAmount.toFixed(2),
        payRate: payRate.toFixed(0),
        newPayRate: newPayRate.toFixed(0),
        payArpu: payArpu.toFixed(2),
        totalArpu: totalArpu.toFixed(2),
        newArpu: newArpu.toFixed(2),
        newPayArpu: newPayArpu.toFixed(2),
        // 游戏详细数据
        gameStats: gameStats.map((game) => ({
          gameId: game.game_id,
          gameName: game.game_name,
          activeUsers: Number(game.active_users) || 0,
          consumeAmount: Number(game.recharge_amount).toFixed(2),
          rechargeAmount: Number(game.recharge_amount).toFixed(2),
          registerUsers: Number(game.register_users) || 0,
          todayAmount: "0.00",
          // 今日金额需要单独计算或从其他地方获取
          payUsers: Number(game.pay_users) || 0,
          payRate: Number(game.pay_rate).toFixed(0),
          arpu: Number(game.arpu).toFixed(2)
        })),
        // 统计周期
        startDate,
        endDate,
        // 权限信息
        adminLevel: currentUserInfo.level,
        allowedChannels: currentUserInfo.level > 0 ? allowedChannels : null,
        allowedGameIds: currentUserInfo.level > 0 ? currentUserInfo.allowed_game_ids : null
      }
    };
  } catch (error) {
    console.error("\u83B7\u53D6\u6570\u636E\u6982\u89C8\u5931\u8D25:", error);
    return {
      success: false,
      message: "\u83B7\u53D6\u6570\u636E\u6982\u89C8\u5931\u8D25: " + error.message
    };
  }
};
const getDailyReportDetails = async (evt) => {
  try {
    const query = getQuery(evt);
    const startDate = query.startDate || getPastDate(7);
    const endDate = query.endDate || getCurrentDate();
    const channelCode = query.channelCode || "";
    const adminId = query.adminId || "";
    const gameId = query.gameId || "";
    let currentUserInfo = {
      level: 0,
      allowed_channel_codes: [],
      allowed_game_ids: []
    };
    if (adminId) {
      try {
        const adminResult = await getAdminWithPermissions(parseInt(adminId));
        if (adminResult) {
          currentUserInfo = {
            level: adminResult.level,
            allowed_channel_codes: adminResult.allowed_channel_codes || [],
            allowed_game_ids: adminResult.allowed_game_ids || []
          };
        }
      } catch (error) {
        console.error("\u83B7\u53D6\u7BA1\u7406\u5458\u4FE1\u606F\u5931\u8D25:", error);
      }
    }
    let allowedChannels = [];
    let allowedGameIds = [];
    if (channelCode) {
      allowedChannels = [channelCode];
    } else {
      if (currentUserInfo.level === 0) {
        allowedChannels = [];
      } else {
        allowedChannels = currentUserInfo.allowed_channel_codes;
      }
    }
    let gameCodeFilter = "";
    if (gameId) {
      if (currentUserInfo.level > 0 && currentUserInfo.allowed_game_ids.length > 0 && !currentUserInfo.allowed_game_ids.includes(parseInt(gameId))) {
        return {
          success: false,
          message: "\u65E0\u6743\u9650\u67E5\u770B\u8BE5\u6E38\u620F\u6570\u636E"
        };
      }
      const gameResult = await sql({
        query: "SELECT game_code FROM games WHERE id = ?",
        values: [parseInt(gameId)]
      });
      if (gameResult.length > 0) {
        gameCodeFilter = gameResult[0].game_code;
      }
    }
    let conditions = ["ds.stat_date BETWEEN ? AND ?"];
    let values = [startDate, endDate];
    if (allowedChannels.length > 0) {
      conditions.push(`ds.channel_code IN (${allowedChannels.map(() => "?").join(",")})`);
      values.push(...allowedChannels);
    }
    if (gameCodeFilter) {
      conditions.push("ds.game_code = ?");
      values.push(gameCodeFilter);
    } else if (currentUserInfo.level > 0 && currentUserInfo.allowed_game_ids.length > 0) {
      const gameCodesResult = await sql({
        query: `SELECT game_code FROM games WHERE id IN (${currentUserInfo.allowed_game_ids.map(() => "?").join(",")})`,
        values: currentUserInfo.allowed_game_ids
      });
      if (gameCodesResult.length > 0) {
        const gameCodes = gameCodesResult.map((g) => g.game_code);
        conditions.push(`ds.game_code IN (${gameCodes.map(() => "?").join(",")})`);
        values.push(...gameCodes);
      }
    }
    const dailyStatsQuery = `
            SELECT 
                ds.stat_date as date,
                COALESCE(SUM(ds.active_users), 0) as activeUsers,
                COALESCE(SUM(ds.register_users), 0) as registerUsers,
                COALESCE(SUM(ds.valid_register_users), 0) as validRegisterUsers,
                COALESCE(SUM(ds.new_users), 0) as newUsers,
                COALESCE(AVG(ds.yesterday_retention), 0) as yesterdayRetention,
                COALESCE(SUM(ds.pay_users), 0) as payUsers,
                COALESCE(SUM(ds.new_pay_users), 0) as newPayUsers,
                COALESCE(SUM(ds.recharge_times), 0) as rechargeTimes,
                COALESCE(SUM(ds.high_value_users), 0) as highValueUsers,
                COALESCE(SUM(ds.consume_amount), 0) as consumeAmount,
                COALESCE(SUM(ds.real_recharge_amount), 0) as realRechargeAmount,
                COALESCE(SUM(ds.new_user_recharge), 0) as newUserRecharge,
                COALESCE(AVG(ds.pay_rate), 0) as payRate,
                COALESCE(AVG(ds.new_pay_rate), 0) as newPayRate,
                COALESCE(AVG(ds.active_arpu), 0) as activeArpu,
                COALESCE(AVG(ds.pay_arpu), 0) as payArpu,
                COALESCE(AVG(ds.new_arpu), 0) as newArpu,
                COALESCE(AVG(ds.new_pay_arpu), 0) as newPayArpu,
                COALESCE(AVG(ltv.ltv2_arpu), 0) as ltv2,
                COALESCE(AVG(ltv.ltv3_arpu), 0) as ltv3,
                COALESCE(AVG(ltv.ltv5_arpu), 0) as ltv5,
                COALESCE(AVG(ltv.ltv7_arpu), 0) as ltv7
            FROM dailystats ds
            LEFT JOIN ltvstats ltv ON ds.stat_date = ltv.stat_date 
                AND ds.channel_code = ltv.channel_code 
                AND ds.game_code = ltv.game_code
            WHERE ${conditions.join(" AND ")}
            GROUP BY ds.stat_date
            ORDER BY ds.stat_date DESC
        `;
    const dailyStatsResult = await sql({
      query: dailyStatsQuery,
      values
    });
    const dailyStats = dailyStatsResult.map((row) => ({
      date: formatDateToString(row.date),
      activeUsers: Number(row.activeUsers) || 0,
      registerUsers: Number(row.registerUsers) || 0,
      validRegisterUsers: Number(row.validRegisterUsers) || 0,
      newUsers: Number(row.newUsers) || 0,
      yesterdayRetention: Number(row.yesterdayRetention).toFixed(1),
      payUsers: Number(row.payUsers) || 0,
      newPayUsers: Number(row.newPayUsers) || 0,
      rechargeTimes: Number(row.rechargeTimes) || 0,
      highValueUsers: Number(row.highValueUsers) || 0,
      consumeAmount: Number(row.consumeAmount).toFixed(2),
      realRechargeAmount: Number(row.realRechargeAmount).toFixed(2),
      newUserRecharge: Number(row.newUserRecharge).toFixed(2),
      payRate: Number(row.payRate).toFixed(1),
      newPayRate: Number(row.newPayRate).toFixed(1),
      activeArpu: Number(row.activeArpu).toFixed(2),
      payArpu: Number(row.payArpu).toFixed(2),
      newArpu: Number(row.newArpu).toFixed(2),
      newPayArpu: Number(row.newPayArpu).toFixed(2),
      ltv2: Number(row.ltv2).toFixed(2),
      ltv3: Number(row.ltv3).toFixed(2),
      ltv5: Number(row.ltv5).toFixed(2),
      ltv7: Number(row.ltv7).toFixed(2)
    }));
    return {
      success: true,
      data: {
        details: dailyStats,
        startDate,
        endDate
      }
    };
  } catch (error) {
    console.error("\u83B7\u53D6\u65E5\u62A5\u8BE6\u7EC6\u6570\u636E\u5931\u8D25:", error);
    return {
      success: false,
      message: "\u83B7\u53D6\u65E5\u62A5\u8BE6\u7EC6\u6570\u636E\u5931\u8D25: " + error.message
    };
  }
};
const getDataOverviewDetails = async (evt) => {
  var _a;
  try {
    const query = getQuery(evt);
    const startDate = query.startDate || getPastDate(7);
    const endDate = query.endDate || getCurrentDate();
    const groupBy = query.groupBy || "date";
    const page = Number(query.page) || 1;
    const pageSize = Number(query.pageSize) || 20;
    const adminId = query.adminId || "";
    let adminInfo = { level: 0, allowed_channel_codes: [] };
    let allowedChannels = [];
    if (adminId) {
      try {
        const adminResult = await getAdminWithPermissions(parseInt(adminId));
        if (adminResult) {
          adminInfo = {
            level: adminResult.level,
            allowed_channel_codes: adminResult.allowed_channel_codes || []
          };
        }
      } catch (error) {
        console.error("\u83B7\u53D6\u7BA1\u7406\u5458\u4FE1\u606F\u5931\u8D25:", error);
      }
    }
    if (adminInfo.level > 0) {
      allowedChannels = adminInfo.allowed_channel_codes;
    }
    let channelFilter = "";
    let channelValues = [];
    if (adminInfo.level > 0 && allowedChannels.length > 0) {
      channelFilter = ` AND u.channel_code COLLATE utf8mb4_unicode_ci IN (${allowedChannels.map(() => "?").join(",")})`;
      channelValues = allowedChannels;
    }
    let groupField = "";
    let orderField = "";
    if (groupBy === "channel") {
      groupField = "u.channel_code";
      orderField = "u.channel_code";
    } else {
      groupField = "DATE(u.created_at)";
      orderField = "DATE(u.created_at) DESC";
    }
    const detailsQuery = `
            WITH date_series AS (
                ${generateDateSeries(startDate, endDate)}
            ),
            user_stats AS (
                SELECT 
                    ${groupField} as group_key,
                    COUNT(*) as new_users,
                    COUNT(DISTINCT ul.username) as active_users
                FROM users u
                LEFT JOIN userloginlogs ul ON u.username = ul.username 
                    AND DATE(ul.login_time) BETWEEN ? AND ?
                WHERE DATE(u.created_at) BETWEEN ? AND ?
                ${channelFilter}
                GROUP BY ${groupField}
            ),
            payment_stats AS (
                SELECT 
                    ${groupField} as group_key,
                    COUNT(DISTINCT pr.user_id) as pay_users,
                    SUM(pr.amount) as pay_amount,
                    COUNT(DISTINCT CASE WHEN first_pay.first_pay_date BETWEEN ? AND ? THEN pr.user_id END) as new_pay_users,
                    SUM(CASE WHEN first_pay.first_pay_date BETWEEN ? AND ? THEN pr.amount ELSE 0 END) as new_pay_amount
                FROM users u
                LEFT JOIN paymentrecords pr ON u.id = pr.user_id AND pr.payment_status = 3
                    AND (pr.payment_way NOT LIKE '%\u5E73\u53F0\u5E01%' OR pr.payment_way IS NULL OR pr.payment_way = '')
                    AND DATE(pr.created_at) BETWEEN ? AND ?
                LEFT JOIN (
                    SELECT user_id, DATE(MIN(created_at)) as first_pay_date
                    FROM paymentrecords 
                    WHERE payment_status = 3
                    AND (payment_way NOT LIKE '%\u5E73\u53F0\u5E01%' OR payment_way IS NULL OR payment_way = '')
                    GROUP BY user_id
                ) first_pay ON u.id = first_pay.user_id
                WHERE DATE(u.created_at) BETWEEN ? AND ?
                ${channelFilter}
                GROUP BY ${groupField}
            )
            SELECT 
                COALESCE(us.group_key, ps.group_key) as group_key,
                COALESCE(us.new_users, 0) as new_users,
                COALESCE(us.active_users, 0) as active_users,
                COALESCE(ps.pay_users, 0) as pay_users,
                COALESCE(ps.new_pay_users, 0) as new_pay_users,
                COALESCE(ps.pay_amount, 0) as pay_amount,
                COALESCE(ps.new_pay_amount, 0) as new_pay_amount,
                CASE WHEN ps.pay_users > 0 THEN ps.pay_amount / ps.pay_users ELSE 0 END as pay_arpu,
                CASE WHEN ps.new_pay_users > 0 THEN ps.new_pay_amount / ps.new_pay_users ELSE 0 END as new_pay_arpu
            FROM user_stats us
            FULL OUTER JOIN payment_stats ps ON us.group_key = ps.group_key
            WHERE COALESCE(us.group_key, ps.group_key) IS NOT NULL
            ORDER BY ${orderField}
            LIMIT ? OFFSET ?
        `;
    const values = [
      startDate,
      endDate,
      // UserLoginLogs date range
      startDate,
      endDate,
      // Users date range
      ...channelValues,
      // channel filter
      startDate,
      endDate,
      // first_pay_date range 1
      startDate,
      endDate,
      // first_pay_date range 2  
      startDate,
      endDate,
      // PaymentRecords date range
      startDate,
      endDate,
      // Users date range 2
      ...channelValues,
      // channel filter 2
      pageSize,
      (page - 1) * pageSize
    ];
    const details = await sql({
      query: detailsQuery,
      values
    });
    const countQuery = `
            SELECT COUNT(DISTINCT ${groupField}) as total
            FROM users u
            WHERE DATE(u.created_at) BETWEEN ? AND ?
            ${channelFilter}
        `;
    const countResult = await sql({
      query: countQuery,
      values: [startDate, endDate, ...channelValues]
    });
    const total = ((_a = countResult[0]) == null ? void 0 : _a.total) || 0;
    return {
      success: true,
      data: {
        details: details.map((row) => ({
          groupKey: groupBy === "date" ? formatDateToString(row.group_key) : row.group_key,
          newUsers: row.new_users,
          activeUsers: row.active_users,
          payUsers: row.pay_users,
          newPayUsers: row.new_pay_users,
          payAmount: Number(row.pay_amount).toFixed(2),
          newPayAmount: Number(row.new_pay_amount).toFixed(2),
          payArpu: Number(row.pay_arpu).toFixed(2),
          newPayArpu: Number(row.new_pay_arpu).toFixed(2)
        })),
        pagination: {
          page,
          pageSize,
          total,
          totalPages: Math.ceil(total / pageSize)
        },
        groupBy,
        startDate,
        endDate
      }
    };
  } catch (error) {
    console.error("\u83B7\u53D6\u6570\u636E\u6982\u89C8\u8BE6\u60C5\u5931\u8D25:", error);
    return {
      success: false,
      message: "\u83B7\u53D6\u6570\u636E\u6982\u89C8\u8BE6\u60C5\u5931\u8D25: " + error.message
    };
  }
};
const getPastDate = (days, baseDate) => {
  const date = /* @__PURE__ */ new Date();
  date.setDate(date.getDate() - days);
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
};
const getCurrentDate = () => {
  const date = /* @__PURE__ */ new Date();
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
};
const formatDateToString = (dateValue) => {
  if (!dateValue) return "";
  if (typeof dateValue === "string") {
    if (dateValue.includes("T")) {
      return dateValue.split("T")[0];
    }
    if (dateValue.match(/^\d{4}-\d{2}-\d{2}$/)) {
      return dateValue;
    }
  }
  if (dateValue instanceof Date) {
    const year = dateValue.getFullYear();
    const month = String(dateValue.getMonth() + 1).padStart(2, "0");
    const day = String(dateValue.getDate()).padStart(2, "0");
    return `${year}-${month}-${day}`;
  }
  try {
    const date = new Date(dateValue);
    if (date instanceof Date && !isNaN(date.getTime())) {
      const year = date.getFullYear();
      const month = String(date.getMonth() + 1).padStart(2, "0");
      const day = String(date.getDate()).padStart(2, "0");
      return `${year}-${month}-${day}`;
    }
  } catch (e) {
    console.error("\u65E5\u671F\u683C\u5F0F\u5316\u5931\u8D25:", dateValue, e);
  }
  return String(dateValue);
};
const generateDateSeries = (startDate, endDate) => {
  return `
        SELECT DATE('${startDate}') as date_value
        UNION ALL
        SELECT DATE(date_value, '+1 day')
        FROM date_series
        WHERE date_value < '${endDate}'
    `;
};
const getLTVData = async (evt) => {
  var _a;
  try {
    const query = getQuery(evt);
    const {
      startDate,
      endDate,
      channelCode,
      gameId,
      adminId,
      page = 1,
      pageSize = 20
    } = query;
    if (!startDate || !endDate) {
      throw createError({
        status: 400,
        message: "\u5F00\u59CB\u65E5\u671F\u548C\u7ED3\u675F\u65E5\u671F\u4E3A\u5FC5\u586B\u9879"
      });
    }
    const currentPage = parseInt(page) || 1;
    const limit = parseInt(pageSize) || 20;
    const offset = (currentPage - 1) * limit;
    let whereConditions = ["ls.stat_date BETWEEN ? AND ?"];
    let queryParams = [startDate, endDate];
    if (adminId) {
      const adminPermissions = await getAdminWithPermissions(parseInt(adminId));
      if (adminPermissions && adminPermissions.level > 0) {
        const allowedChannels = adminPermissions.allowed_channel_codes || [];
        const allowedGames = adminPermissions.allowed_game_ids || [];
        if (allowedChannels.length > 0) {
          const channelPlaceholders = allowedChannels.map(() => "?").join(",");
          whereConditions.push(`ls.channel_code IN (${channelPlaceholders})`);
          queryParams.push(...allowedChannels);
        }
        if (allowedGames.length > 0) {
          const gamePlaceholders = allowedGames.map(() => "?").join(",");
          whereConditions.push(`(ls.game_code IN (${gamePlaceholders}) OR ls.game_code = '')`);
          queryParams.push(...allowedGames.map((id) => id.toString()));
        }
      }
    }
    if (channelCode) {
      whereConditions.push("ls.channel_code = ?");
      queryParams.push(channelCode);
    }
    if (gameId) {
      whereConditions.push("ls.game_code = ?");
      queryParams.push(gameId);
    }
    const whereClause = whereConditions.length > 0 ? `WHERE ${whereConditions.join(" AND ")}` : "";
    const dataQuery = `
            SELECT 
                ls.stat_date,
                SUM(ls.new_users) as new_users,
                SUM(ls.ltv1_amount) as ltv1_amount,
                SUM(ls.ltv2_amount) as ltv2_amount,
                SUM(ls.ltv3_amount) as ltv3_amount,
                SUM(ls.ltv4_amount) as ltv4_amount,
                SUM(ls.ltv5_amount) as ltv5_amount,
                SUM(ls.ltv6_amount) as ltv6_amount,
                SUM(ls.ltv7_amount) as ltv7_amount,
                SUM(ls.ltv10_amount) as ltv10_amount,
                SUM(ls.ltv20_amount) as ltv20_amount,
                SUM(ls.ltv30_amount) as ltv30_amount,
                CASE 
                    WHEN SUM(ls.new_users) > 0 
                    THEN ROUND(SUM(ls.ltv1_amount) / SUM(ls.new_users), 2)
                    ELSE 0 
                END as ltv1_arpu,
                CASE 
                    WHEN SUM(ls.new_users) > 0 
                    THEN ROUND(SUM(ls.ltv2_amount) / SUM(ls.new_users), 2)
                    ELSE 0 
                END as ltv2_arpu,
                CASE 
                    WHEN SUM(ls.new_users) > 0 
                    THEN ROUND(SUM(ls.ltv3_amount) / SUM(ls.new_users), 2)
                    ELSE 0 
                END as ltv3_arpu,
                CASE 
                    WHEN SUM(ls.new_users) > 0 
                    THEN ROUND(SUM(ls.ltv4_amount) / SUM(ls.new_users), 2)
                    ELSE 0 
                END as ltv4_arpu,
                CASE 
                    WHEN SUM(ls.new_users) > 0 
                    THEN ROUND(SUM(ls.ltv5_amount) / SUM(ls.new_users), 2)
                    ELSE 0 
                END as ltv5_arpu,
                CASE 
                    WHEN SUM(ls.new_users) > 0 
                    THEN ROUND(SUM(ls.ltv6_amount) / SUM(ls.new_users), 2)
                    ELSE 0 
                END as ltv6_arpu,
                CASE 
                    WHEN SUM(ls.new_users) > 0 
                    THEN ROUND(SUM(ls.ltv7_amount) / SUM(ls.new_users), 2)
                    ELSE 0 
                END as ltv7_arpu,
                CASE 
                    WHEN SUM(ls.new_users) > 0 
                    THEN ROUND(SUM(ls.ltv10_amount) / SUM(ls.new_users), 2)
                    ELSE 0 
                END as ltv10_arpu,
                CASE 
                    WHEN SUM(ls.new_users) > 0 
                    THEN ROUND(SUM(ls.ltv20_amount) / SUM(ls.new_users), 2)
                    ELSE 0 
                END as ltv20_arpu,
                CASE 
                    WHEN SUM(ls.new_users) > 0 
                    THEN ROUND(SUM(ls.ltv30_amount) / SUM(ls.new_users), 2)
                    ELSE 0 
                END as ltv30_arpu,
                '\u6C47\u603B\u6570\u636E' as channel_name,
                '\u6C47\u603B\u6570\u636E' as game_display_name
            FROM ltvstats ls
            ${whereClause}
            GROUP BY ls.stat_date
            ORDER BY ls.stat_date DESC
            LIMIT ? OFFSET ?
        `;
    const countQuery = `
            SELECT COUNT(DISTINCT ls.stat_date) as total
            FROM ltvstats ls
            ${whereClause}
        `;
    const [dataResult, countResult] = await Promise.all([
      sql({
        query: dataQuery,
        values: [...queryParams, limit, offset]
      }),
      sql({
        query: countQuery,
        values: queryParams
      })
    ]);
    const ltvData = dataResult.map((row) => ({
      ...row,
      stat_date: formatDateToString(row.stat_date)
    }));
    const total = ((_a = countResult == null ? void 0 : countResult[0]) == null ? void 0 : _a.total) || 0;
    const summaryQuery = `
            SELECT 
                SUM(ls.new_users) as total_new_users,
                SUM(ls.ltv1_amount) as total_ltv1_amount,
                SUM(ls.ltv3_amount) as total_ltv3_amount,
                SUM(ls.ltv7_amount) as total_ltv7_amount,
                SUM(ls.ltv30_amount) as total_ltv30_amount
            FROM ltvstats ls
            ${whereClause}
        `;
    const summaryResult = await sql({
      query: summaryQuery,
      values: queryParams
    });
    const summary = (summaryResult == null ? void 0 : summaryResult[0]) || {};
    const avgArpu = {
      ltv1: summary.total_new_users > 0 ? (summary.total_ltv1_amount / summary.total_new_users).toFixed(2) : "0.00",
      ltv3: summary.total_new_users > 0 ? (summary.total_ltv3_amount / summary.total_new_users).toFixed(2) : "0.00",
      ltv7: summary.total_new_users > 0 ? (summary.total_ltv7_amount / summary.total_new_users).toFixed(2) : "0.00",
      ltv30: summary.total_new_users > 0 ? (summary.total_ltv30_amount / summary.total_new_users).toFixed(2) : "0.00"
    };
    return {
      success: true,
      data: {
        list: ltvData,
        pagination: {
          page: currentPage,
          pageSize: limit,
          total,
          totalPages: Math.ceil(total / limit)
        },
        summary: {
          total_new_users: summary.total_new_users || 0,
          total_ltv1_amount: parseFloat(summary.total_ltv1_amount || 0).toFixed(2),
          total_ltv3_amount: parseFloat(summary.total_ltv3_amount || 0).toFixed(2),
          total_ltv7_amount: parseFloat(summary.total_ltv7_amount || 0).toFixed(2),
          total_ltv30_amount: parseFloat(summary.total_ltv30_amount || 0).toFixed(2),
          avg_arpu: avgArpu
        }
      }
    };
  } catch (e) {
    console.error("\u83B7\u53D6LTV\u6570\u636E\u5931\u8D25:", e);
    throw createError({
      status: 500,
      message: e.message || "\u83B7\u53D6LTV\u6570\u636E\u5931\u8D25"
    });
  }
};
const getLTVTrendData = async (evt) => {
  try {
    const query = getQuery(evt);
    const {
      startDate,
      endDate,
      channelCode,
      gameId,
      adminId
    } = query;
    if (!startDate || !endDate) {
      throw createError({
        status: 400,
        message: "\u5F00\u59CB\u65E5\u671F\u548C\u7ED3\u675F\u65E5\u671F\u4E3A\u5FC5\u586B\u9879"
      });
    }
    let whereConditions = ["ls.stat_date BETWEEN ? AND ?"];
    let queryParams = [startDate, endDate];
    if (adminId) {
      const adminPermissions = await getAdminWithPermissions(parseInt(adminId));
      if (adminPermissions && adminPermissions.level > 0) {
        const allowedChannels = adminPermissions.allowed_channel_codes || [];
        const allowedGames = adminPermissions.allowed_game_ids || [];
        if (allowedChannels.length > 0) {
          const channelPlaceholders = allowedChannels.map(() => "?").join(",");
          whereConditions.push(`ls.channel_code IN (${channelPlaceholders})`);
          queryParams.push(...allowedChannels);
        }
        if (allowedGames.length > 0) {
          const gamePlaceholders = allowedGames.map(() => "?").join(",");
          whereConditions.push(`(ls.game_code IN (${gamePlaceholders}) OR ls.game_code = '')`);
          queryParams.push(...allowedGames.map((id) => id.toString()));
        }
      }
    }
    if (channelCode) {
      whereConditions.push("ls.channel_code = ?");
      queryParams.push(channelCode);
    }
    if (gameId) {
      whereConditions.push("ls.game_code = ?");
      queryParams.push(gameId);
    }
    const whereClause = whereConditions.length > 0 ? `WHERE ${whereConditions.join(" AND ")}` : "";
    const trendQuery = `
            SELECT 
                ls.stat_date,
                SUM(ls.new_users) as total_new_users,
                SUM(ls.ltv1_amount) as ltv1_amount,
                SUM(ls.ltv3_amount) as ltv3_amount,
                SUM(ls.ltv7_amount) as ltv7_amount,
                SUM(ls.ltv30_amount) as ltv30_amount,
                CASE 
                    WHEN SUM(ls.new_users) > 0 
                    THEN ROUND(SUM(ls.ltv1_amount) / SUM(ls.new_users), 2)
                    ELSE 0 
                END as ltv1_arpu,
                CASE 
                    WHEN SUM(ls.new_users) > 0 
                    THEN ROUND(SUM(ls.ltv3_amount) / SUM(ls.new_users), 2)
                    ELSE 0 
                END as ltv3_arpu,
                CASE 
                    WHEN SUM(ls.new_users) > 0 
                    THEN ROUND(SUM(ls.ltv7_amount) / SUM(ls.new_users), 2)
                    ELSE 0 
                END as ltv7_arpu,
                CASE 
                    WHEN SUM(ls.new_users) > 0 
                    THEN ROUND(SUM(ls.ltv30_amount) / SUM(ls.new_users), 2)
                    ELSE 0 
                END as ltv30_arpu
            FROM ltvstats ls
            ${whereClause}
            GROUP BY ls.stat_date
            ORDER BY ls.stat_date
        `;
    const trendResult = await sql({
      query: trendQuery,
      values: queryParams
    });
    const trendData = trendResult || [];
    return {
      success: true,
      data: {
        trend: trendData,
        startDate,
        endDate
      }
    };
  } catch (e) {
    console.error("\u83B7\u53D6LTV\u8D8B\u52BF\u6570\u636E\u5931\u8D25:", e);
    throw createError({
      status: 500,
      message: e.message || "\u83B7\u53D6LTV\u8D8B\u52BF\u6570\u636E\u5931\u8D25"
    });
  }
};
const adminTransferPlatformCoins = async (evt) => {
  try {
    const body = await readBody(evt);
    const { from_channel_code, to_channel_code, amount, remark, operator_channel_code } = body;
    if (!from_channel_code || !to_channel_code || !amount) {
      throw createError({
        status: 400,
        message: "\u7F3A\u5C11\u5FC5\u8981\u53C2\u6570"
      });
    }
    if (amount === 0) {
      throw createError({
        status: 400,
        message: "\u8F6C\u8D26\u91D1\u989D\u4E0D\u80FD\u4E3A0"
      });
    }
    const result = await transferBetweenAdmins(
      from_channel_code,
      to_channel_code,
      parseFloat(amount),
      remark || "",
      operator_channel_code || ""
    );
    return {
      success: true,
      message: result.message,
      data: result
    };
  } catch (e) {
    console.error("\u4EE3\u7406\u95F4\u8F6C\u8D26\u5931\u8D25:", e);
    throw createError({
      status: 500,
      message: e.message || "\u8F6C\u8D26\u5931\u8D25"
    });
  }
};
const adminTransferToPlayer = async (evt) => {
  try {
    const authorizationHeader = getHeader(evt, "authorization");
    const token = authorizationHeader ? parseInt(authorizationHeader) : null;
    if (!token) {
      throw createError({ statusCode: 401, message: "\u672A\u63D0\u4F9B\u8BA4\u8BC1token" });
    }
    const currentAdmin = await getAdminWithPermissions(token);
    if (!currentAdmin || currentAdmin.level > 0) {
      throw createError({ statusCode: 403, message: "\u53EA\u6709\u8D85\u7EA7\u7BA1\u7406\u5458\u53EF\u4EE5\u7ED9\u73A9\u5BB6\u53D1\u653E\u5E73\u53F0\u5E01" });
    }
    const body = await readBody(evt);
    const { admin_channel_code, user_id, amount, remark, operator_channel_code } = body;
    if (!admin_channel_code || !user_id || !amount) {
      throw createError({
        status: 400,
        message: "\u7F3A\u5C11\u5FC5\u8981\u53C2\u6570"
      });
    }
    const parsedUserId = parseInt(user_id.toString());
    if (isNaN(parsedUserId) || parsedUserId <= 0) {
      throw createError({
        status: 400,
        message: "\u7528\u6237ID\u5FC5\u987B\u662F\u6709\u6548\u7684\u6B63\u6574\u6570"
      });
    }
    if (amount === 0) {
      throw createError({
        status: 400,
        message: "\u8F6C\u8D26\u91D1\u989D\u4E0D\u80FD\u4E3A0"
      });
    }
    const result = await transferToPlayer(
      admin_channel_code,
      parsedUserId.toString(),
      parseFloat(amount),
      remark || "",
      operator_channel_code || ""
    );
    return {
      success: true,
      message: result.message,
      data: result
    };
  } catch (e) {
    console.error("\u4EE3\u7406\u7ED9\u73A9\u5BB6\u8F6C\u8D26\u5931\u8D25:", e);
    throw createError({
      status: 500,
      message: e.message || "\u8F6C\u8D26\u5931\u8D25"
    });
  }
};
const getAdminPlatformCoinTransactions = async (evt) => {
  try {
    const body = await readBody(evt);
    const { channel_code, page = 1, page_size = 20 } = body;
    if (!channel_code) {
      throw createError({
        status: 400,
        message: "\u7F3A\u5C11\u6E20\u9053\u4EE3\u7801"
      });
    }
    const parsedPage = Math.max(1, parseInt(page.toString()) || 1);
    const parsedPageSize = Math.max(1, Math.min(100, parseInt(page_size.toString()) || 20));
    const result = await getAdminTransactions(
      channel_code,
      parsedPage,
      parsedPageSize
    );
    return {
      success: true,
      data: result
    };
  } catch (e) {
    console.error("\u83B7\u53D6\u4EE3\u7406\u8F6C\u8D26\u8BB0\u5F55\u5931\u8D25:", e);
    throw createError({
      status: 500,
      message: e.message || "\u83B7\u53D6\u8BB0\u5F55\u5931\u8D25"
    });
  }
};
const getAdminToPlayerTransactions = async (evt) => {
  try {
    const body = await readBody(evt);
    const { channel_code, page = 1, page_size = 20 } = body;
    if (!channel_code) {
      throw createError({
        status: 400,
        message: "\u7F3A\u5C11\u6E20\u9053\u4EE3\u7801"
      });
    }
    const parsedPage = Math.max(1, parseInt(page.toString()) || 1);
    const parsedPageSize = Math.max(1, Math.min(100, parseInt(page_size.toString()) || 20));
    const result = await getAdminToPlayerTransactions$1(
      channel_code,
      parsedPage,
      parsedPageSize
    );
    return {
      success: true,
      data: result
    };
  } catch (e) {
    console.error("\u83B7\u53D6\u4EE3\u7406\u7ED9\u73A9\u5BB6\u8F6C\u8D26\u8BB0\u5F55\u5931\u8D25:", e);
    throw createError({
      status: 500,
      message: e.message || "\u83B7\u53D6\u8BB0\u5F55\u5931\u8D25"
    });
  }
};
const getAdminPlatformCoinBalance = async (evt) => {
  try {
    const body = await readBody(evt);
    const { channel_code } = body;
    if (!channel_code) {
      throw createError({
        status: 400,
        message: "\u7F3A\u5C11\u6E20\u9053\u4EE3\u7801"
      });
    }
    const result = await getAdminBalance(channel_code);
    return {
      success: true,
      data: result
    };
  } catch (e) {
    console.error("\u83B7\u53D6\u4EE3\u7406\u4F59\u989D\u5931\u8D25:", e);
    throw createError({
      status: 500,
      message: e.message || "\u83B7\u53D6\u4F59\u989D\u5931\u8D25"
    });
  }
};
const checkUserChannel = async (evt) => {
  try {
    const body = await readBody(evt);
    const { user_id, admin_channel_code } = body;
    if (!user_id || !admin_channel_code) {
      throw createError({
        status: 400,
        message: "\u7F3A\u5C11\u5FC5\u8981\u53C2\u6570"
      });
    }
    const parsedUserId = parseInt(user_id.toString());
    if (isNaN(parsedUserId) || parsedUserId <= 0) {
      throw createError({
        status: 400,
        message: "\u7528\u6237ID\u5FC5\u987B\u662F\u6709\u6548\u7684\u6B63\u6574\u6570"
      });
    }
    const adminResult = await sql({
      query: "SELECT level, allowed_channel_codes FROM admins WHERE channel_code = ? AND is_active = 1",
      values: [admin_channel_code]
    });
    if (adminResult.length === 0) {
      throw createError({
        status: 404,
        message: "\u4EE3\u7406\u4E0D\u5B58\u5728"
      });
    }
    const adminLevel = adminResult[0].level || 0;
    const allowedChannels = adminResult[0].allowed_channel_codes || [];
    if (adminLevel === 0) {
      const userResult2 = await sql({
        query: "SELECT channel_code FROM users WHERE id = ?",
        values: [parsedUserId]
      });
      if (userResult2.length === 0) {
        throw createError({
          status: 404,
          message: "\u73A9\u5BB6\u4E0D\u5B58\u5728"
        });
      }
      return {
        success: true,
        message: "\u8D85\u7EA7\u7BA1\u7406\u5458\u6743\u9650\u9A8C\u8BC1\u901A\u8FC7",
        data: {
          user_channel_code: userResult2[0].channel_code
        }
      };
    }
    const userResult = await sql({
      query: "SELECT channel_code FROM users WHERE id = ?",
      values: [parsedUserId]
    });
    if (userResult.length === 0) {
      throw createError({
        status: 404,
        message: "\u73A9\u5BB6\u4E0D\u5B58\u5728"
      });
    }
    const userChannelCode = userResult[0].channel_code;
    if (!allowedChannels.includes(userChannelCode)) {
      return {
        success: false,
        message: "\u8BE5\u73A9\u5BB6\u4E0D\u5C5E\u4E8E\u60A8\u7684\u7BA1\u7406\u6E20\u9053\u8303\u56F4"
      };
    }
    return {
      success: true,
      message: "\u73A9\u5BB6\u6E20\u9053\u9A8C\u8BC1\u901A\u8FC7",
      data: {
        user_channel_code: userChannelCode
      }
    };
  } catch (e) {
    console.error("\u68C0\u67E5\u73A9\u5BB6\u6E20\u9053\u5931\u8D25:", e);
    throw createError({
      status: 500,
      message: e.message || "\u68C0\u67E5\u73A9\u5BB6\u6E20\u9053\u5931\u8D25"
    });
  }
};
const getChannelData = async (evt) => {
  var _a;
  try {
    const query = getQuery(evt);
    const {
      startDate,
      endDate,
      channelCode,
      gameId,
      adminId,
      page = 1,
      pageSize = 20
    } = query;
    if (!startDate || !endDate) {
      throw createError({
        status: 400,
        message: "\u5F00\u59CB\u65E5\u671F\u548C\u7ED3\u675F\u65E5\u671F\u4E3A\u5FC5\u586B\u9879"
      });
    }
    const currentPage = parseInt(page) || 1;
    const limit = parseInt(pageSize) || 20;
    const offset = (currentPage - 1) * limit;
    let adminPermissions = null;
    let allowedChannels = [];
    if (adminId) {
      adminPermissions = await getAdminWithPermissions(parseInt(adminId));
      if (adminPermissions) {
        if (adminPermissions.level === 0) {
          allowedChannels = [];
        } else {
          allowedChannels = adminPermissions.allowed_channel_codes || [];
        }
      }
    }
    let conditions = ["stat_date BETWEEN ? AND ?"];
    let params = [startDate, endDate];
    if (channelCode) {
      const AgentRelationships = await import('../../_/agentRelationships.mjs');
      const childChannels = await AgentRelationships.getAllChildChannelCodes(channelCode.toString());
      const targetChannels = [channelCode.toString(), ...childChannels];
      const channelPlaceholders = targetChannels.map(() => "?").join(",");
      conditions.push(`channel_code IN (${channelPlaceholders})`);
      params.push(...targetChannels);
      console.log("[\u6E20\u9053\u6570\u636E\u67E5\u8BE2] \u9009\u62E9\u4E86\u5177\u4F53\u6E20\u9053:", {
        selectedChannel: channelCode,
        allChannels: targetChannels
      });
    } else if (allowedChannels.length > 0) {
      const channelPlaceholders = allowedChannels.map(() => "?").join(",");
      conditions.push(`channel_code IN (${channelPlaceholders})`);
      params.push(...allowedChannels);
      console.log("[\u6E20\u9053\u6570\u636E\u67E5\u8BE2] \u4F7F\u7528\u7BA1\u7406\u5458\u6743\u9650:", {
        allowedChannels
      });
    } else {
      console.log("[\u6E20\u9053\u6570\u636E\u67E5\u8BE2] \u8D85\u7EA7\u7BA1\u7406\u5458\uFF0C\u4E0D\u9650\u5236\u6E20\u9053");
    }
    if (gameId) {
      conditions.push("game_code = ?");
      params.push(gameId.toString());
    }
    const dataQuery = `
            SELECT 
                stat_date,
                SUM(register_users) as register_users,
                SUM(valid_register_users) as valid_register_users,
                SUM(character_count) as character_count,
                SUM(high_value_users_200) as high_value_users_200,
                SUM(recharge_times) as recharge_times,
                SUM(recharge_users) as recharge_users,
                SUM(real_recharge_amount) as real_recharge_amount,
                SUM(high_value_recharge_amount) as high_value_recharge_amount
            FROM dailystats
            WHERE ${conditions.join(" AND ")}
            GROUP BY stat_date
            ORDER BY stat_date DESC
            LIMIT ? OFFSET ?
        `;
    const countQuery = `
            SELECT COUNT(DISTINCT stat_date) as total
            FROM dailystats
            WHERE ${conditions.join(" AND ")}
        `;
    const [dataResult, countResult] = await Promise.all([
      sql({
        query: dataQuery,
        values: [...params, limit, offset]
      }),
      sql({
        query: countQuery,
        values: params
      })
    ]);
    const channelData = dataResult.map((row) => ({
      stat_date: formatDateToString(row.stat_date),
      register_users: row.register_users || 0,
      valid_register_users: row.valid_register_users || 0,
      character_count: row.character_count || 0,
      high_value_users_200: row.high_value_users_200 || 0,
      recharge_times: row.recharge_times || 0,
      recharge_users: row.recharge_users || 0,
      real_recharge_amount: parseFloat(row.real_recharge_amount || "0"),
      high_value_recharge_amount: parseFloat(row.high_value_recharge_amount || "0")
    }));
    const total = ((_a = countResult == null ? void 0 : countResult[0]) == null ? void 0 : _a.total) || 0;
    return {
      success: true,
      data: {
        list: channelData,
        pagination: {
          page: currentPage,
          pageSize: limit,
          total,
          totalPages: Math.ceil(total / limit)
        }
      }
    };
  } catch (e) {
    console.error("\u83B7\u53D6\u6E20\u9053\u6570\u636E\u5931\u8D25:", e);
    throw createError({
      status: 500,
      message: e.message || "\u83B7\u53D6\u6E20\u9053\u6570\u636E\u5931\u8D25"
    });
  }
};
const getChannelSettlementData = defineEventHandler(async (evt) => {
  var _a, _b, _c;
  try {
    const query = getQuery(evt);
    const adminId = parseInt(query.admin_id) || null;
    if (!adminId) {
      throw createError({
        status: 400,
        message: "\u7F3A\u5C11\u7BA1\u7406\u5458ID"
      });
    }
    const currentAdmin = await getAdminWithPermissions(adminId);
    if (!currentAdmin) {
      throw createError({
        status: 404,
        message: "\u7BA1\u7406\u5458\u4E0D\u5B58\u5728"
      });
    }
    let childAgents = [];
    if (currentAdmin.level === 0) {
      const result = await sql({
        query: `SELECT * FROM admins 
                       WHERE level = 1 AND is_active = 1 
                       ORDER BY name`,
        values: []
      });
      childAgents = result;
    } else {
      const targetLevel = currentAdmin.level + 1;
      console.log(`[\u6E20\u9053\u7ED3\u7B97\u6570\u636E] \u5F53\u524D\u7BA1\u7406\u5458: ${currentAdmin.name} (\u7EA7\u522B${currentAdmin.level})`);
      console.log(`[\u6E20\u9053\u7ED3\u7B97\u6570\u636E] \u67E5\u627E\u76F4\u63A5\u4E0B\u7EA7\u4EE3\u7406 (\u7EA7\u522B${targetLevel})`);
      const allowedChannelCodes = currentAdmin.allowed_channel_codes || [];
      if (allowedChannelCodes.length > 0) {
        const cleanedChannelCodes = allowedChannelCodes.map((code) => typeof code === "string" ? code.trim() : code).filter((code) => code && code !== "");
        const childChannelCodes = cleanedChannelCodes.filter((code) => code !== currentAdmin.channel_code);
        if (childChannelCodes.length > 0) {
          const placeholders = childChannelCodes.map(() => "?").join(",");
          const result = await sql({
            query: `SELECT * FROM admins 
                               WHERE channel_code IN (${placeholders}) 
                               AND is_active = 1 
                               AND level = ?
                               ORDER BY name`,
            values: [...childChannelCodes, targetLevel]
          });
          childAgents = result;
          console.log(`[\u6E20\u9053\u7ED3\u7B97\u6570\u636E] \u627E\u5230 ${childAgents.length} \u4E2A\u7EA7\u522B${targetLevel}\u7684\u76F4\u63A5\u4E0B\u7EA7\u4EE3\u7406:`);
          childAgents.forEach((agent) => {
            console.log(`  - ${agent.name} (${agent.channel_code}) \u7EA7\u522B${agent.level}`);
          });
        } else {
          console.log(`[\u6E20\u9053\u7ED3\u7B97\u6570\u636E] \u6CA1\u6709\u627E\u5230\u4E0B\u7EA7\u6E20\u9053\u4EE3\u7801`);
        }
      } else {
        console.log(`[\u6E20\u9053\u7ED3\u7B97\u6570\u636E] \u5F53\u524D\u7BA1\u7406\u5458\u6CA1\u6709\u5141\u8BB8\u7684\u6E20\u9053\u4EE3\u7801`);
      }
    }
    const todayStr = getChinaDateString();
    const yesterdayStr = getChinaYesterdayString();
    const settlementData = [];
    console.log(`[\u6E20\u9053\u7ED3\u7B97\u6570\u636E] \u5F00\u59CB\u5904\u7406 ${childAgents.length} \u4E2A\u4E0B\u7EA7\u4EE3\u7406\u7684\u6570\u636E`);
    for (const agent of childAgents) {
      console.log(`[\u6E20\u9053\u7ED3\u7B97\u6570\u636E] \u5904\u7406\u4EE3\u7406: ${agent.name} (${agent.channel_code})`);
      let allChannelCodes = [];
      try {
        if (agent.allowed_channel_codes) {
          if (typeof agent.allowed_channel_codes === "string") {
            allChannelCodes = JSON.parse(agent.allowed_channel_codes);
          } else {
            allChannelCodes = agent.allowed_channel_codes;
          }
        } else {
          allChannelCodes = [agent.channel_code];
        }
        allChannelCodes = allChannelCodes.map((code) => typeof code === "string" ? code.trim() : code).filter((code) => code && code !== "").filter((code, index, arr) => arr.indexOf(code) === index);
        if (!allChannelCodes.includes(agent.channel_code)) {
          allChannelCodes.unshift(agent.channel_code);
        }
        console.log(`[\u6E20\u9053\u7ED3\u7B97\u6570\u636E] \u4EE3\u7406 ${agent.name} \u7BA1\u8F96\u7684\u6E20\u9053:`, allChannelCodes);
      } catch (e) {
        console.warn(`\u89E3\u6790\u4EE3\u7406 ${agent.name} \u7684 allowed_channel_codes \u5931\u8D25\uFF0C\u4F7F\u7528\u9ED8\u8BA4\u6E20\u9053\u4EE3\u7801`);
        allChannelCodes = [agent.channel_code];
      }
      const placeholders = allChannelCodes.map(() => "?").join(",");
      const yesterdayPayments = await sql({
        query: `SELECT COALESCE(SUM(amount), 0) as total
                       FROM paymentrecords pr
                       LEFT JOIN users u ON pr.user_id = u.id
                       WHERE u.channel_code IN (${placeholders})
                       AND DATE(pr.created_at) = ?
                       AND pr.payment_status = 3
                       AND (pr.payment_way NOT LIKE '%\u5E73\u53F0\u5E01%' OR pr.payment_way IS NULL OR pr.payment_way = '')`,
        values: [...allChannelCodes, yesterdayStr]
      });
      const todayPayments = await sql({
        query: `SELECT COALESCE(SUM(amount), 0) as total
                       FROM paymentrecords pr
                       LEFT JOIN users u ON pr.user_id = u.id
                       WHERE u.channel_code IN (${placeholders})
                       AND DATE(pr.created_at) = ?
                       AND pr.payment_status = 3
                       AND (pr.payment_way NOT LIKE '%\u5E73\u53F0\u5E01%' OR pr.payment_way IS NULL OR pr.payment_way = '')`,
        values: [...allChannelCodes, todayStr]
      });
      const totalPayments = await sql({
        query: `SELECT COALESCE(SUM(amount), 0) as total
                       FROM paymentrecords pr
                       LEFT JOIN users u ON pr.user_id = u.id
                       WHERE u.channel_code IN (${placeholders})
                       AND pr.payment_status = 3
                       AND (pr.payment_way NOT LIKE '%\u5E73\u53F0\u5E01%' OR pr.payment_way IS NULL OR pr.payment_way = '')`,
        values: allChannelCodes
      });
      const yesterdayAmount = parseFloat(((_a = yesterdayPayments[0]) == null ? void 0 : _a.total) || 0);
      const todayAmount = parseFloat(((_b = todayPayments[0]) == null ? void 0 : _b.total) || 0);
      const totalAmount = parseFloat(((_c = totalPayments[0]) == null ? void 0 : _c.total) || 0);
      const divideRate = (agent.divide_rate || 0) / 100;
      const yesterdaySettlement = yesterdayAmount * divideRate;
      const todaySettlement = todayAmount * divideRate;
      const totalSettlement = totalAmount * divideRate;
      console.log(`[\u6E20\u9053\u7ED3\u7B97\u6570\u636E] \u4EE3\u7406 ${agent.name} \u7684\u6536\u5165\u7EDF\u8BA1:`);
      console.log(`  - \u7BA1\u8F96\u6E20\u9053\u6570\u91CF: ${allChannelCodes.length}`);
      console.log(`  - \u6628\u65E5\u6D41\u6C34: \xA5${yesterdayAmount}`);
      console.log(`  - \u4ECA\u65E5\u6D41\u6C34: \xA5${todayAmount}`);
      console.log(`  - \u603B\u6D41\u6C34: \xA5${totalAmount}`);
      console.log(`  - \u5206\u6210\u6BD4\u4F8B: ${agent.divide_rate}%`);
      console.log(`  - \u6628\u65E5\u7ED3\u7B97: \xA5${yesterdaySettlement.toFixed(2)}`);
      settlementData.push({
        agent_id: agent.id,
        agent_name: agent.name,
        channel_code: agent.channel_code,
        divide_rate: agent.divide_rate,
        channel_count: allChannelCodes.length,
        // 该代理管辖的渠道数量
        covered_channels: allChannelCodes,
        // 该代理管辖的所有渠道列表
        yesterday_amount: yesterdayAmount,
        yesterday_settlement: yesterdaySettlement,
        today_amount: todayAmount,
        today_settlement: todaySettlement,
        total_amount: totalAmount,
        total_settlement: totalSettlement
      });
    }
    return {
      success: true,
      data: {
        settlement_data: settlementData,
        current_admin: {
          name: currentAdmin.name,
          level: currentAdmin.level,
          divide_rate: currentAdmin.divide_rate
        }
      }
    };
  } catch (e) {
    console.error("\u83B7\u53D6\u6E20\u9053\u7ED3\u7B97\u6570\u636E\u5931\u8D25:", e);
    throw createError({
      status: 500,
      message: e.message || "\u83B7\u53D6\u6E20\u9053\u7ED3\u7B97\u6570\u636E\u5931\u8D25"
    });
  }
});

const insert = async (settlementData) => {
  const result = await sql({
    query: "INSERT INTO settlements (admin_id, admin_name, admin_level, total_amount, divide_rate, settlement_amount, status, settlement_date, remark, u_address, settlement_method, channel_code) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
    values: [
      settlementData.admin_id,
      settlementData.admin_name,
      settlementData.admin_level,
      settlementData.total_amount || 0,
      settlementData.divide_rate || 0,
      settlementData.settlement_amount || 0,
      0,
      settlementData.settlement_date || null,
      settlementData.remark || "",
      settlementData.u_address || "",
      settlementData.settlement_method || "U",
      settlementData.channel_code || ""
    ]
  });
  return result;
};
const updateStatus = async (id, status, remark) => {
  const fields = ["status = ?"];
  const values = [status];
  if (status === 1) {
    fields.push("settlement_date = NOW()");
  }
  if (remark !== void 0) {
    fields.push("remark = ?");
    values.push(remark);
  }
  fields.push("updated_at = NOW()");
  values.push(id);
  await sql({
    query: `UPDATE settlements SET ${fields.join(", ")} WHERE id = ?`,
    values
  });
};
const getAdminRelatedSettlements = async (adminId, page = 1, pageSize = 20) => {
  try {
    const AdminModel = await import('../../_/admin.mjs');
    const admin = await AdminModel.getAdminWithPermissions(adminId);
    if (!admin || !admin.channel_code) {
      return {
        data: [],
        total: 0,
        page,
        pageSize
      };
    }
    const offset = (page - 1) * pageSize;
    const allowedChannels = admin.allowed_channel_codes || [];
    const channelCodes = [admin.channel_code, ...allowedChannels.filter((c) => c !== admin.channel_code)];
    if (channelCodes.length === 0) {
      return {
        data: [],
        total: 0,
        page,
        pageSize
      };
    }
    const placeholders = channelCodes.map(() => "?").join(",");
    const settlements = await sql({
      query: `SELECT s.*, 
                           CASE WHEN s.channel_code = ? THEN 1 ELSE 0 END as is_own
                   FROM settlements s
                   WHERE s.channel_code IN (${placeholders})
                   ORDER BY s.created_at DESC 
                   LIMIT ? OFFSET ?`,
      values: [admin.channel_code, ...channelCodes, pageSize, offset]
    });
    const countResult = await sql({
      query: `SELECT COUNT(*) as total FROM settlements 
                   WHERE channel_code IN (${placeholders})`,
      values: channelCodes
    });
    return {
      data: settlements,
      total: countResult[0].total,
      page,
      pageSize
    };
  } catch (error) {
    console.error("\u83B7\u53D6\u4EE3\u7406\u76F8\u5173\u7ED3\u7B97\u8BB0\u5F55\u5931\u8D25:", error);
    return {
      data: [],
      total: 0,
      page,
      pageSize
    };
  }
};
const getChildAdminSettlements = async (adminId, page = 1, pageSize = 20, selectedAgent, status) => {
  try {
    const AdminModel = await import('../../_/admin.mjs');
    const admin = await AdminModel.getAdminWithPermissions(adminId);
    if (!admin || !admin.channel_code) {
      return {
        data: [],
        total: 0,
        page,
        pageSize
      };
    }
    const offset = (page - 1) * pageSize;
    const allowedChannels = admin.allowed_channel_codes || [];
    let childChannels = allowedChannels.filter((c) => c !== admin.channel_code);
    if (selectedAgent && selectedAgent !== "") {
      childChannels = [selectedAgent];
    }
    if (childChannels.length === 0) {
      return {
        data: [],
        total: 0,
        page,
        pageSize
      };
    }
    const placeholders = childChannels.map(() => "?").join(",");
    let whereClause = `s.channel_code IN (${placeholders})`;
    const queryValues = [...childChannels];
    if (status !== null && status !== void 0) {
      whereClause += " AND s.status = ?";
      queryValues.push(status);
    }
    const settlements = await sql({
      query: `SELECT s.*
                   FROM settlements s
                   WHERE ${whereClause}
                   ORDER BY s.status ASC, s.created_at DESC
                   LIMIT ? OFFSET ?`,
      values: [...queryValues, pageSize, offset]
    });
    const countResult = await sql({
      query: `SELECT COUNT(*) as total FROM settlements s
                   WHERE ${whereClause}`,
      values: queryValues
    });
    return {
      data: settlements,
      total: countResult[0].total,
      page,
      pageSize
    };
  } catch (error) {
    console.error("\u83B7\u53D6\u4E0B\u7EA7\u7ED3\u7B97\u7533\u8BF7\u5931\u8D25:", error);
    return {
      data: [],
      total: 0,
      page,
      pageSize
    };
  }
};
const calculateWithdrawableAmount$1 = async (adminId) => {
  var _a, _b, _c;
  try {
    const AdminModel = await import('../../_/admin.mjs');
    const admin = await AdminModel.getAdminWithPermissions(adminId);
    if (!admin || !admin.channel_code || !admin.divide_rate) {
      return {
        success: false,
        message: "\u4EE3\u7406\u4FE1\u606F\u4E0D\u5B8C\u6574",
        data: {
          total_amount: 0,
          settled_amount: 0,
          available_amount: 0,
          own_channel_amount: 0,
          child_channels_amount: 0,
          withdrawable_amount: 0,
          divide_rate: 0
        }
      };
    }
    const allowedChannels = admin.allowed_channel_codes || [];
    const ownChannelResult = await sql({
      query: `SELECT COALESCE(SUM(pr.amount), 0) as total_amount
                   FROM paymentrecords pr
                   JOIN users u ON pr.user_id = u.id
                   WHERE u.channel_code = ? AND pr.payment_status = 3
                   AND (pr.payment_way NOT LIKE '%\u5E73\u53F0\u5E01%' OR pr.payment_way IS NULL OR pr.payment_way = '')`,
      values: [admin.channel_code]
    });
    const ownChannelAmount = parseFloat(((_a = ownChannelResult[0]) == null ? void 0 : _a.total_amount) || "0");
    let childChannelsAmount = 0;
    if (allowedChannels.length > 0) {
      const childChannels = allowedChannels.filter((channel) => channel !== admin.channel_code);
      if (childChannels.length > 0) {
        const childChannelsResult = await sql({
          query: `SELECT COALESCE(SUM(pr.amount), 0) as total_amount
                           FROM paymentrecords pr
                           JOIN users u ON pr.user_id = u.id
                           WHERE u.channel_code IN (${childChannels.map(() => "?").join(",")}) 
                           AND pr.payment_status = 3
                           AND (pr.payment_way NOT LIKE '%\u5E73\u53F0\u5E01%' OR pr.payment_way IS NULL OR pr.payment_way = '')`,
          values: childChannels
        });
        childChannelsAmount = parseFloat(((_b = childChannelsResult[0]) == null ? void 0 : _b.total_amount) || "0");
      }
    }
    const settledResult = await sql({
      query: `SELECT COALESCE(SUM(total_amount), 0) as settled_amount
                   FROM settlements 
                   WHERE admin_id = ? AND status = 1`,
      values: [adminId]
    });
    const settledAmount = parseFloat(((_c = settledResult[0]) == null ? void 0 : _c.settled_amount) || "0");
    const totalAmount = ownChannelAmount + childChannelsAmount;
    const availableAmount = Math.max(0, totalAmount - settledAmount);
    const withdrawableAmount = availableAmount * (admin.divide_rate / 100);
    return {
      success: true,
      data: {
        total_amount: totalAmount,
        settled_amount: settledAmount,
        available_amount: availableAmount,
        own_channel_amount: ownChannelAmount,
        child_channels_amount: childChannelsAmount,
        own_channel_commission: ownChannelAmount * (admin.divide_rate / 100),
        child_channels_commission: childChannelsAmount * (admin.divide_rate / 100),
        withdrawable_amount: withdrawableAmount,
        divide_rate: admin.divide_rate
      }
    };
  } catch (error) {
    console.error("\u8BA1\u7B97\u53EF\u63D0\u73B0\u91D1\u989D\u5931\u8D25:", error);
    return {
      success: false,
      message: error instanceof Error ? error.message : "\u8BA1\u7B97\u5931\u8D25",
      data: {
        total_amount: 0,
        settled_amount: 0,
        available_amount: 0,
        own_channel_amount: 0,
        child_channels_amount: 0,
        withdrawable_amount: 0,
        divide_rate: 0
      }
    };
  }
};

const calculateWithdrawableAmount = async (evt) => {
  try {
    const body = await readBody(evt);
    const { admin_id } = body;
    if (!admin_id) {
      console.error("[calculateWithdrawableAmount] \u7F3A\u5C11\u7BA1\u7406\u5458ID");
      throw createError({
        status: 400,
        message: "\u7F3A\u5C11\u7BA1\u7406\u5458ID"
      });
    }
    const result = await calculateWithdrawableAmount$1(parseInt(admin_id));
    return result;
  } catch (e) {
    console.error("[calculateWithdrawableAmount] \u8BA1\u7B97\u53EF\u63D0\u73B0\u91D1\u989D\u5931\u8D25:", e);
    throw createError({
      status: 500,
      message: e.message || "\u8BA1\u7B97\u53EF\u63D0\u73B0\u91D1\u989D\u5931\u8D25"
    });
  }
};
const submitSettlementRequest = async (evt) => {
  try {
    const body = await readBody(evt);
    const {
      admin_id,
      settlement_amount,
      u_address,
      settlement_method = "U",
      remark = ""
    } = body;
    if (!admin_id || !settlement_amount || !u_address) {
      console.error("[submitSettlementRequest] \u7F3A\u5C11\u5FC5\u8981\u53C2\u6570");
      throw createError({
        status: 400,
        message: "\u7F3A\u5C11\u5FC5\u8981\u53C2\u6570"
      });
    }
    const admin = await getAdminWithPermissions(parseInt(admin_id));
    if (!admin) {
      console.error("[submitSettlementRequest] \u7BA1\u7406\u5458\u4E0D\u5B58\u5728");
      throw createError({
        status: 404,
        message: "\u7BA1\u7406\u5458\u4E0D\u5B58\u5728"
      });
    }
    let addressWarning = "";
    if (admin.u_address) {
      if (admin.u_address !== u_address) {
        addressWarning = "\u63D0\u4EA4\u7684U\u5730\u5740\u4E0E\u8D26\u6237\u7ED1\u5B9A\u5730\u5740\u4E0D\u4E00\u81F4";
      }
    } else {
      addressWarning = "\u8D26\u6237\u672A\u7ED1\u5B9AU\u5730\u5740";
    }
    console.log(`[submitSettlementRequest] \u8BA1\u7B97\u7BA1\u7406\u5458ID ${admin_id} \u7684\u53EF\u63D0\u73B0\u91D1\u989D`);
    const withdrawableResult = await calculateWithdrawableAmount$1(parseInt(admin_id));
    if (!withdrawableResult.success) {
      console.error("[submitSettlementRequest] \u8BA1\u7B97\u53EF\u63D0\u73B0\u91D1\u989D\u5931\u8D25");
      throw createError({
        status: 400,
        message: withdrawableResult.message || "\u8BA1\u7B97\u53EF\u63D0\u73B0\u91D1\u989D\u5931\u8D25"
      });
    }
    const maxWithdrawable = withdrawableResult.data.withdrawable_amount;
    const availableAmount = withdrawableResult.data.available_amount || 0;
    if (availableAmount <= 0) {
      console.error("[submitSettlementRequest] \u6682\u65E0\u53EF\u7ED3\u7B97\u6D41\u6C34");
      throw createError({
        status: 400,
        message: "\u6682\u65E0\u53EF\u7ED3\u7B97\u6D41\u6C34"
      });
    }
    if (parseFloat(settlement_amount) > maxWithdrawable) {
      console.error("[submitSettlementRequest] \u7533\u8BF7\u91D1\u989D\u8D85\u8FC7\u53EF\u63D0\u73B0\u91D1\u989D");
      throw createError({
        status: 400,
        message: `\u7533\u8BF7\u91D1\u989D\u4E0D\u80FD\u8D85\u8FC7\u53EF\u63D0\u73B0\u91D1\u989D \xA5${maxWithdrawable.toFixed(2)}`
      });
    }
    console.log(`[submitSettlementRequest] \u521B\u5EFA\u7ED3\u7B97\u8BB0\u5F55\uFF0C\u7BA1\u7406\u5458ID: ${admin_id}`);
    const settlementData = {
      admin_id: parseInt(admin_id),
      admin_name: admin.name,
      admin_level: admin.level,
      total_amount: availableAmount,
      // 使用可结算流水而不是总流水
      divide_rate: admin.divide_rate || 0,
      settlement_amount: parseFloat(settlement_amount),
      status: 0,
      // 待结算
      u_address,
      settlement_method,
      channel_code: admin.channel_code || "",
      remark
    };
    const result = await insert(settlementData);
    console.log("[submitSettlementRequest] \u7ED3\u7B97\u7533\u8BF7\u63D0\u4EA4\u6210\u529F");
    return {
      success: true,
      message: "\u7ED3\u7B97\u7533\u8BF7\u63D0\u4EA4\u6210\u529F",
      data: result,
      warning: addressWarning
    };
  } catch (e) {
    console.error("[submitSettlementRequest] \u63D0\u4EA4\u7ED3\u7B97\u7533\u8BF7\u5931\u8D25:", e);
    throw createError({
      status: 500,
      message: e.message || "\u63D0\u4EA4\u7ED3\u7B97\u7533\u8BF7\u5931\u8D25"
    });
  }
};
const getSettlementRecords = async (evt) => {
  try {
    const body = await readBody(evt);
    const { admin_id, page = 1, page_size = 20 } = body;
    console.log("[getSettlementRecords] \u8BF7\u6C42\u53C2\u6570:", body);
    if (!admin_id) {
      console.error("[getSettlementRecords] \u7F3A\u5C11\u7BA1\u7406\u5458ID");
      throw createError({
        status: 400,
        message: "\u7F3A\u5C11\u7BA1\u7406\u5458ID"
      });
    }
    const result = await getAdminRelatedSettlements(
      parseInt(admin_id),
      parseInt(page),
      parseInt(page_size)
    );
    console.log("[getSettlementRecords] \u83B7\u53D6\u7ED3\u7B97\u8BB0\u5F55\u6210\u529F");
    return {
      success: true,
      data: result
    };
  } catch (e) {
    console.error("[getSettlementRecords] \u83B7\u53D6\u7ED3\u7B97\u8BB0\u5F55\u5931\u8D25:", e);
    throw createError({
      status: 500,
      message: e.message || "\u83B7\u53D6\u7ED3\u7B97\u8BB0\u5F55\u5931\u8D25"
    });
  }
};
const getAdminUAddress = async (evt) => {
  try {
    const body = await readBody(evt);
    const { admin_id } = body;
    console.log("[getAdminUAddress] \u8BF7\u6C42\u53C2\u6570:", body);
    if (!admin_id) {
      console.error("[getAdminUAddress] \u7F3A\u5C11\u7BA1\u7406\u5458ID");
      throw createError({
        status: 400,
        message: "\u7F3A\u5C11\u7BA1\u7406\u5458ID"
      });
    }
    const admin = await getAdminWithPermissions(parseInt(admin_id));
    if (!admin) {
      console.error("[getAdminUAddress] \u7BA1\u7406\u5458\u4E0D\u5B58\u5728");
      throw createError({
        status: 404,
        message: "\u7BA1\u7406\u5458\u4E0D\u5B58\u5728"
      });
    }
    console.log("[getAdminUAddress] \u83B7\u53D6\u7BA1\u7406\u5458U\u5730\u5740\u6210\u529F");
    return {
      success: true,
      data: {
        u_address: admin.u_address || "",
        has_u_address: !!admin.u_address
      }
    };
  } catch (e) {
    console.error("[getAdminUAddress] \u83B7\u53D6\u7BA1\u7406\u5458U\u5730\u5740\u5931\u8D25:", e);
    throw createError({
      status: 500,
      message: e.message || "\u83B7\u53D6\u7BA1\u7406\u5458U\u5730\u5740\u5931\u8D25"
    });
  }
};
const updateAdminUAddress = async (evt) => {
  try {
    const body = await readBody(evt);
    const { admin_id, u_address } = body;
    console.log("[updateAdminUAddress] \u8BF7\u6C42\u53C2\u6570:", body);
    if (!admin_id || !u_address) {
      console.error("[updateAdminUAddress] \u7F3A\u5C11\u5FC5\u8981\u53C2\u6570");
      throw createError({
        status: 400,
        message: "\u7F3A\u5C11\u5FC5\u8981\u53C2\u6570"
      });
    }
    if (u_address.length < 10 || u_address.length > 100) {
      console.error("[updateAdminUAddress] U\u5730\u5740\u683C\u5F0F\u4E0D\u6B63\u786E");
      throw createError({
        status: 400,
        message: "U\u5730\u5740\u683C\u5F0F\u4E0D\u6B63\u786E"
      });
    }
    console.log(`[updateAdminUAddress] \u66F4\u65B0\u7BA1\u7406\u5458ID ${admin_id} \u7684U\u5730\u5740`);
    await updateAdmin(parseInt(admin_id), { u_address });
    console.log("[updateAdminUAddress] U\u5730\u5740\u66F4\u65B0\u6210\u529F");
    return {
      success: true,
      message: "U\u5730\u5740\u66F4\u65B0\u6210\u529F"
    };
  } catch (e) {
    console.error("[updateAdminUAddress] \u66F4\u65B0\u7BA1\u7406\u5458U\u5730\u5740\u5931\u8D25:", e);
    throw createError({
      status: 500,
      message: e.message || "\u66F4\u65B0\u7BA1\u7406\u5458U\u5730\u5740\u5931\u8D25"
    });
  }
};
const getChildSettlementRequests = async (evt) => {
  try {
    const body = await readBody(evt);
    const {
      admin_id,
      page = 1,
      page_size = 20,
      selected_agent = "",
      status = ""
    } = body;
    console.log("[getChildSettlementRequests] \u8BF7\u6C42\u53C2\u6570:", body);
    if (!admin_id) {
      console.error("[getChildSettlementRequests] \u7F3A\u5C11\u7BA1\u7406\u5458ID");
      throw createError({
        status: 400,
        message: "\u7F3A\u5C11\u7BA1\u7406\u5458ID"
      });
    }
    console.log("\u7ED3\u7B97\u7BA1\u7406\u7B5B\u9009\u53C2\u6570:", {
      admin_id,
      selected_agent,
      status,
      page,
      page_size
    });
    const result = await getChildAdminSettlements(
      parseInt(admin_id),
      parseInt(page),
      parseInt(page_size),
      selected_agent || null,
      status !== "" ? parseInt(status) : null
    );
    console.log("[getChildSettlementRequests] \u83B7\u53D6\u4E0B\u7EA7\u7ED3\u7B97\u7533\u8BF7\u6210\u529F");
    return {
      success: true,
      data: result
    };
  } catch (e) {
    console.error("\u83B7\u53D6\u4E0B\u7EA7\u7ED3\u7B97\u7533\u8BF7\u5931\u8D25:", e);
    throw createError({
      status: 500,
      message: e.message || "\u83B7\u53D6\u4E0B\u7EA7\u7ED3\u7B97\u7533\u8BF7\u5931\u8D25"
    });
  }
};
const reviewSettlementRequest = async (evt) => {
  try {
    const body = await readBody(evt);
    const { settlement_id, status, remark = "" } = body;
    console.log("[reviewSettlementRequest] \u8BF7\u6C42\u53C2\u6570:", body);
    if (!settlement_id || status !== 1 && status !== 2) {
      console.error("[reviewSettlementRequest] \u7F3A\u5C11\u5FC5\u8981\u53C2\u6570\u6216\u72B6\u6001\u65E0\u6548");
      throw createError({
        status: 400,
        message: "\u7F3A\u5C11\u5FC5\u8981\u53C2\u6570\u6216\u72B6\u6001\u65E0\u6548"
      });
    }
    console.log(`[reviewSettlementRequest] \u5BA1\u6838\u7ED3\u7B97\u7533\u8BF7\uFF0C\u7ED3\u7B97ID: ${settlement_id}, \u72B6\u6001: ${status}`);
    await updateStatus(parseInt(settlement_id), status, remark);
    const statusText = status === 1 ? "\u901A\u8FC7" : "\u62D2\u7EDD";
    console.log(`[reviewSettlementRequest] \u7ED3\u7B97\u7533\u8BF7${statusText}\u6210\u529F`);
    return {
      success: true,
      message: `\u7ED3\u7B97\u7533\u8BF7${statusText}\u6210\u529F`
    };
  } catch (e) {
    console.error("[reviewSettlementRequest] \u5BA1\u6838\u7ED3\u7B97\u7533\u8BF7\u5931\u8D25:", e);
    throw createError({
      status: 500,
      message: e.message || "\u5BA1\u6838\u7ED3\u7B97\u7533\u8BF7\u5931\u8D25"
    });
  }
};

const getAllSystemParams = async (evt) => {
  try {
    const systemParams = await read$2();
    return {
      code: 200,
      data: systemParams,
      message: "\u83B7\u53D6\u7CFB\u7EDF\u53C2\u6570\u6210\u529F"
    };
  } catch (error) {
    console.error("\u83B7\u53D6\u7CFB\u7EDF\u53C2\u6570\u5931\u8D25:", error);
    throw createError({
      status: 500,
      message: error.message || "\u83B7\u53D6\u7CFB\u7EDF\u53C2\u6570\u5931\u8D25"
    });
  }
};
const getSystemParam = async (evt) => {
  try {
    const key = getRouterParam(evt, "key");
    if (!key) {
      throw createError({
        status: 400,
        message: "\u7F3A\u5C11\u53C2\u6570key"
      });
    }
    const param = await detail(key);
    return {
      code: 200,
      data: param,
      message: "\u83B7\u53D6\u7CFB\u7EDF\u53C2\u6570\u6210\u529F"
    };
  } catch (error) {
    console.error("\u83B7\u53D6\u7CFB\u7EDF\u53C2\u6570\u5931\u8D25:", error);
    throw createError({
      status: error.status || 500,
      message: error.message || "\u83B7\u53D6\u7CFB\u7EDF\u53C2\u6570\u5931\u8D25"
    });
  }
};

const router = createRouter();
const withLogging = (handler, apiName) => {
  return defineEventHandler(async (event) => {
    const startTime = Date.now();
    `req_${startTime}_${Math.random().toString(36).substr(2, 9)}`;
    const headers = getHeaders(event);
    const ipAddress = headers["x-forwarded-for"] || headers["x-real-ip"] || "unknown";
    headers["user-agent"] || "unknown";
    const method = getMethod(event);
    const url = getRequestURL(event);
    let requestBody = {};
    let queryParams = {};
    try {
      if (method === "POST" || method === "PUT") {
        requestBody = await readBody(event);
      }
      queryParams = getQuery(event);
    } catch (e) {
      requestBody = {};
    }
    console.log(`[API] ${method} ${url.pathname} | IP: ${ipAddress.split(",")[0]}`);
    let response = {};
    let error = null;
    let statusCode = 200;
    try {
      try {
        const url2 = getRequestURL(event);
        const method2 = getMethod(event) || "GET";
        const pathname = url2.pathname.replace(/\/$/, "");
        const skipSignature = pathname === "/api/admin/login";
        if (!skipSignature) {
          await verifyApiSignature(event, url2.pathname, method2, queryParams, requestBody);
        }
      } catch (sigErr) {
        throw createError({ statusCode: 401, statusMessage: (sigErr == null ? void 0 : sigErr.statusMessage) || "invalid_sign 1" });
      }
      response = await handler(event);
    } catch (e) {
      error = e;
      statusCode = e.statusCode || 500;
      response = {
        success: false,
        message: e.statusMessage || e.message || "\u7CFB\u7EDF\u9519\u8BEF",
        data: null
      };
      try {
        setResponseStatus(event, statusCode);
      } catch {
      }
    }
    if (error) {
      console.error(`[API] \u9519\u8BEF: ${error.message}`);
    }
    console.log("==========================================");
    return response;
  });
};
const adminWrap = (handler, apiName) => {
  return withLogging(async (event) => {
    var _a, _b;
    const sid = getCookie(event, "admin_sid");
    const v = verifyAdminSession(sid);
    if (!v.ok) {
      throw createError({ statusCode: 401, statusMessage: "Unauthorized" });
    }
    const q = getQuery(event) || {};
    const qId = (_a = q.adminId) != null ? _a : q.admin_id;
    if (qId !== void 0 && String(qId) !== String(v.adminId)) {
      throw createError({ statusCode: 403, statusMessage: "Forbidden: adminId mismatch" });
    }
    if (["POST", "PUT", "PATCH", "DELETE"].includes((getMethod(event) || "GET").toUpperCase())) {
      try {
        const body = await readBody(event);
        const bId = (_b = body == null ? void 0 : body.adminId) != null ? _b : body == null ? void 0 : body.admin_id;
        if (bId !== void 0 && String(bId) !== String(v.adminId)) {
          throw createError({ statusCode: 403, statusMessage: "Forbidden: adminId mismatch" });
        }
      } catch {
      }
    }
    try {
      delete event.node.req.headers["authorization"];
      delete event.node.req.headers["Authorization"];
      event.node.req.headers["authorization"] = String(v.adminId);
    } catch {
    }
    return await handler(event);
  });
};
router.post("/admin/login", defineEventHandler(async (event) => {
  var _a;
  const headers = getHeaders(event);
  let clientIp = "unknown";
  if (headers["x-forwarded-for"]) {
    clientIp = String(headers["x-forwarded-for"]).split(",")[0].trim();
  } else if (headers["x-real-ip"]) {
    clientIp = String(headers["x-real-ip"]).trim();
  } else if ((_a = event.node.req.socket) == null ? void 0 : _a.remoteAddress) {
    clientIp = event.node.req.socket.remoteAddress;
  }
  if (clientIp.startsWith("::ffff:")) clientIp = clientIp.substring(7);
  console.log(`[Admin Login] \u767B\u5F55\u8BF7\u6C42 - IP: ${clientIp}`);
  const result = await login(event);
  try {
    const ok = !!(result && result.data);
    if (ok) {
      const adminId = result.data.id || result.data.admin_id || 0;
      const sid = signAdminSession(adminId);
      event.node.res.setHeader("Set-Cookie", [
        "auth_logged_in=true; Path=/; HttpOnly; SameSite=Lax",
        "auth_is_user=false; Path=/; HttpOnly; SameSite=Lax",
        `admin_sid=${sid}; Path=/; HttpOnly; SameSite=Lax`
      ]);
    }
  } catch {
  }
  return result;
}));
router.get("/admin/list", adminWrap(read));
router.post("/admin/refresh-permissions", adminWrap(refreshPermissions));
router.post("/admin/update-profile", adminWrap(updateProfile));
router.post("/admin/get-profile", adminWrap(getProfile));
router.post("/admin/platform-coin-balance", adminWrap(getAdminPlatformCoinBalance));
router.post("/admin/platform-coin-transactions", adminWrap(getAdminPlatformCoinTransactions));
router.post("/admin/transfer-platform-coins", adminWrap(adminTransferPlatformCoins));
router.post("/admin/platform-coin-to-player-transactions", adminWrap(getAdminToPlayerTransactions));
router.post("/admin/transfer-to-player", adminWrap(adminTransferToPlayer));
router.post("/admin/check-user-channel", adminWrap(checkUserChannel));
router.post("/admin/filtered-games", adminWrap(getFilteredGames));
router.get("/admin/games", adminWrap(getAllGames));
router.post("/admin/check-edit-permission", defineEventHandler(checkEditPermission));
router.post("/admin/manageable-admins", adminWrap(getManageableAdmins));
router.get("/admin/users", adminWrap(getUsers));
router.get("/admin/payments", adminWrap(getPaymentRecords));
router.get("/admin/characters", adminWrap(getGameCharacters));
router.get("/admin/user-login-logs", adminWrap(getUserLoginLogs));
router.get("/admin/today-login-stats", adminWrap(getTodayLoginStats));
router.post("/admin/get-child-channels", defineEventHandler(getChildChannels));
router.get("/admin/channel-codes", adminWrap(getChannelCodeOptions));
router.get("/admin/data-overview", adminWrap(getDataOverview));
router.get("/admin/daily-report-details", adminWrap(getDailyReportDetails));
router.get("/admin/data-overview-details", adminWrap(getDataOverviewDetails));
router.get("/admin/ltv-data", adminWrap(getLTVData));
router.get("/admin/ltv-trend", adminWrap(getLTVTrendData));
router.get("/admin/channel-data", adminWrap(getChannelData));
router.get("/admin/channel-settlement-data", adminWrap(getChannelSettlementData));
router.post("/admin/calculate-withdrawable-amount", defineEventHandler(calculateWithdrawableAmount));
router.post("/admin/submit-settlement-request", defineEventHandler(submitSettlementRequest));
router.post("/admin/settlement-records", defineEventHandler(getSettlementRecords));
router.post("/admin/get-u-address", defineEventHandler(getAdminUAddress));
router.post("/admin/update-u-address", adminWrap(updateAdminUAddress));
router.post("/admin/child-settlement-requests", adminWrap(getChildSettlementRequests));
router.post("/admin/review-settlement-request", adminWrap(reviewSettlementRequest));
router.get("/admin/system-params", defineEventHandler(getAllSystemParams));
router.get("/admin/system-params/:key", defineEventHandler(getSystemParam));
router.get("/payment/cashier-notify", withLogging(handleCashierPaymentNotify));
router.get("/payment/third-party-notify", withLogging(handleThirdPartyNotify));
const _____ = useBase("/api", router.handler);

export { _____ as default };
//# sourceMappingURL=_..._.mjs.map
