import { d as defineEventHandler, e as getHeader, c as createError, g as getQuery, t as getItemById, w as deleteItem, r as readBody, x as updateItem, y as addItem, z as getAllItems, A as getItemConfig, B as searchItems } from '../../../nitro/nitro.mjs';
import { getAdminWithPermissions } from '../../../_/admin.mjs';
import 'ioredis';
import 'fs';
import 'path';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'mysql2/promise';
import '@iconify/utils';
import 'consola';

const itemConfig = defineEventHandler(async (event) => {
  const method = event.node.req.method;
  const authorizationHeader = getHeader(event, "authorization");
  const token = authorizationHeader ? parseInt(authorizationHeader) : null;
  if (!token) {
    throw createError({
      status: 401,
      message: "\u672A\u63D0\u4F9B\u8BA4\u8BC1token"
    });
  }
  const adminInfo = await getAdminWithPermissions(token);
  if (!adminInfo || adminInfo.level !== 0) {
    throw createError({
      status: 403,
      message: "\u53EA\u6709\u8D85\u7EA7\u7BA1\u7406\u5458\u53EF\u4EE5\u7BA1\u7406\u7269\u54C1\u914D\u7F6E"
    });
  }
  try {
    switch (method) {
      case "GET":
        return await handleGetItems(event);
      case "POST":
        return await handleCreateItem(event);
      case "PUT":
        return await handleUpdateItem(event);
      case "DELETE":
        return await handleDeleteItem(event);
      default:
        throw createError({
          status: 405,
          message: "\u4E0D\u652F\u6301\u7684\u8BF7\u6C42\u65B9\u6CD5"
        });
    }
  } catch (error) {
    console.error("\u7269\u54C1\u914D\u7F6E\u7BA1\u7406API\u9519\u8BEF:", error);
    throw createError({
      status: error.status || 500,
      message: error.message || "\u670D\u52A1\u5668\u5185\u90E8\u9519\u8BEF"
    });
  }
});
async function handleGetItems(event) {
  const query = getQuery(event);
  const action = query.action;
  switch (action) {
    case "list":
      return await getItemList(query);
    case "search":
      return await searchItemList(query);
    case "types":
      return await getItemTypeList();
    case "rarities":
      return await getItemRarityList();
    case "detail":
      return await getItemDetail(query);
    case "debug":
      return await getConfigDebugInfo();
    case "health":
      return await getHealthCheck();
    default:
      return await getItemList(query);
  }
}
async function getItemList(query) {
  const page = Number(query.page) || 1;
  const pageSize = Math.min(Number(query.pageSize) || 20, 2e4);
  console.log("[getItemList] \u5F00\u59CB\u83B7\u53D6\u7269\u54C1\u914D\u7F6E...");
  const allItems = getAllItems();
  console.log(`[getItemList] \u914D\u7F6E\u52A0\u8F7D\u7ED3\u679C: ${allItems.length} \u4E2A\u7269\u54C1`);
  const items = allItems.map((item) => ({
    id: item.id,
    n: item.name,
    cn: item.name,
    d: "",
    type: "general",
    rarity: "common"
  }));
  const total = items.length;
  const offset = (page - 1) * pageSize;
  const pagedItems = items.slice(offset, offset + pageSize);
  console.log(`[getItemList] \u5206\u9875\u7ED3\u679C: \u7B2C${page}\u9875, \u6BCF\u9875${pageSize}, \u5171${total}\u9879, \u8FD4\u56DE${pagedItems.length}\u9879`);
  if (pagedItems.length > 0) {
    console.log(`[getItemList] \u793A\u4F8B\u5217\u8868\u7ED3\u679C:`, JSON.stringify(pagedItems.slice(0, 2), null, 2));
  }
  return {
    success: true,
    data: {
      list: pagedItems,
      total,
      page,
      pageSize,
      totalPages: Math.ceil(total / pageSize)
    }
  };
}
async function searchItemList(query) {
  const searchTerm = query.q;
  const page = Number(query.page) || 1;
  const pageSize = Math.min(Number(query.pageSize) || 20, 2e4);
  if (!searchTerm) {
    return {
      success: true,
      data: {
        list: [],
        total: 0,
        page,
        pageSize,
        totalPages: 0
      }
    };
  }
  try {
    const results = searchItems(searchTerm);
    const total = results.length;
    const offset = (page - 1) * pageSize;
    const pagedResults = results.slice(offset, offset + pageSize);
    const formattedResults = pagedResults.map((result) => ({
      id: result.id,
      n: result.name,
      cn: result.name,
      d: "",
      type: "general",
      rarity: "common"
    }));
    console.log(`[searchItems] \u641C\u7D22"${searchTerm}", \u627E\u5230${total}\u4E2A\u7ED3\u679C, \u8FD4\u56DE${pagedResults.length}\u4E2A`);
    if (formattedResults.length > 0) {
      console.log(`[searchItems] \u793A\u4F8B\u641C\u7D22\u7ED3\u679C:`, JSON.stringify(formattedResults.slice(0, 2), null, 2));
    }
    return {
      success: true,
      data: {
        list: formattedResults,
        total,
        page,
        pageSize,
        totalPages: Math.ceil(total / pageSize)
      }
    };
  } catch (error) {
    console.error(`[searchItems] \u641C\u7D22\u5931\u8D25: ${error.message}`);
    return {
      success: false,
      message: "\u641C\u7D22\u5931\u8D25: " + error.message,
      data: {
        list: [],
        total: 0,
        page,
        pageSize,
        totalPages: 0
      }
    };
  }
}
async function getItemTypeList() {
  return {
    success: true,
    data: ["general", "weapon", "armor", "consumable", "material"]
  };
}
async function getItemRarityList() {
  return {
    success: true,
    data: ["common", "uncommon", "rare", "epic", "legendary"]
  };
}
async function getItemDetail(query) {
  const itemId = query.id;
  if (!itemId) {
    throw createError({
      status: 400,
      message: "\u7F3A\u5C11\u7269\u54C1ID"
    });
  }
  const itemName = getItemById(itemId);
  if (!itemName) {
    throw createError({
      status: 404,
      message: "\u7269\u54C1\u4E0D\u5B58\u5728"
    });
  }
  return {
    success: true,
    data: {
      id: itemId,
      n: itemName,
      cn: itemName,
      d: "",
      type: "general",
      rarity: "common"
    }
  };
}
async function getConfigDebugInfo() {
  const fs = await import('fs');
  const path = await import('path');
  const possiblePaths = [
    path.join(process.cwd(), "server/config/itemConfig.json"),
    path.join(process.cwd(), "../server/config/itemConfig.json"),
    path.join(process.cwd(), "config/itemConfig.json"),
    process.env.ITEM_CONFIG_PATH || ""
  ];
  const pathInfo = [];
  let foundConfigPath = "";
  for (const configPath of possiblePaths) {
    if (!configPath) continue;
    const exists = fs.existsSync(configPath);
    const info = {
      path: configPath,
      exists
    };
    if (exists) {
      try {
        const stats = fs.statSync(configPath);
        info.size = stats.size;
        info.modified = stats.mtime;
        info.readable = true;
        const content = fs.readFileSync(configPath, "utf8");
        info.preview = content.substring(0, 100);
        info.isValidJson = true;
        const parsed = JSON.parse(content);
        info.itemCount = Object.keys(parsed).length;
        if (!foundConfigPath) {
          foundConfigPath = configPath;
        }
      } catch (error) {
        info.error = error.message;
        info.readable = false;
        info.isValidJson = false;
      }
    }
    pathInfo.push(info);
  }
  const config = getItemConfig();
  const currentItemCount = Object.keys(config).length;
  return {
    success: true,
    data: {
      currentWorkingDirectory: process.cwd(),
      environment: "production",
      configPaths: pathInfo,
      foundConfigPath,
      currentLoadedItems: currentItemCount,
      sampleItems: Object.keys(config).slice(0, 5),
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    }
  };
}
async function getHealthCheck() {
  return {
    success: true,
    data: {
      status: "ok",
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      api: "item-config",
      version: "1.0.0"
    }
  };
}
async function handleCreateItem(event) {
  const body = await readBody(event);
  const { item_id, n, cn } = body;
  if (!item_id || !n && !cn) {
    throw createError({
      status: 400,
      message: "\u7F3A\u5C11\u5FC5\u586B\u5B57\u6BB5\uFF1Aitem_id, \u7269\u54C1\u540D\u79F0"
    });
  }
  const itemName = (cn || n).trim();
  const success = addItem(String(item_id), itemName);
  if (!success) {
    throw createError({
      status: 400,
      message: "\u7269\u54C1\u521B\u5EFA\u5931\u8D25\uFF0C\u53EF\u80FD\u662FID\u5DF2\u5B58\u5728"
    });
  }
  return {
    success: true,
    message: "\u7269\u54C1\u521B\u5EFA\u6210\u529F",
    data: {
      id: item_id,
      n: itemName,
      cn: itemName,
      d: "",
      type: "general",
      rarity: "common"
    }
  };
}
async function handleUpdateItem(event) {
  var _a;
  const body = await readBody(event);
  const { id } = body;
  if (!id) {
    throw createError({
      status: 400,
      message: "\u7F3A\u5C11\u7269\u54C1ID"
    });
  }
  const existingItem = getItemById(id);
  if (!existingItem) {
    throw createError({
      status: 404,
      message: "\u7269\u54C1\u4E0D\u5B58\u5728"
    });
  }
  const newName = (_a = body.cn || body.n || body.name) == null ? void 0 : _a.trim();
  if (!newName) {
    throw createError({
      status: 400,
      message: "\u7F3A\u5C11\u7269\u54C1\u540D\u79F0"
    });
  }
  const success = updateItem(String(id), newName);
  if (!success) {
    throw createError({
      status: 500,
      message: "\u7269\u54C1\u66F4\u65B0\u5931\u8D25"
    });
  }
  return {
    success: true,
    message: "\u7269\u54C1\u66F4\u65B0\u6210\u529F",
    data: {
      id,
      n: newName,
      cn: newName,
      d: "",
      type: "general",
      rarity: "common"
    }
  };
}
async function handleDeleteItem(event) {
  const query = getQuery(event);
  const id = query.id;
  if (!id) {
    throw createError({
      status: 400,
      message: "\u7F3A\u5C11\u7269\u54C1ID"
    });
  }
  const existingItem = getItemById(String(id));
  if (!existingItem) {
    throw createError({
      status: 404,
      message: "\u7269\u54C1\u4E0D\u5B58\u5728"
    });
  }
  const success = deleteItem(String(id));
  if (!success) {
    throw createError({
      status: 500,
      message: "\u7269\u54C1\u5220\u9664\u5931\u8D25"
    });
  }
  return {
    success: true,
    message: "\u7269\u54C1\u5220\u9664\u6210\u529F"
  };
}

export { itemConfig as default };
//# sourceMappingURL=item-config.mjs.map
