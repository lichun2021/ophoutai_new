import { d as defineEventHandler, e as getHeader, c as createError, g as getQuery, s as sql, r as readBody, p as validateGiftItems, q as formatGiftItemsDisplay } from '../../../nitro/nitro.mjs';
import { g as getGiftPackageById, a as getGiftPackageByCode } from '../../../_/externalGiftPackage.mjs';
import { getAdminWithPermissions } from '../../../_/admin.mjs';
import 'ioredis';
import 'fs';
import 'path';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'mysql2/promise';
import '@iconify/utils';
import 'consola';

const giftPackages = defineEventHandler(async (event) => {
  const method = event.node.req.method;
  const authorizationHeader = getHeader(event, "authorization");
  const token = authorizationHeader ? parseInt(authorizationHeader) : null;
  if (!token) {
    throw createError({
      status: 401,
      message: "\u672A\u63D0\u4F9B\u8BA4\u8BC1token"
    });
  }
  const adminInfo = await getAdminWithPermissions(token);
  if (!adminInfo || adminInfo.level !== 0) {
    throw createError({
      status: 403,
      message: "\u53EA\u6709\u8D85\u7EA7\u7BA1\u7406\u5458\u53EF\u4EE5\u7BA1\u7406\u5546\u57CE\u793C\u5305"
    });
  }
  try {
    switch (method) {
      case "GET":
        return await handleGetGiftPackages(event);
      case "POST":
        return await handleCreateGiftPackage(event);
      case "PUT":
        return await handleUpdateGiftPackage(event);
      case "DELETE":
        return await handleDeleteGiftPackage(event);
      default:
        throw createError({
          status: 405,
          message: "\u4E0D\u652F\u6301\u7684\u8BF7\u6C42\u65B9\u6CD5"
        });
    }
  } catch (error) {
    console.error("\u793C\u5305\u7BA1\u7406API\u9519\u8BEF:", error);
    throw createError({
      status: error.status || 500,
      message: error.message || "\u670D\u52A1\u5668\u5185\u90E8\u9519\u8BEF"
    });
  }
});
async function handleGetGiftPackages(event) {
  var _a;
  const query = getQuery(event);
  const page = Number(query.page) || 1;
  const pageSize = Number(query.pageSize) || 20;
  const category = query.category;
  const isActive = query.is_active;
  const gameCode = query.game_code || "hzwqh";
  let whereClause = "WHERE 1=1";
  const values = [];
  {
    whereClause += " AND game_code = ?";
    values.push(gameCode);
  }
  if (category && category.trim() !== "") {
    whereClause += " AND category = ?";
    values.push(category);
  }
  if (isActive !== void 0 && isActive !== "" && isActive !== null) {
    whereClause += " AND is_active = ?";
    values.push(isActive === "true" ? 1 : 0);
  }
  const countQuery = `SELECT COUNT(*) as total FROM externalgiftpackages ${whereClause}`;
  const countResult = await sql({
    query: countQuery,
    values
  });
  const total = ((_a = countResult[0]) == null ? void 0 : _a.total) || 0;
  const offset = (page - 1) * pageSize;
  const dataQuery = `
    SELECT * FROM externalgiftpackages 
    ${whereClause} 
    ORDER BY sort_order DESC, created_at DESC 
    LIMIT ?, ?
  `;
  const giftPackages = await sql({
    query: dataQuery,
    values: [...values, offset, pageSize]
  });
  const formattedPackages = giftPackages.map((pkg) => {
    let giftItems;
    try {
      if (typeof pkg.gift_items === "string") {
        giftItems = JSON.parse(pkg.gift_items || "[]");
      } else {
        giftItems = pkg.gift_items || [];
      }
    } catch (error) {
      console.error("\u89E3\u6790\u793C\u5305\u7269\u54C1\u5931\u8D25:", pkg.package_code, error);
      giftItems = [];
    }
    return {
      ...pkg,
      gift_items_display: formatGiftItemsDisplay(giftItems),
      gift_items: giftItems
    };
  });
  return {
    success: true,
    data: {
      list: formattedPackages,
      total,
      page,
      pageSize,
      totalPages: Math.ceil(total / pageSize)
    }
  };
}
async function handleCreateGiftPackage(event) {
  const body = await readBody(event);
  const {
    package_code,
    package_name,
    description,
    price_platform_coins,
    gift_items,
    category = "general",
    game_code = "hzwqh"
  } = body;
  if (!package_code || !package_name || !price_platform_coins || !gift_items) {
    throw createError({
      status: 400,
      message: "\u7F3A\u5C11\u5FC5\u586B\u5B57\u6BB5\uFF1Apackage_code, package_name, price_platform_coins, gift_items"
    });
  }
  const validation = validateGiftItems(gift_items);
  if (!validation.valid) {
    throw createError({
      status: 400,
      message: "\u793C\u5305\u7269\u54C1\u683C\u5F0F\u9519\u8BEF\uFF1A" + validation.errors.join("\uFF0C")
    });
  }
  const existingPackage = await getGiftPackageByCode(package_code);
  if (existingPackage) {
    throw createError({
      status: 400,
      message: "\u793C\u5305\u4EE3\u7801\u5DF2\u5B58\u5728"
    });
  }
  const packageData = {
    package_code,
    package_name,
    description: description || "",
    price_platform_coins: Number(price_platform_coins),
    price_real_money: Number(body.price_real_money) || 0,
    gift_items: JSON.stringify(gift_items),
    category,
    icon_url: body.icon_url || "",
    is_active: body.is_active !== false,
    is_limited: body.is_limited === true,
    total_quantity: Number(body.total_quantity) || 0,
    sold_quantity: 0,
    max_per_user: Number(body.max_per_user) || 0,
    start_time: body.start_time || null,
    end_time: body.end_time || null,
    available_weekdays: body.available_weekdays || null,
    sort_order: Number(body.sort_order) || 0,
    game_code
  };
  const result = await sql({
    query: `INSERT INTO externalgiftpackages 
            (package_code, package_name, description, price_platform_coins, price_real_money,
             gift_items, category, icon_url, is_active, is_limited, total_quantity, sold_quantity,
             max_per_user, start_time, end_time, available_weekdays, sort_order, game_code)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    values: [
      packageData.package_code,
      packageData.package_name,
      packageData.description,
      packageData.price_platform_coins,
      packageData.price_real_money,
      packageData.gift_items,
      packageData.category,
      packageData.icon_url,
      packageData.is_active ? 1 : 0,
      packageData.is_limited ? 1 : 0,
      packageData.total_quantity,
      packageData.sold_quantity,
      packageData.max_per_user,
      packageData.start_time,
      packageData.end_time,
      packageData.available_weekdays,
      packageData.sort_order,
      packageData.game_code
    ]
  });
  return {
    success: true,
    message: "\u793C\u5305\u521B\u5EFA\u6210\u529F",
    data: { id: result.insertId }
  };
}
async function handleUpdateGiftPackage(event) {
  const body = await readBody(event);
  const { id } = body;
  if (!id) {
    throw createError({
      status: 400,
      message: "\u7F3A\u5C11\u793C\u5305ID"
    });
  }
  const existingPackage = await getGiftPackageById(id);
  if (!existingPackage) {
    throw createError({
      status: 404,
      message: "\u793C\u5305\u4E0D\u5B58\u5728"
    });
  }
  if (body.gift_items) {
    const validation = validateGiftItems(body.gift_items);
    if (!validation.valid) {
      throw createError({
        status: 400,
        message: "\u793C\u5305\u7269\u54C1\u683C\u5F0F\u9519\u8BEF\uFF1A" + validation.errors.join("\uFF0C")
      });
    }
  }
  const updateFields = [];
  const updateValues = [];
  const updatableFields = [
    "package_name",
    "description",
    "price_platform_coins",
    "price_real_money",
    "category",
    "icon_url",
    "is_active",
    "is_limited",
    "total_quantity",
    "max_per_user",
    "start_time",
    "end_time",
    "available_weekdays",
    "sort_order"
  ];
  updatableFields.forEach((field) => {
    if (body[field] !== void 0) {
      updateFields.push(`${field} = ?`);
      if (field === "is_active" || field === "is_limited") {
        updateValues.push(body[field] ? 1 : 0);
      } else {
        updateValues.push(body[field]);
      }
    }
  });
  if (body.gift_items) {
    updateFields.push("gift_items = ?");
    updateValues.push(JSON.stringify(body.gift_items));
  }
  if (updateFields.length === 0) {
    throw createError({
      status: 400,
      message: "\u6CA1\u6709\u9700\u8981\u66F4\u65B0\u7684\u5B57\u6BB5"
    });
  }
  updateValues.push(id);
  await sql({
    query: `UPDATE externalgiftpackages SET ${updateFields.join(", ")} WHERE id = ?`,
    values: updateValues
  });
  return {
    success: true,
    message: "\u793C\u5305\u66F4\u65B0\u6210\u529F"
  };
}
async function handleDeleteGiftPackage(event) {
  var _a;
  const query = getQuery(event);
  const id = query.id;
  if (!id) {
    throw createError({
      status: 400,
      message: "\u7F3A\u5C11\u793C\u5305ID"
    });
  }
  const existingPackage = await getGiftPackageById(Number(id));
  if (!existingPackage) {
    throw createError({
      status: 404,
      message: "\u793C\u5305\u4E0D\u5B58\u5728"
    });
  }
  const purchaseRecords = await sql({
    query: "SELECT COUNT(*) as count FROM giftpackagepurchaserecords WHERE package_id = ?",
    values: [id]
  });
  if (((_a = purchaseRecords[0]) == null ? void 0 : _a.count) > 0) {
    throw createError({
      status: 400,
      message: "\u8BE5\u793C\u5305\u5DF2\u6709\u8D2D\u4E70\u8BB0\u5F55\uFF0C\u4E0D\u80FD\u5220\u9664"
    });
  }
  await sql({
    query: "DELETE FROM externalgiftpackages WHERE id = ?",
    values: [id]
  });
  return {
    success: true,
    message: "\u793C\u5305\u5220\u9664\u6210\u529F"
  };
}

export { giftPackages as default };
//# sourceMappingURL=gift-packages.mjs.map
