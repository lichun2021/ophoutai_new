import { C as getSystemParam, d as defineEventHandler, e as getHeader, c as createError } from '../../../nitro/nitro.mjs';
import { readdir, stat } from 'fs/promises';
import { resolve } from 'path';
import { existsSync } from 'fs';
import { getAdminWithPermissions } from '../../../_/admin.mjs';
import 'ioredis';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'mysql2/promise';
import '@iconify/utils';
import 'consola';

const defaultImageDirectory = process.env.IMAGE_DIRECTORY || "/www/wwwroot/update.kccyei.cn/images";
const defaultUrlPrefix = process.env.IMAGE_URL_PREFIX || "/images";
const defaultResourceDomain = process.env.RESOURCE_DOMAIN || "https://update.kccyei.cn";
async function getImageDirectory() {
  return await getSystemParam("image_directory", defaultImageDirectory);
}
async function getImageUrlPrefix() {
  return await getSystemParam("image_url_prefix", defaultUrlPrefix);
}
async function getResourceDomain() {
  return await getSystemParam("resource_domain", defaultResourceDomain);
}
async function generateImageUrl(filename) {
  const domain = await getResourceDomain();
  const prefix = await getImageUrlPrefix();
  const cleanDomain = domain.replace(/\/$/, "");
  const cleanPrefix = prefix.startsWith("/") ? prefix : `/${prefix}`;
  const finalPrefix = cleanPrefix.replace(/\/$/, "");
  return `${cleanDomain}${finalPrefix}/${filename}`;
}

const listImages = defineEventHandler(async (event) => {
  const authorizationHeader = getHeader(event, "authorization");
  const token = authorizationHeader ? parseInt(authorizationHeader) : null;
  if (!token) {
    throw createError({
      status: 401,
      message: "\u672A\u63D0\u4F9B\u8BA4\u8BC1token"
    });
  }
  const adminInfo = await getAdminWithPermissions(token);
  if (!adminInfo || adminInfo.level !== 0) {
    throw createError({
      status: 403,
      message: "\u53EA\u6709\u8D85\u7EA7\u7BA1\u7406\u5458\u53EF\u4EE5\u67E5\u770B\u56FE\u7247\u5217\u8868"
    });
  }
  try {
    const imageDir = await getImageDirectory();
    if (!existsSync(imageDir)) {
      return {
        code: 200,
        data: {
          images: [],
          total: 0,
          directory: imageDir,
          message: "\u56FE\u7247\u76EE\u5F55\u4E0D\u5B58\u5728"
        }
      };
    }
    const files = await readdir(imageDir);
    const imageExtensions = [".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp"];
    const imageFiles = await Promise.all(
      files.filter((file) => {
        const ext = file.toLowerCase().substring(file.lastIndexOf("."));
        return imageExtensions.includes(ext);
      }).map(async (file) => {
        const filePath = resolve(imageDir, file);
        const stats = await stat(filePath);
        const fullUrl = await generateImageUrl(file);
        return {
          filename: file,
          url: fullUrl,
          size: stats.size,
          modifiedAt: stats.mtime
        };
      })
    );
    imageFiles.sort((a, b) => b.modifiedAt.getTime() - a.modifiedAt.getTime());
    return {
      code: 200,
      data: {
        images: imageFiles,
        total: imageFiles.length,
        directory: imageDir
      }
    };
  } catch (error) {
    console.error("\u83B7\u53D6\u56FE\u7247\u5217\u8868\u5931\u8D25:", error);
    throw createError({
      status: error.status || 500,
      message: error.message || "\u83B7\u53D6\u56FE\u7247\u5217\u8868\u5931\u8D25"
    });
  }
});

export { listImages as default };
//# sourceMappingURL=list-images.mjs.map
