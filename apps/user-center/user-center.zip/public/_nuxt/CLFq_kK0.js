import{am as s}from"./C1tNoiDh.js";const m=s("/logo-warm.svg");export{m as _};
