import { u as useBase, e as createRouter, d as defineEventHandler, h as getHeaders, i as getMethod, j as getRequestURL, r as readBody, A as sdkMessages, B as verifySdkSign } from '../../nitro/nitro.mjs';
import { v4 } from 'uuid';
import { d as getorders, e as getpostorders, w as sdkLogin, x as getSubAccountList, y as addSubAccount, z as editSubAccountNickname, A as getPayWay, B as reportRole, j as doPayment, C as getGameOrder, q as quickreg, c as checkUser, b as userLogin, n as updateSubUserWuid, r as register, D as banUser, o as getNewOne } from '../../_/paymentSettings.mjs';
import 'node:crypto';
import 'ioredis';
import 'fs';
import 'path';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:url';
import 'mysql2/promise';
import '@iconify/utils';
import 'consola';
import '../../_/admin.mjs';
import '../../_/gameServers.mjs';

const router = createRouter();
const withLogging = (handler, apiName) => {
  return defineEventHandler(async (event) => {
    var _a, _b, _c, _d, _e;
    const startTime = Date.now();
    const requestId = `req_${startTime}_${Math.random().toString(36).substr(2, 9)}`;
    const headers = getHeaders(event);
    const ipAddress = headers["x-forwarded-for"] || headers["x-real-ip"] || "unknown";
    const userAgent = headers["user-agent"] || "unknown";
    const method = getMethod(event);
    const url = getRequestURL(event);
    let requestBody = {};
    try {
      const parsed = await readBody(event);
      requestBody = parsed && typeof parsed === "object" ? parsed : {};
    } catch (e) {
      requestBody = {};
    }
    const maskIpForPrivacy = apiName.includes("\u767B\u5F55");
    console.log(`[IN] \u65F6\u95F4: ${(/* @__PURE__ */ new Date()).toISOString()}`);
    console.log(`[IN] \u8DEF\u5F84: ${method} ${url.pathname}${url.search}`);
    console.log(`[IN] IP: ${maskIpForPrivacy ? "[masked]" : ipAddress}, ${userAgent.split(" ")[0]}`);
    console.log(`[IN] \u53C2\u6570: \u7528\u6237\u540D=${(_a = requestBody == null ? void 0 : requestBody.z) != null ? _a : "N/A"}, \u767B\u5F55\u7C7B\u578B=${(_b = requestBody == null ? void 0 : requestBody.c) != null ? _b : "N/A"}, \u6E38\u620FID=${(_c = requestBody == null ? void 0 : requestBody.d) != null ? _c : "N/A"}, \u4EE3\u7406ID=${(_d = requestBody == null ? void 0 : requestBody.f) != null ? _d : "N/A"}`);
    console.log(`[IN] \u8BF7\u6C42\u4F53: ${JSON.stringify(requestBody)}`);
    console.log("=========================================");
    let response = {};
    let error = null;
    try {
      try {
        const tsFromBody = (_e = requestBody == null ? void 0 : requestBody.ts) != null ? _e : requestBody == null ? void 0 : requestBody.TS;
        const tsFromQuery = url.searchParams ? url.searchParams.get("ts") : void 0;
        const tsRaw = tsFromBody != null ? tsFromBody : tsFromQuery;
        if (tsRaw !== void 0 && tsRaw !== null && tsRaw !== "") {
          const n = Number(tsRaw);
          if (!Number.isFinite(n)) {
            throw new Error("\u65E0\u6548\u7684\u65F6\u95F4\u6233");
          }
          const tsSec = n > 1e12 ? Math.floor(n / 1e3) : Math.floor(n);
          const nowSec = Math.floor(Date.now() / 1e3);
          if (Math.abs(nowSec - tsSec) > 50) {
            throw new Error("\u8BF7\u6C42\u5DF2\u8FC7\u671F");
          }
        }
      } catch (tsErr) {
        throw new Error((tsErr == null ? void 0 : tsErr.message) || "\u65F6\u95F4\u6233\u6821\u9A8C\u5931\u8D25");
      }
      response = await handler(event);
    } catch (e) {
      error = e;
      if (apiName.includes("\u652F\u4ED8") || apiName.includes("getPayWay")) {
        response = {
          code: "0",
          data: [],
          msg: e.message || sdkMessages.payment.systemError(),
          djq: null,
          ttb: null,
          discount: null,
          flb: 0
        };
      } else if (apiName.includes("\u6E38\u620F\u8BA2\u5355\u67E5\u8BE2")) {
        response = {
          code: -1,
          msg: e.message || sdkMessages.payment.systemError(),
          amount: "0"
        };
      } else {
        response = {
          z: -1,
          x: e.message || sdkMessages.login.systemError(),
          b: "",
          c: "",
          d: "",
          sid: requestBody.sid || "",
          e: Date.now().toString()
        };
      }
    }
    const endTime = Date.now();
    const processingTime = endTime - startTime;
    console.log(`[OUT] ${apiName} \u8017\u65F6: ${processingTime}ms, \u72B6\u6001: ${response && response.code !== void 0 ? `\u7801=${response.code}, ${String(response.code) === "1" ? "\u6210\u529F" : "\u5931\u8D25"}` : response && response.z !== void 0 ? `\u7801=${response.z}, ${response.z === 0 ? "\u6210\u529F" : "\u5931\u8D25"}` : "\u672A\u77E5"}${error ? `, \u9519\u8BEF: ${error.message}` : ""}`);
    try {
      let logEntry = {
        requestId,
        apiName,
        timestamp: (/* @__PURE__ */ new Date()).toISOString(),
        method,
        path: url.pathname,
        clientIp: ipAddress,
        userAgent,
        processingTime,
        error: (error == null ? void 0 : error.message) || null
      };
      if (apiName.includes("\u652F\u4ED8") || apiName.includes("getPayWay")) {
        logEntry.request = {
          gameId: requestBody == null ? void 0 : requestBody.z,
          username: requestBody == null ? void 0 : requestBody.zz,
          channelId: requestBody == null ? void 0 : requestBody.b,
          agentId: requestBody == null ? void 0 : requestBody.bb,
          money: requestBody == null ? void 0 : requestBody.money
        };
        logEntry.response = response ? {
          code: response.code,
          message: response.msg,
          success: response.code === "1"
        } : { code: "undefined", message: "no response", success: false };
      } else {
        logEntry.request = {
          username: requestBody == null ? void 0 : requestBody.z,
          loginType: requestBody == null ? void 0 : requestBody.c,
          gameId: requestBody == null ? void 0 : requestBody.d,
          agentId: requestBody == null ? void 0 : requestBody.f
        };
        logEntry.response = response ? {
          code: response.z,
          message: response.x,
          success: response.z === 0
        } : { code: "undefined", message: "no response", success: false };
      }
    } catch (logError) {
      console.error("[ERROR] \u65E5\u5FD7\u8BB0\u5F55\u5931\u8D25:", logError);
    }
    return response;
  });
};
const withSign = (handler) => {
  return defineEventHandler(async (event) => {
    const ok = await verifySdkSign(event);
    if (!ok) {
      throw new Error("\u7B7E\u540D\u65E0\u6548");
    }
    return handler(event);
  });
};
const withSignAndLogging = (handler, apiName) => withLogging(withSign(handler), apiName);
router.post("/login/dologin", withSignAndLogging(sdkLogin, "SDK\u767B\u5F55\u63A5\u53E3"));
router.post("/login/xiaohao", withSignAndLogging(getSubAccountList, "\u83B7\u53D6\u5B50\u8D26\u53F7\u5217\u8868\u63A5\u53E3"));
router.post("/login/addxiaohao", withSignAndLogging(addSubAccount, "\u6DFB\u52A0\u5B50\u8D26\u53F7\u63A5\u53E3"));
router.post("/login/editSubAccount", withSignAndLogging(editSubAccountNickname, "\u7F16\u8F91\u5B50\u8D26\u53F7\u6635\u79F0\u63A5\u53E3"));
router.post("/Pay/payway", withSignAndLogging(getPayWay, "\u83B7\u53D6\u652F\u4ED8\u65B9\u5F0F\u63A5\u53E3"));
router.post("/user/setRole", withSignAndLogging(reportRole, "\u89D2\u8272\u4E0A\u62A5\u63A5\u53E3"));
router.post("/Unipay/pay", withLogging(doPayment, "\u652F\u4ED8\u8BF7\u6C42\u63A5\u53E3(\u4EE3\u7406)"));
router.post("/game/order", withSignAndLogging(getGameOrder, "\u6E38\u620F\u8BA2\u5355\u67E5\u8BE2\u63A5\u53E3"));
router.get("/user/token", withSignAndLogging(quickreg, "SDK \u83B7\u53D6\u7528\u6237token"));
router.post("/user/check", withSignAndLogging(checkUser, "SDK \u68C0\u67E5\u7528\u6237"));
router.post("/user/login", withSignAndLogging(async (event) => {
  const result = await userLogin(event);
  try {
    const ok = !!(result && result.data && result.data.user);
    if (ok) {
      event.node.res.setHeader("Set-Cookie", [
        "auth_logged_in=true; Path=/; HttpOnly; SameSite=Lax",
        "auth_is_user=true; Path=/; HttpOnly; SameSite=Lax"
      ]);
    }
  } catch {
  }
  return result;
}, "SDK \u7528\u6237\u767B\u5F55"));
router.post("/user/reg", withSignAndLogging(updateSubUserWuid, "SDK \u5728\u5B50\u5E10\u6237\u5173\u8054\u6E38\u620F wuid"));
router.post("/user/register", withSignAndLogging(register, "SDK \u7528\u6237\u6CE8\u518C\u63A5\u53E3"));
router.post("/user/ban", withSignAndLogging(banUser, "SDK \u5C01\u53F7/\u89E3\u5C01\u7528\u6237\u63A5\u53E3"));
router.get("/user/get/:thirdparty_uid", withSignAndLogging(getNewOne, "SDK \u6839\u636E\u7B2C\u4E09\u65B9\u7528\u6237ID\u83B7\u53D6\u7528\u6237\u4FE1\u606F"));
router.get("/user/undo/:thirdparty_uid", withSignAndLogging(defineEventHandler(getorders), "SDK \u83B7\u53D6\u7528\u6237\u8BA2\u5355(\u672A\u5B8C\u6210)"));
router.post("/user/undop", withSignAndLogging(defineEventHandler(getpostorders), "SDK POST\u83B7\u53D6\u7528\u6237\u8BA2\u5355(\u672A\u5B8C\u6210)"));
router.get("/utils/uuid", withSignAndLogging(async (event) => {
  const id = v4();
  return { code: "1", msg: "success", data: { uuid: id } };
}, "\u751F\u6210\u552F\u4E00UUID\u63A5\u53E3"));
router.post("/utils/uuid", withSignAndLogging(async (event) => {
  const id = v4();
  return { code: "1", msg: "success", data: { uuid: id } };
}, "\u751F\u6210\u552F\u4E00UUID\u63A5\u53E3"));
const _____ = useBase("/sdkapi", router.handler);

export { _____ as default };
//# sourceMappingURL=_..._.mjs.map
