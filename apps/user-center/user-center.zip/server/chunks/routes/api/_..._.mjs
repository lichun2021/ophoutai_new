import { s as sql, d as defineEventHandler, c as createError, g as getQuery, a as getHeader, r as readBody, b as getCookie, u as useBase, e as createRouter, f as generateCaptcha, h as getHeaders, i as getMethod, j as getRequestURL, v as verifyApiSignature, k as setResponseStatus, l as verifyCaptcha } from '../../nitro/nitro.mjs';
import { f as findById, g as getPlatformCoins, u as updatePlatformCoinsUnified, i as insert, q as quickreg, c as checkUser, a as checkChannelStatus, b as userLogin, d as getorders, e as getpostorders, h as getActivePaymentSettingsForUser, j as doPayment, k as queryPaymentOrder, l as getPaymentByTransId, m as getPaymentByUserID, r as register, n as updateSubUserWuid, o as getNewOne, p as paymentNewReps, s as checkOrder, t as handleThirdPartyNotify, v as handleCashierPaymentNotify } from '../../_/paymentSettings.mjs';
import { getUserPurchaseRecordsCountByUserId, getGiftPackagesByCategory, getAllActiveGiftPackages, checkUserCanPurchase, getGiftPackageById, updatePackageSoldQuantity, createPurchaseRecord, deliverPackageToGameViaIDIP, updatePurchaseRecordStatus, getPlayerGiftPackageRecords as getPlayerGiftPackageRecords$1, getPlayerGiftPackageRecordsCount, getUserPurchaseRecords, getUserPurchaseRecordsCount } from '../../_/externalGiftPackage.mjs';
import { g as getAdminWithPermissions } from '../../_/admin.mjs';
import { getBeijingDate, getCardStatus, getActiveCardsByUserId, getTodayClaimedCardIds, insertClaim } from '../../_/monthlyCard.mjs';
import { listActive, listCdkRedeemable } from '../../_/gameServers.mjs';
import { detail } from '../../_/systemParams.mjs';
import 'node:crypto';
import 'ioredis';
import 'fs';
import 'path';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:url';
import 'mysql2/promise';
import '@iconify/utils';
import 'consola';

const getTotalRechargeAmountByUserId = async (user_id) => {
  var _a;
  const result = await sql({
    query: 'SELECT SUM(amount) as total FROM PlatformCoinRechargeRecords WHERE user_id = ? AND status = "completed"',
    values: [user_id]
  });
  return parseFloat(((_a = result[0]) == null ? void 0 : _a.total) || 0);
};
const getRechargeStatsByTypeByUserId = async (user_id) => {
  const result = await sql({
    query: `SELECT recharge_type, COUNT(*) as count, SUM(amount) as total_amount 
                FROM PlatformCoinRechargeRecords 
                WHERE user_id = ? AND status = "completed" 
                GROUP BY recharge_type`,
    values: [user_id]
  });
  return result;
};

function getCurrentFormattedTime() {
  const date = /* @__PURE__ */ new Date();
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  const hours = String(date.getHours()).padStart(2, "0");
  const minutes = String(date.getMinutes()).padStart(2, "0");
  const seconds = String(date.getSeconds()).padStart(2, "0");
  return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
}
const checkPermission = async (event, userChannelCode) => {
  try {
    const authorizationHeader = getHeader(event, "authorization");
    const token = authorizationHeader ? parseInt(authorizationHeader) : null;
    if (!token) {
      return { hasPermission: false };
    }
    const adminWithPermissions = await getAdminWithPermissions(token);
    if (!adminWithPermissions) {
      return { hasPermission: false };
    }
    if (adminWithPermissions.level === 0) {
      return { hasPermission: true, adminInfo: adminWithPermissions };
    }
    const allowedChannelCodes = adminWithPermissions.allowed_channel_codes || [];
    if (allowedChannelCodes.length === 0 || allowedChannelCodes.includes(userChannelCode)) {
      return { hasPermission: true, adminInfo: adminWithPermissions };
    }
    return { hasPermission: false };
  } catch (error) {
    console.error("\u6743\u9650\u9A8C\u8BC1\u5931\u8D25:", error);
    return { hasPermission: false };
  }
};
const getUserProfile = defineEventHandler(async (event) => {
  var _a, _b;
  try {
    const id = parseInt((_b = (_a = event.context.params) == null ? void 0 : _a.id) != null ? _b : "");
    if (!id || isNaN(id)) {
      return {
        code: 400,
        message: "\u7F3A\u5C11\u7528\u6237ID\u53C2\u6570"
      };
    }
    const user = await findById(id);
    if (!user) {
      return {
        code: 404,
        message: "\u7528\u6237\u4E0D\u5B58\u5728"
      };
    }
    const permissionCheck = await checkPermission(event, user.channel_code || "");
    if (!permissionCheck.hasPermission) {
      return {
        code: 403,
        message: "\u6CA1\u6709\u6743\u9650\u8BBF\u95EE\u8BE5\u7528\u6237\u4FE1\u606F"
      };
    }
    const platformCoins = await getPlatformCoins(id);
    const totalRechargeAmount = await getTotalRechargeAmountByUserId(id);
    const rechargeStats = await getRechargeStatsByTypeByUserId(id);
    const totalPurchases = await getUserPurchaseRecordsCountByUserId(id);
    return {
      code: 200,
      data: {
        id: user.id,
        username: user.username,
        thirdparty_uid: user.thirdparty_uid,
        channel_code: user.channel_code,
        platform_coins: platformCoins,
        total_recharge_amount: totalRechargeAmount,
        recharge_stats: rechargeStats,
        total_purchases: totalPurchases,
        created_at: user.created_at
      },
      message: "\u83B7\u53D6\u7528\u6237\u4FE1\u606F\u6210\u529F"
    };
  } catch (error) {
    console.error("\u83B7\u53D6\u7528\u6237\u4FE1\u606F\u51FA\u9519:", error);
    throw createError({
      status: 500,
      message: "\u83B7\u53D6\u7528\u6237\u4FE1\u606F\u65F6\u53D1\u751F\u9519\u8BEF"
    });
  }
});
const getAvailableGiftPackages = defineEventHandler(async (event) => {
  try {
    const authorizationHeader = getHeader(event, "authorization");
    const token = authorizationHeader ? parseInt(authorizationHeader) : null;
    if (!token) {
      return {
        code: 401,
        message: "\u9700\u8981\u767B\u5F55"
      };
    }
    const adminWithPermissions = await getAdminWithPermissions(token);
    if (!adminWithPermissions) {
      return {
        code: 403,
        message: "\u7BA1\u7406\u5458\u4E0D\u5B58\u5728"
      };
    }
    const query = getQuery(event);
    const category = query.category;
    let packages;
    if (category && category !== "all") {
      packages = await getGiftPackagesByCategory(category);
    } else {
      packages = await getAllActiveGiftPackages();
    }
    return {
      code: 200,
      data: packages,
      message: "\u83B7\u53D6\u793C\u5305\u5217\u8868\u6210\u529F"
    };
  } catch (error) {
    console.error("\u83B7\u53D6\u793C\u5305\u5217\u8868\u51FA\u9519:", error);
    throw createError({
      status: 500,
      message: "\u83B7\u53D6\u793C\u5305\u5217\u8868\u65F6\u53D1\u751F\u9519\u8BEF"
    });
  }
});
const getPublicGiftPackages = defineEventHandler(async (event) => {
  try {
    const query = getQuery(event);
    const category = query.category;
    let packages;
    if (category && category !== "all") {
      packages = await getGiftPackagesByCategory(category);
    } else {
      packages = await getAllActiveGiftPackages();
    }
    return {
      code: 200,
      data: packages,
      message: "\u83B7\u53D6\u793C\u5305\u5217\u8868\u6210\u529F"
    };
  } catch (error) {
    console.error("\u83B7\u53D6\u516C\u5F00\u793C\u5305\u5217\u8868\u51FA\u9519:", error);
    throw createError({
      status: 500,
      message: "\u83B7\u53D6\u793C\u5305\u5217\u8868\u65F6\u53D1\u751F\u9519\u8BEF"
    });
  }
});
const getGiftPackageCategories = defineEventHandler(async (event) => {
  try {
    const result = await sql({
      query: `SELECT DISTINCT category FROM ExternalGiftPackages 
                    WHERE is_active = 1 
                    AND category IS NOT NULL 
                    AND category != '' 
                    AND (start_time IS NULL OR start_time <= NOW()) 
                    AND (end_time IS NULL OR end_time >= NOW())
                    ORDER BY category`
    });
    const categories = result.map((row) => row.category);
    return {
      code: 200,
      data: categories,
      message: "\u83B7\u53D6\u5206\u7C7B\u5217\u8868\u6210\u529F"
    };
  } catch (error) {
    console.error("\u83B7\u53D6\u5206\u7C7B\u5217\u8868\u51FA\u9519:", error);
    throw createError({
      status: 500,
      message: "\u83B7\u53D6\u5206\u7C7B\u5217\u8868\u65F6\u53D1\u751F\u9519\u8BEF"
    });
  }
});
const userPurchaseGiftPackage = defineEventHandler(async (event) => {
  var _a;
  try {
    const body = await readBody(event);
    const { user_id, package_id, character_uuid } = body;
    console.log(body);
    const quantity = 1;
    if (!user_id || !package_id) {
      return {
        code: 400,
        message: "\u7F3A\u5C11\u5FC5\u8981\u53C2\u6570"
      };
    }
    if (!character_uuid) {
      return {
        code: 400,
        message: "\u8BF7\u9009\u62E9\u8981\u53D1\u653E\u7684\u89D2\u8272"
      };
    }
    try {
      const { getRedisCluster } = await import('../../nitro/nitro.mjs').then(function (n) { return n.af; });
      const redis = getRedisCluster();
      const rateLimitKey = `purchase_cooldown:${user_id}`;
      const acquired = await redis.set(rateLimitKey, "1", "EX", 5, "NX");
      if (!acquired) {
        const ttl = await redis.ttl(rateLimitKey);
        return {
          code: 429,
          message: `\u64CD\u4F5C\u592A\u9891\u7E41\uFF0C\u8BF7 ${ttl} \u79D2\u540E\u518D\u8BD5`
        };
      }
    } catch (redisErr) {
      console.warn("[userPurchaseGiftPackage] Redis \u9650\u901F\u68C0\u67E5\u5931\u8D25:", redisErr);
    }
    const user = await findById(user_id);
    if (!user) {
      return {
        code: 404,
        message: "\u7528\u6237\u4E0D\u5B58\u5728"
      };
    }
    const character = await sql({
      query: `SELECT gc.* FROM GameCharacters gc 
                   INNER JOIN SubUsers su ON gc.subuser_id = su.id 
                   WHERE su.parent_user_id = ? AND gc.uuid = ?`,
      values: [user_id, character_uuid]
    });
    if (character.length === 0) {
      return {
        code: 400,
        message: "\u89D2\u8272\u4E0D\u5B58\u5728\u6216\u4E0D\u5C5E\u4E8E\u8BE5\u7528\u6237"
      };
    }
    const selectedCharacter = character[0];
    console.log(`========== \u7528\u6237\u8D2D\u4E70\u793C\u5305\u5F00\u59CB ==========`);
    console.log(`\u7528\u6237ID: ${user_id}, \u89D2\u8272UUID: ${selectedCharacter.uuid}, \u89D2\u8272\u540D: ${selectedCharacter.character_name}`);
    console.log(`\u793C\u5305ID: ${package_id}, \u6570\u91CF: ${quantity}`);
    console.log(`========================================`);
    const checkResult = await checkUserCanPurchase(selectedCharacter.uuid, package_id, quantity);
    if (!checkResult.canPurchase) {
      console.log(`\u274C \u9650\u8D2D\u68C0\u67E5\u5931\u8D25: ${checkResult.reason}`);
      return {
        code: 400,
        message: checkResult.reason
      };
    }
    console.log(`\u2705 \u9650\u8D2D\u68C0\u67E5\u901A\u8FC7\uFF0C\u7EE7\u7EED\u8D2D\u4E70\u6D41\u7A0B`);
    const giftPackage = await getGiftPackageById(package_id);
    if (!giftPackage) {
      return {
        code: 404,
        message: "\u793C\u5305\u4E0D\u5B58\u5728"
      };
    }
    const totalAmount = giftPackage.price_platform_coins * quantity;
    const currentBalance = await getPlatformCoins(user_id);
    if (currentBalance < totalAmount) {
      return {
        code: 400,
        message: "\u5E73\u53F0\u5E01\u4F59\u989D\u4E0D\u8DB3"
      };
    }
    const deductResult = await updatePlatformCoinsUnified(user_id, -totalAmount, 1);
    if (!deductResult.success) {
      return {
        code: 400,
        message: deductResult.message || "\u6263\u9664\u5E73\u53F0\u5E01\u5931\u8D25"
      };
    }
    const orderTs = Date.now();
    const orderRand = Math.floor(Math.random() * 9e3) + 1e3;
    const mchOrderId = `${orderTs}${orderRand}`;
    const transactionId = `PC${orderTs}${orderRand}${user.id}`;
    const paymentData = {
      user_id: user.id,
      sub_user_id: selectedCharacter.subuser_id,
      // 使用角色的 subuser_id
      role_id: selectedCharacter.uuid,
      // 角色UUID作为role_id
      transaction_id: transactionId,
      wuid: selectedCharacter.uuid,
      // 使用角色的 uuid 作为 wuid
      payment_way: "\u5E73\u53F0\u5E01",
      payment_id: 0,
      world_id: selectedCharacter.server_id || 1,
      product_name: giftPackage.package_name,
      product_des: "\u793C\u5305\u8D2D\u4E70",
      ip: "",
      amount: totalAmount,
      mch_order_id: mchOrderId,
      // 使用相同的订单号
      msg: "",
      server_url: "",
      device: "",
      channel_code: user.channel_code || "",
      game_code: user.game_code || "hzwqh",
      payment_status: 2,
      // 先标记为处理中
      ptb_before: currentBalance,
      ptb_change: -totalAmount,
      ptb_after: deductResult.newBalance
    };
    const PaymentModel2 = await import('../../_/paymentSettings.mjs').then(function (n) { return n.E; });
    await PaymentModel2.insert(paymentData);
    if (giftPackage.is_limited) {
      await updatePackageSoldQuantity(package_id, quantity);
    }
    const purchaseRecord = {
      user_id: user.id,
      thirdparty_uid: selectedCharacter.uuid,
      // 使用角色UUID作为thirdparty_uid
      mch_order_id: mchOrderId,
      // 使用生成的订单号
      package_id,
      package_code: giftPackage.package_code,
      package_name: giftPackage.package_name,
      quantity,
      unit_price: giftPackage.price_platform_coins,
      total_amount: totalAmount,
      balance_before: currentBalance,
      balance_after: deductResult.newBalance,
      gift_items: giftPackage.gift_items,
      status: "paid",
      remark: `\u5E73\u53F0\u5E01\u8D2D\u4E70 - \u670D\u52A1\u5668${selectedCharacter.server_id || 1}`
    };
    console.log(`[userPurchaseGiftPackage] \u521B\u5EFA\u8D2D\u4E70\u8BB0\u5F55, \u7528\u6237ID: ${user_id}, \u793C\u5305ID: ${package_id}, \u89D2\u8272: ${selectedCharacter.uuid}`);
    const createResult = await createPurchaseRecord(purchaseRecord);
    const purchaseRecordId = createResult.insertId;
    console.log(`[userPurchaseGiftPackage] \u8D2D\u4E70\u8BB0\u5F55\u521B\u5EFA\u6210\u529F, \u8BB0\u5F55ID: ${purchaseRecordId}`);
    console.log(`[userPurchaseGiftPackage] \u5F00\u59CB\u81EA\u52A8\u53D1\u653E\u793C\u5305\u5230\u6E38\u620F\u5185...`);
    try {
      const deliveryResult = await deliverPackageToGameViaIDIP(
        purchaseRecordId,
        ((_a = selectedCharacter.server_id) == null ? void 0 : _a.toString()) || "1",
        selectedCharacter.uuid
      );
      if (deliveryResult.success) {
        console.log(`[userPurchaseGiftPackage] \u2705 \u793C\u5305\u81EA\u52A8\u53D1\u653E\u6210\u529F! \u8D2D\u4E70\u8BB0\u5F55ID: ${purchaseRecordId}`);
        const currentTime = getCurrentFormattedTime();
        await PaymentModel2.updateByTransactionId(transactionId, {
          payment_status: 3,
          notify_at: currentTime,
          msg: "\u793C\u5305\u53D1\u653E\u6210\u529F"
        });
        return {
          code: 200,
          data: {
            new_balance: deductResult.newBalance,
            purchase_amount: totalAmount
          },
          message: "\u793C\u5305\u8D2D\u4E70\u6210\u529F"
        };
      } else if (deliveryResult.timeout) {
        console.warn(`[userPurchaseGiftPackage] \u23F3 \u793C\u5305\u53D1\u653E\u8D85\u65F6\uFF0C\u7B49\u5F85\u786E\u8BA4. \u8D2D\u4E70\u8BB0\u5F55ID: ${purchaseRecordId}`);
        await PaymentModel2.updateByTransactionId(transactionId, {
          payment_status: 1,
          msg: `DELIVERY_TIMEOUT:${deliveryResult.message || "\u53D1\u653E\u8D85\u65F6\uFF0C\u7B49\u5F85\u786E\u8BA4"}`
        });
        await updatePurchaseRecordStatus(
          purchaseRecordId,
          "paid",
          "sent",
          "\u53D1\u653E\u8D85\u65F6\uFF0C\u7B49\u5F85\u786E\u8BA4"
        );
        return {
          code: 202,
          message: "\u793C\u5305\u53D1\u653E\u5904\u7406\u4E2D\uFF0C\u8BF7\u7A0D\u540E\u67E5\u8BE2"
        };
      } else {
        console.error(`[userPurchaseGiftPackage] \u274C \u793C\u5305\u81EA\u52A8\u53D1\u653E\u5931\u8D25! \u8D2D\u4E70\u8BB0\u5F55ID: ${purchaseRecordId}, \u9519\u8BEF: ${deliveryResult.message}`);
        const { getPaymentRefundEnabled } = await import('../../_/systemParams.mjs');
        const refundEnabled = await getPaymentRefundEnabled();
        if (refundEnabled) {
          const refundResult = await updatePlatformCoinsUnified(user_id, totalAmount, 6);
          if (!refundResult.success) {
            console.error(`[userPurchaseGiftPackage] \u26A0\uFE0F \u9000\u6B3E\u5931\u8D25:`, refundResult.message);
          }
          const refundBalance = refundResult.newBalance || deductResult.newBalance;
          console.log(`[userPurchaseGiftPackage] \u{1F4B0} \u5DF2\u9000\u8FD8\u5E73\u53F0\u5E01: ${totalAmount}, \u65B0\u4F59\u989D: ${refundBalance}`);
          await PaymentModel2.updateByTransactionId(transactionId, {
            payment_status: 2,
            msg: `${deliveryResult.message || "\u672A\u77E5\u9519\u8BEF"}`,
            ptb_after: refundBalance,
            ptb_change: 0
          });
          await updatePurchaseRecordStatus(
            purchaseRecordId,
            "failed",
            "failed",
            `\u5DF2\u9000\u6B3E: ${deliveryResult.message || "\u672A\u77E5\u9519\u8BEF"}`
          );
          return {
            code: 500,
            message: `\u793C\u5305\u53D1\u653E\u5931\u8D25: ${deliveryResult.message || "\u672A\u77E5\u9519\u8BEF"}\uFF0C\u5E73\u53F0\u5E01\u5DF2\u9000\u8FD8`
          };
        }
        await PaymentModel2.updateByTransactionId(transactionId, {
          payment_status: 1,
          msg: `GIFT_DELIVERY_FAILED_NO_REFUND:${deliveryResult.message || "\u672A\u77E5\u9519\u8BEF"}`
        });
        await updatePurchaseRecordStatus(
          purchaseRecordId,
          "paid",
          "failed",
          "\u53D1\u653E\u5931\u8D25\uFF08\u9000\u6B3E\u5173\u95ED\uFF0C\u5F85\u786E\u8BA4\uFF09"
        );
        return {
          code: 202,
          message: "\u793C\u5305\u53D1\u653E\u5931\u8D25\uFF0C\u9000\u6B3E\u5DF2\u5173\u95ED\uFF0C\u8BF7\u8054\u7CFB\u7BA1\u7406\u5458\u5904\u7406"
        };
      }
    } catch (deliveryError) {
      console.error(`[userPurchaseGiftPackage] \u274C \u81EA\u52A8\u53D1\u653E\u793C\u5305\u5F02\u5E38:`, deliveryError);
      const { getPaymentRefundEnabled } = await import('../../_/systemParams.mjs');
      const refundEnabled = await getPaymentRefundEnabled();
      const errorMsg = deliveryError instanceof Error ? deliveryError.message : "\u7CFB\u7EDF\u9519\u8BEF";
      if (refundEnabled) {
        const refundResult = await updatePlatformCoinsUnified(user_id, totalAmount, 7);
        if (!refundResult.success) {
          console.error(`[userPurchaseGiftPackage] \u26A0\uFE0F \u9000\u6B3E\u5931\u8D25:`, refundResult.message);
        }
        const refundBalance = refundResult.newBalance || deductResult.newBalance;
        console.log(`[userPurchaseGiftPackage] \u{1F4B0} \u5DF2\u9000\u8FD8\u5E73\u53F0\u5E01: ${totalAmount}, \u65B0\u4F59\u989D: ${refundBalance}`);
        await PaymentModel2.updateByTransactionId(transactionId, {
          payment_status: 2,
          msg: `${errorMsg}`,
          ptb_after: refundBalance,
          ptb_change: 0
        });
        await updatePurchaseRecordStatus(
          purchaseRecordId,
          "failed",
          "failed",
          `\u5DF2\u9000\u6B3E: ${errorMsg}`
        );
        return {
          code: 500,
          message: `\u793C\u5305\u53D1\u653E\u5F02\u5E38: ${errorMsg}\uFF0C\u5E73\u53F0\u5E01\u5DF2\u9000\u8FD8`
        };
      }
      await PaymentModel2.updateByTransactionId(transactionId, {
        payment_status: 1,
        msg: `GIFT_DELIVERY_EXCEPTION_NO_REFUND:${errorMsg}`
      });
      await updatePurchaseRecordStatus(
        purchaseRecordId,
        "paid",
        "failed",
        "\u53D1\u653E\u5F02\u5E38\uFF08\u9000\u6B3E\u5173\u95ED\uFF0C\u5F85\u786E\u8BA4\uFF09"
      );
      return {
        code: 202,
        message: "\u793C\u5305\u53D1\u653E\u5F02\u5E38\uFF0C\u9000\u6B3E\u5DF2\u5173\u95ED\uFF0C\u8BF7\u8054\u7CFB\u7BA1\u7406\u5458\u5904\u7406"
      };
    }
  } catch (error) {
    console.error("\u7528\u6237\u8D2D\u4E70\u793C\u5305\u51FA\u9519:", error);
    throw createError({
      status: 500,
      message: "\u8D2D\u4E70\u793C\u5305\u65F6\u53D1\u751F\u9519\u8BEF"
    });
  }
});
const getUserPurchaseHistory = defineEventHandler(async (event) => {
  try {
    const query = getQuery(event);
    const user_id = parseInt(query.user_id);
    const page = parseInt(query.page) || 1;
    const pageSize = parseInt(query.pageSize) || 10;
    if (!user_id || isNaN(user_id)) {
      return {
        code: 400,
        message: "\u7F3A\u5C11\u7528\u6237ID\u53C2\u6570"
      };
    }
    const user = await findById(user_id);
    if (!user) {
      return {
        code: 404,
        message: "\u7528\u6237\u4E0D\u5B58\u5728"
      };
    }
    const records = await getUserPurchaseRecords(user.thirdparty_uid, page, pageSize);
    const total = await getUserPurchaseRecordsCount(user.thirdparty_uid);
    return {
      code: 200,
      data: {
        records,
        pagination: {
          page,
          pageSize,
          total,
          totalPages: Math.ceil(total / pageSize)
        }
      },
      message: "\u83B7\u53D6\u8D2D\u4E70\u8BB0\u5F55\u6210\u529F"
    };
  } catch (error) {
    console.error("\u83B7\u53D6\u7528\u6237\u8D2D\u4E70\u8BB0\u5F55\u51FA\u9519:", error);
    throw createError({
      status: 500,
      message: "\u83B7\u53D6\u8D2D\u4E70\u8BB0\u5F55\u65F6\u53D1\u751F\u9519\u8BEF"
    });
  }
});
const getUserRechargeHistory = defineEventHandler(async (event) => {
  var _a;
  try {
    const query = getQuery(event);
    const user_id = parseInt(query.user_id);
    const page = parseInt(query.page) || 1;
    const pageSize = parseInt(query.pageSize) || 10;
    if (!user_id || isNaN(user_id)) {
      return {
        code: 400,
        message: "\u7F3A\u5C11\u7528\u6237ID\u53C2\u6570"
      };
    }
    const user = await findById(user_id);
    if (!user) {
      return {
        code: 404,
        message: "\u7528\u6237\u4E0D\u5B58\u5728"
      };
    }
    const offset = (page - 1) * pageSize;
    const records = await sql({
      query: `SELECT pr.*, gc.character_name as role_name
                   FROM PaymentRecords pr
                   LEFT JOIN GameCharacters gc ON pr.role_id = gc.uuid
                   WHERE pr.user_id = ? AND pr.payment_status = 3
                   AND (pr.payment_way NOT LIKE '%\u5E73\u53F0\u5E01%' OR pr.payment_way IS NULL OR pr.payment_way = '')
                   ORDER BY pr.created_at DESC 
                   LIMIT ?, ?`,
      values: [user_id, offset, pageSize]
    });
    const countResult = await sql({
      query: `SELECT COUNT(*) as total FROM PaymentRecords 
                   WHERE user_id = ? AND payment_status = 3
                   AND (payment_way NOT LIKE '%\u5E73\u53F0\u5E01%' OR payment_way IS NULL OR payment_way = '')`,
      values: [user_id]
    });
    const total = ((_a = countResult[0]) == null ? void 0 : _a.total) || 0;
    return {
      code: 200,
      data: {
        records,
        pagination: {
          page,
          pageSize,
          total,
          totalPages: Math.ceil(total / pageSize)
        }
      },
      message: "\u83B7\u53D6\u5145\u503C\u8BB0\u5F55\u6210\u529F"
    };
  } catch (error) {
    console.error("\u83B7\u53D6\u7528\u6237\u5145\u503C\u8BB0\u5F55\u51FA\u9519:", error);
    throw createError({
      status: 500,
      message: "\u83B7\u53D6\u5145\u503C\u8BB0\u5F55\u65F6\u53D1\u751F\u9519\u8BEF"
    });
  }
});
const getUserPlatformCoinSpendHistory = defineEventHandler(async (event) => {
  var _a, _b, _c;
  try {
    const query = getQuery(event);
    const user_id = parseInt(query.user_id);
    const page = parseInt(query.page) || 1;
    const pageSize = parseInt(query.pageSize) || 10;
    if (!user_id || isNaN(user_id)) {
      return {
        code: 400,
        message: "\u7F3A\u5C11\u7528\u6237ID\u53C2\u6570"
      };
    }
    const user = await findById(user_id);
    if (!user) {
      return {
        code: 404,
        message: "\u7528\u6237\u4E0D\u5B58\u5728"
      };
    }
    const offset = (page - 1) * pageSize;
    const statusFilter = (query.status || "all").toLowerCase();
    const baseWhereClauses = [
      "pr.user_id = ?",
      "pr.payment_way = '\u5E73\u53F0\u5E01'",
      "pr.role_id IS NOT NULL",
      "TRIM(pr.role_id) <> ''"
    ];
    const whereValues = [user_id];
    if (statusFilter === "success") {
      baseWhereClauses.push("pr.payment_status = 3");
    } else if (statusFilter === "failed") {
      baseWhereClauses.push("(pr.payment_status IS NULL OR pr.payment_status <> 3)");
    }
    const whereClauseSql = baseWhereClauses.join(" AND ");
    const records = await sql({
      query: `SELECT pr.*, gc.character_name as role_name
                   FROM PaymentRecords pr
                   LEFT JOIN GameCharacters gc ON pr.role_id = gc.uuid
                   WHERE ${whereClauseSql}
                   ORDER BY pr.created_at DESC 
                   LIMIT ?, ?`,
      values: [...whereValues, offset, pageSize]
    });
    const countResult = await sql({
      query: `SELECT COUNT(*) as total 
                   FROM PaymentRecords pr
                   WHERE ${whereClauseSql}`,
      values: whereValues
    });
    const completedCountResult = await sql({
      query: `SELECT COUNT(*) as completed 
                   FROM PaymentRecords 
                   WHERE user_id = ?
                     AND payment_way = '\u5E73\u53F0\u5E01'
                     AND payment_status = 3
                     AND role_id IS NOT NULL
                     AND TRIM(role_id) <> ''`,
      values: [user_id]
    });
    const totalSpentResult = await sql({
      query: `SELECT COALESCE(SUM(amount), 0) AS total_spent
                   FROM PaymentRecords
                   WHERE user_id = ?
                     AND payment_way = '\u5E73\u53F0\u5E01'
                     AND payment_status = 3
                     AND role_id IS NOT NULL
                     AND TRIM(role_id) <> ''`,
      values: [user_id]
    });
    const totalSpent = Number(((_a = totalSpentResult[0]) == null ? void 0 : _a.total_spent) || 0);
    const completedCount = Number(((_b = completedCountResult[0]) == null ? void 0 : _b.completed) || 0);
    const total = ((_c = countResult[0]) == null ? void 0 : _c.total) || 0;
    return {
      code: 200,
      data: {
        records,
        pagination: {
          page,
          pageSize,
          total,
          totalPages: Math.ceil(total / pageSize)
        },
        totalSpent,
        completedCount
      },
      message: "\u83B7\u53D6\u6D88\u8D39\u8BB0\u5F55\u6210\u529F"
    };
  } catch (error) {
    console.error("\u83B7\u53D6\u7528\u6237\u6D88\u8D39\u8BB0\u5F55\u51FA\u9519:", error);
    throw createError({
      status: 500,
      message: "\u83B7\u53D6\u6D88\u8D39\u8BB0\u5F55\u65F6\u53D1\u751F\u9519\u8BEF"
    });
  }
});
const getUserHomeStats = defineEventHandler(async (event) => {
  var _a, _b;
  try {
    const query = getQuery(event);
    const user_id = parseInt(query.user_id);
    if (!user_id || isNaN(user_id)) {
      return {
        code: 400,
        message: "\u7F3A\u5C11\u7528\u6237ID\u53C2\u6570"
      };
    }
    const user = await findById(user_id);
    if (!user) {
      return {
        code: 404,
        message: "\u7528\u6237\u4E0D\u5B58\u5728"
      };
    }
    const totalRechargeResult = await sql({
      query: `SELECT SUM(amount) as total FROM PaymentRecords 
                   WHERE user_id = ? AND payment_status = 3
                   AND (payment_way NOT LIKE '%\u5E73\u53F0\u5E01%' OR payment_way IS NULL OR payment_way = '')`,
      values: [user_id]
    });
    const totalRecharge = ((_a = totalRechargeResult[0]) == null ? void 0 : _a.total) || 0;
    const purchaseCountResult = await sql({
      query: `SELECT COUNT(*) as count FROM PaymentRecords 
                   WHERE user_id = ? AND payment_way = '\u5E73\u53F0\u5E01' AND payment_status = 3`,
      values: [user_id]
    });
    const purchaseCount = ((_b = purchaseCountResult[0]) == null ? void 0 : _b.count) || 0;
    const recentOrdersResult = await sql({
      query: `SELECT * FROM PaymentRecords 
                   WHERE user_id = ? AND payment_way = '\u5E73\u53F0\u5E01'
                   ORDER BY created_at DESC 
                   LIMIT 3`,
      values: [user_id]
    });
    return {
      code: 200,
      data: {
        totalRecharge,
        purchaseCount,
        recentOrders: recentOrdersResult
      },
      message: "\u83B7\u53D6\u7528\u6237\u7EDF\u8BA1\u6570\u636E\u6210\u529F"
    };
  } catch (error) {
    console.error("\u83B7\u53D6\u7528\u6237\u7EDF\u8BA1\u6570\u636E\u51FA\u9519:", error);
    throw createError({
      status: 500,
      message: "\u83B7\u53D6\u7EDF\u8BA1\u6570\u636E\u65F6\u53D1\u751F\u9519\u8BEF"
    });
  }
});
const getUserStats = defineEventHandler(async (event) => {
  var _a, _b, _c, _d;
  try {
    const user_id = parseInt((_b = (_a = event.context.params) == null ? void 0 : _a.id) != null ? _b : "");
    if (!user_id || isNaN(user_id)) {
      return {
        code: 400,
        message: "\u7F3A\u5C11\u7528\u6237ID\u53C2\u6570"
      };
    }
    const user = await findById(user_id);
    if (!user) {
      return {
        code: 404,
        message: "\u7528\u6237\u4E0D\u5B58\u5728"
      };
    }
    const totalRechargeResult = await sql({
      query: `SELECT SUM(amount) as total FROM PaymentRecords 
                   WHERE user_id = ? AND payment_status = 3
                   AND (payment_way NOT LIKE '%\u5E73\u53F0\u5E01%' OR payment_way IS NULL OR payment_way = '')`,
      values: [user_id]
    });
    const totalRecharge = ((_c = totalRechargeResult[0]) == null ? void 0 : _c.total) || 0;
    const purchaseCountResult = await sql({
      query: `SELECT COUNT(*) as count FROM PaymentRecords 
                   WHERE user_id = ? AND payment_way = '\u5E73\u53F0\u5E01' AND payment_status = 3`,
      values: [user_id]
    });
    const purchaseCount = ((_d = purchaseCountResult[0]) == null ? void 0 : _d.count) || 0;
    return {
      code: 200,
      data: {
        total_recharge: totalRecharge,
        total_purchases: purchaseCount
      },
      message: "\u83B7\u53D6\u7528\u6237\u7EDF\u8BA1\u6570\u636E\u6210\u529F"
    };
  } catch (error) {
    console.error("\u83B7\u53D6\u7528\u6237\u7EDF\u8BA1\u6570\u636E\u51FA\u9519:", error);
    throw createError({
      status: 500,
      message: "\u83B7\u53D6\u7EDF\u8BA1\u6570\u636E\u65F6\u53D1\u751F\u9519\u8BEF"
    });
  }
});
const getUserBalance = defineEventHandler(async (event) => {
  try {
    const authorizationHeader = getHeader(event, "authorization");
    const userId = authorizationHeader ? parseInt(authorizationHeader) : null;
    if (!userId || isNaN(userId)) {
      return {
        code: 401,
        message: "\u672A\u6388\u6743\uFF0C\u8BF7\u5148\u767B\u5F55"
      };
    }
    const user = await findById(userId);
    if (!user) {
      return {
        code: 404,
        message: "\u7528\u6237\u4E0D\u5B58\u5728"
      };
    }
    const platformCoins = await getPlatformCoins(userId);
    return {
      code: 200,
      data: {
        platform_coins: platformCoins
      },
      message: "\u83B7\u53D6\u4F59\u989D\u6210\u529F"
    };
  } catch (error) {
    console.error("[\u4F59\u989D\u67E5\u8BE2] \u5F02\u5E38:", error);
    return {
      code: 500,
      message: "\u83B7\u53D6\u4F59\u989D\u5931\u8D25"
    };
  }
});
const getUserCharacters = defineEventHandler(async (event) => {
  try {
    const query = getQuery(event);
    const user_id = parseInt(query.user_id);
    if (!user_id || isNaN(user_id)) {
      return {
        code: 400,
        message: "\u7F3A\u5C11\u7528\u6237ID\u53C2\u6570"
      };
    }
    const user = await findById(user_id);
    if (!user) {
      return {
        code: 404,
        message: "\u7528\u6237\u4E0D\u5B58\u5728"
      };
    }
    const GameCharactersModel = await import('../../_/gameCharacters.mjs');
    const characters = await GameCharactersModel.findByUserId(user_id);
    const GameServersModel = await import('../../_/gameServers.mjs');
    const uniqueServerIds = [...new Set(characters.map((c) => c.server_id).filter(Boolean))];
    const serverNameMap = {};
    await Promise.all(uniqueServerIds.map(async (sid) => {
      const gs = await GameServersModel.getByServerId(Number(sid));
      if (gs) serverNameMap[Number(sid)] = gs.name;
    }));
    return {
      code: 200,
      data: {
        user_id,
        characters: characters.map((char) => ({
          id: char.id,
          uuid: char.uuid,
          subuser_id: char.subuser_id,
          character_name: char.character_name,
          character_level: char.character_level,
          // 优先用 gameservers.name，兜底用存储的 server_name
          server_name: serverNameMap[Number(char.server_id)] || char.server_name,
          server_id: char.server_id,
          game_id: char.game_id,
          last_login_at: char.last_login_at
        }))
      },
      message: "\u83B7\u53D6\u7528\u6237\u89D2\u8272\u4FE1\u606F\u6210\u529F"
    };
  } catch (error) {
    console.error("\u83B7\u53D6\u7528\u6237\u89D2\u8272\u4FE1\u606F\u51FA\u9519:", error);
    throw createError({
      status: 500,
      message: "\u83B7\u53D6\u7528\u6237\u89D2\u8272\u4FE1\u606F\u65F6\u53D1\u751F\u9519\u8BEF"
    });
  }
});
const getPlayerGiftPackageRecords = defineEventHandler(async (event) => {
  try {
    const query = getQuery(event);
    const user_id = parseInt(query.user_id);
    const page = parseInt(query.page) || 1;
    const pageSize = parseInt(query.pageSize) || 10;
    const startDate = query.startDate;
    const endDate = query.endDate;
    const packageType = query.packageType || "all";
    if (!user_id || isNaN(user_id)) {
      return {
        code: 400,
        message: "\u7F3A\u5C11\u7528\u6237ID\u53C2\u6570"
      };
    }
    const records = await getPlayerGiftPackageRecords$1(
      user_id,
      page,
      pageSize,
      startDate,
      endDate,
      packageType
    );
    const total = await getPlayerGiftPackageRecordsCount(
      user_id,
      startDate,
      endDate,
      packageType
    );
    return {
      code: 200,
      data: {
        records,
        pagination: {
          page,
          pageSize,
          total,
          totalPages: Math.ceil(total / pageSize)
        },
        filters: {
          user_id,
          startDate,
          endDate,
          packageType
        }
      },
      message: "\u83B7\u53D6\u793C\u5305\u8BB0\u5F55\u6210\u529F"
    };
  } catch (error) {
    console.error("\u83B7\u53D6\u73A9\u5BB6\u793C\u5305\u8BB0\u5F55\u51FA\u9519:", error);
    throw createError({
      status: 500,
      message: "\u83B7\u53D6\u793C\u5305\u8BB0\u5F55\u65F6\u53D1\u751F\u9519\u8BEF"
    });
  }
});

const OP_ADMIN_BASE = process.env.OP_ADMIN_BASE_URL || "http://localhost:3003";
const redeem = async (evt) => {
  const body = await readBody(evt);
  console.log(`[CDK][redeem][proxy] \u8F6C\u53D1\u8BF7\u6C42\u5230 op-admin`, { body });
  let result;
  try {
    const resp = await fetch(`${OP_ADMIN_BASE}/api/client/cdk/redeem`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body)
    });
    result = await resp.json();
    console.log(`[CDK][redeem][proxy] op-admin \u54CD\u5E94`, result);
  } catch (e) {
    console.error(`[CDK][redeem][proxy] \u8BF7\u6C42 op-admin \u5931\u8D25`, e);
    throw createError({ status: 502, message: "\u5151\u6362\u670D\u52A1\u6682\u65F6\u4E0D\u53EF\u7528\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5" });
  }
  return result;
};

const MILESTONES = [
  { days: 3, bonus: 300 },
  { days: 7, bonus: 400 },
  { days: 13, bonus: 600 },
  { days: 17, bonus: 800 },
  { days: 25, bonus: 1e3 },
  { days: 30, bonus: 1200 }
];
const BASE_COINS = 200;
const getMonthlyCheckInStatus = async (userId) => {
  const today = getBeijingDate();
  const yearMonth = today.slice(0, 7);
  console.log(`[CheckIn][status] userId=${userId} today="${today}" yearMonth="${yearMonth}"`);
  const records = await sql({
    query: `SELECT check_date, cumulative_days, total_coins, bonus_coins
                FROM CheckInRecords
                WHERE user_id = ? AND check_date LIKE ?
                ORDER BY check_date ASC`,
    values: [userId, `${yearMonth}%`]
  });
  console.log(`[CheckIn][status] \u67E5\u5230 ${records.length} \u6761\u8BB0\u5F55`);
  if (records.length > 0) {
    const r0 = records[0];
    console.log(`[CheckIn][status] \u7B2C\u4E00\u6761 check_date \u539F\u59CB\u503C=`, r0.check_date);
    console.log(`[CheckIn][status] \u7B2C\u4E00\u6761 check_date typeof=`, typeof r0.check_date);
    console.log(`[CheckIn][status] \u7B2C\u4E00\u6761 check_date instanceof Date=`, r0.check_date instanceof Date);
    console.log(`[CheckIn][status] String(check_date)=`, String(r0.check_date));
    if (r0.check_date instanceof Date) {
      console.log(`[CheckIn][status] toISOString=`, r0.check_date.toISOString());
    }
  }
  const checkedDates = records.map((r) => {
    const raw = r.check_date;
    if (raw instanceof Date) {
      return raw.toISOString().slice(0, 10);
    }
    return String(raw).slice(0, 10);
  });
  console.log(`[CheckIn][status] checkedDates=`, checkedDates);
  const todayChecked = checkedDates.includes(today);
  console.log(`[CheckIn][status] todayChecked=${todayChecked}`);
  const cumulativeDays = records.length > 0 ? records[records.length - 1].cumulative_days : 0;
  const nextMilestone = MILESTONES.find((m) => m.days > cumulativeDays) || null;
  const achievedMilestones = MILESTONES.filter((m) => m.days <= cumulativeDays);
  return {
    today,
    checkedDates,
    todayChecked,
    cumulativeDays,
    nextMilestone,
    achievedMilestones,
    milestones: MILESTONES,
    baseCoins: BASE_COINS
  };
};
const calcCheckInReward = (cumulativeDays) => {
  const newCumulativeDays = cumulativeDays + 1;
  const baseCo = BASE_COINS;
  const milestone = MILESTONES.find((m) => m.days === newCumulativeDays);
  const bonusCo = milestone ? milestone.bonus : 0;
  const totalCo = baseCo + bonusCo;
  return { baseCo, bonusCo, totalCo };
};
const doCheckIn$1 = async (userId, transactionId) => {
  var _a, _b, _c;
  const today = getBeijingDate();
  const yearMonth = today.slice(0, 7);
  const todayRecord = await sql({
    query: "SELECT id FROM CheckInRecords WHERE user_id = ? AND check_date = ? LIMIT 1",
    values: [userId, today]
  });
  if (todayRecord.length > 0) {
    return { success: false, message: "\u4ECA\u65E5\u5DF2\u7B7E\u5230" };
  }
  const monthRecord = await sql({
    query: `SELECT MAX(cumulative_days) AS max_days
                FROM CheckInRecords
                WHERE user_id = ? AND check_date LIKE ?`,
    values: [userId, `${yearMonth}%`]
  });
  const cumulativeDays = (_b = (_a = monthRecord[0]) == null ? void 0 : _a.max_days) != null ? _b : 0;
  const { baseCo, bonusCo, totalCo } = calcCheckInReward(cumulativeDays);
  const newCumulativeDays = cumulativeDays + 1;
  try {
    await sql({
      query: `INSERT INTO CheckInRecords
                        (user_id, check_date, base_coins, bonus_coins, total_coins, cumulative_days, transaction_id)
                    VALUES (?, ?, ?, ?, ?, ?, ?)`,
      values: [userId, today, baseCo, bonusCo, totalCo, newCumulativeDays, transactionId]
    });
  } catch (err) {
    if (((_c = err == null ? void 0 : err.message) == null ? void 0 : _c.includes("Duplicate")) || (err == null ? void 0 : err.code) === "ER_DUP_ENTRY") {
      return { success: false, message: "\u4ECA\u65E5\u5DF2\u7B7E\u5230" };
    }
    throw err;
  }
  return {
    success: true,
    message: "\u7B7E\u5230\u6210\u529F",
    reward: {
      base: baseCo,
      bonus: bonusCo,
      total: totalCo,
      cumulative: newCumulativeDays
    }
  };
};

async function getCurrentUserId(event) {
  const cookieUserId = getCookie(event, "user_id");
  if (cookieUserId) {
    const id = parseInt(cookieUserId);
    if (!isNaN(id) && id > 0) return id;
  }
  const query = getQuery(event);
  if (query.user_id) {
    const id = parseInt(query.user_id);
    if (!isNaN(id) && id > 0) return id;
  }
  return null;
}
function genTransactionId(prefix, userId) {
  const ts = Date.now();
  const rand = Math.floor(Math.random() * 9e3) + 1e3;
  return `${prefix}${ts}${rand}${userId}`;
}
const getMonthlyCardStatus = defineEventHandler(async (event) => {
  try {
    const userId = await getCurrentUserId(event);
    if (!userId) return { code: 401, message: "\u672A\u767B\u5F55" };
    const status = await getCardStatus(userId);
    return { code: 200, data: status };
  } catch (err) {
    console.error("[getMonthlyCardStatus] error:", err);
    return { code: 500, message: "\u83B7\u53D6\u6708\u5361\u72B6\u6001\u5931\u8D25" };
  }
});
const claimMonthlyCard = defineEventHandler(async (event) => {
  var _a;
  const body = await readBody(event);
  const userId = (body == null ? void 0 : body.user_id) ? parseInt(body.user_id) : await getCurrentUserId(event);
  if (!userId) return { code: 401, message: "\u672A\u767B\u5F55" };
  try {
    const today = getBeijingDate();
    const cards = await getActiveCardsByUserId(userId);
    if (cards.length === 0) {
      return { code: 400, message: "\u60A8\u6CA1\u6709\u6709\u6548\u7684\u6708\u5361" };
    }
    const claimedCardIds = await getTodayClaimedCardIds(userId, today);
    const unclaimedCards = cards.filter((c) => !claimedCardIds.includes(c.id));
    if (unclaimedCards.length === 0) {
      return { code: 400, message: "\u4ECA\u65E5\u6708\u5361\u6743\u76CA\u5DF2\u9886\u53D6" };
    }
    const totalCoins = unclaimedCards.reduce((sum, c) => sum + c.daily_coins, 0);
    const currentBalance = await getPlatformCoins(userId);
    const transactionId = genTransactionId("MC", userId);
    const updateResult = await updatePlatformCoinsUnified(userId, totalCoins, 8);
    if (!updateResult.success) {
      return { code: 500, message: updateResult.message || "\u9886\u53D6\u5931\u8D25" };
    }
    const newBalance = updateResult.newBalance;
    const cardNames = unclaimedCards.map((c) => c.card_type === "monthly" ? "\u6708\u5361" : "\u7EC8\u8EAB\u5361").join("+");
    await insert({
      user_id: userId,
      sub_user_id: null,
      role_id: "",
      transaction_id: transactionId,
      wuid: "",
      payment_way: "\u6708\u5361\u6743\u76CA",
      payment_id: 0,
      world_id: 1,
      product_name: `${cardNames}\u6BCF\u65E5\u9886\u53D6`,
      product_des: `\u9886\u53D6 ${totalCoins} \u5E73\u53F0\u5E01`,
      ip: "",
      amount: 0,
      mch_order_id: transactionId,
      msg: `${cardNames}\uFF0C\u5171\u9886\u53D6${totalCoins}\u5E73\u53F0\u5E01`,
      server_url: "",
      device: "",
      channel_code: "",
      game_code: "",
      payment_status: 3,
      ptb_before: currentBalance,
      ptb_change: totalCoins,
      ptb_after: newBalance
    });
    for (const card of unclaimedCards) {
      try {
        await insertClaim(card.id, userId, today, card.daily_coins, transactionId);
      } catch (err) {
        if (!((_a = err == null ? void 0 : err.message) == null ? void 0 : _a.includes("Duplicate"))) throw err;
      }
    }
    return {
      code: 200,
      data: {
        coins_claimed: totalCoins,
        new_balance: newBalance,
        transaction_id: transactionId
      },
      message: `\u6210\u529F\u9886\u53D6 ${totalCoins} \u5E73\u53F0\u5E01`
    };
  } catch (err) {
    console.error("[claimMonthlyCard] error:", err);
    return { code: 500, message: "\u9886\u53D6\u5931\u8D25\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5" };
  }
});
const getCheckInStatus = defineEventHandler(async (event) => {
  try {
    const userId = await getCurrentUserId(event);
    if (!userId) return { code: 401, message: "\u672A\u767B\u5F55" };
    const status = await getMonthlyCheckInStatus(userId);
    return { code: 200, data: status };
  } catch (err) {
    console.error("[getCheckInStatus] error:", err);
    return { code: 500, message: "\u83B7\u53D6\u7B7E\u5230\u72B6\u6001\u5931\u8D25" };
  }
});
const doCheckIn = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const userId = (body == null ? void 0 : body.user_id) ? parseInt(body.user_id) : await getCurrentUserId(event);
  if (!userId) return { code: 401, message: "\u672A\u767B\u5F55" };
  try {
    try {
      const { getRedisCluster } = await import('../../nitro/nitro.mjs').then(function (n) { return n.af; });
      const redis = getRedisCluster();
      const today = getBeijingDate();
      const key = `checkin:${userId}:${today}`;
      const acquired = await redis.set(key, "1", "EX", 86400, "NX");
      if (!acquired) {
        return { code: 400, message: "\u4ECA\u65E5\u5DF2\u7B7E\u5230" };
      }
    } catch {
    }
    const transactionId = genTransactionId("CI", userId);
    const checkInResult = await doCheckIn$1(userId, transactionId);
    if (!checkInResult.success) {
      return { code: 400, message: checkInResult.message };
    }
    const { reward } = checkInResult;
    const totalCoins = reward.total;
    const currentBalance = await getPlatformCoins(userId);
    const updateResult = await updatePlatformCoinsUnified(userId, totalCoins, 9);
    if (!updateResult.success) {
      return { code: 500, message: "\u7B7E\u5230\u53D1\u653E\u5E73\u53F0\u5E01\u5931\u8D25" };
    }
    const newBalance = updateResult.newBalance;
    const desc = reward.bonus > 0 ? `\u7B7E\u5230\u7B2C${reward.cumulative}\u5929\uFF0C\u57FA\u7840+${reward.base}\uFF0C\u91CC\u7A0B\u7891\u989D\u5916+${reward.bonus}` : `\u7B7E\u5230\u7B2C${reward.cumulative}\u5929\uFF0C\u57FA\u7840+${reward.base}`;
    await insert({
      user_id: userId,
      sub_user_id: null,
      role_id: "",
      transaction_id: transactionId,
      wuid: "",
      payment_way: "\u7B7E\u5230\u5956\u52B1",
      payment_id: 0,
      world_id: 1,
      product_name: "\u6BCF\u65E5\u7B7E\u5230",
      product_des: desc,
      ip: "",
      amount: 0,
      mch_order_id: transactionId,
      msg: desc,
      server_url: "",
      device: "",
      channel_code: "",
      game_code: "",
      payment_status: 3,
      ptb_before: currentBalance,
      ptb_change: totalCoins,
      ptb_after: newBalance
    });
    return {
      code: 200,
      data: {
        base_coins: reward.base,
        bonus_coins: reward.bonus,
        total_coins: totalCoins,
        cumulative_days: reward.cumulative,
        new_balance: newBalance,
        transaction_id: transactionId
      },
      message: reward.bonus > 0 ? `\u7B7E\u5230\u6210\u529F\uFF01\u83B7\u5F97 ${totalCoins} \u5E73\u53F0\u5E01\uFF08\u542B\u91CC\u7A0B\u7891\u5956\u52B1 ${reward.bonus}\uFF09` : `\u7B7E\u5230\u6210\u529F\uFF01\u83B7\u5F97 ${totalCoins} \u5E73\u53F0\u5E01`
    };
  } catch (err) {
    console.error("[doCheckIn] error:", err);
    return { code: 500, message: "\u7B7E\u5230\u5931\u8D25\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5" };
  }
});

const getPublicPTBRate = async (evt) => {
  try {
    const param = await detail("ptb_exchange_rate");
    return {
      code: 200,
      data: param,
      message: "\u83B7\u53D6\u6210\u529F"
    };
  } catch (error) {
    console.error("\u83B7\u53D6 PTB \u6C47\u7387\u5931\u8D25:", error);
    throw createError({ status: 500, message: error.message || "\u83B7\u53D6\u5931\u8D25" });
  }
};
const getPublicParamByKey = async (evt) => {
  var _a, _b, _c, _d;
  try {
    const whitelist = /* @__PURE__ */ new Set(["ptb_exchange_rate", "kefu_line"]);
    const key = ((_b = (_a = evt.context) == null ? void 0 : _a.params) == null ? void 0 : _b.key) || ((_d = (_c = evt.context) == null ? void 0 : _c.params) == null ? void 0 : _d.key);
    const k = String(key || "").trim();
    if (!k || !whitelist.has(k)) {
      throw createError({ status: 404, message: "\u53C2\u6570\u4E0D\u53EF\u7528" });
    }
    const param = await detail(k);
    return { code: 200, data: param, message: "\u83B7\u53D6\u6210\u529F" };
  } catch (error) {
    throw createError({ status: error.status || 500, message: error.message || "\u83B7\u53D6\u5931\u8D25" });
  }
};

const router = createRouter();
function getRealIp(headers) {
  const aliCdnRealIp = headers["ali-cdn-real-ip"];
  const xForwardedFor = headers["x-forwarded-for"];
  const xRealIp = headers["x-real-ip"];
  return aliCdnRealIp || (xForwardedFor ? xForwardedFor.split(",")[0].trim() : "") || xRealIp || "unknown";
}
function nowStr() {
  return (/* @__PURE__ */ new Date()).toLocaleString("zh-CN", { timeZone: "Asia/Shanghai", hour12: false });
}
const withLogging = (handler, apiName) => {
  return defineEventHandler(async (event) => {
    const headers = getHeaders(event);
    const ipAddress = getRealIp(headers);
    const method = getMethod(event);
    const url = getRequestURL(event);
    let requestBody = {};
    let queryParams = {};
    try {
      if (method === "POST" || method === "PUT") {
        requestBody = await readBody(event);
      }
      queryParams = getQuery(event);
    } catch (e) {
      requestBody = {};
    }
    console.log(`[${nowStr()}] [API] ${method} ${url.pathname} | IP: ${ipAddress}`);
    let response = {};
    let error = null;
    let statusCode = 200;
    try {
      try {
        const url2 = getRequestURL(event);
        const method2 = getMethod(event) || "GET";
        const pathname = url2.pathname.replace(/\/$/, "");
        const skipSignature = pathname === "/api/user/login" || pathname === "/api/user/register" || pathname === "/api/user/captcha" || pathname === "/api/user/check" || pathname === "/api/user/check-channel" || pathname === "/api/user/token" || pathname === "/api/client/cdk/servers" || pathname === "/api/client/cdk/redeem" || pathname === "/api/client/servers" || pathname === "/api/client/balance" || // 有自己的 Authorization header 鉴权
        pathname === "/api/payment/cashier-notify" || pathname === "/api/payment/third-party-notify";
        if (!skipSignature) {
          await verifyApiSignature(event, url2.pathname, method2, queryParams, requestBody);
        }
      } catch (sigErr) {
        throw createError({ statusCode: 401, statusMessage: (sigErr == null ? void 0 : sigErr.statusMessage) || "invalid_sign" });
      }
      response = await handler(event);
    } catch (e) {
      error = e;
      statusCode = e.statusCode || 500;
      response = {
        success: false,
        message: e.statusMessage || e.message || "\u7CFB\u7EDF\u9519\u8BEF",
        data: null
      };
      try {
        setResponseStatus(event, statusCode);
      } catch {
      }
    }
    if (error) {
      console.error(`[API] \u9519\u8BEF: ${error.message}`);
    }
    console.log("==========================================");
    return response;
  });
};
router.get("/user/token", defineEventHandler(quickreg));
router.post("/user/check", defineEventHandler(checkUser));
router.get("/user/check-channel", defineEventHandler(checkChannelStatus));
router.post("/user/login", defineEventHandler(async (event) => {
  const result = await userLogin(event);
  try {
    const ok = !!(result && result.data && result.data.user);
    if (ok) {
      event.node.res.setHeader("Set-Cookie", [
        "auth_logged_in=true; Path=/; HttpOnly; SameSite=Lax",
        "auth_is_user=true; Path=/; HttpOnly; SameSite=Lax"
      ]);
    }
  } catch {
  }
  return result;
}));
router.get("/user/captcha", defineEventHandler(async () => {
  return generateCaptcha();
}));
router.post("/user/register", withLogging(async (event) => {
  const headers = getHeaders(event);
  const clientIp = getRealIp(headers);
  const REGISTER_IP_LIMIT_TTL = 8 * 60 * 60;
  const ipLimitKey = `reg_ip_limit:${clientIp}`;
  if (clientIp && clientIp !== "unknown") {
    const { getRedisCluster } = await import('../../nitro/nitro.mjs').then(function (n) { return n.af; });
    const redis = getRedisCluster();
    const existing = await redis.get(ipLimitKey);
    if (existing) {
      const ttl = await redis.ttl(ipLimitKey);
      const remainHours = Math.floor(ttl / 3600);
      const remainMins = Math.ceil(ttl % 3600 / 60);
      const waitMsg = remainHours > 0 ? `${remainHours} \u5C0F\u65F6 ${remainMins} \u5206\u949F` : `${remainMins} \u5206\u949F`;
      console.warn(`[${nowStr()}] [\u6CE8\u518C\u62D2\u7EDD] IP ${clientIp} \u9650\u5236\u671F\u5185\u91CD\u590D\u6CE8\u518C\uFF0C\u5269\u4F59 ${ttl}s`);
      return { status: "fail", message: `\u8BE5IP\u6CE8\u518C\u8FC7\u4E8E\u9891\u7E41\uFF0C\u8BF7 ${waitMsg} \u540E\u518D\u8BD5` };
    }
  }
  const body = await readBody(event);
  const { captcha_token, captcha_input } = body || {};
  if (!captcha_token || !captcha_input) {
    throw createError({ statusCode: 400, statusMessage: "\u8BF7\u5B8C\u6210\u56FE\u5F62\u9A8C\u8BC1\u7801" });
  }
  const captchaOk = await verifyCaptcha(captcha_token, captcha_input);
  if (!captchaOk) {
    throw createError({ statusCode: 400, statusMessage: "\u9A8C\u8BC1\u7801\u9519\u8BEF\u6216\u5DF2\u8FC7\u671F\uFF0C\u8BF7\u5237\u65B0\u91CD\u8BD5" });
  }
  const result = await register(event);
  if ((result == null ? void 0 : result.status) === "success" && clientIp && clientIp !== "unknown") {
    const { getRedisCluster } = await import('../../nitro/nitro.mjs').then(function (n) { return n.af; });
    const redis = getRedisCluster();
    await redis.set(ipLimitKey, "1", "EX", REGISTER_IP_LIMIT_TTL);
    console.log(`[${nowStr()}] [\u6CE8\u518C] IP ${clientIp} \u5DF2\u9501\u5B9A\uFF0C8\u5C0F\u65F6\u5185\u4E0D\u53EF\u518D\u6CE8\u518C`);
  }
  return result;
}));
router.post("/user/reg", withLogging(updateSubUserWuid));
router.get("/user/get/:thirdparty_uid", withLogging(getNewOne));
router.get("/user/undo/:thirdparty_uid", defineEventHandler(getorders));
router.post("/user/undop", defineEventHandler(getpostorders));
router.get("/user/system-params/ptb_exchange_rate", defineEventHandler(getPublicPTBRate));
router.get("/user/system-params/:key", defineEventHandler(getPublicParamByKey));
router.get("/user/payment-settings/active", defineEventHandler(getActivePaymentSettingsForUser));
router.get("/user/item-config", defineEventHandler(async (event) => {
  const { getAllItems, searchItems } = await import('../../nitro/nitro.mjs').then(function (n) { return n.ag; });
  const q = getQuery(event) || {};
  const action = String(q.action || "list");
  const page = Number(q.page) || 1;
  const pageSize = Math.min(Number(q.pageSize) || 1e3, 2e4);
  if (action === "search") {
    const term = String(q.q || "").trim();
    if (!term) {
      return { success: true, data: { list: [], total: 0, page, pageSize, totalPages: 0 } };
    }
    const results = searchItems(term);
    const total2 = results.length;
    const offset2 = (page - 1) * pageSize;
    const paged2 = results.slice(offset2, offset2 + pageSize).map((r) => ({ id: r.id, n: r.name, cn: r.name }));
    return { success: true, data: { list: paged2, total: total2, page, pageSize, totalPages: Math.ceil(total2 / pageSize) } };
  }
  const all = getAllItems();
  const total = all.length;
  const offset = (page - 1) * pageSize;
  const paged = all.slice(offset, offset + pageSize).map((it) => ({ id: it.id, n: it.name, cn: it.name }));
  return { success: true, data: { list: paged, total, page, pageSize, totalPages: Math.ceil(total / pageSize) } };
}));
router.post("/user/cashier/pay", defineEventHandler(doPayment));
router.post("/user/payment/query", defineEventHandler(queryPaymentOrder));
router.get("/client/user/profile/:id", withLogging(getUserProfile));
router.get("/client/user/home-stats", withLogging(getUserHomeStats));
router.get("/client/user/stats/:id", withLogging(getUserStats));
router.get("/client/balance", withLogging(getUserBalance));
router.get("/client/gift-packages", withLogging(getPublicGiftPackages));
router.get("/client/gift-packages/categories", withLogging(getGiftPackageCategories));
router.post("/client/gift-packages/purchase", withLogging(userPurchaseGiftPackage));
router.get("/client/packages", withLogging(getAvailableGiftPackages));
router.get("/client/player-gift-packages", withLogging(getPlayerGiftPackageRecords));
router.get("/client/purchase-history", withLogging(getUserPurchaseHistory));
router.get("/client/recharge-history", withLogging(getUserRechargeHistory));
router.get("/client/spend-history", withLogging(getUserPlatformCoinSpendHistory));
router.get("/client/benefits/monthly-card/status", withLogging(getMonthlyCardStatus));
router.post("/client/benefits/monthly-card/claim", withLogging(claimMonthlyCard));
router.get("/client/benefits/checkin/status", withLogging(getCheckInStatus));
router.post("/client/benefits/checkin", withLogging(doCheckIn));
router.get("/client/getUserCharacters", withLogging(getUserCharacters));
router.get("/client/servers", withLogging(async () => {
  const active = await listActive();
  const data = active.map((s) => {
    var _a;
    return { name: s.name, bname: s.bname, server_id: (_a = s.server_id) != null ? _a : null };
  }).filter((s) => s.name && s.bname);
  return { success: true, data };
}));
router.post("/client/cdk/redeem", defineEventHandler(redeem));
router.get("/client/cdk/servers", withLogging(async () => {
  const active = await listCdkRedeemable();
  const data = active.map((s) => {
    var _a;
    return { name: s.name, bname: s.bname, server_id: (_a = s.server_id) != null ? _a : null };
  }).filter((s) => s.name && s.bname);
  return { success: true, data };
}));
router.post("/rechargeurl/get", withLogging(paymentNewReps));
router.get("/payment/check/:tranId", withLogging(checkOrder));
router.get("/payment/trans/:transaction_id", defineEventHandler(getPaymentByTransId));
router.get("/payment/user/:user_id", defineEventHandler(getPaymentByUserID));
router.get("/payment/third-party-notify", withLogging(handleThirdPartyNotify));
router.post("/payment/third-party-notify", withLogging(handleThirdPartyNotify));
router.get("/payment/cashier-notify", withLogging(handleCashierPaymentNotify));
router.post("/payment/cashier-notify", withLogging(handleCashierPaymentNotify));
const _____ = useBase("/api", router.handler);

export { _____ as default };
//# sourceMappingURL=_..._.mjs.map
