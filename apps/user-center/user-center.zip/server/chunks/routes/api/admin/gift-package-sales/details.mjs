import { d as defineEventHandler, a as getHeader, c as createError, r as readBody, s as sql } from '../../../../nitro/nitro.mjs';
import { g as getAdminWithPermissions } from '../../../../_/admin.mjs';
import 'node:crypto';
import 'ioredis';
import 'fs';
import 'path';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:url';
import 'mysql2/promise';
import '@iconify/utils';
import 'consola';

const details = defineEventHandler(async (event) => {
  const authorizationHeader = getHeader(event, "authorization");
  const token = authorizationHeader ? parseInt(authorizationHeader) : null;
  if (!token) {
    throw createError({
      status: 401,
      message: "\u672A\u63D0\u4F9B\u8BA4\u8BC1token"
    });
  }
  const adminInfo = await getAdminWithPermissions(token);
  if (!adminInfo || adminInfo.level !== 0) {
    throw createError({
      status: 403,
      message: "\u53EA\u6709\u8D85\u7EA7\u7BA1\u7406\u5458\u53EF\u4EE5\u67E5\u770B\u793C\u5305\u9500\u552E\u8BE6\u60C5"
    });
  }
  try {
    return await handleGetSalesDetails(event);
  } catch (error) {
    console.error("\u793C\u5305\u9500\u552E\u8BE6\u60C5API\u9519\u8BEF:", error);
    throw createError({
      status: error.status || 500,
      message: error.message || "\u670D\u52A1\u5668\u5185\u90E8\u9519\u8BEF"
    });
  }
});
async function handleGetSalesDetails(event) {
  var _a, _b, _c;
  const body = await readBody(event);
  const packageId = body.package_id;
  const startDate = body.start_date;
  const endDate = body.end_date;
  if (!packageId || !startDate || !endDate) {
    throw createError({
      status: 400,
      message: "\u7F3A\u5C11\u5FC5\u586B\u53C2\u6570\uFF1Apackage_id, start_date, end_date"
    });
  }
  const packageQuery = `
    SELECT 
      id as package_id,
      package_code,
      package_name,
      category,
      price_platform_coins + price_real_money as price
    FROM ExternalGiftPackages
    WHERE id = ?
  `;
  const packageResult = await sql({
    query: packageQuery,
    values: [packageId]
  });
  if (!packageResult.length) {
    throw createError({
      status: 404,
      message: "\u793C\u5305\u4E0D\u5B58\u5728"
    });
  }
  const packageInfo = packageResult[0];
  const statsQuery = `
    SELECT 
      COUNT(*) as total_sales,
      SUM(CASE 
        WHEN payment_type = 'platform_coins' THEN platform_coins_paid 
        ELSE real_money_paid 
      END) as total_amount,
      COUNT(DISTINCT user_id) as unique_buyers
    FROM giftpackagepurchaserecords
    WHERE package_id = ? 
      AND created_at >= ? 
      AND created_at < DATE_ADD(?, INTERVAL 1 DAY)
  `;
  const statsResult = await sql({
    query: statsQuery,
    values: [packageId, startDate, endDate]
  });
  const dailyQuery = `
    SELECT 
      DATE(created_at) as date,
      COUNT(*) as sales,
      SUM(CASE 
        WHEN payment_type = 'platform_coins' THEN platform_coins_paid 
        ELSE real_money_paid 
      END) as amount
    FROM giftpackagepurchaserecords
    WHERE package_id = ? 
      AND created_at >= ? 
      AND created_at < DATE_ADD(?, INTERVAL 1 DAY)
    GROUP BY DATE(created_at)
    ORDER BY date DESC
  `;
  const dailyResult = await sql({
    query: dailyQuery,
    values: [packageId, startDate, endDate]
  });
  return {
    success: true,
    data: {
      ...packageInfo,
      total_sales: ((_a = statsResult[0]) == null ? void 0 : _a.total_sales) || 0,
      total_amount: Number(((_b = statsResult[0]) == null ? void 0 : _b.total_amount) || 0),
      unique_buyers: ((_c = statsResult[0]) == null ? void 0 : _c.unique_buyers) || 0,
      dailyTrend: dailyResult.map((day) => ({
        date: day.date,
        sales: day.sales,
        amount: Number(day.amount || 0)
      }))
    }
  };
}

export { details as default };
//# sourceMappingURL=details.mjs.map
