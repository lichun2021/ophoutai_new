import { d as defineEventHandler, a as getHeader, c as createError, r as readBody, s as sql } from '../../../nitro/nitro.mjs';
import { g as getAdminWithPermissions } from '../../../_/admin.mjs';
import 'node:crypto';
import 'ioredis';
import 'fs';
import 'path';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:url';
import 'mysql2/promise';
import '@iconify/utils';
import 'consola';

const giftPackageSales = defineEventHandler(async (event) => {
  const authorizationHeader = getHeader(event, "authorization");
  const token = authorizationHeader ? parseInt(authorizationHeader) : null;
  if (!token) {
    throw createError({
      status: 401,
      message: "\u672A\u63D0\u4F9B\u8BA4\u8BC1token"
    });
  }
  const adminInfo = await getAdminWithPermissions(token);
  if (!adminInfo || adminInfo.level !== 0) {
    throw createError({
      status: 403,
      message: "\u53EA\u6709\u8D85\u7EA7\u7BA1\u7406\u5458\u53EF\u4EE5\u67E5\u770B\u793C\u5305\u9500\u552E\u7EDF\u8BA1"
    });
  }
  try {
    return await handleGetSalesData(event);
  } catch (error) {
    console.error("\u793C\u5305\u9500\u552E\u7EDF\u8BA1API\u9519\u8BEF:", error);
    throw createError({
      status: error.status || 500,
      message: error.message || "\u670D\u52A1\u5668\u5185\u90E8\u9519\u8BEF"
    });
  }
});
async function handleGetSalesData(event) {
  var _a, _b, _c, _d, _e, _f;
  const body = await readBody(event);
  const startDate = body.start_date;
  const endDate = body.end_date;
  const category = body.category;
  const packageName = body.package_name;
  const page = Number(body.page) || 1;
  const pageSize = Number(body.page_size) || 20;
  if (!startDate || !endDate) {
    throw createError({
      status: 400,
      message: "\u7F3A\u5C11\u5FC5\u586B\u53C2\u6570\uFF1Astart_date, end_date"
    });
  }
  const start = new Date(startDate);
  const end = new Date(endDate);
  if (start > end) {
    throw createError({
      status: 400,
      message: "\u5F00\u59CB\u65E5\u671F\u4E0D\u80FD\u5927\u4E8E\u7ED3\u675F\u65E5\u671F"
    });
  }
  let whereClause = "WHERE r.created_at >= ? AND r.created_at < DATE_ADD(?, INTERVAL 1 DAY)";
  const values = [startDate, endDate];
  if (category && category.trim() !== "") {
    whereClause += " AND p.category = ?";
    values.push(category);
  }
  if (packageName && packageName.trim() !== "") {
    whereClause += " AND p.package_name LIKE ?";
    values.push(`%${packageName}%`);
  }
  const salesQuery = `
    SELECT 
      p.id as package_id,
      p.package_code,
      p.package_name,
      p.category,
      p.price_real_money as price,
      COUNT(r.id) as total_sales,
      SUM(p.price_real_money * r.quantity) as total_amount,
      COUNT(DISTINCT r.user_id) as unique_buyers,
      AVG(p.price_real_money * r.quantity) as avg_price
    FROM giftpackagepurchaserecords r
    INNER JOIN ExternalGiftPackages p ON r.package_id = p.id
    ${whereClause}
    GROUP BY p.id, p.package_code, p.package_name, p.category
    ORDER BY total_sales DESC
    LIMIT ?, ?
  `;
  const offset = (page - 1) * pageSize;
  const salesData = await sql({
    query: salesQuery,
    values: [...values, offset, pageSize]
  });
  const countQuery = `
    SELECT COUNT(DISTINCT p.id) as total
    FROM giftpackagepurchaserecords r
    INNER JOIN ExternalGiftPackages p ON r.package_id = p.id
    ${whereClause}
  `;
  const countResult = await sql({
    query: countQuery,
    values
  });
  const total = ((_a = countResult[0]) == null ? void 0 : _a.total) || 0;
  const today = /* @__PURE__ */ new Date();
  const todayStr = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, "0")}-${String(today.getDate()).padStart(2, "0")}`;
  const todayQuery = `
    SELECT COUNT(*) as today_total
    FROM giftpackagepurchaserecords
    WHERE DATE(created_at) = ?
  `;
  const todayResult = await sql({
    query: todayQuery,
    values: [todayStr]
  });
  const statsQuery = `
    SELECT 
      COUNT(*) as query_total,
      SUM(p.price_real_money * r.quantity) as query_amount,
      COUNT(DISTINCT r.user_id) as unique_users
    FROM giftpackagepurchaserecords r
    INNER JOIN ExternalGiftPackages p ON r.package_id = p.id
    ${whereClause}
  `;
  const statsResult = await sql({
    query: statsQuery,
    values
  });
  let categoryTotalQuery = "";
  let categoryTotalValues = [];
  if (category && category.trim() !== "") {
    categoryTotalQuery = `
      SELECT COUNT(*) as category_total
      FROM giftpackagepurchaserecords r
      INNER JOIN ExternalGiftPackages p ON r.package_id = p.id
      WHERE p.category = ?
    `;
    categoryTotalValues = [category];
  } else {
    categoryTotalQuery = `
      SELECT COUNT(*) as category_total
      FROM giftpackagepurchaserecords
    `;
  }
  const categoryTotalResult = await sql({
    query: categoryTotalQuery,
    values: categoryTotalValues
  });
  return {
    success: true,
    data: {
      list: salesData.map((item) => ({
        ...item,
        total_amount: Number(item.total_amount || 0),
        avg_price: Number(item.avg_price || 0)
      })),
      total,
      stats: {
        today_total: ((_b = todayResult[0]) == null ? void 0 : _b.today_total) || 0,
        query_total: ((_c = statsResult[0]) == null ? void 0 : _c.query_total) || 0,
        category_total: ((_d = categoryTotalResult[0]) == null ? void 0 : _d.category_total) || 0,
        query_amount: Number(((_e = statsResult[0]) == null ? void 0 : _e.query_amount) || 0),
        unique_users: ((_f = statsResult[0]) == null ? void 0 : _f.unique_users) || 0
      }
    }
  };
}

export { giftPackageSales as default };
//# sourceMappingURL=gift-package-sales.mjs.map
