import { s as sql } from '../nitro/nitro.mjs';
import 'node:crypto';
import 'ioredis';
import 'fs';
import 'path';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:url';
import 'mysql2/promise';
import '@iconify/utils';
import 'consola';

const findByUuid = async (uuid) => {
  const result = await sql({
    query: "SELECT * FROM GameCharacters WHERE uuid = ? LIMIT 1",
    values: [uuid]
  });
  return result.length > 0 ? result[0] : null;
};
const findByUserId = async (user_id) => {
  const result = await sql({
    query: "SELECT * FROM GameCharacters WHERE user_id = ? ORDER BY created_at DESC",
    values: [user_id]
  });
  return result;
};
const findBySubUserId = async (subuser_id) => {
  const result = await sql({
    query: "SELECT * FROM GameCharacters WHERE subuser_id = ? ORDER BY created_at DESC",
    values: [subuser_id]
  });
  return result;
};
const findByGameId = async (game_id) => {
  const result = await sql({
    query: "SELECT * FROM GameCharacters WHERE game_id = ? ORDER BY created_at DESC",
    values: [game_id]
  });
  return result;
};
const findByUserAndGame = async (user_id, game_id) => {
  const result = await sql({
    query: "SELECT * FROM GameCharacters WHERE user_id = ? AND game_id = ? ORDER BY created_at DESC",
    values: [user_id, game_id]
  });
  return result;
};
const findBySubUserAndGame = async (subuser_id, game_id) => {
  const result = await sql({
    query: "SELECT * FROM GameCharacters WHERE subuser_id = ? AND game_id = ? ORDER BY created_at DESC",
    values: [subuser_id, game_id]
  });
  return result;
};
const read = async () => {
  const characters = await sql({
    query: "SELECT * FROM GameCharacters ORDER BY created_at DESC"
  });
  return characters;
};
const readPage = async (pageIndex, pageSize = 10, user_id, subuser_id, game_id) => {
  const offset = (pageIndex - 1) * pageSize;
  let _sql = {
    query: "SELECT * FROM GameCharacters",
    values: []
  };
  const conditions = [];
  if (user_id !== void 0) {
    conditions.push("user_id = ?");
    _sql.values.push(user_id);
  }
  if (subuser_id !== void 0) {
    conditions.push("subuser_id = ?");
    _sql.values.push(subuser_id);
  }
  if (game_id !== void 0) {
    conditions.push("game_id = ?");
    _sql.values.push(game_id);
  }
  if (conditions.length > 0) {
    _sql.query += " WHERE " + conditions.join(" AND ");
  }
  _sql.query += " ORDER BY created_at DESC LIMIT ?, ?";
  _sql.values.push(offset, pageSize);
  const characters = await sql(_sql);
  return characters;
};
const count = async (user_id, subuser_id, game_id) => {
  try {
    let _sql = {
      query: "SELECT COUNT(*) AS total FROM GameCharacters",
      values: []
    };
    const conditions = [];
    if (user_id !== void 0) {
      conditions.push("user_id = ?");
      _sql.values.push(user_id);
    }
    if (subuser_id !== void 0) {
      conditions.push("subuser_id = ?");
      _sql.values.push(subuser_id);
    }
    if (game_id !== void 0) {
      conditions.push("game_id = ?");
      _sql.values.push(game_id);
    }
    if (conditions.length > 0) {
      _sql.query += " WHERE " + conditions.join(" AND ");
    }
    const result = await sql(_sql);
    const rows = result;
    return rows[0].total;
  } catch (error) {
    console.error("Failed to count GameCharacters:", error);
    return 0;
  }
};
const normalizeExtData = (ext) => {
  if (!ext) return null;
  if (typeof ext === "object") {
    return JSON.stringify(ext);
  } else if (typeof ext === "string") {
    try {
      JSON.parse(ext);
      return ext;
    } catch {
      return JSON.stringify({ value: ext });
    }
  }
  return null;
};
const insert = async (characterData) => {
  const extData = normalizeExtData(characterData.ext);
  const result = await sql({
    query: "INSERT INTO GameCharacters (user_id, subuser_id, game_id, uuid, character_name, character_level, server_name, server_id, ext, last_login_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
    values: [
      characterData.user_id,
      characterData.subuser_id,
      characterData.game_id,
      characterData.uuid,
      characterData.character_name,
      characterData.character_level || 1,
      characterData.server_name,
      characterData.server_id || 1,
      extData,
      characterData.last_login_at || null
    ]
  });
  return result;
};
const upsertByUuid = async (characterData) => {
  try {
    const extData = normalizeExtData(characterData.ext);
    const characterLevel = characterData.character_level || 1;
    const existingResult = await sql({
      query: "SELECT id, server_id, server_name FROM GameCharacters WHERE subuser_id = ? AND uuid = ? LIMIT 1",
      values: [characterData.subuser_id, characterData.uuid]
    });
    if (existingResult.length > 0) {
      const existingId = existingResult[0].id;
      await sql({
        query: `
                    UPDATE GameCharacters 
                    SET 
                        character_name = ?, 
                        character_level = ?, 
                        ext = ?, 
                        last_login_at = NOW() 
                    WHERE id = ?
                `,
        values: [
          characterData.character_name,
          characterLevel,
          extData,
          existingId
        ]
      });
      console.log(`\u89D2\u8272\u4E0A\u62A5\u6210\u529F: \u66F4\u65B0\u4FE1\u606F uuid=${characterData.uuid}, \u670D\u52A1\u5668ID=${existingResult[0].server_id}`);
      return { isNew: false, id: existingId };
    } else {
      const result = await sql({
        query: `
                    INSERT INTO GameCharacters 
                    (user_id, subuser_id, game_id, uuid, character_name, character_level, server_name, server_id, ext, last_login_at) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
                `,
        values: [
          characterData.user_id,
          characterData.subuser_id,
          characterData.game_id,
          characterData.uuid,
          characterData.character_name,
          characterLevel,
          characterData.server_name,
          characterData.server_id || 1,
          extData
        ]
      });
      const id = result.insertId || result.lastInsertId;
      console.log(`\u89D2\u8272\u4E0A\u62A5\u6210\u529F: \u65B0\u5EFA\u89D2\u8272 uuid=${characterData.uuid}, \u670D\u52A1\u5668ID=${characterData.server_id || 1}`);
      return { isNew: true, id };
    }
  } catch (error) {
    console.error("\u89D2\u8272\u4E0A\u62A5\u5931\u8D25:", error);
    throw error;
  }
};
const update = async (id, characterData) => {
  const fields = [];
  const values = [];
  if (characterData.user_id !== void 0) {
    fields.push("user_id = ?");
    values.push(characterData.user_id);
  }
  if (characterData.subuser_id !== void 0) {
    fields.push("subuser_id = ?");
    values.push(characterData.subuser_id);
  }
  if (characterData.game_id !== void 0) {
    fields.push("game_id = ?");
    values.push(characterData.game_id);
  }
  if (characterData.uuid !== void 0) {
    fields.push("uuid = ?");
    values.push(characterData.uuid);
  }
  if (characterData.character_name !== void 0) {
    fields.push("character_name = ?");
    values.push(characterData.character_name);
  }
  if (characterData.character_level !== void 0) {
    fields.push("character_level = ?");
    values.push(characterData.character_level);
  }
  if (characterData.server_name !== void 0) {
    fields.push("server_name = ?");
    values.push(characterData.server_name);
  }
  if (characterData.server_id !== void 0) {
    fields.push("server_id = ?");
    values.push(characterData.server_id);
  }
  if (characterData.ext !== void 0) {
    const extData = typeof characterData.ext === "object" ? JSON.stringify(characterData.ext) : characterData.ext;
    fields.push("ext = ?");
    values.push(extData);
  }
  if (characterData.last_login_at !== void 0) {
    fields.push("last_login_at = ?");
    values.push(characterData.last_login_at);
  }
  if (fields.length > 0) {
    values.push(id);
    await sql({
      query: `UPDATE GameCharacters SET ${fields.join(", ")} WHERE id = ?`,
      values
    });
  }
};
const updateLastLogin = async (id, last_login_at) => {
  await sql({
    query: "UPDATE GameCharacters SET last_login_at = ? WHERE id = ?",
    values: [last_login_at, id]
  });
};
const updateLevel = async (id, character_level) => {
  await sql({
    query: "UPDATE GameCharacters SET character_level = ? WHERE id = ?",
    values: [character_level, id]
  });
};
const remove = async (id) => {
  await sql({
    query: "DELETE FROM GameCharacters WHERE id = ?",
    values: [id]
  });
};
const removeByUserId = async (user_id) => {
  await sql({
    query: "DELETE FROM GameCharacters WHERE user_id = ?",
    values: [user_id]
  });
};
const removeBySubUserId = async (subuser_id) => {
  await sql({
    query: "DELETE FROM GameCharacters WHERE subuser_id = ?",
    values: [subuser_id]
  });
};

export { count, findByGameId, findBySubUserAndGame, findBySubUserId, findByUserAndGame, findByUserId, findByUuid, insert, read, readPage, remove, removeBySubUserId, removeByUserId, update, updateLastLogin, updateLevel, upsertByUuid };
//# sourceMappingURL=gameCharacters.mjs.map
