import { s as sql, d as defineEventHandler, r as readBody, g as getQuery, c as createError, C as getRedisCluster, D as getSystemConfig, z as getSystemParam, k as setResponseStatus, E as updateApiUrl, F as verifyThirdPartyToken, h as getHeaders, G as selectGameIpByAmount, A as sdkMessages, H as config } from '../nitro/nitro.mjs';
import { g as getAdminWithPermissions } from './admin.mjs';
import * as crypto from 'crypto';
import { getByWorldId } from './gameServers.mjs';

const findByParentUserId = async (parent_user_id) => {
  const result = await sql({
    query: "SELECT * FROM SubUsers WHERE parent_user_id = ?",
    values: [parent_user_id]
  });
  return result;
};
const findByUsername = async (username) => {
  const result = await sql({
    query: "SELECT * FROM SubUsers WHERE username = ?",
    values: [username]
  });
  return result.length === 1 ? result[0] : null;
};
const findById$1 = async (id) => {
  const result = await sql({
    query: "SELECT * FROM SubUsers WHERE id = ?",
    values: [id]
  });
  return result.length === 1 ? result[0] : null;
};
const countByParentUserId = async (parent_user_id) => {
  const result = await sql({
    query: "SELECT COUNT(*) AS total FROM SubUsers WHERE parent_user_id = ?",
    values: [parent_user_id]
  });
  return result[0].total;
};
const read$1 = async () => {
  const subUsers = await sql({
    query: "SELECT * FROM SubUsers ORDER BY created_at DESC"
  });
  return subUsers;
};
const readPage$1 = async (pageIndex, pageSize = 10, parent_user_id) => {
  const offset = (pageIndex - 1) * pageSize;
  let _sql = {
    query: "SELECT * FROM SubUsers",
    values: []
  };
  if (parent_user_id) {
    _sql.query += " WHERE parent_user_id = ?";
    _sql.values.push(parent_user_id);
  }
  _sql.query += " ORDER BY created_at DESC LIMIT ?, ?";
  _sql.values.push(offset, pageSize);
  const subUsers = await sql(_sql);
  return subUsers;
};
const count$1 = async (parent_user_id) => {
  try {
    let _sql = {
      query: "SELECT COUNT(*) AS total FROM SubUsers",
      values: []
    };
    if (parent_user_id) {
      _sql.query += " WHERE parent_user_id = ?";
      _sql.values.push(parent_user_id);
    }
    const result = await sql(_sql);
    const rows = result;
    return rows[0].total;
  } catch (error) {
    console.error("Failed to count SubUsers:", error);
    return 0;
  }
};
const insert$2 = async (subUserData) => {
  const result = await sql({
    query: "INSERT INTO SubUsers (parent_user_id, username, wuid) VALUES (?, ?, ?)",
    values: [subUserData.parent_user_id, subUserData.username, subUserData.wuid || ""]
  });
  return result;
};
const update = async (id, subUserData) => {
  const fields = [];
  const values = [];
  if (subUserData.parent_user_id !== void 0) {
    fields.push("parent_user_id = ?");
    values.push(subUserData.parent_user_id);
  }
  if (subUserData.username !== void 0) {
    fields.push("username = ?");
    values.push(subUserData.username);
  }
  if (subUserData.wuid !== void 0) {
    fields.push("wuid = ?");
    values.push(subUserData.wuid);
  }
  if (fields.length > 0) {
    values.push(id);
    await sql({
      query: `UPDATE SubUsers SET ${fields.join(", ")} WHERE id = ?`,
      values
    });
  }
};
const remove$1 = async (id) => {
  await sql({
    query: "DELETE FROM SubUsers WHERE id = ?",
    values: [id]
  });
};
const removeByParentUserId = async (parent_user_id) => {
  await sql({
    query: "DELETE FROM SubUsers WHERE parent_user_id = ?",
    values: [parent_user_id]
  });
};
const updateWuidByThirdpartyUid = async (thirdparty_uid, uid) => {
  try {
    const subUserResult = await sql({
      query: "SELECT id FROM SubUsers WHERE id = ?",
      values: [thirdparty_uid]
    });
    if (subUserResult.length === 0) {
      return {
        success: false,
        message: "\u6CE8\u518C\u5931\u8D25\uFF1A\u672A\u627E\u5230\u5BF9\u5E94\u7684\u5B50\u8D26\u53F7"
      };
    }
    await sql({
      query: "UPDATE SubUsers SET wuid = ? WHERE id = ?",
      values: [uid, thirdparty_uid]
    });
    return {
      success: true,
      message: "\u6CE8\u518C\u6210\u529F"
    };
  } catch (error) {
    console.error("\u66F4\u65B0\u5B50\u7528\u6237wuid\u5931\u8D25:", error);
    return {
      success: false,
      message: "\u6CE8\u518C\u5931\u8D25\uFF1A\u7CFB\u7EDF\u9519\u8BEF"
    };
  }
};

const subUsers = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
    __proto__: null,
    count: count$1,
    countByParentUserId: countByParentUserId,
    findById: findById$1,
    findByParentUserId: findByParentUserId,
    findByUsername: findByUsername,
    insert: insert$2,
    read: read$1,
    readPage: readPage$1,
    remove: remove$1,
    removeByParentUserId: removeByParentUserId,
    update: update,
    updateWuidByThirdpartyUid: updateWuidByThirdpartyUid
}, Symbol.toStringTag, { value: 'Module' }));

const findById = async (id) => {
  const result = await sql({
    query: "SELECT * FROM Users WHERE id = ?",
    values: [id]
  });
  return result.length === 1 ? result[0] : null;
};
const findByThirdpartyUid = async (thirdparty_uid) => {
  const result = await sql({
    query: "SELECT * FROM Users WHERE thirdparty_uid = ?",
    values: [thirdparty_uid]
  });
  return result.length === 1 ? result[0] : null;
};
const upsertUserByThirdparty = async (thirdparty_uid, access_token, sign, channel) => {
  const existingUser = await findByThirdpartyUid(thirdparty_uid);
  if (existingUser) {
    await sql({
      query: "UPDATE Users SET access_token = ? WHERE thirdparty_uid = ?",
      values: [access_token, thirdparty_uid]
    });
    return { ...existingUser, access_token };
  } else {
    const result = await sql({
      query: `INSERT INTO Users 
                (username, iphone, password, channel_code, thirdparty_uid, platform_coins, status, created_at) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      values: [
        `user_${thirdparty_uid.substring(0, 8)}`,
        // 生成默认用户名
        "",
        // 默认空手机号
        "",
        // 默认空密码
        channel,
        // 渠道代码
        thirdparty_uid,
        0,
        // 默认平台币余额
        0
        // 默认状态：0=正常
      ]
    });
    console.log("upsertUserByThirdparty result:", result);
    return {
      code: 200,
      msg: "\u7528\u6237\u521B\u5EFA\u6210\u529F"
    };
  }
};
const insert$1 = async (userData) => {
  try {
    await sql({
      query: "START TRANSACTION",
      values: []
    });
    const userResult = await sql({
      query: "INSERT INTO Users (username, iphone, password, channel_code, game_code, thirdparty_uid, platform_coins, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
      values: [userData.username, userData.iphone, userData.password, userData.channel_code, userData.game_code, userData.thirdparty_uid, userData.platform_coins || 0, userData.status || 0]
    });
    const userId = userResult.insertId;
    const subUserData = {
      parent_user_id: userId,
      username: "\u5C0F\u53F71_\u5C0F\u53F71"
    };
    await insert$2(subUserData);
    await sql({
      query: "COMMIT",
      values: []
    });
    return userResult;
  } catch (error) {
    try {
      await sql({
        query: "ROLLBACK",
        values: []
      });
    } catch (rollbackError) {
      console.error("\u56DE\u6EDA\u4E8B\u52A1\u5931\u8D25:", rollbackError);
    }
    console.error("\u521B\u5EFA\u7528\u6237\u548C\u5B50\u7528\u6237\u5931\u8D25:", error);
    throw error;
  }
};
const getPlatformCoins = async (user_id) => {
  const result = await sql({
    query: "SELECT platform_coins FROM Users WHERE id = ?",
    values: [user_id]
  });
  return result.length > 0 ? parseFloat(result[0].platform_coins) : 0;
};
const updatePlatformCoinsUnified = async (userId, amount, operationType) => {
  const operationNames = {
    1: "\u6E38\u620F\u5185\u8D2D\u6263\u6B3E",
    2: "\u7B2C\u4E09\u65B9\u5145\u503C\u5230\u8D26",
    3: "\u6536\u94F6\u53F0\u5145\u503C\u5230\u8D26",
    4: "\u652F\u4ED8\u67E5\u8BE2\u8865\u5355",
    5: "\u7BA1\u7406\u5458\u53D1\u653E",
    6: "\u793C\u5305\u5931\u8D25\u9000\u6B3E",
    7: "\u793C\u5305\u5F02\u5E38\u9000\u6B3E"
  };
  console.log(`[\u5E73\u53F0\u5E01\u64CD\u4F5C] userId=${userId}, amount=${amount}, operationType=${operationType}(${operationNames[operationType]})`);
  try {
    const oldBalance = await getPlatformCoins(userId);
    if (amount < 0 && oldBalance < Math.abs(amount)) {
      console.log(`[\u5E73\u53F0\u5E01\u64CD\u4F5C\u5931\u8D25] userId=${userId}, \u4F59\u989D\u4E0D\u8DB3: \u5F53\u524D=${oldBalance}, \u9700\u8981=${Math.abs(amount)}`);
      return { success: false, message: "\u5E73\u53F0\u5E01\u4F59\u989D\u4E0D\u8DB3", oldBalance };
    }
    const newBalance = oldBalance + amount;
    await sql({
      query: "UPDATE Users SET platform_coins = ? WHERE id = ?",
      values: [newBalance, userId]
    });
    console.log(`[\u5E73\u53F0\u5E01\u64CD\u4F5C\u6210\u529F] userId=${userId}, \u65E7\u4F59\u989D=${oldBalance}, \u53D8\u52A8=${amount}, \u65B0\u4F59\u989D=${newBalance}`);
    return { success: true, newBalance, oldBalance };
  } catch (error) {
    console.error(`[\u5E73\u53F0\u5E01\u64CD\u4F5C\u5F02\u5E38] userId=${userId}, amount=${amount}, operationType=${operationType}`, error);
    return { success: false, message: "\u5E73\u53F0\u5E01\u64CD\u4F5C\u5931\u8D25" };
  }
};
const updateUserStatus = async (user_id, status) => {
  try {
    if (status !== 0 && status !== 1) {
      return { success: false, message: "\u72B6\u6001\u503C\u65E0\u6548\uFF0C\u53EA\u80FD\u662F0\uFF08\u6B63\u5E38\uFF09\u62161\uFF08\u5C01\u53F7\uFF09" };
    }
    const user = await findById(user_id);
    if (!user) {
      return { success: false, message: "\u7528\u6237\u4E0D\u5B58\u5728" };
    }
    await sql({
      query: "UPDATE Users SET status = ? WHERE id = ?",
      values: [status, user_id]
    });
    return {
      success: true,
      message: status === 1 ? "\u7528\u6237\u5DF2\u5C01\u53F7" : "\u7528\u6237\u5DF2\u89E3\u5C01"
    };
  } catch (error) {
    console.error("\u66F4\u65B0\u7528\u6237\u72B6\u6001\u5931\u8D25:", error);
    return { success: false, message: "\u66F4\u65B0\u7528\u6237\u72B6\u6001\u5931\u8D25" };
  }
};

const detailByTransId = async (transaction_id) => {
  const result = await sql({
    query: "SELECT * FROM PaymentRecords WHERE transaction_id = ?",
    values: [transaction_id]
  });
  return result.length === 1 ? result[0] : null;
};
const detailByMchOrderId = async (mch_order_id) => {
  const result = await sql({
    query: "SELECT * FROM PaymentRecords WHERE mch_order_id = ?",
    values: [mch_order_id]
  });
  return result.length === 1 ? result[0] : null;
};
const detailByUserId = async (user_id) => {
  const paymentdata = await sql({
    query: "SELECT * FROM PaymentRecords WHERE user_id = ?",
    values: [user_id]
  });
  return paymentdata;
};
const readPage = async (pageIndex, permissions, tranId, start_time, end_time, userid, mch_order_id, payment_status) => {
  const pageSize = 10;
  const offset = (pageIndex - 1) * pageSize;
  let _sql = {
    query: "SELECT pr.* FROM PaymentRecords pr ",
    values: []
  };
  let where = false;
  if (permissions && permissions.channel_codes && permissions.channel_codes.length > 0) {
    if (!where) {
      _sql.query += " WHERE ";
      where = true;
    }
    _sql.query += " pr.channel_code IN (" + permissions.channel_codes.map(() => "?").join(",") + ")";
    permissions.channel_codes.forEach((code) => _sql.values.push(code));
  }
  if (tranId) {
    if (!where) {
      _sql.query += " where ";
      where = true;
    } else {
      _sql.query += " and ";
    }
    _sql.query += "pr.transaction_id = ?";
    _sql.values.push(tranId);
  }
  if (mch_order_id) {
    if (!where) {
      _sql.query += " where ";
      where = true;
    } else {
      _sql.query += " and ";
    }
    _sql.query += "pr.mch_order_id = ?";
    _sql.values.push(mch_order_id);
  }
  if (userid) {
    if (!where) {
      _sql.query += " where ";
      where = true;
    } else {
      _sql.query += " and ";
    }
    _sql.query += "pr.wuid = ?";
    _sql.values.push(userid);
  }
  if (payment_status) {
    if (!where) {
      _sql.query += " where ";
      where = true;
    } else {
      _sql.query += " and ";
    }
    _sql.query += "pr.payment_status = ?";
    _sql.values.push(payment_status);
  }
  if (start_time && end_time) {
    if (!where) {
      _sql.query += " where ";
      where = true;
    } else {
      _sql.query += " and ";
    }
    _sql.query += "timestamp(pr.created_at) between ? and ?";
    _sql.values.push(start_time);
    _sql.values.push(end_time);
  }
  _sql.query += " ORDER BY pr.created_at DESC";
  _sql.query += " LIMIT ?, ?";
  _sql.values.push(offset);
  _sql.values.push(pageSize);
  const paymentdata = await sql(_sql);
  return paymentdata;
};
const count = async (permissions, tranId, start_time, end_time, userid, mch_order_id, payment_status) => {
  try {
    let _sql = {
      query: "SELECT COUNT(*) AS total FROM PaymentRecords pr",
      values: []
    };
    let where = false;
    if (permissions && permissions.channel_codes && permissions.channel_codes.length > 0) {
      if (!where) {
        _sql.query += " WHERE ";
        where = true;
      }
      _sql.query += " pr.channel_code IN (" + permissions.channel_codes.map(() => "?").join(",") + ")";
      permissions.channel_codes.forEach((code) => _sql.values.push(code));
    }
    if (tranId) {
      if (!where) {
        _sql.query += " where ";
        where = true;
      } else {
        _sql.query += " and ";
      }
      _sql.query += "pr.transaction_id = ?";
      _sql.values.push(tranId);
    }
    if (mch_order_id) {
      if (!where) {
        _sql.query += " where ";
        where = true;
      } else {
        _sql.query += " and ";
      }
      _sql.query += "pr.mch_order_id = ?";
      _sql.values.push(mch_order_id);
    }
    if (userid) {
      if (!where) {
        _sql.query += " where ";
        where = true;
      } else {
        _sql.query += " and ";
      }
      _sql.query += "pr.wuid = ?";
      _sql.values.push(userid);
    }
    if (payment_status) {
      if (!where) {
        _sql.query += " where ";
        where = true;
      } else {
        _sql.query += " and ";
      }
      _sql.query += "pr.payment_status = ?";
      _sql.values.push(payment_status);
    }
    if (start_time && end_time) {
      if (!where) {
        _sql.query += " where ";
        where = true;
      } else {
        _sql.query += " and ";
      }
      _sql.query += "timestamp(pr.created_at) between ? and ?";
      _sql.values.push(start_time);
      _sql.values.push(end_time);
    }
    const result = await sql(_sql);
    const rows = result;
    return rows[0].total;
  } catch (error) {
    console.error("Failed to count PaymentRecords:", error);
    return 0;
  }
};
const allAmount = async (permissions, tranId, start_time, end_time, userid, mch_order_id, state, payment_status) => {
  try {
    let _sql = {
      query: "SELECT sum(pr.amount) AS total FROM PaymentRecords pr",
      values: []
    };
    let where = false;
    if (permissions && permissions.channel_codes && permissions.channel_codes.length > 0) {
      if (!where) {
        _sql.query += " WHERE ";
        where = true;
      }
      _sql.query += " pr.channel_code IN (" + permissions.channel_codes.map(() => "?").join(",") + ")";
      permissions.channel_codes.forEach((code) => _sql.values.push(code));
    }
    if (tranId) {
      if (!where) {
        _sql.query += " where ";
        where = true;
      } else {
        _sql.query += " and ";
      }
      _sql.query += "pr.transaction_id = ?";
      _sql.values.push(tranId);
    }
    if (mch_order_id) {
      if (!where) {
        _sql.query += " where ";
        where = true;
      } else {
        _sql.query += " and ";
      }
      _sql.query += "pr.mch_order_id = ?";
      _sql.values.push(mch_order_id);
    }
    if (userid) {
      if (!where) {
        _sql.query += " where ";
        where = true;
      } else {
        _sql.query += " and ";
      }
      _sql.query += "pr.wuid = ?";
      _sql.values.push(userid);
    }
    if (payment_status) {
      if (!where) {
        _sql.query += " where ";
        where = true;
      } else {
        _sql.query += " and ";
      }
      _sql.query += "pr.payment_status = ?";
      _sql.values.push(payment_status);
    }
    if (start_time && end_time) {
      if (!where) {
        _sql.query += " where ";
        where = true;
      } else {
        _sql.query += " and ";
      }
      _sql.query += "timestamp(pr.created_at) between ? and ?";
      _sql.values.push(start_time);
      _sql.values.push(end_time);
    }
    if (payment_status) {
      if (!where) {
        _sql.query += " where ";
        where = true;
      } else {
        _sql.query += " and ";
      }
      _sql.query += "pr.payment_status = ?";
      _sql.values.push(payment_status);
    }
    if (state && state > 0) {
      if (!where) {
        _sql.query += " where ";
        where = true;
      } else {
        _sql.query += " and ";
      }
      _sql.query += "pr.payment_status = " + state;
    }
    const result = await sql(_sql);
    const rows = result;
    return rows[0].total;
  } catch (error) {
    console.error("Failed to count PaymentRecords:", error);
    return 0;
  }
};
const updateState = async (transaction_id, data) => {
  await sql({
    query: "UPDATE PaymentRecords SET payment_status = ? WHERE transaction_id = ?",
    values: [data.payment_status, transaction_id]
  });
};
const updateOrderCall = async (transaction_id, data) => {
  var _a, _b, _c;
  const existing = await sql({
    query: "SELECT mch_order_id, payment_status FROM PaymentRecords WHERE transaction_id = ?",
    values: [transaction_id]
  });
  const current = ((_a = existing[0]) == null ? void 0 : _a.mch_order_id) || "";
  const status = Number((_c = (_b = existing[0]) == null ? void 0 : _b.payment_status) != null ? _c : 0);
  const looksLocal = (v) => !v || v.startsWith("zfb_") || v.startsWith("wx_") || v.startsWith("ptb_") || v.startsWith("kf_");
  const nextMchId = data.mch_order_id || "";
  const allowOverwrite = status <= 1 || looksLocal(current) || current === "" || current === nextMchId;
  const fields = ["payment_status = ?"];
  const values = [2];
  if (allowOverwrite) {
    fields.push("mch_order_id = ?");
    values.push(nextMchId);
  }
  values.push(transaction_id);
  const _sql = {
    query: `UPDATE PaymentRecords SET ${fields.join(", ")} WHERE transaction_id = ?`,
    values
  };
  await sql(_sql);
};
const getUserOrders = async (thirdparty_uid, status) => {
  let query = "SELECT * FROM PaymentRecords WHERE user_id = ?";
  const values = [thirdparty_uid];
  if (status !== void 0) {
    query += " AND payment_status = ?";
    values.push(status);
  }
  query += " ORDER BY created_at DESC";
  const result = await sql({
    query,
    values
  });
  return result;
};
const updateOrderStatus = async (transaction_id, status, notify_at, callback_at, orderid) => {
  var _a, _b, _c;
  let query = "UPDATE PaymentRecords SET payment_status = ?";
  const values = [status];
  if (orderid) {
    const existing = await sql({
      query: "SELECT mch_order_id, payment_status FROM PaymentRecords WHERE transaction_id = ?",
      values: [transaction_id]
    });
    const current = ((_a = existing[0]) == null ? void 0 : _a.mch_order_id) || "";
    const statusNow = Number((_c = (_b = existing[0]) == null ? void 0 : _b.payment_status) != null ? _c : 0);
    const looksLocal = (v) => !v || v.startsWith("zfb_") || v.startsWith("wx_") || v.startsWith("ptb_") || v.startsWith("kf_");
    const allowOverwrite = statusNow <= 1 || looksLocal(current) || current === orderid;
    if (allowOverwrite) {
      query += ", mch_order_id = ?";
      values.push(orderid);
    }
  }
  if (notify_at !== null && notify_at !== void 0) {
    query += ", notify_at = ?";
    values.push(notify_at);
  }
  if (callback_at !== null && callback_at !== void 0) {
    query += ", callback_at = ?";
    values.push(callback_at);
  }
  query += " WHERE transaction_id = ?";
  values.push(transaction_id);
  await sql({
    query,
    values
  });
};
const getOrderStatus = async (transaction_id) => {
  try {
    const result = await sql({
      query: "SELECT payment_status FROM PaymentRecords WHERE transaction_id = ?",
      values: [transaction_id]
    });
    if (result && result.length > 0) {
      return result[0].payment_status;
    } else {
      return 0;
    }
  } catch (error) {
    console.error("Failed to Get OrderStatus", error);
    return 0;
  }
};
const updateOrderErrorMsg = async (transaction_id, error_msg) => {
  await sql({
    query: "UPDATE PaymentRecords SET msg=? WHERE transaction_id = ?",
    values: [error_msg, transaction_id]
  });
};
const remove = async (id) => {
  await sql({
    query: "DELETE FROM PaymentRecords WHERE id = ?",
    values: [id]
  });
};
const insert = async (paymentData) => {
  const result = await sql({
    query: "INSERT INTO PaymentRecords (user_id, sub_user_id, role_id, transaction_id, wuid, payment_way, payment_id, world_id, product_name, product_des, ip, amount, mch_order_id, msg, server_url, device, channel_code, game_code, payment_status, ptb_before, ptb_change, ptb_after) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
    values: [
      paymentData.user_id,
      paymentData.sub_user_id,
      // 保持null值，不转换为0
      paymentData.role_id || "",
      paymentData.transaction_id,
      paymentData.wuid,
      paymentData.payment_way,
      paymentData.payment_id || 0,
      paymentData.world_id || 1,
      paymentData.product_name,
      paymentData.product_des || "",
      paymentData.ip || "",
      paymentData.amount,
      paymentData.mch_order_id || "",
      paymentData.msg || "",
      paymentData.server_url || "",
      paymentData.device || "",
      paymentData.channel_code || "",
      paymentData.game_code || "",
      paymentData.payment_status || 0,
      paymentData.ptb_before || 0,
      paymentData.ptb_change || 0,
      paymentData.ptb_after || 0
    ]
  });
  return result;
};
const updateByTransactionId = async (transaction_id, updateData) => {
  var _a, _b, _c;
  let actualTransactionId = transaction_id;
  if (typeof transaction_id === "object" && transaction_id !== null && "attachInfo" in transaction_id) {
    actualTransactionId = transaction_id.attachInfo;
  }
  const fields = [];
  const values = [];
  if (updateData.user_id !== void 0) {
    fields.push("user_id = ?");
    values.push(updateData.user_id);
  }
  if (updateData.sub_user_id !== void 0) {
    fields.push("sub_user_id = ?");
    values.push(updateData.sub_user_id);
  }
  if (updateData.role_id !== void 0) {
    fields.push("role_id = ?");
    values.push(updateData.role_id);
  }
  if (updateData.wuid !== void 0) {
    fields.push("wuid = ?");
    values.push(updateData.wuid);
  }
  if (updateData.payment_way !== void 0) {
    fields.push("payment_way = ?");
    values.push(updateData.payment_way);
  }
  if (updateData.payment_id !== void 0) {
    fields.push("payment_id = ?");
    values.push(updateData.payment_id);
  }
  if (updateData.world_id !== void 0) {
    fields.push("world_id = ?");
    values.push(updateData.world_id);
  }
  if (updateData.product_name !== void 0) {
    fields.push("product_name = ?");
    values.push(updateData.product_name);
  }
  if (updateData.product_des !== void 0) {
    fields.push("product_des = ?");
    values.push(updateData.product_des);
  }
  if (updateData.ip !== void 0) {
    fields.push("ip = ?");
    values.push(updateData.ip);
  }
  if (updateData.amount !== void 0) {
    fields.push("amount = ?");
    values.push(updateData.amount);
  }
  if (updateData.ptb_before !== void 0) {
    fields.push("ptb_before = ?");
    values.push(updateData.ptb_before);
  }
  if (updateData.ptb_change !== void 0) {
    fields.push("ptb_change = ?");
    values.push(updateData.ptb_change);
  }
  if (updateData.ptb_after !== void 0) {
    fields.push("ptb_after = ?");
    values.push(updateData.ptb_after);
  }
  if (updateData.mch_order_id !== void 0) {
    const existing = await sql({
      query: "SELECT mch_order_id, payment_status FROM PaymentRecords WHERE transaction_id = ?",
      values: [actualTransactionId]
    });
    const current = ((_a = existing[0]) == null ? void 0 : _a.mch_order_id) || "";
    const status = Number((_c = (_b = existing[0]) == null ? void 0 : _b.payment_status) != null ? _c : 0);
    const looksLocal = (v) => !v || v.startsWith("zfb_") || v.startsWith("wx_") || v.startsWith("ptb_") || v.startsWith("kf_");
    if (status <= 1 || looksLocal(current) || current === updateData.mch_order_id) {
      fields.push("mch_order_id = ?");
      values.push(updateData.mch_order_id);
    }
  }
  if (updateData.msg !== void 0) {
    fields.push("msg = ?");
    values.push(updateData.msg);
  }
  if (updateData.server_url !== void 0) {
    fields.push("server_url = ?");
    values.push(updateData.server_url);
  }
  if (updateData.device !== void 0) {
    fields.push("device = ?");
    values.push(updateData.device);
  }
  if (updateData.channel_code !== void 0) {
    fields.push("channel_code = ?");
    values.push(updateData.channel_code);
  }
  if (updateData.game_code !== void 0) {
    fields.push("game_code = ?");
    values.push(updateData.game_code);
  }
  if (updateData.payment_status !== void 0) {
    fields.push("payment_status = ?");
    values.push(updateData.payment_status);
  }
  if (updateData.notify_at !== void 0) {
    fields.push("notify_at = ?");
    values.push(updateData.notify_at);
  }
  if (updateData.callback_at !== void 0) {
    fields.push("callback_at = ?");
    values.push(updateData.callback_at);
  }
  if (fields.length === 0) {
    return;
  }
  values.push(actualTransactionId);
  await sql({
    query: `UPDATE PaymentRecords SET ${fields.join(", ")} WHERE transaction_id = ?`,
    values
  });
};

const payment = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
    __proto__: null,
    allAmount: allAmount,
    count: count,
    detailByMchOrderId: detailByMchOrderId,
    detailByTransId: detailByTransId,
    detailByUserId: detailByUserId,
    getOrderStatus: getOrderStatus,
    getUserOrders: getUserOrders,
    insert: insert,
    readPage: readPage,
    remove: remove,
    updateByTransactionId: updateByTransactionId,
    updateOrderCall: updateOrderCall,
    updateOrderErrorMsg: updateOrderErrorMsg,
    updateOrderStatus: updateOrderStatus,
    updateState: updateState
}, Symbol.toStringTag, { value: 'Module' }));

const read = async () => {
  const result = await sql({
    query: "SELECT * FROM PaymentSettings"
  });
  return result;
};
const GetOpenPaySetting = async () => {
  const result = await sql({
    query: "SELECT * FROM PaymentSettings where isClose = 1"
  });
  return result;
};

function getCurrentFormattedTime() {
  const date = /* @__PURE__ */ new Date();
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  const hours = String(date.getHours()).padStart(2, "0");
  const minutes = String(date.getMinutes()).padStart(2, "0");
  const seconds = String(date.getSeconds()).padStart(2, "0");
  return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
}
const checkOrder = defineEventHandler(async (event) => {
  var _a, _b;
  try {
    const tranId = (_b = (_a = event.context.params) == null ? void 0 : _a.tranId) != null ? _b : "";
    var _status = await getOrderStatus(tranId);
    if (_status == 3) {
      const currentTime = getCurrentFormattedTime();
      await updateOrderStatus(tranId, 3, null, currentTime);
    }
    return _status;
  } catch (e) {
    return -1;
  }
});
const paymentNewReps = async (evt) => {
  var _a, _b;
  try {
    const body = await readBody(evt);
    console.log("paymentNewReps \u8BF7\u6C42:", body);
    if (body.transactionId) {
      const existingRecord = await detailByTransId(body.transactionId);
      if (existingRecord) {
        let updateUserChannelCode = "";
        let updateUserGameCode = "";
        if (existingRecord.user_id) {
          const userResult = await sql({
            query: "SELECT channel_code, game_code FROM Users WHERE id = ?",
            values: [existingRecord.user_id]
          });
          if (userResult.length > 0) {
            updateUserChannelCode = userResult[0].channel_code || "";
            updateUserGameCode = userResult[0].game_code || "";
            console.log("\u66F4\u65B0\u65F6\u83B7\u53D6\u7528\u6237\u6E20\u9053\u4FE1\u606F:", {
              user_id: existingRecord.user_id,
              updateUserChannelCode,
              updateUserGameCode
            });
          }
        }
        const updatepayrecord = {
          role_id: body.wuid,
          wuid: body.uid,
          //   payment_way: updatePaymentWay, // 更新支付方式
          //   payment_id: body.iid,
          product_name: body.descname,
          ip: body.ip,
          server_url: body.server_url,
          channel_code: updateUserChannelCode,
          // 设置渠道代码
          game_code: updateUserGameCode,
          // 设置游戏代码
          payment_status: 1
        };
        await updateByTransactionId(body.transactionId, updatepayrecord);
        console.log("\u652F\u4ED8\u8BB0\u5F55\u5DF2\u66F4\u65B0:", body.transactionId);
        return {
          code: 200,
          message: "update success"
        };
      }
    }
    const newTransactionId = body.transactionId || `tx_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    let realUserId = null;
    let realSubUserId = null;
    let userChannelCode = "";
    let userGameCode = "";
    if (body.uid) {
      const subUserResult = await sql({
        query: "SELECT id, parent_user_id FROM SubUsers WHERE wuid = ?",
        values: [body.uid]
      });
      if (subUserResult.length > 0) {
        realUserId = subUserResult[0].parent_user_id;
        realSubUserId = subUserResult[0].id;
        console.log("\u627E\u5230\u5B50\u7528\u6237:", { realUserId, realSubUserId, uid: body.uid });
        if (realUserId) {
          const userResult = await sql({
            query: "SELECT channel_code, game_code FROM Users WHERE id = ?",
            values: [realUserId]
          });
          if (userResult.length > 0) {
            userChannelCode = userResult[0].channel_code || "";
            userGameCode = userResult[0].game_code || "";
            console.log("\u83B7\u53D6\u7528\u6237\u6E20\u9053\u4FE1\u606F:", { realUserId, userChannelCode, userGameCode });
          } else {
            console.log("\u672A\u627E\u5230\u7528\u6237\u4FE1\u606F:", realUserId);
          }
        }
      } else {
        console.log("\u672A\u627E\u5230\u5B50\u7528\u6237:", body.uid);
      }
    }
    let paymentWay = "\u672A\u77E5";
    const paymentId = body.iid || 0;
    if (paymentId === 1) {
      paymentWay = "\u5E73\u53F0\u5E01";
    } else if (paymentId === 2) {
      paymentWay = "\u652F\u4ED8\u5B9D";
    } else if (paymentId === 3) {
      paymentWay = "\u5FAE\u4FE1";
    } else if (body.payment_method) {
      const methodMap = {
        "ptb": "\u5E73\u53F0\u5E01",
        "zfb": "\u652F\u4ED8\u5B9D",
        "wx": "\u5FAE\u4FE1",
        "kf": "\u5BA2\u670D"
      };
      paymentWay = methodMap[body.payment_method] || body.payment_method;
    } else {
      console.warn("[\u652F\u4ED8\u65B9\u5F0F\u5224\u65AD] \u65E0\u6CD5\u786E\u5B9A\u652F\u4ED8\u65B9\u5F0F:", {
        paymentId,
        hasPaymentMethod: !!body.payment_method,
        paymentMethodValue: body.payment_method
      });
    }
    console.log("\u{1F4DD} [\u652F\u4ED8\u65B9\u5F0F\u5224\u65AD] \u6700\u7EC8\u786E\u5B9A\u7684\u652F\u4ED8\u65B9\u5F0F:", paymentWay);
    const requestedAmount = parseFloat(String(body.price || 0));
    const ABSOLUTE_MAX = 1e5;
    if (isNaN(requestedAmount) || requestedAmount <= 0) {
      throw createError({ status: 400, message: "\u91D1\u989D\u65E0\u6548" });
    }
    if (requestedAmount > ABSOLUTE_MAX) {
      console.error(`\u{1F6A8} [\u91D1\u989D\u5F02\u5E38] \u8BF7\u6C42\u91D1\u989D ${requestedAmount} \u8D85\u8FC7\u7EDD\u5BF9\u4E0A\u9650 ${ABSOLUTE_MAX}`, { uid: body.uid, ip: body.ip });
      throw createError({ status: 400, message: `\u5145\u503C\u91D1\u989D\u4E0D\u5F97\u8D85\u8FC7 ${ABSOLUTE_MAX}` });
    }
    if (body.payment_method && body.payment_method !== "kf") {
      try {
        const settingsList = await read();
        const setting = settingsList.find(
          (s) => s.payment_method === body.payment_method || s.payment_channel === body.payment_method
        );
        if (setting) {
          const minPrice = Number((_a = setting.MinPrice) != null ? _a : 0);
          const maxPrice = Number((_b = setting.MaxPrice) != null ? _b : ABSOLUTE_MAX);
          if (requestedAmount < minPrice) {
            console.warn(`\u26A0\uFE0F [\u91D1\u989D\u8FC7\u5C0F] amount=${requestedAmount} < MinPrice=${minPrice}`, { method: body.payment_method });
            throw createError({ status: 400, message: `\u6700\u5C0F\u5145\u503C\u91D1\u989D\u4E3A ${minPrice}` });
          }
          if (maxPrice > 0 && requestedAmount > maxPrice) {
            console.error(`\u{1F6A8} [\u91D1\u989D\u8D85\u9650] amount=${requestedAmount} > MaxPrice=${maxPrice}  uid=${body.uid} ip=${body.ip}`, { method: body.payment_method });
            throw createError({ status: 400, message: `\u6700\u5927\u5145\u503C\u91D1\u989D\u4E3A ${maxPrice}` });
          }
          console.log(`\u2705 [\u91D1\u989D\u6821\u9A8C\u901A\u8FC7] amount=${requestedAmount} \u5728 [${minPrice}, ${maxPrice}] \u8303\u56F4\u5185`);
        } else {
          console.warn(`\u26A0\uFE0F [\u91D1\u989D\u6821\u9A8C] \u672A\u627E\u5230\u652F\u4ED8\u65B9\u5F0F ${body.payment_method} \u7684\u914D\u7F6E\uFF0C\u8DF3\u8FC7 MinPrice/MaxPrice \u6821\u9A8C`);
        }
      } catch (e) {
        if (e.statusCode === 400) throw e;
        console.error("\u26A0\uFE0F [\u91D1\u989D\u6821\u9A8C] \u8BFB\u53D6 PaymentSettings \u5931\u8D25\uFF0C\u8DF3\u8FC7\u6821\u9A8C:", e.message);
      }
    }
    const { channelId: sdkChannelId } = await selectProviderBySystemParam(body.price || 0, body.payment_method, newTransactionId);
    const insertRecord = {
      user_id: realUserId,
      sub_user_id: realSubUserId,
      role_id: body.wuid || "",
      transaction_id: newTransactionId,
      wuid: body.uid || "",
      payment_way: paymentWay,
      // 使用正确的支付方式
      payment_id: parseInt(sdkChannelId) || body.iid || 0,
      // 保存渠道ID到payment_id
      world_id: body.worldId || 1,
      product_name: body.descname || "",
      product_des: "",
      ip: body.ip || "",
      amount: requestedAmount,
      // 使用校验后的金额，不直接用 body.price
      mch_order_id: newTransactionId,
      //不能为空 数据库会报错
      msg: "",
      server_url: body.server_url || "",
      device: "",
      channel_code: userChannelCode,
      // 使用从用户表获取的渠道代码
      game_code: userGameCode,
      // 使用从用户表获取的游戏代码
      payment_status: 0
    };
    await insert(insertRecord);
    console.log(`\u652F\u4ED8\u8BB0\u5F55\u5DF2\u63D2\u5165: ${newTransactionId}, \u6E20\u9053ID: ${sdkChannelId}`);
    return {
      code: 200,
      message: "insert success",
      transaction_id: newTransactionId
    };
  } catch (e) {
    throw createError({
      status: 500,
      message: e.message
    });
  }
};
async function notifyGameServer(transactionId, wuid, serverUrl, gameServerUrl, worldId) {
  try {
    let port = "";
    let preferredBaseUrl = "";
    if (typeof serverUrl === "string" && (serverUrl.startsWith("http://") || serverUrl.startsWith("https://"))) {
      try {
        const urlObj = new URL(serverUrl);
        port = urlObj.port || "";
      } catch (error) {
        console.error("URL \u89E3\u6790\u5931\u8D25:", serverUrl, error);
      }
    } else if (serverUrl) {
      port = String(serverUrl || "");
    }
    const requestData = {
      transactionId,
      uid: wuid,
      port
    };
    const systemConfig = await getSystemConfig();
    if (worldId && Number(worldId) > 0) {
      try {
        const serverCfg = await getByWorldId(Number(worldId));
        if (serverCfg && serverCfg.webhost) {
          const base = serverCfg.webhost.replace(/\/$/, "");
          preferredBaseUrl = `${base}/update_pay_status`;
          try {
            const u = new URL(serverCfg.webhost);
            if (!port) port = u.port || "";
          } catch {
          }
        }
      } catch (e) {
        console.warn("\u6309 worldId \u67E5\u8BE2 GameServers \u5931\u8D25\uFF0C\u9000\u56DE\u9ED8\u8BA4:", e);
      }
    }
    const targetGameServerUrl = preferredBaseUrl || gameServerUrl || systemConfig.notify_game_url || "http://160.202.240.19:8888/update_pay_status";
    console.log("\u51C6\u5907\u8C03\u7528\u6E38\u620F\u670D\u63A5\u53E3:", requestData, "\u5730\u5740:", targetGameServerUrl);
    const response = await fetch(targetGameServerUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(requestData),
      signal: AbortSignal.timeout(3e4)
    });
    if (response.ok) {
      console.log("\u6E38\u620F\u670D\u901A\u77E5\u6210\u529F:", transactionId);
      return {
        success: true,
        message: "\u6E38\u620F\u670D\u901A\u77E5\u6210\u529F"
      };
    } else {
      console.error("\u6E38\u620F\u670D\u901A\u77E5\u5931\u8D25:", response.status, response.statusText);
      return {
        success: false,
        message: `\u6E38\u620F\u670D\u8FD4\u56DE\u9519\u8BEF: ${response.status}`
      };
    }
  } catch (fetchError) {
    console.error("\u6E38\u620F\u670D\u901A\u77E5\u5F02\u5E38:", fetchError);
    if (fetchError.name === "AbortError") {
      return {
        success: false,
        message: "\u6E38\u620F\u670D\u54CD\u5E94\u8D85\u65F6"
      };
    } else {
      return {
        success: false,
        message: `\u6E38\u620F\u670D\u8FDE\u63A5\u5931\u8D25: ${fetchError.message}`
      };
    }
  }
}
async function generateUserLoginUrl(userId, redirectPath = "/user/home") {
  try {
    const userResult = await sql({
      query: "SELECT id FROM Users WHERE id = ?",
      values: [userId]
    });
    if (userResult.length === 0) {
      console.error("\u7528\u6237\u4E0D\u5B58\u5728:", userId);
      return null;
    }
    const token = crypto.randomBytes(32).toString("hex");
    try {
      const redis = getRedisCluster();
      const ok = await redis.set(`autologin:${token}`, String(userId), "EX", 60, "NX");
      if (!ok) {
        console.error("autologin token \u5199 Redis \u5931\u8D25\uFF1ANX \u51B2\u7A81", { userId });
        return null;
      }
    } catch (redisErr) {
      console.error("autologin token \u5199 Redis \u5F02\u5E38:", redisErr);
      return null;
    }
    const systemConfig = await getSystemConfig();
    const baseLoginUrl = systemConfig.user_login_url;
    const loginParams = new URLSearchParams({ t: token, auto_login: "true", redirect: redirectPath });
    return `${baseLoginUrl}?${loginParams.toString()}`;
  } catch (error) {
    console.error("\u751F\u6210\u7528\u6237\u767B\u5F55\u94FE\u63A5\u5931\u8D25:", error);
    return null;
  }
}
const getPaymentByTransId = defineEventHandler(async (event) => {
  var _a, _b;
  const transaction_id = (_b = (_a = event.context.params) == null ? void 0 : _a.transaction_id) != null ? _b : "";
  try {
    const result = await detailByTransId(transaction_id);
    return {
      code: result === null ? 404 : 200,
      data: result
    };
  } catch (e) {
    throw createError({
      status: 500,
      message: e.message
    });
  }
});
const getGameOrder = defineEventHandler(async (event) => {
  const query = getQuery(event);
  let oid = query.oid || "";
  if (!oid && event.node.req.method === "POST") {
    try {
      const body = await readBody(event);
      oid = body.oid || "";
    } catch (error) {
      console.error("\u8BFB\u53D6POST\u8BF7\u6C42\u4F53\u5931\u8D25:", error);
    }
  }
  try {
    if (!oid) {
      return {
        code: -1,
        msg: "\u7F3A\u5C11\u8BA2\u5355\u53F7\u53C2\u6570",
        amount: "0"
      };
    }
    const result = await detailByMchOrderId(oid);
    if (!result) {
      return {
        code: 0,
        msg: "\u8BA2\u5355\u4E0D\u5B58\u5728:" + oid,
        amount: "0"
      };
    }
    let code = 0;
    let msg = "\u8BA2\u5355\u672A\u77E5\u72B6\u6001";
    switch (result.payment_status) {
      case 0:
        code = 0;
        msg = "\u8BA2\u5355\u672A\u5B8C\u6210";
        break;
      case 1:
        code = 0;
        msg = "\u8BA2\u5355\u5904\u7406\u4E2D";
        break;
      case 2:
        code = 0;
        msg = "\u8BA2\u5355\u5931\u8D25";
        break;
      case 3:
      case 4:
        code = 1;
        msg = "\u8BA2\u5355\u6210\u529F";
        break;
      default:
        code = 0;
        msg = "\u8BA2\u5355\u72B6\u6001\u5F02\u5E38";
        break;
    }
    return {
      code,
      msg,
      amount: (result.amount || 0).toString()
    };
  } catch (e) {
    console.error("SDK\u6E38\u620F\u8BA2\u5355\u67E5\u8BE2\u5931\u8D25:", e);
    return {
      code: -1,
      msg: "\u7CFB\u7EDF\u9519\u8BEF",
      amount: "0"
    };
  }
});
const getPaymentByUserID = defineEventHandler(async (event) => {
  var _a, _b;
  var user_id = (_b = (_a = event.context.params) == null ? void 0 : _a.user_id) != null ? _b : 0;
  try {
    const result = await detailByUserId(user_id);
    return {
      code: result === null ? 404 : 200,
      data: result
    };
  } catch (e) {
    throw createError({
      status: 500,
      message: e.message
    });
  }
});
const doPayment = async (evt) => {
  var _a;
  try {
    const { getSystemParam: getSystemParam2 } = await import('../nitro/nitro.mjs').then(function (n) { return n.ai; });
    const opAdminUrl = await getSystemParam2("op_admin_url", "https://pay.kccyei.cn");
    const targetUrl = `${opAdminUrl.replace(/\/+$/, "")}/sdkapi/Unipay/pay`;
    let body = {};
    const method = ((_a = evt.node.req.method) == null ? void 0 : _a.toUpperCase()) || "GET";
    if (method !== "GET") {
      try {
        body = await readBody(evt);
      } catch {
        body = {};
      }
    }
    const query = getQuery(evt) || {};
    const params = { ...query, ...body && typeof body === "object" ? body : {} };
    delete params.sign;
    delete params.__signed;
    const { computeSdkSign } = await import('../nitro/nitro.mjs').then(function (n) { return n.aj; });
    const sdkSecret = await getSystemParam2("sdk_sign_secret", "AQE!@#a123JNJKO$@#fg1");
    params.sign = computeSdkSign(params, sdkSecret);
    const debugFields = Object.keys(params).filter((k) => k !== "sign" && k !== "__signed").sort();
    console.log(`[PaymentProxy] re-sign=${params.sign}, fields=[${debugFields.join(",")}]`);
    console.log(`[PaymentProxy] -> ${targetUrl}`);
    const resp = await fetch(targetUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-forwarded-for": evt.node.req.headers["x-forwarded-for"] || "",
        "x-real-ip": evt.node.req.headers["x-real-ip"] || "",
        "user-agent": evt.node.req.headers["user-agent"] || ""
      },
      body: JSON.stringify(params)
    });
    const text = await resp.text();
    if (!text || !text.trim()) {
      console.error("[PaymentProxy] op-admin empty response");
      return { code: -1, msg: "payment service unavailable", data: null };
    }
    try {
      const result = JSON.parse(text);
      console.log(`[PaymentProxy] <- code=${result.code}`);
      return result;
    } catch {
      console.error("[PaymentProxy] non-JSON response:", text.slice(0, 200));
      return { code: -1, msg: "payment service error", data: null };
    }
  } catch (err) {
    console.error("[PaymentProxy] error:", (err == null ? void 0 : err.message) || err);
    return { code: -1, msg: "payment service unreachable", data: null };
  }
};
const handleThirdPartyNotify = async (evt) => {
  var _a;
  const startTime = Date.now();
  const requestId = `notify_${startTime}_${Math.random().toString(36).substr(2, 9)}`;
  try {
    console.log(`[${requestId}] === \u5F00\u59CB\u5904\u7406\u7B2C\u4E09\u65B9\u652F\u4ED8\u56DE\u8C03 ===`);
    console.log(`[${requestId}] \u65F6\u95F4: ${(/* @__PURE__ */ new Date()).toISOString()}`);
    console.log(`[${requestId}] \u8BF7\u6C42\u65B9\u6CD5: ${evt.node.req.method}`);
    console.log(`[${requestId}] \u8BF7\u6C42URL: ${evt.node.req.url}`);
    console.log(`[${requestId}] \u8BF7\u6C42\u5934:`, evt.node.req.headers);
    const query = getQuery(evt);
    const requestMethod = (_a = evt.node.req.method) == null ? void 0 : _a.toUpperCase();
    console.log(`[${requestId}] GET\u67E5\u8BE2\u53C2\u6570:`, query);
    let body = {};
    if (requestMethod === "POST") {
      try {
        body = await readBody(evt);
        console.log(`[${requestId}] POST\u8BF7\u6C42\u4F53\u8BFB\u53D6\u6210\u529F:`, body);
      } catch (e) {
        console.log(`[${requestId}] POST body\u8BFB\u53D6\u5931\u8D25\uFF0C\u56DE\u9000\u5230GET\u53C2\u6570`);
        body = query;
      }
    } else {
      console.log(`[${requestId}] \u68C0\u6D4B\u5230GET\u8BF7\u6C42\uFF0C\u4F7F\u7528query\u53C2\u6570`);
      body = query;
    }
    console.log(`[${requestId}] \u6700\u7EC8\u4F7F\u7528\u7684\u901A\u77E5\u53C2\u6570:`, body);
    console.log(`[${requestId}] \u53C2\u6570\u7C7B\u578B:`, typeof body);
    console.log(`[${requestId}] \u53C2\u6570\u952E\u503C\u5BF9:`, Object.keys(body));
    const isPaySuccess = body.trade_status === "TRADE_SUCCESS" || Number(body.state) === 1;
    console.log(`[${requestId}] \u8BA2\u5355\u72B6\u6001:`, { trade_status: body.trade_status, state: body.state, isPaySuccess });
    if (!isPaySuccess) {
      console.log(`[${requestId}] \u8BA2\u5355\u72B6\u6001\u4E0D\u662F\u6210\u529F`);
      setResponseStatus(evt, 200);
      return "success";
    }
    console.log(`[${requestId}] \u8BA2\u5355\u72B6\u6001\u9A8C\u8BC1\u6210\u529F!`);
    const notifyOrderNo = body.trade_no || body.outTradeNo || "";
    console.log(`[${requestId}] \u4F7F\u7528\u8BA2\u5355\u53F7\u67E5\u627E\u8BA2\u5355:`, notifyOrderNo);
    const result = await sql({
      query: "SELECT * FROM PaymentRecords WHERE mch_order_id = ? LIMIT 1",
      values: [notifyOrderNo]
    });
    const localOrder = result.length > 0 ? result[0] : null;
    if (!localOrder) {
      console.error(`[${requestId}] \u8BA2\u5355\u4E0D\u5B58\u5728, \u8BA2\u5355\u53F7:`, notifyOrderNo);
      setResponseStatus(evt, 200);
      return "fail";
    }
    console.log(`[${requestId}] \u8BA2\u5355\u67E5\u627E\u6210\u529F!`, { transaction_id: localOrder.transaction_id, mch_order_id: localOrder.mch_order_id });
    const dbChannelId = localOrder.payment_id;
    const channelId = String(dbChannelId || "1");
    console.log(`[${requestId}] [\u56DE\u8C03\u8FFD\u8E2A] \u8BA2\u5355\u53F7:${localOrder.transaction_id}, \u6570\u636E\u5E93\u5B58\u7684\u6E20\u9053ID:${dbChannelId}, \u6700\u7EC8\u91C7\u7528ID:${channelId}`);
    const { getProviderByChannelId } = await import('../nitro/nitro.mjs').then(function (n) { return n.ah; });
    let provider, credentials;
    try {
      const result2 = getProviderByChannelId(channelId);
      provider = result2.provider;
      credentials = result2.credentials;
      console.log(`[${requestId}] \u4F7F\u7528\u6E20\u9053 ${channelId} \u7684\u914D\u7F6E\u8FDB\u884C\u9A8C\u7B7E`);
    } catch (error) {
      console.error(`[${requestId}] \u83B7\u53D6\u652F\u4ED8\u6E20\u9053\u914D\u7F6E\u5931\u8D25:`, error);
      const { selectProviderBySystemParam: selectProviderBySystemParam2 } = await import('../nitro/nitro.mjs').then(function (n) { return n.ah; });
      const result2 = await selectProviderBySystemParam2();
      provider = result2.provider;
      credentials = result2.credentials;
      console.log(`[${requestId}] \u964D\u7EA7\u4F7F\u7528\u7CFB\u7EDF\u9ED8\u8BA4\u914D\u7F6E\u8FDB\u884C\u9A8C\u7B7E`);
    }
    const verified = provider.verify ? provider.verify(body, credentials) : true;
    if (!verified) {
      console.error(`[${requestId}] \u7B7E\u540D\u9A8C\u8BC1\u5931\u8D25! \u6E20\u9053ID: ${channelId}`);
      setResponseStatus(evt, 200);
      return "fail";
    }
    console.log(`[${requestId}] \u7B7E\u540D\u9A8C\u8BC1\u6210\u529F!`);
    console.log(`[${requestId}] \u68C0\u67E5\u8BA2\u5355\u5904\u7406\u72B6\u6001:`, localOrder.payment_status);
    if (localOrder.payment_status === 3) {
      console.log(`[${requestId}] \u8BA2\u5355\u5DF2\u5904\u7406\u8FC7:`, notifyOrderNo);
      setResponseStatus(evt, 200);
      return "success";
    }
    console.log(`[${requestId}] \u5F00\u59CB\u9A8C\u8BC1\u91D1\u989D...`);
    let notifyAmount;
    if (body.amount !== void 0 && body.money === void 0) {
      notifyAmount = parseInt(body.amount) / 100;
    } else {
      notifyAmount = parseFloat(body.money);
    }
    const orderAmount = parseFloat(String(localOrder.amount || 0));
    console.log(`[${requestId}] \u901A\u77E5\u91D1\u989D:`, notifyAmount, "\u8BA2\u5355\u91D1\u989D:", orderAmount);
    if (Math.abs(notifyAmount - orderAmount) > 0.01) {
      console.error(`[${requestId}] \u91D1\u989D\u4E0D\u5339\u914D:`, { notify: notifyAmount, order: orderAmount });
      setResponseStatus(evt, 200);
      return "fail";
    }
    console.log(`[${requestId}] \u91D1\u989D\u9A8C\u8BC1\u6210\u529F!`);
    console.log(`[${requestId}] \u5F00\u59CB\u66F4\u65B0\u8BA2\u5355\u72B6\u6001\u4E3A\u6210\u529F...`);
    console.log(`\u{1F50D} [\u7B2C\u4E09\u65B9\u56DE\u8C03] \u5F53\u524D\u8BA2\u5355\u652F\u4ED8\u65B9\u5F0F\u72B6\u6001:`, {
      transactionId: localOrder.transaction_id,
      currentPaymentWay: localOrder.payment_way,
      isPaymentWayEmpty: !localOrder.payment_way,
      isPaymentWayUnknown: localOrder.payment_way === "\u672A\u77E5",
      callbackType: body.type || "unknown",
      callbackParams: body
    });
    await fixPaymentWay(localOrder, body, requestId);
    const currentTime = getCurrentFormattedTime();
    console.log(`[${requestId}] \u66F4\u65B0\u53C2\u6570:`, {
      transaction_id: localOrder.transaction_id,
      status: 3,
      currentTime,
      trade_no: body.trade_no
    });
    await updateOrderStatus(localOrder.transaction_id || "", 3, currentTime, currentTime, body.trade_no || body.tradeNo || "");
    console.log(`[${requestId}] \u8BA2\u5355\u72B6\u6001\u66F4\u65B0\u5B8C\u6210!`);
    try {
      const isRoutingEnabled = await getSystemParam("payment_routing_enabled", "false");
      if (isRoutingEnabled === "true") {
        const { getOrderRuleMapping, incrementRedisUsedQuota } = await import('./paymentRouting.mjs');
        const ruleId = await getOrderRuleMapping(localOrder.transaction_id || "");
        if (ruleId) {
          await incrementRedisUsedQuota(ruleId, notifyAmount);
          console.log(`[${requestId}] \u652F\u4ED8\u8DEF\u7531 Redis \u989D\u5EA6\u5DF2\u7D2F\u52A0: \u89C4\u5219ID=${ruleId}, \u91D1\u989D=${notifyAmount}`);
        }
      }
    } catch (redisErr) {
      console.error(`[${requestId}] \u652F\u4ED8\u8DEF\u7531 Redis \u989D\u5EA6\u7D2F\u52A0\u5931\u8D25:`, redisErr);
    }
    const giftHandled = await processGiftOrder(localOrder, requestId, body.trade_no);
    if (!giftHandled) {
      console.log(`[${requestId}] \u8BBE\u7F6E\u5EF6\u8FDF\u6E38\u620F\u670D\u901A\u77E5...`);
      setTimeout(async () => {
        try {
          console.log(`[${requestId}] \u5F00\u59CB\u6267\u884C\u5EF6\u8FDF\u6E38\u620F\u670D\u901A\u77E5`);
          await notifyGameServer(
            String(localOrder.transaction_id || ""),
            String(localOrder.wuid || ""),
            String(localOrder.server_url || ""),
            void 0,
            Number(localOrder.world_id || 0)
          );
          console.log(`[${requestId}] \u5EF6\u8FDF\u6E38\u620F\u670D\u901A\u77E5\u5B8C\u6210`);
        } catch (error) {
          console.error(`[${requestId}] \u5EF6\u8FDF\u901A\u77E5\u6E38\u620F\u670D\u5931\u8D25:`, error);
        }
      }, 12e4);
    } else {
      console.log(`[${requestId}] \u793C\u5305\u8BA2\u5355\u5DF2\u5904\u7406\uFF0C\u8DF3\u8FC7\u6E38\u620F\u670D\u901A\u77E5`);
    }
    const endTime = Date.now();
    const processingTime = endTime - startTime;
    console.log(`[${requestId}] === \u7B2C\u4E09\u65B9\u652F\u4ED8\u56DE\u8C03\u5904\u7406\u5B8C\u6210\uFF0C\u8FD4\u56DEsuccess ===`);
    console.log(`[${requestId}] \u603B\u5904\u7406\u65F6\u95F4: ${processingTime}ms`);
    setResponseStatus(evt, 200);
    return "SUCCESS";
  } catch (error) {
    const endTime = Date.now();
    const processingTime = endTime - startTime;
    console.error(`[${requestId}] \u5904\u7406\u7B2C\u4E09\u65B9\u652F\u4ED8\u901A\u77E5\u5931\u8D25:`, error);
    console.error(`[${requestId}] \u9519\u8BEF\u5806\u6808:`, error.stack);
    console.error(`[${requestId}] \u5904\u7406\u65F6\u95F4: ${processingTime}ms`);
    setResponseStatus(evt, 200);
    return "fail";
  }
};
const handleCashierPaymentNotify = async (evt) => {
  var _a;
  const startTime = Date.now();
  const requestId = `cashier_notify_${startTime}_${Math.random().toString(36).substr(2, 9)}`;
  try {
    console.log(`[${requestId}] === \u5F00\u59CB\u5904\u7406\u6536\u94F6\u53F0\u652F\u4ED8\u56DE\u8C03 ===`);
    console.log(`[${requestId}] \u65F6\u95F4: ${(/* @__PURE__ */ new Date()).toISOString()}`);
    console.log(`[${requestId}] \u8BF7\u6C42\u65B9\u6CD5: ${evt.node.req.method}`);
    console.log(`[${requestId}] \u8BF7\u6C42URL: ${evt.node.req.url}`);
    console.log(`[${requestId}] \u8BF7\u6C42\u5934:`, evt.node.req.headers);
    const query = getQuery(evt);
    const requestMethod = (_a = evt.node.req.method) == null ? void 0 : _a.toUpperCase();
    console.log(`[${requestId}] GET\u67E5\u8BE2\u53C2\u6570:`, query);
    let body = {};
    if (requestMethod === "POST") {
      try {
        body = await readBody(evt);
        console.log(`[${requestId}] POST\u8BF7\u6C42\u4F53\u8BFB\u53D6\u6210\u529F:`, body);
      } catch (e) {
        console.log(`[${requestId}] POST body\u8BFB\u53D6\u5931\u8D25\uFF0C\u56DE\u9000\u5230GET\u53C2\u6570`);
        body = query;
      }
    } else {
      console.log(`[${requestId}] \u68C0\u6D4B\u5230GET\u8BF7\u6C42\uFF0C\u4F7F\u7528query\u53C2\u6570`);
      body = query;
    }
    console.log(`[${requestId}] \u6700\u7EC8\u4F7F\u7528\u7684\u901A\u77E5\u53C2\u6570:`, body);
    console.log(`[${requestId}] \u53C2\u6570\u7C7B\u578B:`, typeof body);
    console.log(`[${requestId}] \u53C2\u6570\u952E\u503C\u5BF9:`, Object.keys(body));
    const isPaySuccess = body.trade_status === "TRADE_SUCCESS" || Number(body.state) === 1;
    console.log(`[${requestId}] \u8BA2\u5355\u72B6\u6001:`, { trade_status: body.trade_status, state: body.state, isPaySuccess });
    if (!isPaySuccess) {
      console.log(`[${requestId}] \u8BA2\u5355\u72B6\u6001\u4E0D\u662F\u6210\u529F`);
      setResponseStatus(evt, 200);
      return "success";
    }
    console.log(`[${requestId}] \u8BA2\u5355\u72B6\u6001\u9A8C\u8BC1\u6210\u529F!`);
    const notifyOrderNo = body.trade_no || body.outTradeNo || "";
    console.log(`[${requestId}] \u4F7F\u7528\u8BA2\u5355\u53F7\u67E5\u627E\u8BA2\u5355:`, notifyOrderNo);
    const result = await sql({
      query: "SELECT * FROM PaymentRecords WHERE mch_order_id = ? LIMIT 1",
      values: [notifyOrderNo]
    });
    const localOrder = result.length > 0 ? result[0] : null;
    if (!localOrder) {
      console.error(`[${requestId}] \u8BA2\u5355\u4E0D\u5B58\u5728, \u8BA2\u5355\u53F7:`, notifyOrderNo);
      setResponseStatus(evt, 200);
      return "fail";
    }
    console.log(`[${requestId}] \u8BA2\u5355\u67E5\u627E\u6210\u529F!`, { transaction_id: localOrder.transaction_id, mch_order_id: localOrder.mch_order_id });
    const dbChannelId = localOrder.payment_id;
    const channelId = String(dbChannelId || "1");
    console.log(`[${requestId}] [\u56DE\u8C03\u8FFD\u8E2A] \u8BA2\u5355\u53F7:${localOrder.transaction_id}, \u6570\u636E\u5E93\u5B58\u7684\u6E20\u9053ID:${dbChannelId}, \u6700\u7EC8\u91C7\u7528ID:${channelId}`);
    const { getProviderByChannelId } = await import('../nitro/nitro.mjs').then(function (n) { return n.ah; });
    let provider, credentials;
    try {
      const result2 = getProviderByChannelId(channelId);
      provider = result2.provider;
      credentials = result2.credentials;
      console.log(`[${requestId}] \u4F7F\u7528\u6E20\u9053 ${channelId} \u7684\u914D\u7F6E\u8FDB\u884C\u9A8C\u7B7E`);
    } catch (error) {
      console.error(`[${requestId}] \u83B7\u53D6\u652F\u4ED8\u6E20\u9053\u914D\u7F6E\u5931\u8D25:`, error);
      const { selectProviderBySystemParam: selectProviderBySystemParam2 } = await import('../nitro/nitro.mjs').then(function (n) { return n.ah; });
      const result2 = await selectProviderBySystemParam2();
      provider = result2.provider;
      credentials = result2.credentials;
      console.log(`[${requestId}] \u964D\u7EA7\u4F7F\u7528\u7CFB\u7EDF\u9ED8\u8BA4\u914D\u7F6E\u8FDB\u884C\u9A8C\u7B7E`);
    }
    const verified = provider.verify ? provider.verify(body, credentials) : true;
    if (!verified) {
      console.error(`[${requestId}] \u7B7E\u540D\u9A8C\u8BC1\u5931\u8D25! \u6E20\u9053ID: ${channelId}`);
      setResponseStatus(evt, 200);
      return "fail";
    }
    console.log(`[${requestId}] \u7B7E\u540D\u9A8C\u8BC1\u6210\u529F!`);
    console.log(`[${requestId}] \u68C0\u67E5\u8BA2\u5355\u5904\u7406\u72B6\u6001:`, localOrder.payment_status);
    if (localOrder.payment_status === 3) {
      console.log(`[${requestId}] \u8BA2\u5355\u5DF2\u5904\u7406\u8FC7:`, body.out_trade_no);
      setResponseStatus(evt, 200);
      return "success";
    }
    console.log(`[${requestId}] \u5F00\u59CB\u9A8C\u8BC1\u91D1\u989D...`);
    let notifyAmount;
    if (body.amount !== void 0 && body.money === void 0) {
      notifyAmount = parseInt(body.amount) / 100;
    } else {
      notifyAmount = parseFloat(body.money);
    }
    const orderAmount = parseFloat(String(localOrder.amount || 0));
    console.log(`[${requestId}] \u901A\u77E5\u91D1\u989D:`, notifyAmount, "\u8BA2\u5355\u91D1\u989D:", orderAmount);
    if (Math.abs(notifyAmount - orderAmount) > 0.01) {
      console.error(`[${requestId}] \u91D1\u989D\u4E0D\u5339\u914D:`, { notify: notifyAmount, order: orderAmount });
      setResponseStatus(evt, 200);
      return "fail";
    }
    console.log(`[${requestId}] \u91D1\u989D\u9A8C\u8BC1\u6210\u529F!`);
    console.log(`[${requestId}] \u5F00\u59CB\u66F4\u65B0\u8BA2\u5355\u72B6\u6001\u4E3A\u6210\u529F...`);
    console.log(`\u{1F50D} [\u7B2C\u4E09\u65B9\u56DE\u8C03] \u5F53\u524D\u8BA2\u5355\u652F\u4ED8\u65B9\u5F0F\u72B6\u6001:`, {
      transactionId: localOrder.transaction_id,
      currentPaymentWay: localOrder.payment_way,
      isPaymentWayEmpty: !localOrder.payment_way,
      isPaymentWayUnknown: localOrder.payment_way === "\u672A\u77E5",
      callbackType: body.type || "unknown",
      callbackParams: body
    });
    await fixPaymentWay(localOrder, body, requestId);
    const currentTime = getCurrentFormattedTime();
    console.log(`[${requestId}] \u66F4\u65B0\u53C2\u6570:`, {
      transaction_id: localOrder.transaction_id,
      status: 3,
      currentTime,
      trade_no: body.trade_no
    });
    await updateOrderStatus(localOrder.transaction_id || "", 3, currentTime, currentTime, body.trade_no || body.tradeNo || "");
    console.log(`[${requestId}] \u8BA2\u5355\u72B6\u6001\u66F4\u65B0\u5B8C\u6210!`);
    try {
      const { getSystemParam: getSystemParam2 } = await import('../nitro/nitro.mjs').then(function (n) { return n.ai; });
      const isRoutingEnabled = await getSystemParam2("payment_routing_enabled", "false");
      if (isRoutingEnabled === "true") {
        const { getOrderRuleMapping, incrementRedisUsedQuota } = await import('./paymentRouting.mjs');
        const ruleId = await getOrderRuleMapping(localOrder.transaction_id || "");
        if (ruleId) {
          await incrementRedisUsedQuota(ruleId, orderAmount);
          console.log(`[${requestId}] \u652F\u4ED8\u8DEF\u7531 Redis \u989D\u5EA6\u5DF2\u7D2F\u52A0: \u89C4\u5219ID=${ruleId}, \u91D1\u989D=${orderAmount}`);
        }
      }
    } catch (redisErr) {
      console.error(`[${requestId}] \u652F\u4ED8\u8DEF\u7531 Redis \u989D\u5EA6\u7D2F\u52A0\u5931\u8D25:`, redisErr);
    }
    console.log(`[${requestId}] \u5F00\u59CB\u5904\u7406\u5E73\u53F0\u5E01\u5230\u8D26...`);
    try {
      const rateStr = await getSystemParam("ptb_exchange_rate", "10");
      const rate = Math.max(1, parseFloat(rateStr) || 10);
      const platformCoinsToAdd = orderAmount * rate;
      console.log(`[${requestId}] \u8BA1\u7B97\u5E73\u53F0\u5E01\u5230\u8D26\u6570\u91CF: ${orderAmount}\u5143 = ${platformCoinsToAdd}\u5E73\u53F0\u5E01`);
      const user = await sql({
        query: "SELECT id, platform_coins FROM Users WHERE id = ?",
        values: [localOrder.user_id]
      });
      if (user.length === 0) {
        console.error(`[${requestId}] \u7528\u6237\u4E0D\u5B58\u5728:`, localOrder.user_id);
        setResponseStatus(evt, 200);
        return "fail";
      }
      const currentPlatformCoins = parseFloat(user[0].platform_coins) || 0;
      console.log(`[${requestId}] \u5E73\u53F0\u5E01\u4F59\u989D\u66F4\u65B0: ${currentPlatformCoins} + ${platformCoinsToAdd}`);
      const updateResult = await updatePlatformCoinsUnified(localOrder.user_id, platformCoinsToAdd, 3);
      if (!updateResult.success) {
        console.error(`[${requestId}] \u5E73\u53F0\u5E01\u4F59\u989D\u66F4\u65B0\u5931\u8D25:`, updateResult.message);
        setResponseStatus(evt, 200);
        return "fail";
      }
      const newPlatformCoins = updateResult.newBalance;
      console.log(`[${requestId}] \u5E73\u53F0\u5E01\u4F59\u989D\u66F4\u65B0\u6210\u529F!`);
      try {
        await updateByTransactionId(localOrder.transaction_id || "", {
          ptb_before: currentPlatformCoins,
          ptb_change: platformCoinsToAdd,
          ptb_after: newPlatformCoins
        });
        console.log(`[${requestId}] PaymentRecords \u5E73\u53F0\u5E01\u53D8\u5316\u5DF2\u8BB0\u5F55`, {
          before: currentPlatformCoins,
          change: platformCoinsToAdd,
          after: newPlatformCoins
        });
      } catch (e) {
        console.warn(`[${requestId}] PaymentRecords \u5E73\u53F0\u5E01\u53D8\u5316\u8BB0\u5F55\u5931\u8D25(\u4E0D\u5F71\u54CD\u5230\u8D26):`, (e == null ? void 0 : e.message) || e);
      }
      await sql({
        query: "INSERT INTO logs (log_type, log_content) VALUES (?, ?)",
        values: [
          "platform_coin_recharge",
          `\u7528\u6237ID: ${localOrder.user_id}, \u7528\u6237\u540D: ${localOrder.wuid}, \u5145\u503C\u91D1\u989D: ${orderAmount}\u5143, \u5230\u8D26\u5E73\u53F0\u5E01: ${platformCoinsToAdd}, \u4EA4\u6613ID: ${localOrder.transaction_id}`
        ]
      });
      console.log(`[${requestId}] \u5E73\u53F0\u5E01\u5145\u503C\u65E5\u5FD7\u8BB0\u5F55\u6210\u529F!`);
    } catch (platformCoinError) {
      console.error(`[${requestId}] \u5E73\u53F0\u5E01\u5230\u8D26\u5904\u7406\u5931\u8D25:`, platformCoinError);
      await sql({
        query: "INSERT INTO logs (log_type, log_content) VALUES (?, ?)",
        values: [
          "platform_coin_recharge_error",
          `\u7528\u6237ID: ${localOrder.user_id}, \u4EA4\u6613ID: ${localOrder.transaction_id}, \u9519\u8BEF: ${platformCoinError.message}`
        ]
      });
    }
    try {
      const productName = String(localOrder.product_name || "");
      const isMonthlyCard = productName.includes("\u6708\u5361") || productName.includes("\u7EC8\u8EAB\u5361");
      if (isMonthlyCard) {
        const { activateCard, getCardByTransactionId, getBeijingDate } = await import('./monthlyCard.mjs');
        const transId = localOrder.transaction_id || "";
        const existingCard = await getCardByTransactionId(transId);
        if (!existingCard) {
          const cardType = productName.includes("\u7EC8\u8EAB\u5361") ? "lifetime" : "monthly";
          const dailyCoins = cardType === "lifetime" ? 500 : 300;
          const today = getBeijingDate();
          let expireDate = null;
          if (cardType === "monthly") {
            const exp = /* @__PURE__ */ new Date();
            exp.setTime(exp.getTime() + 8 * 60 * 60 * 1e3 + 29 * 86400 * 1e3);
            expireDate = exp.toISOString().slice(0, 10);
          }
          await activateCard({
            userId: localOrder.user_id,
            cardType,
            dailyCoins,
            startDate: today,
            expireDate,
            purchaseAmount: orderAmount,
            transactionId: transId
          });
          console.log(`[${requestId}] \u2705 \u6708\u5361\u6FC0\u6D3B\u6210\u529F: type=${cardType}, userId=${localOrder.user_id}, expire=${expireDate || "\u6C38\u4E45"}`);
        } else {
          console.log(`[${requestId}] \u26A0\uFE0F \u6708\u5361\u5DF2\u6FC0\u6D3B(\u91CD\u590D\u56DE\u8C03), transaction_id=${transId}`);
        }
      }
    } catch (cardErr) {
      console.error(`[${requestId}] \u6708\u5361\u6FC0\u6D3B\u5931\u8D25(\u4E0D\u5F71\u54CD\u56DE\u8C03):`, cardErr == null ? void 0 : cardErr.message);
    }
    const endTime = Date.now();
    const processingTime = endTime - startTime;
    console.log(`[${requestId}] === \u6536\u94F6\u53F0\u652F\u4ED8\u56DE\u8C03\u5904\u7406\u5B8C\u6210\uFF0C\u8FD4\u56DEsuccess ===`);
    console.log(`[${requestId}] \u603B\u5904\u7406\u65F6\u95F4: ${processingTime}ms`);
    setResponseStatus(evt, 200);
    return "SUCCESS";
  } catch (error) {
    const endTime = Date.now();
    const processingTime = endTime - startTime;
    console.error(`[${requestId}] \u5904\u7406\u6536\u94F6\u53F0\u652F\u4ED8\u901A\u77E5\u5931\u8D25:`, error);
    console.error(`[${requestId}] \u9519\u8BEF\u5806\u6808:`, error.stack);
    console.error(`[${requestId}] \u5904\u7406\u65F6\u95F4: ${processingTime}ms`);
    setResponseStatus(evt, 200);
    return "fail";
  }
};
const queryPaymentOrder = async (evt) => {
  try {
    const body = await readBody(evt);
    const { transaction_id } = body;
    console.log("[PaymentQuery] \u5F00\u59CB\u8BE2\u5355:", { transaction_id });
    if (!transaction_id) {
      return {
        code: 400,
        msg: "\u7F3A\u5C11\u8BA2\u5355\u53F7"
      };
    }
    const orderDetail = await detailByTransId(transaction_id);
    if (!orderDetail) {
      return {
        code: 404,
        msg: "\u8BA2\u5355\u4E0D\u5B58\u5728:" + transaction_id
      };
    }
    console.log("[PaymentQuery] \u8BA2\u5355\u8BE6\u60C5:", {
      transaction_id,
      mch_order_id: orderDetail.mch_order_id,
      payment_status: orderDetail.payment_status,
      payment_way: orderDetail.payment_way
    });
    if (orderDetail.payment_status === 3) {
      return {
        code: 200,
        msg: "\u8BA2\u5355\u5DF2\u652F\u4ED8",
        data: {
          status: 1,
          // 已支付
          transaction_id,
          local_status: orderDetail.payment_status
        }
      };
    }
    const { executeQueryBySystemParam, isSupportQueryBySystemParam } = await import('../nitro/nitro.mjs').then(function (n) { return n.ah; });
    const supportQuery = await isSupportQueryBySystemParam();
    if (!supportQuery) {
      return {
        code: 400,
        msg: "\u5F53\u524D\u652F\u4ED8\u6E20\u9053\u4E0D\u652F\u6301\u8BE2\u5355\u529F\u80FD"
      };
    }
    const queryResult = await executeQueryBySystemParam({
      out_trade_no: orderDetail.mch_order_id,
      trade_no: orderDetail.mch_order_id
    });
    console.log("[PaymentQuery] \u8BE2\u5355\u7ED3\u679C:", queryResult);
    if (queryResult.code === 0) {
      const thirdPartyStatus = queryResult.status || 0;
      if (thirdPartyStatus === 1 && orderDetail.payment_status !== 3) {
        console.log("[PaymentQuery] \u68C0\u6D4B\u5230\u652F\u4ED8\u6210\u529F\u4F46\u672C\u5730\u672A\u5230\u8D26\uFF0C\u89E6\u53D1\u5230\u8D26\u903B\u8F91");
        await processSuccessfulPayment(orderDetail, queryResult);
        return {
          code: 200,
          msg: "\u8BA2\u5355\u5DF2\u652F\u4ED8\u5E76\u5B8C\u6210\u5230\u8D26",
          data: {
            status: thirdPartyStatus,
            transaction_id,
            processed: true
          }
        };
      }
      return {
        code: 200,
        msg: "\u8BE2\u5355\u6210\u529F",
        data: {
          status: thirdPartyStatus,
          transaction_id,
          trade_no: queryResult.trade_no,
          out_trade_no: queryResult.out_trade_no,
          money: queryResult.money
        }
      };
    }
    return {
      code: queryResult.code,
      msg: queryResult.msg || "\u8BE2\u5355\u5931\u8D25"
    };
  } catch (error) {
    console.error("[PaymentQuery] \u8BE2\u5355\u5F02\u5E38:", error);
    return {
      code: 500,
      msg: error.message || "\u8BE2\u5355\u8BF7\u6C42\u5931\u8D25"
    };
  }
};
async function processSuccessfulPayment(orderDetail, queryResult) {
  try {
    const currentTime = getCurrentFormattedTime();
    const productName = String(orderDetail.product_name || "").toLowerCase();
    const serverUrl = String(orderDetail.server_url || "");
    const isPlatformCoinRecharge = productName.includes("\u5E73\u53F0\u5E01") || productName.includes("\u5145\u503C") || productName.includes("ptb") || serverUrl.includes("cashier");
    const isGiftOrder = serverUrl.startsWith("gift://");
    if (isPlatformCoinRecharge && !isGiftOrder) {
      console.log("[PaymentQuery] \u5904\u7406\u5E73\u53F0\u5E01\u5145\u503C\u5230\u8D26...");
      const rateStr = await getSystemParam("ptb_exchange_rate", "10");
      const rate = Math.max(1, parseFloat(rateStr) || 10);
      const orderAmount = parseFloat(String(orderDetail.amount || 0));
      const platformCoinsToAdd = orderAmount * rate;
      console.log(`[PaymentQuery] \u8BA1\u7B97\u5E73\u53F0\u5E01: ${orderAmount}\u5143 \xD7 ${rate} = ${platformCoinsToAdd}\u5E73\u53F0\u5E01`);
      const user = await sql({
        query: "SELECT id, platform_coins FROM Users WHERE id = ?",
        values: [orderDetail.user_id]
      });
      if (user.length === 0) {
        console.error("[PaymentQuery] \u7528\u6237\u4E0D\u5B58\u5728:", orderDetail.user_id);
        throw new Error("\u7528\u6237\u4E0D\u5B58\u5728");
      }
      const currentPlatformCoins = parseFloat(user[0].platform_coins) || 0;
      console.log(`[PaymentQuery] \u5E73\u53F0\u5E01\u4F59\u989D\u66F4\u65B0: ${currentPlatformCoins} + ${platformCoinsToAdd}`);
      const updateResult = await updatePlatformCoinsUnified(orderDetail.user_id, platformCoinsToAdd, 4);
      if (!updateResult.success) {
        console.error("[PaymentQuery] \u5E73\u53F0\u5E01\u4F59\u989D\u66F4\u65B0\u5931\u8D25:", updateResult.message);
        throw new Error(updateResult.message || "\u5E73\u53F0\u5E01\u4F59\u989D\u66F4\u65B0\u5931\u8D25");
      }
      const newPlatformCoins = updateResult.newBalance;
      await updateByTransactionId(orderDetail.transaction_id, {
        payment_status: 3,
        ptb_before: currentPlatformCoins,
        ptb_change: platformCoinsToAdd,
        ptb_after: newPlatformCoins
      });
      console.log("[PaymentQuery] \u5E73\u53F0\u5E01\u5145\u503C\u5230\u8D26\u5B8C\u6210");
    } else if (isGiftOrder) {
      console.log("[PaymentQuery] \u5904\u7406\u793C\u5305\u8BA2\u5355\u5230\u8D26...");
      const metaStr = serverUrl.replace("gift://", "");
      let meta = {};
      try {
        meta = JSON.parse(decodeURIComponent(metaStr));
      } catch (e) {
        console.error("[PaymentQuery] \u793C\u5305\u5143\u6570\u636E\u89E3\u6790\u5931\u8D25:", e);
      }
      const packageId = meta.pid;
      const characterUuid = meta.cid;
      const serverId = meta.sid || 1;
      console.log("[PaymentQuery] \u793C\u5305\u5143\u6570\u636E:", { packageId, characterUuid, serverId });
      console.log("[PaymentQuery] \u67E5\u8BE2\u793C\u5305\u4FE1\u606F, packageId:", packageId);
      const packageInfo = await sql({
        query: "SELECT * FROM externalgiftpackages WHERE id = ?",
        values: [packageId]
      });
      console.log("[PaymentQuery] \u793C\u5305\u67E5\u8BE2\u7ED3\u679C:", packageInfo.length > 0 ? "\u627E\u5230" : "\u672A\u627E\u5230");
      if (packageInfo.length === 0) {
        console.error("[PaymentQuery] \u793C\u5305\u4E0D\u5B58\u5728:", packageId);
        throw new Error(`\u793C\u5305\u4E0D\u5B58\u5728: id=${packageId}`);
      }
      const pkg = packageInfo[0];
      console.log("[PaymentQuery] \u793C\u5305\u4FE1\u606F:", {
        id: pkg.id,
        package_name: pkg.package_name,
        price_real_money: pkg.price_real_money
      });
      let giftItems;
      try {
        giftItems = typeof pkg.gift_items === "string" ? JSON.parse(pkg.gift_items) : pkg.gift_items;
        console.log("[PaymentQuery] gift_items \u89E3\u6790\u6210\u529F");
      } catch (parseError) {
        console.error("[PaymentQuery] gift_items \u89E3\u6790\u5931\u8D25:", parseError.message);
        throw new Error(`\u793C\u5305\u7269\u54C1\u914D\u7F6E\u89E3\u6790\u5931\u8D25: ${parseError.message}`);
      }
      console.log("[PaymentQuery] \u521B\u5EFA\u793C\u5305\u8D2D\u4E70\u8BB0\u5F55...");
      const purchaseRecord = {
        user_id: orderDetail.user_id,
        thirdparty_uid: characterUuid,
        package_id: packageId,
        package_code: pkg.package_code || "",
        package_name: pkg.package_name,
        quantity: 1,
        unit_price: parseFloat(orderDetail.amount || 0),
        total_amount: parseFloat(orderDetail.amount || 0),
        balance_before: 0,
        balance_after: 0,
        gift_items: pkg.gift_items,
        status: "paid",
        remark: `\u7B2C\u4E09\u65B9\u652F\u4ED8\u8D2D\u4E70 - \u8BE2\u5355\u8865\u507F\u53D1\u653E`
      };
      console.log("[PaymentQuery] \u5BFC\u5165 ExternalGiftPackageModel...");
      const ExternalGiftPackageModel2 = await import('./externalGiftPackage.mjs');
      console.log("[PaymentQuery] \u8C03\u7528 createPurchaseRecord, \u53C2\u6570:", {
        user_id: purchaseRecord.user_id,
        package_id: purchaseRecord.package_id,
        package_name: purchaseRecord.package_name,
        total_amount: purchaseRecord.total_amount
      });
      const createResult = await ExternalGiftPackageModel2.createPurchaseRecord(purchaseRecord);
      const purchaseRecordId = createResult.insertId;
      console.log("[PaymentQuery] \u8D2D\u4E70\u8BB0\u5F55\u521B\u5EFA\u6210\u529F, \u8BB0\u5F55ID:", purchaseRecordId);
      console.log("[PaymentQuery] \u5F00\u59CB\u53D1\u653E\u793C\u5305\u5230\u6E38\u620F\u5185, \u53C2\u6570:", {
        purchaseRecordId,
        serverId: serverId.toString(),
        characterUuid
      });
      try {
        const deliveryResult = await ExternalGiftPackageModel2.deliverPackageToGameViaIDIP(
          purchaseRecordId,
          serverId.toString(),
          characterUuid
        );
        console.log("[PaymentQuery] IDIP \u53D1\u653E\u8FD4\u56DE\u7ED3\u679C:", JSON.stringify(deliveryResult));
        if (deliveryResult.success) {
          console.log("[PaymentQuery] \u2705 \u793C\u5305\u53D1\u653E\u6210\u529F!");
          const currentTime2 = getCurrentFormattedTime();
          await updateByTransactionId(orderDetail.transaction_id, {
            notify_at: currentTime2,
            msg: "\u793C\u5305\u53D1\u653E\u6210\u529F"
          });
        } else {
          console.error("[PaymentQuery] \u274C \u793C\u5305\u53D1\u653E\u5931\u8D25:", deliveryResult.message);
          throw new Error(deliveryResult.message || "\u793C\u5305\u53D1\u653E\u5931\u8D25");
        }
      } catch (deliveryError) {
        console.error("[PaymentQuery] \u274C \u793C\u5305\u53D1\u653E\u5F02\u5E38:", deliveryError.message || deliveryError);
        console.error("[PaymentQuery] \u5F02\u5E38\u5806\u6808:", deliveryError.stack);
        throw deliveryError;
      }
      console.log("[PaymentQuery] \u66F4\u65B0\u8BA2\u5355\u72B6\u6001\u4E3A\u6210\u529F, transaction_id:", orderDetail.transaction_id);
      await updateOrderStatus(orderDetail.transaction_id, 3);
      console.log("[PaymentQuery] \u8BA2\u5355\u72B6\u6001\u66F4\u65B0\u5B8C\u6210");
      console.log("[PaymentQuery] \u2705 \u793C\u5305\u8BA2\u5355\u5904\u7406\u5B8C\u6210");
    }
    console.log("[PaymentQuery] \u2705 \u5230\u8D26\u903B\u8F91\u5904\u7406\u5B8C\u6210");
  } catch (error) {
    console.error("[PaymentQuery] \u274C \u5230\u8D26\u903B\u8F91\u5904\u7406\u5931\u8D25");
    console.error("[PaymentQuery] \u9519\u8BEF\u7C7B\u578B:", error.constructor.name);
    console.error("[PaymentQuery] \u9519\u8BEF\u6D88\u606F:", error.message);
    console.error("[PaymentQuery] \u9519\u8BEF\u5806\u6808:", error.stack);
    if (error.sql) {
      console.error("[PaymentQuery] SQL\u9519\u8BEF:", error.sql);
      console.error("[PaymentQuery] SQL\u53C2\u6570:", error.sqlParameters);
    }
    throw error;
  }
}

function getGameIp(amount) {
  const value = typeof amount === "number" && Number.isFinite(amount) ? amount : 0;
  return selectGameIpByAmount(value);
}
async function getUserZfbWxSuccessTotal(userId) {
  var _a, _b;
  const rows = await sql({
    query: `SELECT COALESCE(SUM(amount), 0) AS total
                FROM PaymentRecords
                WHERE user_id = ?
                  AND payment_status = 3
                  AND payment_way IN ('\u652F\u4ED8\u5B9D', '\u5FAE\u4FE1')`,
    values: [userId]
  });
  const total = parseFloat(String((_b = (_a = rows[0]) == null ? void 0 : _a.total) != null ? _b : 0));
  return Number.isFinite(total) ? total : 0;
}
const checkChannelStatus = async (evt) => {
  try {
    const query = getQuery(evt);
    const channelCode = query.channel_code;
    if (!channelCode) {
      return {
        valid: false,
        message: "\u7F3A\u5C11\u6E20\u9053\u4EE3\u7801\u53C2\u6570"
      };
    }
    const adminResult = await sql({
      query: "SELECT id, name, channel_code, is_active FROM Admins WHERE channel_code = ?",
      values: [channelCode]
    });
    if (adminResult.length === 0) {
      return {
        valid: false,
        message: "\u65E0\u6548\u7684\u6E20\u9053\u4EE3\u7801",
        exists: false
      };
    }
    const admin = adminResult[0];
    if (admin.is_active !== 1) {
      return {
        valid: false,
        message: "\u8BE5\u4EE3\u7406\u8D26\u53F7\u5DF2\u88AB\u7981\u7528\uFF0C\u65E0\u6CD5\u6CE8\u518C",
        exists: true,
        is_active: false
      };
    }
    return {
      valid: true,
      message: "\u4EE3\u7406\u8D26\u53F7\u72B6\u6001\u6B63\u5E38",
      exists: true,
      is_active: true,
      admin_name: admin.name
    };
  } catch (e) {
    console.error("\u68C0\u67E5\u4EE3\u7406\u8D26\u53F7\u72B6\u6001\u5931\u8D25:", e);
    return {
      valid: false,
      message: "\u68C0\u67E5\u4EE3\u7406\u8D26\u53F7\u72B6\u6001\u65F6\u53D1\u751F\u9519\u8BEF"
    };
  }
};
const quickreg = defineEventHandler(async (event) => {
  var _a, _b, _c, _d, _e;
  const query = getQuery(event);
  try {
    const userid = (_a = query == null ? void 0 : query.userid) != null ? _a : "";
    const token = (_b = query == null ? void 0 : query.token) != null ? _b : "";
    const sign = (_c = query == null ? void 0 : query.sign) != null ? _c : "";
    const channel = (_d = query == null ? void 0 : query.channel) != null ? _d : "";
    const apiUrl = (_e = query == null ? void 0 : query.host) != null ? _e : "";
    if (String(apiUrl).length > 10) {
      await updateApiUrl(String(apiUrl));
    }
    const result = await upsertUserByThirdparty(
      String(userid),
      String(token),
      String(sign),
      String(channel)
    );
    return {
      status: "ok",
      data: result
    };
  } catch (e) {
    return {
      status: "fail",
      msg: e.message
    };
  }
});
const checkUser = async (evt) => {
  const body = await readBody(evt);
  const user = await findByThirdpartyUid(body.userid);
  if (!user) {
    return { code: -1, msg: "\u7528\u6237\u4E0D\u5B58\u5728" };
  }
  const result = await verifyThirdPartyToken(body.token);
  return result;
};
const getNewOne = defineEventHandler(async (event) => {
  var _a, _b;
  const thirdparty_uid = (_b = (_a = event.context.params) == null ? void 0 : _a.thirdparty_uid) != null ? _b : "";
  try {
    const result = await sql({
      query: "SELECT * FROM SubUsers WHERE id = ?",
      values: [thirdparty_uid]
    });
    console.log("getNewOne result:", result);
    if (result.length === 0) {
      return {
        code: 404,
        data: null
      };
    }
    const subUserData = result[0];
    const responseData = {
      ...subUserData,
      uid: subUserData.wuid
      // 把 wuid 重命名为 uid
    };
    delete responseData.wuid;
    return {
      code: 200,
      data: responseData
    };
  } catch (e) {
    throw createError({
      status: 500,
      message: e.message
    });
  }
});
const getpostorders = defineEventHandler(async (event) => {
  var _a;
  try {
    const body = await readBody(event);
    const thirdparty_uid = (_a = body.thirdparty_uid) != null ? _a : "";
    if (!thirdparty_uid) {
      return {
        code: 400,
        message: "\u7F3A\u5C11\u7528\u6237ID\u53C2\u6570"
      };
    }
    const orders = await getUserOrders(thirdparty_uid);
    if (!orders || orders.length === 0) {
      return {
        code: 200,
        data: [],
        message: "\u6CA1\u6709\u627E\u5230\u7B26\u5408\u6761\u4EF6\u7684\u8BA2\u5355"
      };
    }
    const redis = getRedisCluster();
    const validOrders = [];
    for (const order of orders) {
      try {
        const transactionData = await redis.get(order.transaction_id || "");
        if (transactionData) {
          const transaction = JSON.parse(transactionData);
          if (transaction.done === 0 && transaction.haspay === 1) {
            validOrders.push({
              ...order,
              redisStatus: transaction
            });
          }
        }
      } catch (redisError) {
        console.error(`\u83B7\u53D6Redis\u6570\u636E\u51FA\u9519\uFF0C\u8BA2\u5355ID: ${order.transaction_id}`, redisError);
      }
    }
    return {
      code: 200,
      data: validOrders,
      total: validOrders.length
    };
  } catch (error) {
    console.error("\u83B7\u53D6\u8BA2\u5355\u5217\u8868\u51FA\u9519:", error);
    throw createError({
      status: 500,
      message: "\u83B7\u53D6\u8BA2\u5355\u5217\u8868\u65F6\u53D1\u751F\u9519\u8BEF"
    });
  }
});
const getorders = defineEventHandler(async (event) => {
  var _a, _b;
  try {
    const thirdparty_uid = (_b = (_a = event.context.params) == null ? void 0 : _a.thirdparty_uid) != null ? _b : "";
    if (!thirdparty_uid) {
      return {
        code: 400,
        message: "\u7F3A\u5C11\u7528\u6237ID\u53C2\u6570"
      };
    }
    const orders = await getUserOrders(thirdparty_uid);
    if (!orders || orders.length === 0) {
      return {
        code: 200,
        data: [],
        message: "\u6CA1\u6709\u627E\u5230\u7B26\u5408\u6761\u4EF6\u7684\u8BA2\u5355"
      };
    }
    const redis = getRedisCluster();
    const validOrders = [];
    for (const order of orders) {
      try {
        const transactionData = await redis.get(order.transaction_id || "");
        if (transactionData) {
          const transaction = JSON.parse(transactionData);
          if (transaction.done === 0 && transaction.haspay === 1) {
            validOrders.push({
              ...order,
              redisStatus: transaction
            });
          }
        }
      } catch (redisError) {
        console.error(`\u83B7\u53D6Redis\u6570\u636E\u51FA\u9519\uFF0C\u8BA2\u5355ID: ${order.transaction_id}`, redisError);
      }
    }
    return {
      code: 200,
      data: validOrders,
      total: validOrders.length
    };
  } catch (error) {
    console.error("\u83B7\u53D6\u8BA2\u5355\u5217\u8868\u51FA\u9519:", error);
    throw createError({
      status: 500,
      message: "\u83B7\u53D6\u8BA2\u5355\u5217\u8868\u65F6\u53D1\u751F\u9519\u8BEF"
    });
  }
});
const userLogin = async (evt) => {
  var _a;
  let loginSuccess = false;
  let userId = 0;
  let usernameToLog = "";
  try {
    const body = await readBody(evt);
    console.log("\u7528\u6237\u767B\u5F55\u8BF7\u6C42:", body);
    const { username, password, t } = body;
    usernameToLog = username || "";
    const headers = getHeaders(evt);
    const aliCdnRealIp = headers["ali-cdn-real-ip"];
    const xForwardedFor = headers["x-forwarded-for"];
    const xRealIp = headers["x-real-ip"];
    const ipAddress = aliCdnRealIp || (xForwardedFor ? xForwardedFor.split(",")[0].trim() : "") || xRealIp || "unknown";
    const userAgent = headers["user-agent"] || "";
    if (!username && !t) {
      console.log("\u7528\u6237\u767B\u5F55\u5931\u8D25: \u7528\u6237\u540D\u4E3A\u7A7A");
      throw createError({ status: 400, message: "\u7528\u6237\u540D\u4E0D\u80FD\u4E3A\u7A7A" });
    }
    console.log("\u6B63\u5728\u67E5\u8BE2\u7528\u6237:", username || `[autologin token]`);
    let user = [];
    if (password) {
      user = await sql({
        query: "SELECT * FROM Users WHERE username = ? AND password = ?",
        values: [username, password]
      });
    } else if (t) {
      let userIdStr = null;
      try {
        const redis = getRedisCluster();
        userIdStr = await redis.call("GETDEL", `autologin:${t}`);
      } catch (redisErr) {
        console.error("autologin token \u6821\u9A8C\u5931\u8D25 Redis \u5F02\u5E38:", redisErr);
        throw createError({ status: 500, message: "\u767B\u5F55\u670D\u52A1\u6682\u4E0D\u53EF\u7528" });
      }
      if (!userIdStr) {
        throw createError({ status: 401, message: "\u767B\u5F55\u94FE\u63A5\u5DF2\u5931\u6548\u6216\u5DF2\u88AB\u4F7F\u7528" });
      }
      const userIdNum = parseInt(String(userIdStr), 10);
      if (!Number.isFinite(userIdNum) || userIdNum <= 0) {
        throw createError({ status: 401, message: "\u767B\u5F55\u94FE\u63A5\u65E0\u6548" });
      }
      user = await sql({
        query: "SELECT * FROM Users WHERE id = ? LIMIT 1",
        values: [userIdNum]
      });
    } else {
      throw createError({ status: 400, message: "\u7F3A\u5C11\u5BC6\u7801\u6216\u767B\u5F55 token" });
    }
    console.log("\u6570\u636E\u5E93\u67E5\u8BE2\u7ED3\u679C:", user.length > 0 ? "\u627E\u5230\u7528\u6237" : "\u672A\u627E\u5230\u7528\u6237");
    if (user.length === 0) {
      console.log("\u7528\u6237\u767B\u5F55\u5931\u8D25: \u7528\u6237\u540D\u6216\u5BC6\u7801\u9519\u8BEF");
      const UserLoginLogsModel2 = await import('./userLoginLogs.mjs');
      await UserLoginLogsModel2.recordLogin({
        username: usernameToLog,
        game_code: "",
        login_time: (/* @__PURE__ */ new Date()).toISOString(),
        imei: "",
        ip_address: ipAddress,
        device: userAgent,
        channel_code: ""
      });
      throw createError({
        status: 401,
        message: "\u7528\u6237\u540D\u6216\u5BC6\u7801\u9519\u8BEF"
      });
    }
    const userData = user[0];
    userId = userData.id;
    let rechargeUrl = "";
    let mallUrl = "";
    let cdkUrl = "";
    if (userId) {
      const generatedUrl = await generateUserLoginUrl(userId, "/user/cashier");
      const generatedmallUrl = await generateUserLoginUrl(userId, "/user/mall");
      const generatedCdkUrl = await generateUserLoginUrl(userId, "/user/cdk-redeem");
      if (generatedUrl) {
        rechargeUrl = generatedUrl;
      }
      if (generatedmallUrl) {
        mallUrl = generatedmallUrl;
      }
      if (generatedCdkUrl) {
        cdkUrl = generatedCdkUrl;
      }
    }
    const userStatus = parseInt(String((_a = userData.status) != null ? _a : "0")) || 0;
    if (userStatus === 1) {
      console.log("\u7528\u6237\u767B\u5F55\u5931\u8D25: \u7528\u6237\u5DF2\u88AB\u5C01\u53F7");
      const UserLoginLogsModel2 = await import('./userLoginLogs.mjs');
      await UserLoginLogsModel2.recordLogin({
        username: userData.username || "",
        game_code: "",
        login_time: (/* @__PURE__ */ new Date()).toISOString(),
        imei: "",
        ip_address: ipAddress,
        device: userAgent,
        channel_code: userData.channel_code || ""
      });
      throw createError({
        status: 403,
        message: "\u60A8\u7684\u8D26\u53F7\u5DF2\u88AB\u5C01\u53F7\uFF0C\u65E0\u6CD5\u767B\u5F55"
      });
    }
    loginSuccess = true;
    console.log("\u7528\u6237\u767B\u5F55\u6210\u529F:", userData.username);
    const UserLoginLogsModel = await import('./userLoginLogs.mjs');
    await UserLoginLogsModel.recordLogin({
      username: userData.username || "",
      game_code: "",
      // 暂时为空，后续可根据需要填充
      login_time: (/* @__PURE__ */ new Date()).toISOString(),
      imei: "",
      // 暂时为空，需要从客户端传递
      ip_address: ipAddress,
      device: userAgent,
      channel_code: userData.channel_code || ""
    });
    const { password: pwd, ...userInfo } = userData;
    const rechargeTotal = await getUserZfbWxSuccessTotal(userId);
    const response = {
      code: 200,
      message: "\u767B\u5F55\u6210\u529F",
      data: {
        user: userInfo,
        rechargeUrl,
        mallUrl,
        cdkUrl,
        // 根据该用户支付宝/微信成功充值总额选择游戏服IP
        gameip: getGameIp(rechargeTotal),
        isUser: true
      }
    };
    console.log("\u7528\u6237\u767B\u5F55\u8FD4\u56DE\u6570\u636E:", response);
    return response;
  } catch (e) {
    console.error("\u7528\u6237\u767B\u5F55\u5F02\u5E38:", e);
    if (!loginSuccess && usernameToLog) {
      try {
        const headers = getHeaders(evt);
        const ipAddress = headers["x-forwarded-for"] || headers["x-real-ip"] || "unknown";
        const userAgent = headers["user-agent"] || "";
        const UserLoginLogsModel = await import('./userLoginLogs.mjs');
        await UserLoginLogsModel.recordLogin({
          username: usernameToLog,
          game_code: "",
          login_time: (/* @__PURE__ */ new Date()).toISOString(),
          imei: "",
          ip_address: ipAddress,
          device: userAgent,
          channel_code: ""
        });
      } catch (logError) {
        console.error("\u8BB0\u5F55\u767B\u5F55\u65E5\u5FD7\u5931\u8D25:", logError);
      }
    }
    throw createError({
      status: e.status || 500,
      message: e.message || "\u767B\u5F55\u5931\u8D25"
    });
  }
};
const sdkLogin = async (evt) => {
  var _a, _b;
  let loginSuccess = false;
  let usernameToLog = "";
  try {
    const body = await readBody(evt);
    console.log("SDK\u767B\u5F55", { username: (body == null ? void 0 : body.z) || "", gameId: (body == null ? void 0 : body.d) || "" });
    const {
      z: username,
      // 用户名
      b: password,
      // 密码
      c: loginType,
      // 登录类型
      d: gameId,
      // 游戏ID
      e: imei,
      // 设备IMEI
      f: agentId,
      // 代理ID
      x: appId,
      // APP ID
      h: deviceInfo,
      // 设备信息
      i: quickLogin,
      // 快速登录标识
      vs: versionCode,
      // 版本号
      sid: serverId,
      // 服务器ID
      o: dpi,
      // 屏幕信息
      p: deviceName,
      // 设备名
      q: netType,
      // 网络类型
      r: providersName,
      // 运营商
      s: deviceInfo2,
      // 设备信息2
      si: isEmulator
      // 模拟器检测
    } = body;
    usernameToLog = username || "";
    const headers = getHeaders(evt);
    const ipAddress = headers["x-forwarded-for"] || headers["x-real-ip"] || "unknown";
    const userAgent = headers["user-agent"] || "";
    if (!username || !password) {
      console.log("SDK\u767B\u5F55\u5931\u8D25: \u7528\u6237\u540D\u6216\u5BC6\u7801\u4E3A\u7A7A");
      return {
        z: -1,
        x: sdkMessages.login.missingCredentials(),
        b: "",
        c: "",
        d: "",
        sid: serverId || "",
        e: Date.now().toString()
      };
    }
    console.log("\u6B63\u5728\u67E5\u8BE2SDK\u7528\u6237:", username);
    const user = await sql({
      query: "SELECT * FROM Users WHERE username = ? AND password = ?",
      values: [username, password]
    });
    console.log("SDK\u6570\u636E\u5E93\u67E5\u8BE2\u7ED3\u679C:", user.length > 0 ? "\u627E\u5230\u7528\u6237" : "\u672A\u627E\u5230\u7528\u6237");
    if (user.length === 0) {
      console.log("SDK\u767B\u5F55\u5931\u8D25: \u7528\u6237\u540D\u6216\u5BC6\u7801\u9519\u8BEF");
      try {
        const UserLoginLogsModel = await import('./userLoginLogs.mjs');
        await UserLoginLogsModel.recordLogin({
          username: usernameToLog,
          game_code: gameId || "",
          login_time: (/* @__PURE__ */ new Date()).toISOString(),
          imei: imei || "",
          ip_address: ipAddress,
          device: deviceInfo || userAgent,
          channel_code: agentId || ""
        });
      } catch (logError) {
        console.error("\u8BB0\u5F55SDK\u767B\u5F55\u65E5\u5FD7\u5931\u8D25:", logError);
      }
      return {
        z: -1,
        x: sdkMessages.login.invalidCredentials(),
        b: "",
        c: "",
        d: "",
        sid: serverId || "",
        e: Date.now().toString()
      };
    }
    const userData = user[0];
    const userStatus = parseInt(String((_a = userData.status) != null ? _a : "0")) || 0;
    if (userStatus === 1) {
      console.log("SDK\u767B\u5F55\u5931\u8D25: \u7528\u6237\u5DF2\u88AB\u5C01\u53F7");
      try {
        const UserLoginLogsModel = await import('./userLoginLogs.mjs');
        await UserLoginLogsModel.recordLogin({
          username: userData.username || "",
          game_code: gameId || "",
          login_time: (/* @__PURE__ */ new Date()).toISOString(),
          imei: imei || "",
          ip_address: ipAddress,
          device: deviceInfo || userAgent,
          channel_code: userData.channel_code || agentId || ""
        });
      } catch (logError) {
        console.error("\u8BB0\u5F55SDK\u767B\u5F55\u65E5\u5FD7\u5931\u8D25:", logError);
      }
      return {
        z: -1,
        x: "\u60A8\u7684\u8D26\u53F7\u5DF2\u88AB\u5C01\u53F7\uFF0C\u65E0\u6CD5\u767B\u5F55",
        b: "",
        c: "",
        d: "",
        sid: serverId || "",
        e: Date.now().toString()
      };
    }
    loginSuccess = true;
    console.log("SDK\u7528\u6237\u767B\u5F55\u6210\u529F:", userData.username);
    const sign = crypto.createHash("md5").update(`${userData.username}${Date.now()}${((_b = config.thirdPartyConfig) == null ? void 0 : _b.accessKey) || "default_key"}`).digest("hex");
    const rechargeTotal = await getUserZfbWxSuccessTotal(userData.id);
    let rechargeUrl = "";
    let mallUrl = "";
    const userId = userData.id;
    if (userId) {
      const generatedUrl = await generateUserLoginUrl(userId, "/user/cashier");
      const generatedmallUrl = await generateUserLoginUrl(userId, "/user/mall");
      if (generatedUrl) {
        rechargeUrl = generatedUrl;
      }
      if (generatedmallUrl) {
        mallUrl = generatedmallUrl;
      }
    }
    const response = {
      z: 1,
      // 成功状态码
      x: sdkMessages.login.success(),
      // 消息
      b: userData.username || "",
      // 用户名
      c: userData.password || "",
      // 密码（如果需要返回）
      d: sign,
      // 签名
      sid: serverId || "",
      // 服务器ID
      e: Date.now().toString(),
      // 登录时间戳  
      gameip: getGameIp(rechargeTotal),
      // 按支付宝/微信成功充值总额选择游戏服IP
      rechargeUrl,
      mallUrl
    };
    console.log("SDK\u767B\u5F55\u8FD4\u56DE\u6570\u636E:", response);
    return response;
  } catch (e) {
    console.error("SDK\u767B\u5F55\u5F02\u5E38:", e);
    if (!loginSuccess && usernameToLog) {
      try {
        const headers = getHeaders(evt);
        const ipAddress = headers["x-forwarded-for"] || headers["x-real-ip"] || "unknown";
        const userAgent = headers["user-agent"] || "";
        const UserLoginLogsModel = await import('./userLoginLogs.mjs');
        await UserLoginLogsModel.recordLogin({
          username: usernameToLog,
          game_code: "",
          login_time: (/* @__PURE__ */ new Date()).toISOString(),
          imei: "",
          ip_address: ipAddress,
          device: userAgent,
          channel_code: ""
        });
      } catch (logError) {
        console.error("\u8BB0\u5F55SDK\u767B\u5F55\u65E5\u5FD7\u5931\u8D25:", logError);
      }
    }
    return {
      z: -1,
      x: e.message || sdkMessages.login.failed(),
      b: "",
      c: "",
      d: "",
      sid: "",
      e: Date.now().toString()
    };
  }
};
const getSubAccountList = async (evt) => {
  try {
    const body = await readBody(evt);
    console.log("\u83B7\u53D6\u5B50\u8D26\u53F7\u5217\u8868\u8BF7\u6C42:", body);
    const {
      z: username,
      // 用户名
      c: gameId,
      // 游戏ID
      e: agentId,
      // 代理ID
      f: appId
      // APP ID
    } = body;
    if (!username) {
      setResponseStatus(evt, 200);
      return {
        code: "0",
        data: [],
        msg: "\u7528\u6237\u540D\u4E0D\u80FD\u4E3A\u7A7A",
        djq: null,
        ttb: null,
        discount: null,
        flb: 0
      };
    }
    const user = await sql({
      query: "SELECT id FROM Users WHERE username = ?",
      values: [username]
    });
    if (user.length === 0) {
      setResponseStatus(evt, 200);
      return {
        code: "0",
        data: [],
        msg: "\u7528\u6237\u4E0D\u5B58\u5728",
        djq: null,
        ttb: null,
        discount: null,
        flb: 0
      };
    }
    const userId = user[0].id;
    const SubUsersModel = await Promise.resolve().then(function () { return subUsers; });
    const subUsers$1 = await SubUsersModel.findByParentUserId(userId);
    const currentTime = Math.floor(Date.now() / 1e3);
    const subAccountList = subUsers$1.map((subUser) => {
      var _a, _b;
      const signString = `${subUser.id}${currentTime}${((_a = config.thirdPartyConfig) == null ? void 0 : _a.accessKey) || "default_key"}`;
      const sign = crypto.createHash("md5").update(signString).digest("hex");
      return {
        username: ((_b = subUser.id) == null ? void 0 : _b.toString()) || "",
        // 返回 subusers 的 id
        nickname: subUser.username,
        // nickname 是子账号的完整名称
        login_time: currentTime,
        sign
      };
    });
    setResponseStatus(evt, 200);
    return {
      code: "1",
      // 成功返回字符串"1"
      data: subAccountList,
      msg: "\u67E5\u8BE2\u6210\u529F",
      djq: null,
      ttb: null,
      discount: null,
      flb: 0
    };
  } catch (e) {
    console.error("\u83B7\u53D6\u5B50\u8D26\u53F7\u5217\u8868\u5F02\u5E38:", e);
    setResponseStatus(evt, 200);
    return {
      code: "0",
      data: [],
      msg: e.message || "\u83B7\u53D6\u5B50\u8D26\u53F7\u5217\u8868\u5931\u8D25",
      djq: null,
      ttb: null,
      discount: null,
      flb: 0
    };
  }
};
const addSubAccount = async (evt) => {
  try {
    const body = await readBody(evt);
    console.log("\u6DFB\u52A0\u5B50\u8D26\u53F7\u8BF7\u6C42:", body);
    const {
      z: username,
      // 主用户名
      c: gameId,
      // 游戏ID
      e: agentId,
      // 代理ID
      f: appId,
      // APP ID
      x: subAccountName
      // 子账号名称
    } = body;
    if (!username) {
      setResponseStatus(evt, 200);
      return {
        code: "0",
        data: [],
        msg: "\u7528\u6237\u540D\u4E0D\u80FD\u4E3A\u7A7A",
        djq: null,
        ttb: null,
        discount: null,
        flb: 0
      };
    }
    const user = await sql({
      query: "SELECT id FROM Users WHERE username = ?",
      values: [username]
    });
    if (user.length === 0) {
      setResponseStatus(evt, 200);
      return {
        code: "0",
        data: [],
        msg: "\u4E3B\u7528\u6237\u4E0D\u5B58\u5728",
        djq: null,
        ttb: null,
        discount: null,
        flb: 0
      };
    }
    const userId = user[0].id;
    const SubUsersModel = await Promise.resolve().then(function () { return subUsers; });
    const subUserCount = await SubUsersModel.countByParentUserId(userId);
    if (subUserCount >= 10) {
      setResponseStatus(evt, 200);
      return {
        code: "0",
        data: [],
        msg: "\u6BCF\u4E2A\u4E3B\u8D26\u53F7\u6700\u591A\u53EA\u80FD\u521B\u5EFA10\u4E2A\u5B50\u8D26\u53F7",
        djq: null,
        ttb: null,
        discount: null,
        flb: 0
      };
    }
    const subAccountIndex = subUserCount + 1;
    const nickname = subAccountName || `\u5C0F\u53F7${subAccountIndex}`;
    const finalSubAccountName = `\u5C0F\u53F7${subAccountIndex}_${nickname}`;
    const existingSubUser = await SubUsersModel.findByUsername(finalSubAccountName);
    if (existingSubUser) {
      setResponseStatus(evt, 200);
      return {
        code: "0",
        data: [],
        msg: "\u5B50\u8D26\u53F7\u540D\u5DF2\u5B58\u5728",
        djq: null,
        ttb: null,
        discount: null,
        flb: 0
      };
    }
    const result = await SubUsersModel.insert({
      parent_user_id: userId,
      username: finalSubAccountName
    });
    const subUsers$1 = await SubUsersModel.findByParentUserId(userId);
    const currentTime = Math.floor(Date.now() / 1e3);
    const subAccountList = subUsers$1.map((subUser) => {
      var _a, _b;
      const signString = `${subUser.id}${currentTime}${((_a = config.thirdPartyConfig) == null ? void 0 : _a.accessKey) || "default_key"}`;
      const sign = crypto.createHash("md5").update(signString).digest("hex");
      return {
        username: ((_b = subUser.id) == null ? void 0 : _b.toString()) || "",
        // 返回 subusers 的 id
        nickname: subUser.username,
        // nickname 是子账号的完整名称
        login_time: currentTime,
        sign
      };
    });
    setResponseStatus(evt, 200);
    return {
      code: "1",
      // 成功返回字符串"1"
      data: subAccountList,
      // 返回完整的子账号列表
      msg: "\u6DFB\u52A0\u5B50\u8D26\u53F7\u6210\u529F",
      djq: null,
      ttb: null,
      discount: null,
      flb: 0
    };
  } catch (e) {
    console.error("\u6DFB\u52A0\u5B50\u8D26\u53F7\u5F02\u5E38:", e);
    if (e.message && e.message.includes("\u4E0D\u80FD\u4E3A\u5355\u4E2A\u4E3B\u8D26\u53F7\u521B\u5EFA\u8D85\u8FC710\u4E2A\u5B50\u8D26\u53F7")) {
      setResponseStatus(evt, 200);
      return {
        code: "0",
        data: [],
        msg: "\u6BCF\u4E2A\u4E3B\u8D26\u53F7\u6700\u591A\u53EA\u80FD\u521B\u5EFA10\u4E2A\u5B50\u8D26\u53F7",
        djq: null,
        ttb: null,
        discount: null,
        flb: 0
      };
    }
    setResponseStatus(evt, 200);
    return {
      code: "0",
      data: [],
      msg: e.message || "\u6DFB\u52A0\u5B50\u8D26\u53F7\u5931\u8D25",
      djq: null,
      ttb: null,
      discount: null,
      flb: 0
    };
  }
};
const editSubAccountNickname = async (evt) => {
  var _a;
  try {
    const body = await readBody(evt);
    console.log("\u7F16\u8F91\u5B50\u8D26\u53F7\u6635\u79F0\u8BF7\u6C42:", body);
    const {
      username,
      // 主用户名
      gid: gameId,
      // 游戏ID
      cpsId: agentId,
      // 代理ID
      appid: appId,
      // APP ID
      nickname,
      // 昵称
      subAccount
      // 子账号名称
    } = body;
    if (!username || !subAccount || !nickname) {
      setResponseStatus(evt, 200);
      return {
        code: "0",
        data: null,
        msg: "\u7528\u6237\u540D\u3001\u5B50\u8D26\u53F7\u540D\u548C\u6635\u79F0\u4E0D\u80FD\u4E3A\u7A7A",
        djq: null,
        ttb: null,
        discount: null,
        flb: 0
      };
    }
    const user = await sql({
      query: "SELECT id FROM Users WHERE username = ?",
      values: [username]
    });
    if (user.length === 0) {
      setResponseStatus(evt, 200);
      return {
        code: "0",
        data: null,
        msg: "\u4E3B\u7528\u6237\u4E0D\u5B58\u5728",
        djq: null,
        ttb: null,
        discount: null,
        flb: 0
      };
    }
    const userId = user[0].id;
    const subUser = await sql({
      query: "SELECT id FROM SubUsers WHERE username = ? AND parent_user_id = ?",
      values: [subAccount, userId]
    });
    if (subUser.length === 0) {
      setResponseStatus(evt, 200);
      return {
        code: "0",
        data: null,
        msg: "\u5B50\u8D26\u53F7\u4E0D\u5B58\u5728\u6216\u4E0D\u5C5E\u4E8E\u8BE5\u4E3B\u7528\u6237",
        djq: null,
        ttb: null,
        discount: null,
        flb: 0
      };
    }
    const subUserId = subUser[0].id;
    await sql({
      query: "UPDATE SubUsers SET username = ? WHERE id = ?",
      values: [nickname, subUserId]
    });
    const currentTime = Math.floor(Date.now() / 1e3);
    const signString = `${nickname}${currentTime}${((_a = config.thirdPartyConfig) == null ? void 0 : _a.accessKey) || "default_key"}`;
    const sign = crypto.createHash("md5").update(signString).digest("hex");
    setResponseStatus(evt, 200);
    return {
      code: "1",
      // 成功返回字符串"1"
      data: {
        username: nickname,
        nickname,
        login_time: currentTime,
        sign
      },
      msg: "\u7F16\u8F91\u5B50\u8D26\u53F7\u6635\u79F0\u6210\u529F",
      djq: null,
      ttb: null,
      discount: null,
      flb: 0
    };
  } catch (e) {
    console.error("\u7F16\u8F91\u5B50\u8D26\u53F7\u6635\u79F0\u5F02\u5E38:", e);
    setResponseStatus(evt, 200);
    return {
      code: "0",
      data: null,
      msg: e.message || "\u7F16\u8F91\u5B50\u8D26\u53F7\u6635\u79F0\u5931\u8D25",
      djq: null,
      ttb: null,
      discount: null,
      flb: 0
    };
  }
};
const reportRole = async (evt) => {
  var _a, _b;
  try {
    const body = await readBody(evt);
    console.log("\u89D2\u8272\u4E0A\u62A5\u8BF7\u6C42:", body);
    const {
      z: username,
      // 主用户名
      b: gameId,
      // 游戏ID
      i: appId,
      // APP ID
      xh: subUserId,
      // 子账号ID（subusers表的id）
      c: characterUuid,
      // 角色UUID（角色的唯一标识）
      d: roleName,
      // 角色名称
      e: roleLevel,
      // 角色等级
      f: serverId,
      // 服务器ID
      x: serverName,
      // 服务器名称
      h: extData
      // 扩展信息
    } = body;
    if (!username || !gameId || !subUserId || !characterUuid || !roleName || !serverName) {
      setResponseStatus(evt, 200);
      return {
        z: -1,
        x: "\u7F3A\u5C11\u5FC5\u8981\u53C2\u6570",
        b: "",
        c: "",
        d: "",
        sid: "",
        e: Date.now().toString()
      };
    }
    const user = await sql({
      query: "SELECT id FROM Users WHERE username = ?",
      values: [username]
    });
    if (user.length === 0) {
      setResponseStatus(evt, 200);
      return {
        z: -1,
        x: "\u4E3B\u7528\u6237\u4E0D\u5B58\u5728",
        b: "",
        c: "",
        d: "",
        sid: "",
        e: Date.now().toString()
      };
    }
    const userId = user[0].id;
    const SubUsersModel = await Promise.resolve().then(function () { return subUsers; });
    const subUser = await SubUsersModel.findById(parseInt(subUserId));
    if (!subUser || subUser.parent_user_id !== userId) {
      setResponseStatus(evt, 200);
      return {
        z: -1,
        x: "\u5B50\u8D26\u53F7\u4E0D\u5B58\u5728\u6216\u4E0D\u5C5E\u4E8E\u8BE5\u4E3B\u7528\u6237",
        b: "",
        c: "",
        d: "",
        sid: "",
        e: Date.now().toString()
      };
    }
    let gameIdNum = parseInt(gameId, 10);
    if (!Number.isFinite(gameIdNum)) {
      gameIdNum = 1;
    }
    const characterData = {
      user_id: userId,
      subuser_id: subUser.id,
      game_id: gameIdNum,
      uuid: characterUuid.toString(),
      character_name: roleName.toString(),
      character_level: parseInt(roleLevel) || 1,
      server_name: serverName.toString(),
      server_id: parseInt(serverId) || 1,
      ext: extData || null
    };
    const GameCharactersModel = await import('./gameCharacters.mjs');
    const result = await GameCharactersModel.upsertByUuid(characterData);
    console.log(`\u89D2\u8272\u4E0A\u62A5\u6210\u529F: ${result.isNew ? "\u65B0\u5EFA" : "\u66F4\u65B0"} \u89D2\u8272ID=${result.id}`);
    try {
      console.log("\u89D2\u8272\u4E0A\u62A5\u6210\u529F\uFF0C\u5F00\u59CB\u81EA\u52A8\u4E0A\u62A5\u767B\u5F55\u65E5\u5FD7");
      const headers = getHeaders(evt);
      const ipAddress = headers["x-forwarded-for"] || headers["x-real-ip"] || "unknown";
      const userInfoResult = await sql({
        query: "SELECT game_code, channel_code FROM Users WHERE id = ?",
        values: [userId]
      });
      if (userInfoResult.length > 0) {
        const { game_code: gameCode, channel_code: channelCode } = userInfoResult[0];
        const loginLogData = {
          username: subUser.username,
          // 使用子账号用户名
          sub_user_id: subUser.id,
          // 子账号ID
          sub_user_name: subUser.username,
          // 子账号名称（用于显示）
          game_code: gameCode,
          login_time: (/* @__PURE__ */ new Date()).toISOString(),
          imei: "",
          // 角色上报中没有设备信息
          ip_address: ipAddress,
          device: "Unknown",
          // 角色上报中没有设备类型信息
          channel_code: channelCode
          // 从users表获取channel_code
        };
        const UserLoginLogsModel = await import('./userLoginLogs.mjs');
        await UserLoginLogsModel.recordLogin(loginLogData);
        console.log(`\u81EA\u52A8\u767B\u5F55\u65E5\u5FD7\u4E0A\u62A5\u6210\u529F: \u7528\u6237=${loginLogData.username}, \u6E38\u620F=${gameCode}, \u6E20\u9053=${channelCode}`);
      }
    } catch (loginLogError) {
      console.error("\u81EA\u52A8\u767B\u5F55\u65E5\u5FD7\u4E0A\u62A5\u5931\u8D25:", loginLogError);
    }
    setResponseStatus(evt, 200);
    return {
      z: 0,
      // 成功
      x: "\u89D2\u8272\u4E0A\u62A5\u6210\u529F",
      b: result.isNew ? "\u65B0\u5EFA\u89D2\u8272" : "\u66F4\u65B0\u89D2\u8272",
      c: ((_a = result.id) == null ? void 0 : _a.toString()) || "",
      d: characterData.character_name,
      sid: ((_b = characterData.server_id) == null ? void 0 : _b.toString()) || "",
      e: Date.now().toString()
    };
  } catch (e) {
    console.error("\u89D2\u8272\u4E0A\u62A5\u5F02\u5E38:", e);
    setResponseStatus(evt, 200);
    return {
      z: -1,
      x: e.message || "\u89D2\u8272\u4E0A\u62A5\u5931\u8D25",
      b: "",
      c: "",
      d: "",
      sid: "",
      e: Date.now().toString()
    };
  }
};
const updateSubUserWuid = async (evt) => {
  try {
    const body = await readBody(evt);
    console.log("\u66F4\u65B0\u5B50\u7528\u6237wuid\u8BF7\u6C42:", body);
    const { thirdparty_uid, uid } = body;
    if (!thirdparty_uid || !uid) {
      return {
        success: false,
        message: "\u7F3A\u5C11\u5FC5\u8981\u53C2\u6570\uFF1Athirdparty_uid \u548C uid \u4E0D\u80FD\u4E3A\u7A7A"
      };
    }
    const SubUsersModel = await Promise.resolve().then(function () { return subUsers; });
    const result = await SubUsersModel.updateWuidByThirdpartyUid(thirdparty_uid, uid);
    return result;
  } catch (error) {
    console.error("\u66F4\u65B0\u5B50\u7528\u6237wuid\u5931\u8D25:", error);
    return {
      success: false,
      message: "\u6CE8\u518C\u5931\u8D25\uFF1A\u7CFB\u7EDF\u9519\u8BEF"
    };
  }
};
const register = async (evt) => {
  try {
    const body = await readBody(evt);
    const _headers = getHeaders(evt);
    const _aliIp = _headers["ali-cdn-real-ip"];
    const _xffIp = _headers["x-forwarded-for"];
    const _realIp = _headers["x-real-ip"];
    const clientIp = _aliIp || (_xffIp ? _xffIp.split(",")[0].trim() : "") || _realIp || "unknown";
    console.log(`[\u7528\u6237\u6CE8\u518C] IP: ${clientIp} | \u7528\u6237\u540D: ${body.username} | \u6E20\u9053: ${body.channel_code} | \u6E38\u620F: ${body.game_code}`);
    if (!body.username || !body.password) {
      return {
        status: "fail",
        message: "\u7528\u6237\u540D\u548C\u5BC6\u7801\u4E0D\u80FD\u4E3A\u7A7A"
      };
    }
    if (!body.channel_code) {
      return {
        status: "fail",
        message: "\u7F3A\u5C11\u6E20\u9053\u4EE3\u7801\u53C2\u6570"
      };
    }
    if (!body.game_code) {
      return {
        status: "fail",
        message: "\u7F3A\u5C11\u6E38\u620F\u4EE3\u7801\u53C2\u6570"
      };
    }
    const thirdpartyUid = body.thirdparty_uid || `user_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const existingUserByUsername = await sql({
      query: "SELECT id FROM Users WHERE username = ?",
      values: [body.username]
    });
    if (existingUserByUsername.length > 0) {
      return {
        status: "fail",
        message: "\u7528\u6237\u540D\u5DF2\u5B58\u5728"
      };
    }
    const existingUserByThirdpartyUid = await findByThirdpartyUid(thirdpartyUid);
    if (existingUserByThirdpartyUid) {
      return {
        status: "fail",
        message: "\u8BE5\u8D26\u53F7\u5DF2\u5B58\u5728"
      };
    }
    const adminResult = await sql({
      query: "SELECT id FROM Admins WHERE channel_code = ? AND is_active = 1",
      values: [body.channel_code]
    });
    if (adminResult.length === 0) {
      return {
        status: "fail",
        message: "\u65E0\u6548\u7684\u6E20\u9053\u4EE3\u7801"
      };
    }
    const gameResult = await sql({
      query: "SELECT id FROM Games WHERE game_code = ? AND is_active = 1",
      values: [body.game_code]
    });
    if (gameResult.length === 0) {
      return {
        status: "fail",
        message: "\u65E0\u6548\u7684\u6E38\u620F\u4EE3\u7801"
      };
    }
    const userData = {
      username: body.username.trim(),
      password: body.password,
      iphone: body.iphone || "",
      channel_code: body.channel_code,
      game_code: body.game_code,
      thirdparty_uid: thirdpartyUid,
      platform_coins: 0
    };
    const result = await insert$1(userData);
    console.log("\u7528\u6237\u6CE8\u518C\u6210\u529F:", { userId: result.insertId, thirdpartyUid });
    return {
      status: "success",
      message: "\u6CE8\u518C\u6210\u529F",
      data: {
        user_id: result.insertId,
        thirdparty_uid: thirdpartyUid
      }
    };
  } catch (error) {
    console.error("\u7528\u6237\u6CE8\u518C\u5931\u8D25:", error);
    if (error instanceof Error) {
      if (error.message.includes("Duplicate") && error.message.includes("username")) {
        return {
          status: "fail",
          message: "\u7528\u6237\u540D\u5DF2\u5B58\u5728"
        };
      } else if (error.message.includes("Duplicate") && error.message.includes("thirdparty_uid")) {
        return {
          status: "fail",
          message: "\u8BE5\u8D26\u53F7\u5DF2\u5B58\u5728"
        };
      }
    }
    return {
      status: "fail",
      message: "\u6CE8\u518C\u5931\u8D25\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5"
    };
  }
};
const banUser = async (evt) => {
  try {
    const body = await readBody(evt);
    const { user_id, status, admin_id } = body;
    console.log("\u5C01\u53F7/\u89E3\u5C01\u7528\u6237\u8BF7\u6C42:", body);
    if (!user_id || status === void 0) {
      return {
        status: "fail",
        message: "\u7F3A\u5C11\u7528\u6237ID\u6216\u72B6\u6001\u53C2\u6570"
      };
    }
    if (status !== 0 && status !== 1) {
      return {
        status: "fail",
        message: "\u72B6\u6001\u503C\u65E0\u6548\uFF0C\u53EA\u80FD\u662F0\uFF08\u89E3\u5C01\uFF09\u62161\uFF08\u5C01\u53F7\uFF09"
      };
    }
    if (!admin_id) {
      return {
        status: "fail",
        message: "\u9700\u8981\u7BA1\u7406\u5458\u6388\u6743"
      };
    }
    const admin = await getAdminWithPermissions(admin_id);
    if (!admin || admin.level !== 0) {
      return {
        status: "fail",
        message: "\u53EA\u6709\u8D85\u7EA7\u7BA1\u7406\u5458\u53EF\u4EE5\u5C01\u53F7\u7528\u6237"
      };
    }
    const result = await updateUserStatus(user_id, status);
    if (result.success) {
      console.log(`\u7528\u6237\u72B6\u6001\u66F4\u65B0\u6210\u529F: \u7528\u6237ID=${user_id}, \u72B6\u6001=${status}, \u64CD\u4F5C\u5458=${admin.name}`);
      return {
        status: "success",
        message: result.message,
        data: {
          user_id,
          status,
          operator: admin.name
        }
      };
    } else {
      return {
        status: "fail",
        message: result.message
      };
    }
  } catch (error) {
    console.error("\u5C01\u53F7/\u89E3\u5C01\u7528\u6237\u5931\u8D25:", error);
    return {
      status: "fail",
      message: "\u5C01\u53F7/\u89E3\u5C01\u7528\u6237\u5931\u8D25\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5"
    };
  }
};

const getActivePaymentSettingsForUser = async (evt) => {
  try {
    const paymentSettings = await GetOpenPaySetting();
    const clientEnabled = paymentSettings || [];
    return {
      code: 200,
      data: clientEnabled,
      message: "\u83B7\u53D6\u542F\u7528\u652F\u4ED8\u65B9\u5F0F\u6210\u529F"
    };
  } catch (error) {
    console.error("\u83B7\u53D6\u542F\u7528\u652F\u4ED8\u65B9\u5F0F\u5931\u8D25:", error);
    throw createError({
      status: 500,
      message: error.message || "\u83B7\u53D6\u542F\u7528\u652F\u4ED8\u65B9\u5F0F\u5931\u8D25"
    });
  }
};
const getPayWay = async (evt) => {
  try {
    let body = {};
    try {
      body = await readBody(evt);
    } catch {
    }
    if (!body || Object.keys(body).length === 0) {
      const q = getQuery(evt);
      body = {
        username: q.username,
        gid: q.gid ? Number(q.gid) : void 0,
        money: q.money ? Number(q.money) : void 0
      };
    }
    console.log("getPayWay \u8BF7\u6C42\u53C2\u6570:", body);
    const {
      username,
      // 用户名
      gid: gameId,
      // 游戏ID  
      money
      // 充值金额
    } = body;
    if (!money || money <= 0) {
      setResponseStatus(evt, 200);
      return {
        code: "0",
        data: [],
        msg: sdkMessages.payment.invalidAmount(),
        djq: null,
        ttb: null,
        discount: null,
        flb: 0,
        rechargeUrl: ""
      };
    }
    const paymentSettings = await GetOpenPaySetting();
    const validPaymentMethods = paymentSettings.filter((setting) => {
      if (setting.clientIsClose === 0) return false;
      return money >= setting.MinPrice && money <= setting.MaxPrice;
    });
    validPaymentMethods.sort((a, b) => (a.Sort || 0) - (b.Sort || 0));
    const paymentData = validPaymentMethods.map((setting) => {
      const baseUrl = "https://api.lzb88.com/static/paytype/";
      let icon = "";
      let amountStr = "";
      let moneyStr = "";
      let displayName = "";
      switch (setting.payment_method) {
        case "zfb":
          displayName = "\u652F\u4ED8\u5B9D";
          icon = `${baseUrl}zfb.png`;
          amountStr = `${money}\u5143`;
          moneyStr = `${money}\u5143`;
          break;
        case "wx":
          displayName = "\u5FAE\u4FE1\u652F\u4ED8";
          icon = `${baseUrl}wx.png`;
          amountStr = `${money}\u5143`;
          moneyStr = `${money}\u5143`;
          break;
        case "ptb":
          displayName = "\u5E73\u53F0\u5E01";
          icon = `${baseUrl}ptb.png`;
          amountStr = `${money}\u5E73\u53F0\u5E01`;
          moneyStr = `${money}\u5E73\u53F0\u5E01`;
          break;
        case "djq":
          displayName = "\u4EE3\u91D1\u5238";
          icon = `${baseUrl}djq.png`;
          amountStr = `${money}\u5143`;
          moneyStr = `${money}\u5143`;
          break;
        case "kf":
          displayName = "\u5BA2\u670D";
          icon = `${baseUrl}kf.png`;
          amountStr = `${money}\u5143`;
          moneyStr = `${money}\u5143`;
          break;
        case "flb":
          displayName = "\u798F\u5229\u5E01";
          icon = `${baseUrl}flb.png`;
          amountStr = `${money}\u5143`;
          moneyStr = `${money}\u5143`;
          break;
        default:
          displayName = setting.payment_method;
          icon = `${baseUrl}default.png`;
          amountStr = `${money}\u5143`;
          moneyStr = `${money}\u5143`;
      }
      return {
        name: displayName,
        // 根据paytype显示对应的中文名称
        paytype: setting.payment_method,
        // 使用支付方式作为类型
        yue: setting.payment_method === "ptb" ? "0" : "",
        icon: setting.icon_url || icon,
        // 优先使用数据库配置的图标URL
        discount: "",
        amount_str: amountStr,
        amount: money.toString(),
        money_str: moneyStr
      };
    });
    let userPlatformCoins = 0;
    let rechargeUrl = "";
    let userId = null;
    if (username) {
      try {
        console.log(`\u5F00\u59CB\u67E5\u8BE2\u7528\u6237\u5E73\u53F0\u5E01\u4F59\u989D\uFF0Cusername: ${username}`);
        const userResult = await sql({
          query: "SELECT id, username, platform_coins FROM Users WHERE username = ? LIMIT 1",
          values: [username]
        });
        console.log(`\u7528\u6237\u67E5\u8BE2\u7ED3\u679C:`, userResult);
        if (userResult && userResult.length > 0) {
          userId = userResult[0].id;
          userPlatformCoins = parseFloat(userResult[0].platform_coins) || 0;
          console.log(`\u627E\u5230\u7528\u6237: ID=${userResult[0].id}, username=${userResult[0].username}, platform_coins=${userResult[0].platform_coins}`);
        } else {
          console.log(`\u672A\u627E\u5230\u7528\u6237\uFF0Cusername: ${username}`);
          const allUsersResult = await sql({
            query: "SELECT id, username, platform_coins FROM Users LIMIT 5",
            values: []
          });
          console.log(`\u6570\u636E\u5E93\u4E2D\u524D5\u4E2A\u7528\u6237:`, allUsersResult);
        }
        console.log(`\u6700\u7EC8\u5E73\u53F0\u5E01\u4F59\u989D: ${userPlatformCoins}`);
      } catch (error) {
        console.log("\u83B7\u53D6\u7528\u6237\u5E73\u53F0\u5E01\u4F59\u989D\u5931\u8D25:", error);
      }
    } else {
      console.log("username\u53C2\u6570\u4E3A\u7A7A\uFF0C\u65E0\u6CD5\u67E5\u8BE2\u5E73\u53F0\u5E01\u4F59\u989D");
    }
    const platformCoinPayment = paymentData.find((p) => p.paytype === "ptb");
    if (platformCoinPayment) {
      platformCoinPayment.yue = userPlatformCoins.toString();
    }
    const SystemParamsModel = await import('./systemParams.mjs');
    const paymentMessage = await SystemParamsModel.getPaymentMessage();
    setResponseStatus(evt, 200);
    return {
      code: "1",
      data: paymentData,
      msg: paymentMessage,
      djq: null,
      ttb: null,
      discount: null,
      flb: 0
    };
  } catch (error) {
    console.error("getPayWay \u63A5\u53E3\u5F02\u5E38:", error);
    setResponseStatus(evt, 200);
    return {
      code: "0",
      data: [],
      msg: error.message || sdkMessages.payment.getPaymentMethodsFailed(),
      djq: null,
      ttb: null,
      discount: null,
      flb: 0
    };
  }
};

export { getPayWay as A, reportRole as B, getGameOrder as C, banUser as D, payment as E, checkChannelStatus as a, userLogin as b, checkUser as c, getorders as d, getpostorders as e, findById as f, getPlatformCoins as g, getActivePaymentSettingsForUser as h, insert as i, doPayment as j, queryPaymentOrder as k, getPaymentByTransId as l, getPaymentByUserID as m, updateSubUserWuid as n, getNewOne as o, paymentNewReps as p, quickreg as q, register as r, checkOrder as s, handleThirdPartyNotify as t, updatePlatformCoinsUnified as u, handleCashierPaymentNotify as v, sdkLogin as w, getSubAccountList as x, addSubAccount as y, editSubAccountNickname as z };
//# sourceMappingURL=paymentSettings.mjs.map
