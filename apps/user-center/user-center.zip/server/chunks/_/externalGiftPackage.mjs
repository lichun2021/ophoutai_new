import { s as sql, D as getSystemConfig } from '../nitro/nitro.mjs';
import { getByWorldId } from './gameServers.mjs';
import 'node:crypto';
import 'ioredis';
import 'fs';
import 'path';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:url';
import 'mysql2/promise';
import '@iconify/utils';
import 'consola';

const getAllActiveGiftPackages = async () => {
  const packages = await sql({
    query: `SELECT * FROM ExternalGiftPackages 
                WHERE is_active = 1 
                AND (start_time IS NULL OR start_time <= NOW()) 
                AND (end_time IS NULL OR end_time >= NOW()) 
                AND category NOT IN ('daily', 'cumulative')
                ORDER BY sort_order DESC, created_at DESC`
  });
  const currentWeekday = (/* @__PURE__ */ new Date()).getDay();
  const weekdayMap = currentWeekday === 0 ? 7 : currentWeekday;
  return packages.filter((pkg) => {
    if (pkg.category === "scheduled" && pkg.available_weekdays) {
      const availableDays = String(pkg.available_weekdays).split(",").map((d) => parseInt(d.trim()));
      return availableDays.includes(weekdayMap);
    }
    return true;
  });
};
const getGiftPackagesByCategory = async (category) => {
  const packages = await sql({
    query: `SELECT * FROM ExternalGiftPackages 
                WHERE is_active = 1 AND category = ?
                AND (start_time IS NULL OR start_time <= NOW()) 
                AND (end_time IS NULL OR end_time >= NOW()) 
                ORDER BY sort_order DESC, created_at DESC`,
    values: [category]
  });
  if (category === "scheduled") {
    const currentWeekday = (/* @__PURE__ */ new Date()).getDay();
    const weekdayMap = currentWeekday === 0 ? 7 : currentWeekday;
    return packages.filter((pkg) => {
      if (pkg.available_weekdays) {
        const availableDays = String(pkg.available_weekdays).split(",").map((d) => parseInt(d.trim()));
        return availableDays.includes(weekdayMap);
      }
      return true;
    });
  }
  return packages;
};
const getGiftPackageById = async (id) => {
  const result = await sql({
    query: "SELECT * FROM ExternalGiftPackages WHERE id = ?",
    values: [id]
  });
  return result.length > 0 ? result[0] : null;
};
const getGiftPackageByCode = async (package_code) => {
  const result = await sql({
    query: "SELECT * FROM ExternalGiftPackages WHERE package_code = ?",
    values: [package_code]
  });
  return result.length > 0 ? result[0] : null;
};
const checkUserCanPurchase = async (thirdparty_uid, package_id, quantity = 1) => {
  console.log(`[\u9650\u8D2D\u68C0\u67E5] \u5F00\u59CB\u68C0\u67E5 - \u89D2\u8272UUID: ${thirdparty_uid}, \u793C\u5305ID: ${package_id}, \u6570\u91CF: ${quantity}`);
  const giftPackage = await getGiftPackageById(package_id);
  if (!giftPackage) {
    console.log(`[\u9650\u8D2D\u68C0\u67E5] \u5931\u8D25 - \u793C\u5305\u4E0D\u5B58\u5728`);
    return { canPurchase: false, reason: "\u793C\u5305\u4E0D\u5B58\u5728" };
  }
  console.log(`[\u9650\u8D2D\u68C0\u67E5] \u793C\u5305\u4FE1\u606F - \u540D\u79F0: ${giftPackage.package_name}, \u5206\u7C7B: ${giftPackage.category}, \u9650\u8D2D: ${giftPackage.max_per_user}`);
  if (!giftPackage.is_active) {
    console.log(`[\u9650\u8D2D\u68C0\u67E5] \u5931\u8D25 - \u793C\u5305\u5DF2\u4E0B\u67B6`);
    return { canPurchase: false, reason: "\u793C\u5305\u5DF2\u4E0B\u67B6" };
  }
  const now = /* @__PURE__ */ new Date();
  if (giftPackage.start_time && new Date(giftPackage.start_time) > now) {
    console.log(`[\u9650\u8D2D\u68C0\u67E5] \u5931\u8D25 - \u793C\u5305\u5C1A\u672A\u5F00\u59CB\u9500\u552E`);
    return { canPurchase: false, reason: "\u793C\u5305\u5C1A\u672A\u5F00\u59CB\u9500\u552E" };
  }
  if (giftPackage.end_time && new Date(giftPackage.end_time) < now) {
    console.log(`[\u9650\u8D2D\u68C0\u67E5] \u5931\u8D25 - \u793C\u5305\u9500\u552E\u5DF2\u7ED3\u675F`);
    return { canPurchase: false, reason: "\u793C\u5305\u9500\u552E\u5DF2\u7ED3\u675F" };
  }
  if (giftPackage.category === "scheduled" && giftPackage.available_weekdays) {
    const currentWeekday = now.getDay();
    const weekdayMap = currentWeekday === 0 ? 7 : currentWeekday;
    const availableDays = String(giftPackage.available_weekdays).split(",").map((d) => parseInt(d.trim()));
    console.log(`[\u9650\u8D2D\u68C0\u67E5] \u9650\u671F\u793C\u5305 - \u5F53\u524D\u661F\u671F: ${weekdayMap}, \u53EF\u8D2D\u4E70\u661F\u671F: [${availableDays.join(", ")}]`);
    if (!availableDays.includes(weekdayMap)) {
      const weekdayNames = ["", "\u5468\u4E00", "\u5468\u4E8C", "\u5468\u4E09", "\u5468\u56DB", "\u5468\u4E94", "\u5468\u516D", "\u5468\u65E5"];
      const availableNames = availableDays.map((d) => weekdayNames[d]).join("\u3001");
      console.log(`[\u9650\u8D2D\u68C0\u67E5] \u5931\u8D25 - \u4ECA\u65E5\u4E0D\u53EF\u8D2D\u4E70\u6B64\u793C\u5305`);
      return { canPurchase: false, reason: `\u8BE5\u793C\u5305\u4EC5\u5728${availableNames}\u53EF\u8D2D\u4E70` };
    }
    console.log(`[\u9650\u8D2D\u68C0\u67E5] \u901A\u8FC7 - \u4ECA\u65E5\u53EF\u8D2D\u4E70`);
  }
  if (giftPackage.is_limited && giftPackage.total_quantity && giftPackage.total_quantity > 0) {
    const remainingQuantity = giftPackage.total_quantity - (giftPackage.sold_quantity || 0);
    console.log(`[\u9650\u8D2D\u68C0\u67E5] \u5E93\u5B58\u68C0\u67E5 - \u603B\u91CF: ${giftPackage.total_quantity}, \u5DF2\u552E: ${giftPackage.sold_quantity}, \u5269\u4F59: ${remainingQuantity}`);
    if (remainingQuantity < quantity) {
      console.log(`[\u9650\u8D2D\u68C0\u67E5] \u5931\u8D25 - \u793C\u5305\u5E93\u5B58\u4E0D\u8DB3`);
      return { canPurchase: false, reason: "\u793C\u5305\u5E93\u5B58\u4E0D\u8DB3" };
    }
  }
  if (giftPackage.max_per_user && giftPackage.max_per_user > 0) {
    if (giftPackage.category === "daily_recharge") {
      console.log(`[\u9650\u8D2D\u68C0\u67E5] \u6BCF\u65E5\u5145\u503C\u793C\u5305 - \u5F00\u59CB\u67E5\u8BE2\u4ECA\u65E5\u8D2D\u4E70\u6B21\u6570`);
      const todayCount = await getUserPackagePurchaseCount(thirdparty_uid, package_id, { todayOnly: true });
      console.log(`[\u9650\u8D2D\u68C0\u67E5] \u4ECA\u65E5\u5DF2\u8D2D\u4E70: ${todayCount}\u6B21, \u9650\u8D2D: ${giftPackage.max_per_user}\u6B21, \u672C\u6B21\u8D2D\u4E70: ${quantity}\u6B21`);
      if (todayCount + quantity > giftPackage.max_per_user) {
        console.log(`[\u9650\u8D2D\u68C0\u67E5] \u5931\u8D25 - \u8D85\u8FC7\u6BCF\u65E5\u9650\u8D2D (${todayCount} + ${quantity} > ${giftPackage.max_per_user})`);
        return { canPurchase: false, reason: `\u6BCF\u65E5\u6700\u591A\u8D2D\u4E70${giftPackage.max_per_user}\u6B21` };
      }
      console.log(`[\u9650\u8D2D\u68C0\u67E5] \u901A\u8FC7 - \u672A\u8D85\u8FC7\u6BCF\u65E5\u9650\u8D2D`);
    } else {
      console.log(`[\u9650\u8D2D\u68C0\u67E5] \u666E\u901A\u793C\u5305 - \u5F00\u59CB\u67E5\u8BE2\u603B\u8D2D\u4E70\u6B21\u6570`);
      const userPurchaseCount = await getUserPackagePurchaseCount(thirdparty_uid, package_id);
      console.log(`[\u9650\u8D2D\u68C0\u67E5] \u603B\u5171\u5DF2\u8D2D\u4E70: ${userPurchaseCount}\u6B21, \u9650\u8D2D: ${giftPackage.max_per_user}\u6B21, \u672C\u6B21\u8D2D\u4E70: ${quantity}\u6B21`);
      if (userPurchaseCount + quantity > giftPackage.max_per_user) {
        console.log(`[\u9650\u8D2D\u68C0\u67E5] \u5931\u8D25 - \u8D85\u8FC7\u603B\u9650\u8D2D (${userPurchaseCount} + ${quantity} > ${giftPackage.max_per_user})`);
        return { canPurchase: false, reason: `\u6BCF\u7528\u6237\u6700\u591A\u8D2D\u4E70${giftPackage.max_per_user}\u4E2A` };
      }
      console.log(`[\u9650\u8D2D\u68C0\u67E5] \u901A\u8FC7 - \u672A\u8D85\u8FC7\u603B\u9650\u8D2D`);
    }
  } else {
    console.log(`[\u9650\u8D2D\u68C0\u67E5] \u65E0\u9650\u8D2D\u9650\u5236`);
  }
  console.log(`[\u9650\u8D2D\u68C0\u67E5] \u2705 \u901A\u8FC7 - \u5141\u8BB8\u8D2D\u4E70`);
  return { canPurchase: true, reason: "" };
};
const getUserPackagePurchaseCount = async (thirdparty_uid, package_id, options) => {
  var _a;
  const where = [
    "thirdparty_uid = ?",
    "package_id = ?",
    "status IN ('paid', 'delivered')"
  ];
  const values = [thirdparty_uid, package_id];
  if (options == null ? void 0 : options.todayOnly) {
    where.push("DATE(created_at) = CURDATE()");
  }
  const query = `SELECT SUM(quantity) as total FROM GiftPackagePurchaseRecords 
                WHERE ${where.join(" AND ")}`;
  console.log(`[\u8D2D\u4E70\u6B21\u6570\u67E5\u8BE2] SQL: ${query}, \u53C2\u6570: [${values.join(", ")}]`);
  const result = await sql({
    query,
    values
  });
  const count = parseInt(((_a = result[0]) == null ? void 0 : _a.total) || 0);
  console.log(`[\u8D2D\u4E70\u6B21\u6570\u67E5\u8BE2] \u7ED3\u679C: ${count}\u6B21, \u539F\u59CB\u6570\u636E: ${JSON.stringify(result[0])}`);
  return count;
};
const createPurchaseRecord = async (record) => {
  console.log(`[\u521B\u5EFA\u8D2D\u4E70\u8BB0\u5F55] \u5F00\u59CB\u521B\u5EFA - \u7528\u6237ID: ${record.user_id}, \u89D2\u8272UUID: ${record.thirdparty_uid}, \u5546\u6237\u8BA2\u5355\u53F7: ${record.mch_order_id || "\u65E0"}, \u793C\u5305ID: ${record.package_id}, \u793C\u5305\u540D: ${record.package_name}, \u6570\u91CF: ${record.quantity || 1}, \u72B6\u6001: ${record.status || "pending"}`);
  const safeQuantity = Math.max(1, Math.abs(record.quantity || 1));
  if (record.quantity !== safeQuantity) {
    console.error(`[\u521B\u5EFA\u8D2D\u4E70\u8BB0\u5F55] \u26A0\uFE0F \u68C0\u6D4B\u5230\u5F02\u5E38\u6570\u91CF: ${record.quantity}\uFF0C\u5DF2\u5F3A\u5236\u4FEE\u6B63\u4E3A: ${safeQuantity}`);
  }
  const safeTotalAmount = Math.abs(record.total_amount);
  const safeUnitPrice = Math.abs(record.unit_price);
  if (record.total_amount < 0 || record.unit_price < 0) {
    console.error(`[\u521B\u5EFA\u8D2D\u4E70\u8BB0\u5F55] \u26A0\uFE0F \u68C0\u6D4B\u5230\u8D1F\u6570\u91D1\u989D - \u539F\u59CB: ${record.total_amount}/${record.unit_price}\uFF0C\u5DF2\u4FEE\u6B63\u4E3A: ${safeTotalAmount}/${safeUnitPrice}`);
  }
  const result = await sql({
    query: `INSERT INTO GiftPackagePurchaseRecords 
                (user_id, thirdparty_uid, mch_order_id, package_id, package_code, package_name, quantity, 
                 unit_price, total_amount, balance_before, balance_after, gift_items, 
                 status, game_delivery_status, remark) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    values: [
      record.user_id,
      record.thirdparty_uid,
      record.mch_order_id || null,
      record.package_id,
      record.package_code,
      record.package_name,
      safeQuantity,
      // 使用安全验证后的数量
      safeUnitPrice,
      // 使用安全验证后的单价
      safeTotalAmount,
      // 使用安全验证后的总金额
      record.balance_before,
      record.balance_after,
      JSON.stringify(record.gift_items),
      record.status || "pending",
      record.game_delivery_status || "waiting",
      record.remark || ""
    ]
  });
  console.log(`[\u521B\u5EFA\u8D2D\u4E70\u8BB0\u5F55] \u2705 \u521B\u5EFA\u6210\u529F - \u8BB0\u5F55ID: ${result.insertId}`);
  return result;
};
const getUserPurchaseRecords = async (thirdparty_uid, page = 1, pageSize = 10) => {
  const offset = (page - 1) * pageSize;
  const records = await sql({
    query: `SELECT * FROM GiftPackagePurchaseRecords 
                WHERE thirdparty_uid = ? 
                ORDER BY created_at DESC 
                LIMIT ?, ?`,
    values: [thirdparty_uid, offset, pageSize]
  });
  return records;
};
const getUserPurchaseRecordsCount = async (thirdparty_uid) => {
  var _a;
  const result = await sql({
    query: "SELECT COUNT(*) as total FROM GiftPackagePurchaseRecords WHERE thirdparty_uid = ?",
    values: [thirdparty_uid]
  });
  return ((_a = result[0]) == null ? void 0 : _a.total) || 0;
};
const getUserPurchaseRecordsCountByUserId = async (user_id) => {
  var _a;
  const result = await sql({
    query: "SELECT COUNT(*) as total FROM GiftPackagePurchaseRecords WHERE user_id = ?",
    values: [user_id]
  });
  return ((_a = result[0]) == null ? void 0 : _a.total) || 0;
};
const updatePurchaseRecordStatus = async (id, status, game_delivery_status, remark) => {
  let query = "UPDATE GiftPackagePurchaseRecords SET status = ?";
  const values = [status];
  if (game_delivery_status) {
    query += ", game_delivery_status = ?";
    values.push(game_delivery_status);
  }
  if (remark) {
    query += ", remark = ?";
    values.push(remark);
  }
  if (status === "delivered") {
    query += ", delivered_at = NOW()";
  }
  query += " WHERE id = ?";
  values.push(id.toString());
  const result = await sql({
    query,
    values
  });
  return result;
};
const getPlayerGiftPackageRecords = async (user_id, page = 1, pageSize = 10, startDate, endDate, packageType) => {
  const offset = (page - 1) * pageSize;
  let whereConditions = ["gpr.user_id = ?"];
  let values = [user_id];
  if (startDate) {
    whereConditions.push("DATE(gpr.created_at) >= ?");
    values.push(startDate);
  }
  if (endDate) {
    whereConditions.push("DATE(gpr.created_at) <= ?");
    values.push(endDate);
  }
  if (packageType && packageType !== "all") {
    whereConditions.push("egp.category = ?");
    values.push(packageType);
  }
  const whereClause = whereConditions.length > 0 ? "WHERE " + whereConditions.join(" AND ") : "";
  const query = `
        SELECT 
            gpr.*,
            egp.category,
            egp.description as package_description,
            egp.icon_url as package_icon,
            u.username as user_name,
            u.channel_code,
            u.game_code,
            -- \u4ECEremark\u4E2D\u63D0\u53D6\u670D\u52A1\u5668\u4FE1\u606F
            CASE 
                WHEN gpr.remark LIKE '%\u670D\u52A1\u5668%' THEN
                    SUBSTRING_INDEX(SUBSTRING_INDEX(gpr.remark, '\u670D\u52A1\u5668', -1), ' ', 1)
                ELSE ''
            END as server_info,
            -- \u793C\u5305\u7C7B\u578B\u76F4\u63A5\u4F7F\u7528category\u5B57\u6BB5
            egp.category as gift_type
        FROM GiftPackagePurchaseRecords gpr
        LEFT JOIN ExternalGiftPackages egp ON gpr.package_id = egp.id
        LEFT JOIN Users u ON gpr.user_id = u.id
        ${whereClause}
        ORDER BY gpr.created_at DESC 
        LIMIT ?, ?
    `;
  values.push(offset, pageSize);
  const records = await sql({
    query,
    values
  });
  return records;
};
const getPlayerGiftPackageRecordsCount = async (user_id, startDate, endDate, packageType) => {
  var _a;
  let whereConditions = ["gpr.user_id = ?"];
  let values = [user_id];
  if (startDate) {
    whereConditions.push("DATE(gpr.created_at) >= ?");
    values.push(startDate);
  }
  if (endDate) {
    whereConditions.push("DATE(gpr.created_at) <= ?");
    values.push(endDate);
  }
  if (packageType && packageType !== "all") {
    whereConditions.push("egp.category = ?");
    values.push(packageType);
  }
  const whereClause = whereConditions.length > 0 ? "WHERE " + whereConditions.join(" AND ") : "";
  const query = `
        SELECT COUNT(*) as total 
        FROM GiftPackagePurchaseRecords gpr
        LEFT JOIN ExternalGiftPackages egp ON gpr.package_id = egp.id
        ${whereClause}
    `;
  const result = await sql({
    query,
    values
  });
  return ((_a = result[0]) == null ? void 0 : _a.total) || 0;
};
const updatePackageSoldQuantity = async (package_id, quantity) => {
  const result = await sql({
    query: "UPDATE ExternalGiftPackages SET sold_quantity = sold_quantity + ? WHERE id = ?",
    values: [quantity, package_id]
  });
  return result;
};
const deliverPackageToGame = async (purchaseRecordId, server_id, role_id) => {
  console.log(`[deliverPackageToGame] \u5F00\u59CB\u53D1\u653E\u793C\u5305, \u8D2D\u4E70\u8BB0\u5F55ID: ${purchaseRecordId}, \u670D\u52A1\u5668ID: ${server_id}, \u89D2\u8272ID: ${role_id}`);
  try {
    console.log(`[deliverPackageToGame] \u67E5\u8BE2\u8D2D\u4E70\u8BB0\u5F55...`);
    const purchaseRecord = await sql({
      query: "SELECT * FROM GiftPackagePurchaseRecords WHERE id = ?",
      values: [purchaseRecordId]
    });
    if (purchaseRecord.length === 0) {
      console.error(`[deliverPackageToGame] \u8D2D\u4E70\u8BB0\u5F55\u4E0D\u5B58\u5728, ID: ${purchaseRecordId}`);
      return { success: false, message: "\u8D2D\u4E70\u8BB0\u5F55\u4E0D\u5B58\u5728" };
    }
    const record = purchaseRecord[0];
    console.log(`[deliverPackageToGame] \u83B7\u53D6\u5230\u8D2D\u4E70\u8BB0\u5F55:`, JSON.stringify(record, null, 2));
    console.log(`[deliverPackageToGame] \u67E5\u8BE2\u793C\u5305\u914D\u7F6E, \u793C\u5305ID: ${record.package_id}`);
    const giftPackage = await getGiftPackageById(record.package_id);
    if (!giftPackage || !giftPackage.gift_items) {
      console.error(`[deliverPackageToGame] \u793C\u5305\u914D\u7F6E\u4E0D\u5B58\u5728\u6216\u672A\u914D\u7F6E\u6E38\u620F\u670D\u52A1\u5668, \u793C\u5305ID: ${record.package_id}`);
      return { success: false, message: "\u793C\u5305\u914D\u7F6E\u4E0D\u5B58\u5728\u6216\u672A\u914D\u7F6E\u6E38\u620F\u670D\u52A1\u5668" };
    }
    console.log(`[deliverPackageToGame] \u83B7\u53D6\u5230\u793C\u5305\u914D\u7F6E:`, JSON.stringify(giftPackage, null, 2));
    const mailPayload = {
      serverId: server_id,
      userId: role_id,
      items: giftPackage.gift_items,
      title: giftPackage.package_name,
      content: `\u60A8\u8D2D\u4E70\u7684${giftPackage.package_name}\u5DF2\u5230\u8D26\uFF0C\u8BF7\u67E5\u6536\uFF01`
    };
    console.log("[deliverPackageToGame] \u53D1\u653E\u90AE\u4EF6\u6570\u636E:", JSON.stringify(mailPayload, null, 2));
    console.log(`[deliverPackageToGame] \u66F4\u65B0\u72B6\u6001\u4E3A\u6B63\u5728\u53D1\u9001...`);
    await updatePurchaseRecordStatus(purchaseRecordId, "paid", "sent", "\u6B63\u5728\u53D1\u653E\u5230\u6E38\u620F\u5185");
    console.log(`[deliverPackageToGame] \u89E3\u6790\u670D\u52A1\u5668\u5730\u5740...`);
    let targetGameServerUrl = "";
    try {
      const worldId = Number(server_id);
      if (!isNaN(worldId) && worldId > 0) {
        const serverCfg = await getByWorldId(worldId);
        if (serverCfg && serverCfg.webhost) {
          const base = serverCfg.webhost.replace(/\/$/, "");
          targetGameServerUrl = `${base}/send_mail`;
        }
      }
    } catch {
    }
    if (!targetGameServerUrl) {
      const systemConfig = await getSystemConfig();
      targetGameServerUrl = systemConfig.gift_url || "http://160.202.240.19:8888/send_mail";
    }
    console.log(`[deliverPackageToGame] \u76EE\u6807\u6E38\u620F\u670D\u52A1\u5668URL: ${targetGameServerUrl}`);
    console.log(`[deliverPackageToGame] \u53D1\u9001\u8BF7\u6C42\u5230\u6E38\u620F\u670D\u52A1\u5668...`);
    console.log(`[deliverPackageToGame] send_mail\u63A5\u53E3\u53C2\u6570:`, {
      url: targetGameServerUrl,
      serverId: server_id,
      userId: role_id,
      items: mailPayload.items,
      title: mailPayload.title
    });
    const response = await fetch(targetGameServerUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(mailPayload)
    });
    console.log(`[deliverPackageToGame] \u6E38\u620F\u670D\u52A1\u5668\u54CD\u5E94\u72B6\u6001: ${response.status}`);
    const respData = await response.json();
    console.log("[deliverPackageToGame] \u6E38\u620F\u670D\u52A1\u5668\u8FD4\u56DE:", JSON.stringify(respData, null, 2));
    console.log(`[deliverPackageToGame] \u66F4\u65B0\u53D1\u653E\u5C1D\u8BD5\u6B21\u6570\u548C\u54CD\u5E94\u6570\u636E...`);
    await sql({
      query: "UPDATE GiftPackagePurchaseRecords SET delivery_attempts = delivery_attempts + 1, game_delivery_data = ? WHERE id = ?",
      values: [JSON.stringify(respData), purchaseRecordId]
    });
    if (respData && respData.code == 0) {
      console.log(`[deliverPackageToGame] \u53D1\u653E\u6210\u529F! \u8D2D\u4E70\u8BB0\u5F55ID: ${purchaseRecordId}`);
      try {
        if (respData.result && respData.result.success_list && respData.result.success_list.length > 0) {
          const successItem = respData.result.success_list[0];
          if (successItem.u) {
            console.log(`[deliverPackageToGame] \u63D0\u53D6\u5230\u7528\u6237ID: ${successItem.u}, \u66F4\u65B0thirdparty_uid\u5B57\u6BB5`);
            await sql({
              query: "UPDATE GiftPackagePurchaseRecords SET status = ?, game_delivery_status = ?, remark = ?, thirdparty_uid = ?, delivered_at = NOW() WHERE id = ?",
              values: ["delivered", "success", "\u53D1\u653E\u6210\u529F", successItem.u, purchaseRecordId]
            });
            console.log(`[deliverPackageToGame] thirdparty_uid \u5DF2\u66F4\u65B0\u4E3A: ${successItem.u}`);
          } else {
            await updatePurchaseRecordStatus(purchaseRecordId, "delivered", "success", "\u53D1\u653E\u6210\u529F");
            console.log(`[deliverPackageToGame] \u672A\u627E\u5230\u7528\u6237ID\uFF0C\u4EC5\u66F4\u65B0\u72B6\u6001`);
          }
        } else {
          await updatePurchaseRecordStatus(purchaseRecordId, "delivered", "success", "\u53D1\u653E\u6210\u529F");
          console.log(`[deliverPackageToGame] success_list\u4E3A\u7A7A\uFF0C\u4EC5\u66F4\u65B0\u72B6\u6001`);
        }
      } catch (extractError) {
        console.error(`[deliverPackageToGame] \u63D0\u53D6\u7528\u6237ID\u5931\u8D25:`, extractError);
        await updatePurchaseRecordStatus(purchaseRecordId, "delivered", "success", "\u53D1\u653E\u6210\u529F");
      }
      return { success: true, message: "\u793C\u5305\u53D1\u653E\u6210\u529F" };
    } else {
      console.error(`[deliverPackageToGame] \u53D1\u653E\u5931\u8D25! \u8D2D\u4E70\u8BB0\u5F55ID: ${purchaseRecordId}, \u9519\u8BEF: ${(respData == null ? void 0 : respData.msg) || "\u672A\u77E5\u9519\u8BEF"}`);
      await updatePurchaseRecordStatus(purchaseRecordId, "paid", "failed", (respData == null ? void 0 : respData.msg) || "\u53D1\u653E\u5931\u8D25");
      return { success: false, message: (respData == null ? void 0 : respData.msg) || "\u793C\u5305\u53D1\u653E\u5931\u8D25" };
    }
  } catch (error) {
    console.error(`[deliverPackageToGame] \u53D1\u653E\u793C\u5305\u5F02\u5E38, \u8D2D\u4E70\u8BB0\u5F55ID: ${purchaseRecordId}:`, error);
    await updatePurchaseRecordStatus(purchaseRecordId, "paid", "failed", "\u53D1\u653E\u5F02\u5E38: " + error.message);
    return { success: false, message: "\u53D1\u653E\u5F02\u5E38: " + error.message };
  }
};
const deliverPackageToGameViaIDIP = async (purchaseRecordId, serverId, roleId) => {
  var _a, _b;
  console.log(`[deliverPackageToGameViaIDIP] \u5F00\u59CB\u53D1\u653E\u793C\u5305, \u8D2D\u4E70\u8BB0\u5F55ID: ${purchaseRecordId}, \u670D\u52A1\u5668ID: ${serverId}, \u89D2\u8272ID: ${roleId}`);
  try {
    const purchaseRecord = await sql({
      query: "SELECT * FROM GiftPackagePurchaseRecords WHERE id = ?",
      values: [purchaseRecordId]
    });
    if (purchaseRecord.length === 0) {
      console.error(`[deliverPackageToGameViaIDIP] \u8D2D\u4E70\u8BB0\u5F55\u4E0D\u5B58\u5728, ID: ${purchaseRecordId}`);
      return { success: false, message: "\u8D2D\u4E70\u8BB0\u5F55\u4E0D\u5B58\u5728" };
    }
    const record = purchaseRecord[0];
    console.log(`[deliverPackageToGameViaIDIP] \u83B7\u53D6\u5230\u8D2D\u4E70\u8BB0\u5F55:`, JSON.stringify(record, null, 2));
    const giftPackage = await getGiftPackageById(record.package_id);
    if (!giftPackage || !giftPackage.gift_items) {
      console.error(`[deliverPackageToGameViaIDIP] \u793C\u5305\u914D\u7F6E\u4E0D\u5B58\u5728, \u793C\u5305ID: ${record.package_id}`);
      return { success: false, message: "\u793C\u5305\u914D\u7F6E\u4E0D\u5B58\u5728" };
    }
    console.log(`[deliverPackageToGameViaIDIP] \u83B7\u53D6\u5230\u793C\u5305\u914D\u7F6E:`, JSON.stringify(giftPackage, null, 2));
    let giftItems;
    try {
      if (typeof giftPackage.gift_items === "string") {
        giftItems = JSON.parse(giftPackage.gift_items);
      } else {
        giftItems = giftPackage.gift_items;
      }
    } catch (error) {
      console.error(`[deliverPackageToGameViaIDIP] \u89E3\u6790\u793C\u5305\u7269\u54C1\u5931\u8D25:`, error);
      giftItems = [];
    }
    const toNumber = (v) => {
      const n = Number(v);
      return Number.isFinite(n) ? n : NaN;
    };
    const sendItemList = Array.isArray(giftItems) ? giftItems.map((it) => {
      var _a2, _b2, _c, _d, _e, _f, _g, _h, _i, _j;
      const id = toNumber((_e = (_d = (_c = (_b2 = (_a2 = it == null ? void 0 : it.ItemId) != null ? _a2 : it == null ? void 0 : it.itemId) != null ? _b2 : it == null ? void 0 : it.id) != null ? _c : it == null ? void 0 : it.ItemID) != null ? _d : it == null ? void 0 : it.item_id) != null ? _e : it == null ? void 0 : it.i);
      const num = toNumber((_j = (_i = (_h = (_g = (_f = it == null ? void 0 : it.ItemNum) != null ? _f : it == null ? void 0 : it.itemNum) != null ? _g : it == null ? void 0 : it.num) != null ? _h : it == null ? void 0 : it.quantity) != null ? _i : it == null ? void 0 : it.count) != null ? _j : it == null ? void 0 : it.a);
      return { ItemId: id, ItemNum: num };
    }).filter((x) => Number.isFinite(x.ItemId) && x.ItemId > 0 && Number.isFinite(x.ItemNum) && x.ItemNum > 0) : [];
    if (sendItemList.length === 0) {
      await sql({
        query: 'UPDATE GiftPackagePurchaseRecords SET game_delivery_status = ?, remark = CONCAT(remark, " | \u53D1\u653E\u5931\u8D25: \u7269\u8D44\u5217\u8868\u4E3A\u7A7A\u6216\u65E0\u6548") WHERE id = ?',
        values: ["failed", purchaseRecordId]
      });
      return { success: false, message: "\u7269\u8D44\u5217\u8868\u4E3A\u7A7A\u6216\u65E0\u6548" };
    }
    await sql({
      query: "UPDATE GiftPackagePurchaseRecords SET game_delivery_status = ?, delivery_attempts = delivery_attempts + 1 WHERE id = ?",
      values: ["sent", purchaseRecordId]
    });
    const actualRoleId = record.thirdparty_uid || roleId || "";
    const gcRows = await sql({
      query: "SELECT subuser_id, server_id FROM gamecharacters WHERE uuid = ? LIMIT 1",
      values: [actualRoleId]
    });
    console.log(`[deliverPackageToGameViaIDIP] \u67E5\u8BE2\u89D2\u8272\u4FE1\u606F\u7ED3\u679C:`, gcRows);
    if (!gcRows || gcRows.length === 0) {
      const errorMsg = `\u672A\u627E\u5230\u89D2\u8272\u4FE1\u606F: uuid=${actualRoleId}`;
      console.error(`[deliverPackageToGameViaIDIP] ${errorMsg}`);
      await sql({
        query: 'UPDATE GiftPackagePurchaseRecords SET game_delivery_status = ?, remark = CONCAT(remark, " | ", ?) WHERE id = ?',
        values: ["failed", errorMsg, purchaseRecordId]
      });
      return { success: false, message: errorMsg };
    }
    const characterInfo = gcRows[0];
    const subUserId = characterInfo.subuser_id || record.user_id;
    const actualServerId = characterInfo.server_id || serverId;
    console.log(`[deliverPackageToGameViaIDIP] \u89D2\u8272UUID=${actualRoleId}, \u5B50\u8D26\u53F7ID=${subUserId}, \u670D\u52A1\u5668ID=${actualServerId}`);
    const worldId = Number(actualServerId);
    const serverCfg = await getByWorldId(worldId);
    if (!serverCfg || !serverCfg.webhost) {
      const errorMsg = `\u672A\u627E\u5230\u670D\u52A1\u5668\u914D\u7F6E: world_id=${actualServerId}`;
      console.error(`[deliverPackageToGameViaIDIP] ${errorMsg}`);
      await sql({
        query: 'UPDATE GiftPackagePurchaseRecords SET game_delivery_status = ?, remark = CONCAT(remark, " | ", ?) WHERE id = ?',
        values: ["failed", errorMsg, purchaseRecordId]
      });
      return { success: false, message: errorMsg };
    }
    console.log(`[deliverPackageToGameViaIDIP] \u627E\u5230\u670D\u52A1\u5668\u914D\u7F6E: name=${serverCfg.name}, webhost=${serverCfg.webhost}`);
    const rawBase = String(serverCfg.webhost || "").replace(/\/+$/, "");
    const baseURL = rawBase.includes("/script") ? rawBase : `${rawBase}/script`;
    const idipUrl = `${baseURL}/idip/4283`;
    const playerInfo = { openid: String(subUserId), platform: 1 };
    let platId = 1;
    const pf = playerInfo.platform;
    if (typeof pf === "string") ; else {
      platId = Number(pf) === 2 ? 2 : 1;
    }
    const serial = `${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const idipPayload = {
      head: {
        Cmdid: 4283,
        Seqid: "1",
        TimeStamp: Math.floor(Date.now() / 1e3)
      },
      body: {
        PlatId: platId,
        OpenId: String(playerInfo.openid),
        Partition: String(actualServerId),
        // 使用从角色表获取的 server_id
        RoleId: actualRoleId,
        // 使用购买记录中的 thirdparty_uid（角色UUID）
        Serial: serial,
        MailTitle: encodeURIComponent(giftPackage.package_name || "\u7CFB\u7EDF\u53D1\u653E"),
        MailContent: encodeURIComponent(`\u60A8\u8D2D\u4E70\u7684${giftPackage.package_name}\u5DF2\u5230\u8D26\uFF0C\u8BF7\u67E5\u6536\uFF01`),
        SendItemList: sendItemList
      }
    };
    console.log(`[deliverPackageToGameViaIDIP] IDIP URL: ${idipUrl}`);
    console.log(`[deliverPackageToGameViaIDIP] IDIP\u8BF7\u6C42Body:`, JSON.stringify(idipPayload.body, null, 2));
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 1e4);
    let respText = "";
    try {
      const response = await fetch(idipUrl, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(idipPayload),
        signal: controller.signal
      });
      console.log(`[deliverPackageToGameViaIDIP] HTTP\u72B6\u6001: ${response.status} ${response.statusText}`);
      respText = await response.text();
      clearTimeout(timeout);
      console.log(`[deliverPackageToGameViaIDIP] \u54CD\u5E94\u5185\u5BB9: ${respText}`);
    } catch (err) {
      clearTimeout(timeout);
      const errorMsg = (err == null ? void 0 : err.message) || String(err);
      const isTimeout = (err == null ? void 0 : err.name) === "AbortError" || errorMsg.includes("timeout") || errorMsg.includes("\u8D85\u65F6");
      const logMessage = isTimeout ? `\u8BF7\u6C42\u8D85\u65F6: ${errorMsg}` : `\u8BF7\u6C42\u5931\u8D25: ${errorMsg}`;
      console.error(`[deliverPackageToGameViaIDIP] ${logMessage}`);
      if (isTimeout) {
        await sql({
          query: 'UPDATE GiftPackagePurchaseRecords SET game_delivery_status = ?, remark = CONCAT(remark, " | ", ?) WHERE id = ?',
          values: ["sent", logMessage, purchaseRecordId]
        });
        return { success: false, message: logMessage, timeout: true };
      }
      await sql({
        query: 'UPDATE GiftPackagePurchaseRecords SET game_delivery_status = ?, remark = CONCAT(remark, " | ", ?) WHERE id = ?',
        values: ["failed", logMessage, purchaseRecordId]
      });
      return { success: false, message: logMessage, timeout: false };
    }
    let respData;
    try {
      respData = JSON.parse(respText);
    } catch {
      respData = { raw: respText };
    }
    await sql({
      query: "UPDATE GiftPackagePurchaseRecords SET game_delivery_data = ? WHERE id = ?",
      values: [JSON.stringify(respData), purchaseRecordId]
    });
    const resultCode = (_a = respData == null ? void 0 : respData.body) == null ? void 0 : _a.Result;
    if (resultCode === 0) {
      await sql({
        query: "UPDATE GiftPackagePurchaseRecords SET status = ?, game_delivery_status = ?, delivered_at = NOW() WHERE id = ?",
        values: ["delivered", "success", purchaseRecordId]
      });
      console.log(`[deliverPackageToGameViaIDIP] \u793C\u5305\u53D1\u653E\u6210\u529F: \u8BB0\u5F55ID=${purchaseRecordId}`);
      return { success: true, message: "\u53D1\u653E\u6210\u529F" };
    } else {
      const errMsg = ((_b = respData == null ? void 0 : respData.body) == null ? void 0 : _b.RetMsg) || "IDIP\u53D1\u653E\u5931\u8D25";
      await sql({
        query: 'UPDATE GiftPackagePurchaseRecords SET game_delivery_status = ?, remark = CONCAT(remark, " | \u53D1\u653E\u5931\u8D25: ", ?) WHERE id = ?',
        values: ["failed", errMsg, purchaseRecordId]
      });
      console.error(`[deliverPackageToGameViaIDIP] \u793C\u5305\u53D1\u653E\u5931\u8D25: \u8BB0\u5F55ID=${purchaseRecordId}, \u9519\u8BEF: ${errMsg}`);
      return { success: false, message: errMsg };
    }
  } catch (error) {
    console.error(`[deliverPackageToGameViaIDIP] \u53D1\u653E\u793C\u5305\u5F02\u5E38:`, error);
    await sql({
      query: 'UPDATE GiftPackagePurchaseRecords SET game_delivery_status = ?, remark = CONCAT(remark, " | \u53D1\u653E\u5F02\u5E38: ", ?) WHERE id = ?',
      values: ["failed", error.message, purchaseRecordId]
    });
    return { success: false, message: error.message };
  }
};
const retryFailedDeliveries = async () => {
  try {
    const failedRecords = await sql({
      query: `SELECT id FROM GiftPackagePurchaseRecords 
                   WHERE status = 'paid' AND game_delivery_status = 'failed' 
                   AND delivery_attempts < 3`
    });
    let successCount = 0;
    let failCount = 0;
    for (const record of failedRecords) {
      const result = await deliverPackageToGame(record.id, "1", "user_role_id");
      if (result.success) {
        successCount++;
      } else {
        failCount++;
      }
    }
    return {
      success: true,
      message: `\u91CD\u8BD5\u5B8C\u6210: \u6210\u529F ${successCount} \u4E2A\uFF0C\u5931\u8D25 ${failCount} \u4E2A`,
      data: { successCount, failCount, total: failedRecords.length }
    };
  } catch (error) {
    console.error("\u6279\u91CF\u91CD\u8BD5\u53D1\u653E\u5931\u8D25:", error);
    return { success: false, message: "\u6279\u91CF\u91CD\u8BD5\u5931\u8D25" };
  }
};

export { checkUserCanPurchase, createPurchaseRecord, deliverPackageToGame, deliverPackageToGameViaIDIP, getAllActiveGiftPackages, getGiftPackageByCode, getGiftPackageById, getGiftPackagesByCategory, getPlayerGiftPackageRecords, getPlayerGiftPackageRecordsCount, getUserPackagePurchaseCount, getUserPurchaseRecords, getUserPurchaseRecordsCount, getUserPurchaseRecordsCountByUserId, retryFailedDeliveries, updatePackageSoldQuantity, updatePurchaseRecordStatus };
//# sourceMappingURL=externalGiftPackage.mjs.map
