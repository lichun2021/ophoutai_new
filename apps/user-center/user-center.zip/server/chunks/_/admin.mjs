import { s as sql } from '../nitro/nitro.mjs';

const getAdminWithPermissions = async (id) => {
  const result = await sql({
    query: "SELECT * FROM Admins WHERE id = ?",
    values: [id]
  });
  if (result.length === 1) {
    const admin = result[0];
    try {
      if (admin.allowed_channel_codes) {
        if (typeof admin.allowed_channel_codes === "string") {
          admin.allowed_channel_codes = JSON.parse(admin.allowed_channel_codes);
        } else if (!Array.isArray(admin.allowed_channel_codes)) {
          admin.allowed_channel_codes = [];
        }
      } else {
        admin.allowed_channel_codes = [];
      }
      if (admin.allowed_game_ids) {
        if (typeof admin.allowed_game_ids === "string") {
          admin.allowed_game_ids = JSON.parse(admin.allowed_game_ids);
        } else if (!Array.isArray(admin.allowed_game_ids)) {
          admin.allowed_game_ids = [];
        }
      } else {
        admin.allowed_game_ids = [];
      }
    } catch (error) {
      console.error(`JSON\u89E3\u6790\u5931\u8D25 - \u7BA1\u7406\u5458 ${admin.name}: ${error}`);
      admin.allowed_channel_codes = [];
      admin.allowed_game_ids = [];
    }
    return admin;
  }
  return null;
};

export { getAdminWithPermissions as g };
//# sourceMappingURL=admin.mjs.map
