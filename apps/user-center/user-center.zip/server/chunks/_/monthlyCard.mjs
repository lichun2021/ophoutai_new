import { s as sql } from '../nitro/nitro.mjs';
import 'node:crypto';
import 'ioredis';
import 'fs';
import 'path';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:url';
import 'mysql2/promise';
import '@iconify/utils';
import 'consola';

function getBeijingDate(offsetDays = 0) {
  const d = /* @__PURE__ */ new Date();
  d.setTime(d.getTime() + 8 * 60 * 60 * 1e3 + offsetDays * 86400 * 1e3);
  return d.toISOString().slice(0, 10);
}
const getActiveCardsByUserId = async (userId) => {
  const today = getBeijingDate();
  const result = await sql({
    query: `SELECT * FROM MonthlyCards
                WHERE user_id = ?
                  AND is_active = 1
                  AND (expire_date IS NULL OR expire_date >= ?)
                ORDER BY created_at ASC`,
    values: [userId, today]
  });
  return result;
};
const getTodayClaimedCardIds = async (userId, date) => {
  const result = await sql({
    query: `SELECT card_id FROM MonthlyCardClaims
                WHERE user_id = ? AND claim_date = ?`,
    values: [userId, date]
  });
  return result.map((r) => r.card_id);
};
const getMonthClaimedDates = async (userId, yearMonth) => {
  const result = await sql({
    query: `SELECT DISTINCT claim_date FROM MonthlyCardClaims
                WHERE user_id = ? AND claim_date LIKE ?
                ORDER BY claim_date`,
    values: [userId, `${yearMonth}%`]
  });
  return result.map((r) => String(r.claim_date).slice(0, 10));
};
const insertClaim = async (cardId, userId, claimDate, coinsAmount, transactionId) => {
  const result = await sql({
    query: `INSERT INTO MonthlyCardClaims (card_id, user_id, claim_date, coins_amount, transaction_id)
                VALUES (?, ?, ?, ?, ?)`,
    values: [cardId, userId, claimDate, coinsAmount, transactionId]
  });
  return result.insertId;
};
const activateCard = async (params) => {
  const result = await sql({
    query: `INSERT INTO MonthlyCards
                    (user_id, card_type, daily_coins, start_date, expire_date, is_active, purchase_amount, transaction_id)
                VALUES (?, ?, ?, ?, ?, 1, ?, ?)`,
    values: [
      params.userId,
      params.cardType,
      params.dailyCoins,
      params.startDate,
      params.expireDate,
      params.purchaseAmount,
      params.transactionId
    ]
  });
  return result.insertId;
};
const getCardStatus = async (userId) => {
  const today = getBeijingDate();
  const yearMonth = today.slice(0, 7);
  const cards = await getActiveCardsByUserId(userId);
  const claimedCardIds = await getTodayClaimedCardIds(userId, today);
  const claimedDates = await getMonthClaimedDates(userId, yearMonth);
  const totalDailyCoins = cards.reduce((sum, c) => sum + c.daily_coins, 0);
  const todayClaimed = cards.length > 0 && cards.every((c) => claimedCardIds.includes(c.id));
  const unclaimedCards = cards.filter((c) => !claimedCardIds.includes(c.id));
  return {
    cards,
    totalDailyCoins,
    todayClaimed,
    unclaimedCards,
    claimedDates,
    today
  };
};
const getCardByTransactionId = async (transactionId) => {
  const result = await sql({
    query: "SELECT * FROM MonthlyCards WHERE transaction_id = ? LIMIT 1",
    values: [transactionId]
  });
  return result.length > 0 ? result[0] : null;
};

export { activateCard, getActiveCardsByUserId, getBeijingDate, getCardByTransactionId, getCardStatus, getMonthClaimedDates, getTodayClaimedCardIds, insertClaim };
//# sourceMappingURL=monthlyCard.mjs.map
