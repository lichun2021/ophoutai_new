import { C as getRedisCluster } from '../nitro/nitro.mjs';
import 'node:crypto';
import 'ioredis';
import 'fs';
import 'path';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:url';
import 'mysql2/promise';
import '@iconify/utils';
import 'consola';

const getTodayStr = () => {
  const now = /* @__PURE__ */ new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`;
};
const incrementRedisUsedQuota = async (ruleId, amount) => {
  const redis = getRedisCluster();
  const key = `routing:quota:${ruleId}:${getTodayStr()}`;
  await redis.incrbyfloat(key, amount);
  await redis.expire(key, 172800);
  console.log(`[Redis Quota] \u89C4\u5219 ID:${ruleId} \u6210\u529F\u589E\u52A0\u989D\u5EA6: +${amount}`);
};
const getOrderRuleMapping = async (transactionId) => {
  const redis = getRedisCluster();
  const key = `routing:order_rule:${transactionId}`;
  const val = await redis.get(key);
  return val ? parseInt(val) : null;
};

export { getOrderRuleMapping, incrementRedisUsedQuota };
//# sourceMappingURL=paymentRouting.mjs.map
