import { C as getRedisCluster, s as sql } from '../nitro/nitro.mjs';
import 'node:crypto';
import 'ioredis';
import 'fs';
import 'path';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:url';
import 'mysql2/promise';
import '@iconify/utils';
import 'consola';

async function listAll() {
  const rows = await sql({
    query: "SELECT id, server_id, name, webhost, dbip, bname, dbuser, dbpass, is_active, allow_cdk_redeem, count_online, created_at, updated_at FROM GameServers ORDER BY id ASC"
  });
  return rows;
}
async function listActive() {
  const rows = await sql({
    query: "SELECT id, server_id, name, webhost, dbip, bname, dbuser, dbpass, is_active, allow_cdk_redeem, count_online, created_at, updated_at FROM GameServers WHERE is_active = 1 ORDER BY id ASC"
  });
  return rows;
}
async function listCdkRedeemable() {
  const rows = await sql({
    query: "SELECT id, server_id, name, webhost, dbip, bname, dbuser, dbpass, is_active, allow_cdk_redeem, created_at, updated_at FROM GameServers WHERE is_active = 1 AND allow_cdk_redeem = 1 ORDER BY id ASC"
  });
  return rows;
}
async function getById(id) {
  const rows = await sql({
    query: "SELECT id, server_id, name, webhost, dbip, bname, dbuser, dbpass, is_active, allow_cdk_redeem, count_online, created_at, updated_at FROM GameServers WHERE id = ? LIMIT 1",
    values: [id]
  });
  return rows.length ? rows[0] : null;
}
async function getByBName(bname) {
  const rows = await sql({
    query: "SELECT id, server_id, name, webhost, dbip, bname, dbuser, dbpass, is_active, allow_cdk_redeem, count_online, created_at, updated_at FROM GameServers WHERE bname = ? LIMIT 1",
    values: [bname]
  });
  return rows.length ? rows[0] : null;
}
async function getByName(name) {
  const rows = await sql({
    query: "SELECT id, server_id, name, webhost, dbip, bname, dbuser, dbpass, is_active, allow_cdk_redeem, count_online, created_at, updated_at FROM GameServers WHERE name = ? LIMIT 1",
    values: [name]
  });
  return rows.length ? rows[0] : null;
}
async function getByServerId(serverId) {
  const rows = await sql({
    query: "SELECT id, server_id, name, webhost, dbip, bname, dbuser, dbpass, is_active, allow_cdk_redeem, count_online, created_at, updated_at FROM GameServers WHERE server_id = ? LIMIT 1",
    values: [serverId]
  });
  return rows.length ? rows[0] : null;
}
async function getByIdentifier(identifier) {
  const raw = String(identifier || "").trim();
  if (!raw) return null;
  const asNumber = Number(raw);
  if (Number.isFinite(asNumber)) {
    const byServerId = await getByServerId(asNumber);
    if (byServerId) return byServerId;
  }
  return await getByBName(raw);
}
function extractWorldIdFromBName(bname) {
  const match = bname.match(/game_(\d+)/);
  return match ? Number(match[1]) : null;
}
async function getByWorldId(worldId) {
  const cacheKey = `gameserver:world_${worldId}`;
  try {
    const redis = getRedisCluster();
    const cachedData = await redis.get(cacheKey);
    if (cachedData) {
      console.log(`[getByWorldId] Redis \u7F13\u5B58\u547D\u4E2D: world_id=${worldId}`);
      return JSON.parse(cachedData);
    }
    console.log(`[getByWorldId] Redis \u7F13\u5B58\u672A\u547D\u4E2D\uFF0C\u67E5\u8BE2\u6570\u636E\u5E93: world_id=${worldId}`);
  } catch (redisError) {
    console.warn(`[getByWorldId] Redis \u67E5\u8BE2\u5931\u8D25\uFF0C\u964D\u7EA7\u5230\u6570\u636E\u5E93\u67E5\u8BE2:`, redisError);
  }
  const rows = await sql({
    query: "SELECT id, server_id, name, webhost, dbip, bname, dbuser, dbpass, is_active, allow_cdk_redeem, count_online, created_at, updated_at FROM GameServers WHERE server_id = ? OR bname = ? OR name = ? LIMIT 1",
    values: [worldId, `game_${worldId}`, `game_${worldId}`]
  });
  if (rows.length > 0) {
    const serverConfig = rows[0];
    try {
      const redis = getRedisCluster();
      await redis.set(cacheKey, JSON.stringify(serverConfig), "EX", 3600);
      console.log(`[getByWorldId] \u5DF2\u7F13\u5B58\u5230 Redis: world_id=${worldId}, key=${cacheKey}`);
    } catch (redisError) {
      console.warn(`[getByWorldId] Redis \u7F13\u5B58\u5199\u5165\u5931\u8D25:`, redisError);
    }
    return serverConfig;
  }
  console.log(`[getByWorldId] \u6570\u636E\u5E93\u4E2D\u672A\u627E\u5230\u670D\u52A1\u5668\u914D\u7F6E: world_id=${worldId}`);
  return null;
}
async function createServer(cfg) {
  var _a, _b, _c, _d;
  return await sql({
    query: "INSERT INTO GameServers (server_id, name, webhost, dbip, bname, dbuser, dbpass, is_active, allow_cdk_redeem, count_online) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
    values: [(_a = cfg.server_id) != null ? _a : null, cfg.name, cfg.webhost, cfg.dbip, cfg.bname, cfg.dbuser, cfg.dbpass, (_b = cfg.is_active) != null ? _b : 1, (_c = cfg.allow_cdk_redeem) != null ? _c : 1, (_d = cfg.count_online) != null ? _d : 1]
  });
}
async function updateServer(id, cfg) {
  const fields = [];
  const values = [];
  if (cfg.server_id !== void 0) {
    fields.push("server_id = ?");
    values.push(cfg.server_id);
  }
  if (cfg.name !== void 0) {
    fields.push("name = ?");
    values.push(cfg.name);
  }
  if (cfg.webhost !== void 0) {
    fields.push("webhost = ?");
    values.push(cfg.webhost);
  }
  if (cfg.dbip !== void 0) {
    fields.push("dbip = ?");
    values.push(cfg.dbip);
  }
  if (cfg.bname !== void 0) {
    fields.push("bname = ?");
    values.push(cfg.bname);
  }
  if (cfg.dbuser !== void 0) {
    fields.push("dbuser = ?");
    values.push(cfg.dbuser);
  }
  if (cfg.dbpass !== void 0) {
    fields.push("dbpass = ?");
    values.push(cfg.dbpass);
  }
  if (cfg.is_active !== void 0) {
    fields.push("is_active = ?");
    values.push(cfg.is_active);
  }
  if (cfg.allow_cdk_redeem !== void 0) {
    fields.push("allow_cdk_redeem = ?");
    values.push(cfg.allow_cdk_redeem);
  }
  if (cfg.count_online !== void 0) {
    fields.push("count_online = ?");
    values.push(cfg.count_online);
  }
  if (!fields.length) return;
  values.push(id);
  await sql({ query: `UPDATE GameServers SET ${fields.join(", ")}, updated_at = NOW() WHERE id = ?`, values });
  await clearServerCache(id);
}
async function removeServer(id) {
  await sql({ query: "DELETE FROM GameServers WHERE id = ?", values: [id] });
  await clearServerCache(id);
}
async function clearServerCache(serverId) {
  var _a;
  try {
    const server = await getById(serverId);
    if (server) {
      const worldId = (_a = server.server_id) != null ? _a : server.bname ? extractWorldIdFromBName(server.bname) : null;
      if (worldId) {
        const redis = getRedisCluster();
        const cacheKey = `gameserver:world_${worldId}`;
        await redis.del(cacheKey);
        console.log(`[clearServerCache] \u5DF2\u6E05\u9664\u7F13\u5B58: ${cacheKey}`);
      }
    }
  } catch (error) {
    console.warn("[clearServerCache] \u6E05\u9664\u7F13\u5B58\u5931\u8D25:", error);
  }
}
async function clearCacheByWorldId(worldId) {
  try {
    const redis = getRedisCluster();
    const cacheKey = `gameserver:world_${worldId}`;
    await redis.del(cacheKey);
    console.log(`[clearCacheByWorldId] \u5DF2\u6E05\u9664\u7F13\u5B58: ${cacheKey}`);
  } catch (error) {
    console.warn("[clearCacheByWorldId] \u6E05\u9664\u7F13\u5B58\u5931\u8D25:", error);
  }
}

export { clearCacheByWorldId, createServer, extractWorldIdFromBName, getByBName, getById, getByIdentifier, getByName, getByServerId, getByWorldId, listActive, listAll, listCdkRedeemable, removeServer, updateServer };
//# sourceMappingURL=gameServers.mjs.map
